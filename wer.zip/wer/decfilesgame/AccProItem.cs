public abstract class AccProItem
{
	public int VehicleId;

	public int BattleCount;

	public int WinCount;

	public float WinRate;

	public virtual AccProItem Calculate()
	{
		WinRate = ((BattleCount != 0) ? ((float)WinCount / (float)BattleCount) : 0f);
		return this;
	}

	public static int SortByBattleCount(AccProItem a, AccProItem b)
	{
		if (a.BattleCount > b.BattleCount)
		{
			return -1;
		}
		if (a.VehicleId == 0)
		{
			return -1;
		}
		if (a.BattleCount == b.BattleCount && GameManager.Player.TryGetHallTankByGuid(a.VehicleId, out var tank) && GameManager.Player.TryGetHallTankByGuid(b.VehicleId, out var tank2))
		{
			if (tank.TankData.TableVehicle.level > tank2.TankData.TableVehicle.level)
			{
				return -1;
			}
			if (tank.TankData.TableVehicle.level == tank2.TankData.TableVehicle.level)
			{
				if (a.VehicleId == 0)
				{
					return -1;
				}
				if (b.VehicleId == 0)
				{
					return 1;
				}
				if (a.VehicleId > b.VehicleId)
				{
					return -1;
				}
				if (a.VehicleId < b.VehicleId)
				{
					return 1;
				}
			}
			return 1;
		}
		return 1;
	}
}
