using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security;
using System.Security.Cryptography;
using System.Security.Permissions;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using ICSharpCode.SharpZipLib.Checksums;
using ICSharpCode.SharpZipLib.Core;
using ICSharpCode.SharpZipLib.Encryption;
using ICSharpCode.SharpZipLib.GZip;
using ICSharpCode.SharpZipLib.Zip.Compression;
using ICSharpCode.SharpZipLib.Zip.Compression.Streams;
using UnityEngine;
using WebSocketSharp;

[assembly: Debuggable (DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: RuntimeCompatibility (WrapNonExceptionThrows = true)]
[assembly: SecurityPermission (SecurityAction.RequestMinimum, SkipVerification = true)]
[assembly: AssemblyVersion ("0.0.0.0")]
[module: UnverifiableCode]
namespace ICSharpCode.SharpZipLib.BZip2
{
	public static class BZip2
	{
		public static void Decompress (Stream inStream, Stream outStream, bool isStreamOwner)
		{
			if (inStream == null || outStream == null) {
				throw new Exception ("Null Stream");
			}
			try {
				using BZip2InputStream bZip2InputStream = new BZip2InputStream (inStream);
				bZip2InputStream.IsStreamOwner = isStreamOwner;
				StreamUtils.Copy (bZip2InputStream, outStream, new byte[4096]);
			} finally {
				if (isStreamOwner) {
					outStream.Close ();
				}
			}
		}

		public static void Compress (Stream inStream, Stream outStream, bool isStreamOwner, int level)
		{
			if (inStream == null || outStream == null) {
				throw new Exception ("Null Stream");
			}
			try {
				using BZip2OutputStream bZip2OutputStream = new BZip2OutputStream (outStream, level);
				bZip2OutputStream.IsStreamOwner = isStreamOwner;
				StreamUtils.Copy (inStream, bZip2OutputStream, new byte[4096]);
			} finally {
				if (isStreamOwner) {
					inStream.Close ();
				}
			}
		}
	}
	internal sealed class BZip2Constants
	{
		public static readonly int[] RandomNumbers = new int[512] {
			619, 720, 127, 481, 931, 816, 813, 233, 566, 247,
			985, 724, 205, 454, 863, 491, 741, 242, 949, 214,
			733, 859, 335, 708, 621, 574, 73, 654, 730, 472,
			419, 436, 278, 496, 867, 210, 399, 680, 480, 51,
			878, 465, 811, 169, 869, 675, 611, 697, 867, 561,
			862, 687, 507, 283, 482, 129, 807, 591, 733, 623,
			150, 238, 59, 379, 684, 877, 625, 169, 643, 105,
			170, 607, 520, 932, 727, 476, 693, 425, 174, 647,
			73, 122, 335, 530, 442, 853, 695, 249, 445, 515,
			909, 545, 703, 919, 874, 474, 882, 500, 594, 612,
			641, 801, 220, 162, 819, 984, 589, 513, 495, 799,
			161, 604, 958, 533, 221, 400, 386, 867, 600, 782,
			382, 596, 414, 171, 516, 375, 682, 485, 911, 276,
			98, 553, 163, 354, 666, 933, 424, 341, 533, 870,
			227, 730, 475, 186, 263, 647, 537, 686, 600, 224,
			469, 68, 770, 919, 190, 373, 294, 822, 808, 206,
			184, 943, 795, 384, 383, 461, 404, 758, 839, 887,
			715, 67, 618, 276, 204, 918, 873, 777, 604, 560,
			951, 160, 578, 722, 79, 804, 96, 409, 713, 940,
			652, 934, 970, 447, 318, 353, 859, 672, 112, 785,
			645, 863, 803, 350, 139, 93, 354, 99, 820, 908,
			609, 772, 154, 274, 580, 184, 79, 626, 630, 742,
			653, 282, 762, 623, 680, 81, 927, 626, 789, 125,
			411, 521, 938, 300, 821, 78, 343, 175, 128, 250,
			170, 774, 972, 275, 999, 639, 495, 78, 352, 126,
			857, 956, 358, 619, 580, 124, 737, 594, 701, 612,
			669, 112, 134, 694, 363, 992, 809, 743, 168, 974,
			944, 375, 748, 52, 600, 747, 642, 182, 862, 81,
			344, 805, 988, 739, 511, 655, 814, 334, 249, 515,
			897, 955, 664, 981, 649, 113, 974, 459, 893, 228,
			433, 837, 553, 268, 926, 240, 102, 654, 459, 51,
			686, 754, 806, 760, 493, 403, 415, 394, 687, 700,
			946, 670, 656, 610, 738, 392, 760, 799, 887, 653,
			978, 321, 576, 617, 626, 502, 894, 679, 243, 440,
			680, 879, 194, 572, 640, 724, 926, 56, 204, 700,
			707, 151, 457, 449, 797, 195, 791, 558, 945, 679,
			297, 59, 87, 824, 713, 663, 412, 693, 342, 606,
			134, 108, 571, 364, 631, 212, 174, 643, 304, 329,
			343, 97, 430, 751, 497, 314, 983, 374, 822, 928,
			140, 206, 73, 263, 980, 736, 876, 478, 430, 305,
			170, 514, 364, 692, 829, 82, 855, 953, 676, 246,
			369, 970, 294, 750, 807, 827, 150, 790, 288, 923,
			804, 378, 215, 828, 592, 281, 565, 555, 710, 82,
			896, 831, 547, 261, 524, 462, 293, 465, 502, 56,
			661, 821, 976, 991, 658, 869, 905, 758, 745, 193,
			768, 550, 608, 933, 378, 286, 215, 979, 792, 961,
			61, 688, 793, 644, 986, 403, 106, 366, 905, 644,
			372, 567, 466, 434, 645, 210, 389, 550, 919, 135,
			780, 773, 635, 389, 707, 100, 626, 958, 165, 504,
			920, 176, 193, 713, 857, 265, 203, 50, 668, 108,
			645, 990, 626, 197, 510, 357, 358, 850, 858, 364,
			936, 638
		};

		public const int BaseBlockSize = 100000;

		public const int MaximumAlphaSize = 258;

		public const int MaximumCodeLength = 23;

		public const int RunA = 0;

		public const int RunB = 1;

		public const int GroupCount = 6;

		public const int GroupSize = 50;

		public const int NumberOfIterations = 4;

		public const int MaximumSelectors = 18002;

		public const int OvershootBytes = 20;

		private BZip2Constants ()
		{
		}
	}
	[Serializable]
	public class BZip2Exception : SharpZipBaseException
	{
		protected BZip2Exception (SerializationInfo info, StreamingContext context)
			: base (info, context)
		{
		}

		public BZip2Exception ()
		{
		}

		public BZip2Exception (string message)
			: base (message)
		{
		}

		public BZip2Exception (string message, Exception exception)
			: base (message, exception)
		{
		}
	}
	public class BZip2InputStream : Stream
	{
		private const int START_BLOCK_STATE = 1;

		private const int RAND_PART_A_STATE = 2;

		private const int RAND_PART_B_STATE = 3;

		private const int RAND_PART_C_STATE = 4;

		private const int NO_RAND_PART_A_STATE = 5;

		private const int NO_RAND_PART_B_STATE = 6;

		private const int NO_RAND_PART_C_STATE = 7;

		private int last;

		private int origPtr;

		private int blockSize100k;

		private bool blockRandomised;

		private int bsBuff;

		private int bsLive;

		private IChecksum mCrc = new StrangeCRC ();

		private bool[] inUse = new bool[256];

		private int nInUse;

		private byte[] seqToUnseq = new byte[256];

		private byte[] unseqToSeq = new byte[256];

		private byte[] selector = new byte[18002];

		private byte[] selectorMtf = new byte[18002];

		private int[] tt;

		private byte[] ll8;

		private int[] unzftab = new int[256];

		private int[][] limit = new int[6][];

		private int[][] baseArray = new int[6][];

		private int[][] perm = new int[6][];

		private int[] minLens = new int[6];

		private Stream baseStream;

		private bool streamEnd;

		private int currentChar = -1;

		private int currentState = 1;

		private int storedBlockCRC;

		private int storedCombinedCRC;

		private int computedBlockCRC;

		private uint computedCombinedCRC;

		private int count;

		private int chPrev;

		private int ch2;

		private int tPos;

		private int rNToGo;

		private int rTPos;

		private int i2;

		private int j2;

		private byte z;

		private bool isStreamOwner = true;

		public bool IsStreamOwner {
			get {
				return isStreamOwner;
			}
			set {
				isStreamOwner = value;
			}
		}

		public override bool CanRead => baseStream.CanRead;

		public override bool CanSeek => baseStream.CanSeek;

		public override bool CanWrite => false;

		public override long Length => baseStream.Length;

		public override long Position {
			get {
				return baseStream.Position;
			}
			set {
				throw new NotSupportedException ("BZip2InputStream position cannot be set");
			}
		}

		public BZip2InputStream (Stream stream)
		{
			for (int i = 0; i < 6; i++) {
				limit [i] = new int[258];
				baseArray [i] = new int[258];
				perm [i] = new int[258];
			}
			BsSetStream (stream);
			Initialize ();
			InitBlock ();
			SetupBlock ();
		}

		public override void Flush ()
		{
			if (baseStream != null) {
				baseStream.Flush ();
			}
		}

		public override long Seek (long offset, SeekOrigin origin)
		{
			throw new NotSupportedException ("BZip2InputStream Seek not supported");
		}

		public override void SetLength (long value)
		{
			throw new NotSupportedException ("BZip2InputStream SetLength not supported");
		}

		public override void Write (byte[] buffer, int offset, int count)
		{
			throw new NotSupportedException ("BZip2InputStream Write not supported");
		}

		public override void WriteByte (byte value)
		{
			throw new NotSupportedException ("BZip2InputStream WriteByte not supported");
		}

		public override int Read (byte[] buffer, int offset, int count)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			for (int i = 0; i < count; i++) {
				int num = ReadByte ();
				if (num == -1) {
					return i;
				}
				buffer [offset + i] = (byte)num;
			}
			return count;
		}

		public override void Close ()
		{
			if (IsStreamOwner && baseStream != null) {
				baseStream.Close ();
			}
		}

		public override int ReadByte ()
		{
			if (streamEnd) {
				return -1;
			}
			int result = currentChar;
			switch (currentState) {
			case 3:
				SetupRandPartB ();
				break;
			case 4:
				SetupRandPartC ();
				break;
			case 6:
				SetupNoRandPartB ();
				break;
			case 7:
				SetupNoRandPartC ();
				break;
			}
			return result;
		}

		private void MakeMaps ()
		{
			nInUse = 0;
			for (int i = 0; i < 256; i++) {
				if (inUse [i]) {
					seqToUnseq [nInUse] = (byte)i;
					unseqToSeq [i] = (byte)nInUse;
					nInUse++;
				}
			}
		}

		private void Initialize ()
		{
			char c = BsGetUChar ();
			char c2 = BsGetUChar ();
			char c3 = BsGetUChar ();
			char c4 = BsGetUChar ();
			if (c != 'B' || c2 != 'Z' || c3 != 'h' || c4 < '1' || c4 > '9') {
				streamEnd = true;
				return;
			}
			SetDecompressStructureSizes (c4 - 48);
			computedCombinedCRC = 0u;
		}

		private void InitBlock ()
		{
			char c = BsGetUChar ();
			char c2 = BsGetUChar ();
			char c3 = BsGetUChar ();
			char c4 = BsGetUChar ();
			char c5 = BsGetUChar ();
			char c6 = BsGetUChar ();
			if (c == '\u0017' && c2 == 'r' && c3 == 'E' && c4 == '8' && c5 == 'P' && c6 == '\u0090') {
				Complete ();
				return;
			}
			if (c != '1' || c2 != 'A' || c3 != 'Y' || c4 != '&' || c5 != 'S' || c6 != 'Y') {
				BadBlockHeader ();
				streamEnd = true;
				return;
			}
			storedBlockCRC = BsGetInt32 ();
			blockRandomised = BsR (1) == 1;
			GetAndMoveToFrontDecode ();
			mCrc.Reset ();
			currentState = 1;
		}

		private void EndBlock ()
		{
			computedBlockCRC = (int)mCrc.Value;
			if (storedBlockCRC != computedBlockCRC) {
				CrcError ();
			}
			computedCombinedCRC = ((computedCombinedCRC << 1) & 0xFFFFFFFFu) | (computedCombinedCRC >> 31);
			computedCombinedCRC ^= (uint)computedBlockCRC;
		}

		private void Complete ()
		{
			storedCombinedCRC = BsGetInt32 ();
			if (storedCombinedCRC != (int)computedCombinedCRC) {
				CrcError ();
			}
			streamEnd = true;
		}

		private void BsSetStream (Stream stream)
		{
			baseStream = stream;
			bsLive = 0;
			bsBuff = 0;
		}

		private void FillBuffer ()
		{
			int num = 0;
			try {
				num = baseStream.ReadByte ();
			} catch (Exception) {
				CompressedStreamEOF ();
			}
			if (num == -1) {
				CompressedStreamEOF ();
			}
			bsBuff = (bsBuff << 8) | (num & 0xFF);
			bsLive += 8;
		}

		private int BsR (int n)
		{
			while (bsLive < n) {
				FillBuffer ();
			}
			int result = (bsBuff >> bsLive - n) & ((1 << n) - 1);
			bsLive -= n;
			return result;
		}

		private char BsGetUChar ()
		{
			return (char)BsR (8);
		}

		private int BsGetIntVS (int numBits)
		{
			return BsR (numBits);
		}

		private int BsGetInt32 ()
		{
			int num = BsR (8);
			num = (num << 8) | BsR (8);
			num = (num << 8) | BsR (8);
			return (num << 8) | BsR (8);
		}

		private void RecvDecodingTables ()
		{
			char[][] array = new char[6][];
			for (int i = 0; i < 6; i++) {
				array [i] = new char[258];
			}
			bool[] array2 = new bool[16];
			for (int j = 0; j < 16; j++) {
				array2 [j] = BsR (1) == 1;
			}
			for (int k = 0; k < 16; k++) {
				if (array2 [k]) {
					for (int l = 0; l < 16; l++) {
						inUse [k * 16 + l] = BsR (1) == 1;
					}
				} else {
					for (int m = 0; m < 16; m++) {
						inUse [k * 16 + m] = false;
					}
				}
			}
			MakeMaps ();
			int num = nInUse + 2;
			int num2 = BsR (3);
			int num3 = BsR (15);
			for (int n = 0; n < num3; n++) {
				int num4 = 0;
				while (BsR (1) == 1) {
					num4++;
				}
				selectorMtf [n] = (byte)num4;
			}
			byte[] array3 = new byte[6];
			for (int num5 = 0; num5 < num2; num5++) {
				array3 [num5] = (byte)num5;
			}
			for (int num6 = 0; num6 < num3; num6++) {
				int num7 = selectorMtf [num6];
				byte b = array3 [num7];
				while (num7 > 0) {
					array3 [num7] = array3 [num7 - 1];
					num7--;
				}
				array3 [0] = b;
				selector [num6] = b;
			}
			for (int num8 = 0; num8 < num2; num8++) {
				int num9 = BsR (5);
				for (int num10 = 0; num10 < num; num10++) {
					while (BsR (1) == 1) {
						num9 = ((BsR (1) != 0) ? (num9 - 1) : (num9 + 1));
					}
					array [num8] [num10] = (char)num9;
				}
			}
			for (int num11 = 0; num11 < num2; num11++) {
				int num12 = 32;
				int num13 = 0;
				for (int num14 = 0; num14 < num; num14++) {
					num13 = Math.Max (num13, array [num11] [num14]);
					num12 = Math.Min (num12, array [num11] [num14]);
				}
				HbCreateDecodeTables (limit [num11], baseArray [num11], perm [num11], array [num11], num12, num13, num);
				minLens [num11] = num12;
			}
		}

		private void GetAndMoveToFrontDecode ()
		{
			byte[] array = new byte[256];
			int num = 100000 * blockSize100k;
			origPtr = BsGetIntVS (24);
			RecvDecodingTables ();
			int num2 = nInUse + 1;
			int num3 = -1;
			int num4 = 0;
			for (int i = 0; i <= 255; i++) {
				unzftab [i] = 0;
			}
			for (int j = 0; j <= 255; j++) {
				array [j] = (byte)j;
			}
			last = -1;
			if (num4 == 0) {
				num3++;
				num4 = 50;
			}
			num4--;
			int num5 = selector [num3];
			int num6 = minLens [num5];
			int num7 = BsR (num6);
			while (num7 > limit [num5] [num6]) {
				if (num6 > 20) {
					throw new BZip2Exception ("Bzip data error");
				}
				num6++;
				while (bsLive < 1) {
					FillBuffer ();
				}
				int num8 = (bsBuff >> bsLive - 1) & 1;
				bsLive--;
				num7 = (num7 << 1) | num8;
			}
			if (num7 - baseArray [num5] [num6] < 0 || num7 - baseArray [num5] [num6] >= 258) {
				throw new BZip2Exception ("Bzip data error");
			}
			int num9 = perm [num5] [num7 - baseArray [num5] [num6]];
			while (num9 != num2) {
				if (num9 == 0 || num9 == 1) {
					int num10 = -1;
					int num11 = 1;
					do {
						switch (num9) {
						case 0:
							num10 += num11;
							break;
						case 1:
							num10 += 2 * num11;
							break;
						}
						num11 <<= 1;
						if (num4 == 0) {
							num3++;
							num4 = 50;
						}
						num4--;
						num5 = selector [num3];
						num6 = minLens [num5];
						num7 = BsR (num6);
						while (num7 > limit [num5] [num6]) {
							num6++;
							while (bsLive < 1) {
								FillBuffer ();
							}
							int num8 = (bsBuff >> bsLive - 1) & 1;
							bsLive--;
							num7 = (num7 << 1) | num8;
						}
						num9 = perm [num5] [num7 - baseArray [num5] [num6]];
					} while (num9 == 0 || num9 == 1);
					num10++;
					byte b = seqToUnseq [array [0]];
					unzftab [b] += num10;
					while (num10 > 0) {
						last++;
						ll8 [last] = b;
						num10--;
					}
					if (last >= num) {
						BlockOverrun ();
					}
					continue;
				}
				last++;
				if (last >= num) {
					BlockOverrun ();
				}
				byte b2 = array [num9 - 1];
				unzftab [seqToUnseq [b2]]++;
				ll8 [last] = seqToUnseq [b2];
				for (int num12 = num9 - 1; num12 > 0; num12--) {
					array [num12] = array [num12 - 1];
				}
				array [0] = b2;
				if (num4 == 0) {
					num3++;
					num4 = 50;
				}
				num4--;
				num5 = selector [num3];
				num6 = minLens [num5];
				num7 = BsR (num6);
				while (num7 > limit [num5] [num6]) {
					num6++;
					while (bsLive < 1) {
						FillBuffer ();
					}
					int num8 = (bsBuff >> bsLive - 1) & 1;
					bsLive--;
					num7 = (num7 << 1) | num8;
				}
				num9 = perm [num5] [num7 - baseArray [num5] [num6]];
			}
		}

		private void SetupBlock ()
		{
			int[] array = new int[257];
			array [0] = 0;
			Array.Copy (unzftab, 0, array, 1, 256);
			for (int i = 1; i <= 256; i++) {
				array [i] += array [i - 1];
			}
			for (int j = 0; j <= last; j++) {
				byte b = ll8 [j];
				tt [array [b]] = j;
				array [b]++;
			}
			array = null;
			tPos = tt [origPtr];
			count = 0;
			i2 = 0;
			ch2 = 256;
			if (blockRandomised) {
				rNToGo = 0;
				rTPos = 0;
				SetupRandPartA ();
			} else {
				SetupNoRandPartA ();
			}
		}

		private void SetupRandPartA ()
		{
			if (i2 <= last) {
				chPrev = ch2;
				ch2 = ll8 [tPos];
				tPos = tt [tPos];
				if (rNToGo == 0) {
					rNToGo = BZip2Constants.RandomNumbers [rTPos];
					rTPos++;
					if (rTPos == 512) {
						rTPos = 0;
					}
				}
				rNToGo--;
				ch2 ^= ((rNToGo == 1) ? 1 : 0);
				i2++;
				currentChar = ch2;
				currentState = 3;
				mCrc.Update (ch2);
			} else {
				EndBlock ();
				InitBlock ();
				SetupBlock ();
			}
		}

		private void SetupNoRandPartA ()
		{
			if (i2 <= last) {
				chPrev = ch2;
				ch2 = ll8 [tPos];
				tPos = tt [tPos];
				i2++;
				currentChar = ch2;
				currentState = 6;
				mCrc.Update (ch2);
			} else {
				EndBlock ();
				InitBlock ();
				SetupBlock ();
			}
		}

		private void SetupRandPartB ()
		{
			if (ch2 != chPrev) {
				currentState = 2;
				count = 1;
				SetupRandPartA ();
				return;
			}
			count++;
			if (count >= 4) {
				z = ll8 [tPos];
				tPos = tt [tPos];
				if (rNToGo == 0) {
					rNToGo = BZip2Constants.RandomNumbers [rTPos];
					rTPos++;
					if (rTPos == 512) {
						rTPos = 0;
					}
				}
				rNToGo--;
				z ^= ((rNToGo == 1) ? ((byte)1) : ((byte)0));
				j2 = 0;
				currentState = 4;
				SetupRandPartC ();
			} else {
				currentState = 2;
				SetupRandPartA ();
			}
		}

		private void SetupRandPartC ()
		{
			if (j2 < z) {
				currentChar = ch2;
				mCrc.Update (ch2);
				j2++;
			} else {
				currentState = 2;
				i2++;
				count = 0;
				SetupRandPartA ();
			}
		}

		private void SetupNoRandPartB ()
		{
			if (ch2 != chPrev) {
				currentState = 5;
				count = 1;
				SetupNoRandPartA ();
				return;
			}
			count++;
			if (count >= 4) {
				z = ll8 [tPos];
				tPos = tt [tPos];
				currentState = 7;
				j2 = 0;
				SetupNoRandPartC ();
			} else {
				currentState = 5;
				SetupNoRandPartA ();
			}
		}

		private void SetupNoRandPartC ()
		{
			if (j2 < z) {
				currentChar = ch2;
				mCrc.Update (ch2);
				j2++;
			} else {
				currentState = 5;
				i2++;
				count = 0;
				SetupNoRandPartA ();
			}
		}

		private void SetDecompressStructureSizes (int newSize100k)
		{
			if (0 > newSize100k || newSize100k > 9 || 0 > blockSize100k || blockSize100k > 9) {
				throw new BZip2Exception ("Invalid block size");
			}
			blockSize100k = newSize100k;
			if (newSize100k != 0) {
				int num = 100000 * newSize100k;
				ll8 = new byte[num];
				tt = new int[num];
			}
		}

		private static void CompressedStreamEOF ()
		{
			throw new EndOfStreamException ("BZip2 input stream end of compressed stream");
		}

		private static void BlockOverrun ()
		{
			throw new BZip2Exception ("BZip2 input stream block overrun");
		}

		private static void BadBlockHeader ()
		{
			throw new BZip2Exception ("BZip2 input stream bad block header");
		}

		private static void CrcError ()
		{
			throw new BZip2Exception ("BZip2 input stream crc error");
		}

		private static void HbCreateDecodeTables (int[] limit, int[] baseArray, int[] perm, char[] length, int minLen, int maxLen, int alphaSize)
		{
			int num = 0;
			for (int i = minLen; i <= maxLen; i++) {
				for (int j = 0; j < alphaSize; j++) {
					if (length [j] == i) {
						perm [num] = j;
						num++;
					}
				}
			}
			for (int k = 0; k < 23; k++) {
				baseArray [k] = 0;
			}
			for (int l = 0; l < alphaSize; l++) {
				baseArray [length [l] + 1]++;
			}
			for (int m = 1; m < 23; m++) {
				baseArray [m] += baseArray [m - 1];
			}
			for (int n = 0; n < 23; n++) {
				limit [n] = 0;
			}
			int num2 = 0;
			for (int num3 = minLen; num3 <= maxLen; num3++) {
				num2 += baseArray [num3 + 1] - baseArray [num3];
				limit [num3] = num2 - 1;
				num2 <<= 1;
			}
			for (int num4 = minLen + 1; num4 <= maxLen; num4++) {
				baseArray [num4] = (limit [num4 - 1] + 1 << 1) - baseArray [num4];
			}
		}
	}
	public class BZip2OutputStream : Stream
	{
		private struct StackElement
		{
			public int ll;

			public int hh;

			public int dd;
		}

		private const int SETMASK = 2097152;

		private const int CLEARMASK = -2097153;

		private const int GREATER_ICOST = 15;

		private const int LESSER_ICOST = 0;

		private const int SMALL_THRESH = 20;

		private const int DEPTH_THRESH = 10;

		private const int QSORT_STACK_SIZE = 1000;

		private readonly int[] increments = new int[14] {
			1, 4, 13, 40, 121, 364, 1093, 3280, 9841, 29524,
			88573, 265720, 797161, 2391484
		};

		private bool isStreamOwner = true;

		private int last;

		private int origPtr;

		private int blockSize100k;

		private bool blockRandomised;

		private int bytesOut;

		private int bsBuff;

		private int bsLive;

		private IChecksum mCrc = new StrangeCRC ();

		private bool[] inUse = new bool[256];

		private int nInUse;

		private char[] seqToUnseq = new char[256];

		private char[] unseqToSeq = new char[256];

		private char[] selector = new char[18002];

		private char[] selectorMtf = new char[18002];

		private byte[] block;

		private int[] quadrant;

		private int[] zptr;

		private short[] szptr;

		private int[] ftab;

		private int nMTF;

		private int[] mtfFreq = new int[258];

		private int workFactor;

		private int workDone;

		private int workLimit;

		private bool firstAttempt;

		private int nBlocksRandomised;

		private int currentChar = -1;

		private int runLength;

		private uint blockCRC;

		private uint combinedCRC;

		private int allowableBlockSize;

		private Stream baseStream;

		private bool disposed_;

		public bool IsStreamOwner {
			get {
				return isStreamOwner;
			}
			set {
				isStreamOwner = value;
			}
		}

		public override bool CanRead => false;

		public override bool CanSeek => false;

		public override bool CanWrite => baseStream.CanWrite;

		public override long Length => baseStream.Length;

		public override long Position {
			get {
				return baseStream.Position;
			}
			set {
				throw new NotSupportedException ("BZip2OutputStream position cannot be set");
			}
		}

		public int BytesWritten => bytesOut;

		public BZip2OutputStream (Stream stream)
			: this (stream, 9)
		{
		}

		public BZip2OutputStream (Stream stream, int blockSize)
		{
			BsSetStream (stream);
			workFactor = 50;
			if (blockSize > 9) {
				blockSize = 9;
			}
			if (blockSize < 1) {
				blockSize = 1;
			}
			blockSize100k = blockSize;
			AllocateCompressStructures ();
			Initialize ();
			InitBlock ();
		}

		~BZip2OutputStream ()
		{
			Dispose (disposing: false);
		}

		public override long Seek (long offset, SeekOrigin origin)
		{
			throw new NotSupportedException ("BZip2OutputStream Seek not supported");
		}

		public override void SetLength (long value)
		{
			throw new NotSupportedException ("BZip2OutputStream SetLength not supported");
		}

		public override int ReadByte ()
		{
			throw new NotSupportedException ("BZip2OutputStream ReadByte not supported");
		}

		public override int Read (byte[] buffer, int offset, int count)
		{
			throw new NotSupportedException ("BZip2OutputStream Read not supported");
		}

		public override void Write (byte[] buffer, int offset, int count)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (offset < 0) {
				throw new ArgumentOutOfRangeException ("offset");
			}
			if (count < 0) {
				throw new ArgumentOutOfRangeException ("count");
			}
			if (buffer.Length - offset < count) {
				throw new ArgumentException ("Offset/count out of range");
			}
			for (int i = 0; i < count; i++) {
				WriteByte (buffer [offset + i]);
			}
		}

		public override void WriteByte (byte value)
		{
			int num = (256 + value) % 256;
			if (currentChar != -1) {
				if (currentChar == num) {
					runLength++;
					if (runLength > 254) {
						WriteRun ();
						currentChar = -1;
						runLength = 0;
					}
				} else {
					WriteRun ();
					runLength = 1;
					currentChar = num;
				}
			} else {
				currentChar = num;
				runLength++;
			}
		}

		public override void Close ()
		{
			Dispose (disposing: true);
			GC.SuppressFinalize (this);
		}

		private void MakeMaps ()
		{
			nInUse = 0;
			for (int i = 0; i < 256; i++) {
				if (inUse [i]) {
					seqToUnseq [nInUse] = (char)i;
					unseqToSeq [i] = (char)nInUse;
					nInUse++;
				}
			}
		}

		private void WriteRun ()
		{
			if (last < allowableBlockSize) {
				inUse [currentChar] = true;
				for (int i = 0; i < runLength; i++) {
					mCrc.Update (currentChar);
				}
				switch (runLength) {
				case 1:
					last++;
					block [last + 1] = (byte)currentChar;
					break;
				case 2:
					last++;
					block [last + 1] = (byte)currentChar;
					last++;
					block [last + 1] = (byte)currentChar;
					break;
				case 3:
					last++;
					block [last + 1] = (byte)currentChar;
					last++;
					block [last + 1] = (byte)currentChar;
					last++;
					block [last + 1] = (byte)currentChar;
					break;
				default:
					inUse [runLength - 4] = true;
					last++;
					block [last + 1] = (byte)currentChar;
					last++;
					block [last + 1] = (byte)currentChar;
					last++;
					block [last + 1] = (byte)currentChar;
					last++;
					block [last + 1] = (byte)currentChar;
					last++;
					block [last + 1] = (byte)(runLength - 4);
					break;
				}
			} else {
				EndBlock ();
				InitBlock ();
				WriteRun ();
			}
		}

		protected override void Dispose (bool disposing)
		{
			try {
				base.Dispose (disposing);
				if (!disposed_) {
					disposed_ = true;
					if (runLength > 0) {
						WriteRun ();
					}
					currentChar = -1;
					EndBlock ();
					EndCompression ();
					Flush ();
				}
			} finally {
				if (disposing && IsStreamOwner) {
					baseStream.Close ();
				}
			}
		}

		public override void Flush ()
		{
			baseStream.Flush ();
		}

		private void Initialize ()
		{
			bytesOut = 0;
			nBlocksRandomised = 0;
			BsPutUChar (66);
			BsPutUChar (90);
			BsPutUChar (104);
			BsPutUChar (48 + blockSize100k);
			combinedCRC = 0u;
		}

		private void InitBlock ()
		{
			mCrc.Reset ();
			last = -1;
			for (int i = 0; i < 256; i++) {
				inUse [i] = false;
			}
			allowableBlockSize = 100000 * blockSize100k - 20;
		}

		private void EndBlock ()
		{
			if (last >= 0) {
				blockCRC = (uint)mCrc.Value;
				combinedCRC = (combinedCRC << 1) | (combinedCRC >> 31);
				combinedCRC ^= blockCRC;
				DoReversibleTransformation ();
				BsPutUChar (49);
				BsPutUChar (65);
				BsPutUChar (89);
				BsPutUChar (38);
				BsPutUChar (83);
				BsPutUChar (89);
				BsPutint ((int)blockCRC);
				if (blockRandomised) {
					BsW (1, 1);
					nBlocksRandomised++;
				} else {
					BsW (1, 0);
				}
				MoveToFrontCodeAndSend ();
			}
		}

		private void EndCompression ()
		{
			BsPutUChar (23);
			BsPutUChar (114);
			BsPutUChar (69);
			BsPutUChar (56);
			BsPutUChar (80);
			BsPutUChar (144);
			BsPutint ((int)combinedCRC);
			BsFinishedWithStream ();
		}

		private void BsSetStream (Stream stream)
		{
			baseStream = stream;
			bsLive = 0;
			bsBuff = 0;
			bytesOut = 0;
		}

		private void BsFinishedWithStream ()
		{
			while (bsLive > 0) {
				int num = bsBuff >> 24;
				baseStream.WriteByte ((byte)num);
				bsBuff <<= 8;
				bsLive -= 8;
				bytesOut++;
			}
		}

		private void BsW (int n, int v)
		{
			while (bsLive >= 8) {
				int num = bsBuff >> 24;
				baseStream.WriteByte ((byte)num);
				bsBuff <<= 8;
				bsLive -= 8;
				bytesOut++;
			}
			bsBuff |= v << 32 - bsLive - n;
			bsLive += n;
		}

		private void BsPutUChar (int c)
		{
			BsW (8, c);
		}

		private void BsPutint (int u)
		{
			BsW (8, (u >> 24) & 0xFF);
			BsW (8, (u >> 16) & 0xFF);
			BsW (8, (u >> 8) & 0xFF);
			BsW (8, u & 0xFF);
		}

		private void BsPutIntVS (int numBits, int c)
		{
			BsW (numBits, c);
		}

		private void SendMTFValues ()
		{
			char[][] array = new char[6][];
			for (int i = 0; i < 6; i++) {
				array [i] = new char[258];
			}
			int num = 0;
			int num2 = nInUse + 2;
			for (int j = 0; j < 6; j++) {
				for (int k = 0; k < num2; k++) {
					array [j] [k] = '\u000f';
				}
			}
			if (nMTF <= 0) {
				Panic ();
			}
			int num3 = ((nMTF < 200) ? 2 : ((nMTF < 600) ? 3 : ((nMTF < 1200) ? 4 : ((nMTF >= 2400) ? 6 : 5))));
			int num4 = num3;
			int num5 = nMTF;
			int num6 = 0;
			while (num4 > 0) {
				int num7 = num5 / num4;
				int l = 0;
				int num8;
				for (num8 = num6 - 1; l < num7; l += mtfFreq [num8]) {
					if (num8 >= num2 - 1) {
						break;
					}
					num8++;
				}
				if (num8 > num6 && num4 != num3 && num4 != 1 && (num3 - num4) % 2 == 1) {
					l -= mtfFreq [num8];
					num8--;
				}
				for (int m = 0; m < num2; m++) {
					if (m >= num6 && m <= num8) {
						array [num4 - 1] [m] = '\0';
					} else {
						array [num4 - 1] [m] = '\u000f';
					}
				}
				num4--;
				num6 = num8 + 1;
				num5 -= l;
			}
			int[][] array2 = new int[6][];
			for (int n = 0; n < 6; n++) {
				array2 [n] = new int[258];
			}
			int[] array3 = new int[6];
			short[] array4 = new short[6];
			for (int num9 = 0; num9 < 4; num9++) {
				for (int num10 = 0; num10 < num3; num10++) {
					array3 [num10] = 0;
				}
				for (int num11 = 0; num11 < num3; num11++) {
					for (int num12 = 0; num12 < num2; num12++) {
						array2 [num11] [num12] = 0;
					}
				}
				num = 0;
				int num13 = 0;
				num6 = 0;
				while (num6 < nMTF) {
					int num8 = num6 + 50 - 1;
					if (num8 >= nMTF) {
						num8 = nMTF - 1;
					}
					for (int num14 = 0; num14 < num3; num14++) {
						array4 [num14] = 0;
					}
					if (num3 == 6) {
						short num19;
						short num18;
						short num17;
						short num16;
						short num15;
						short num20 = (num19 = (num18 = (num17 = (num16 = (num15 = 0)))));
						for (int num21 = num6; num21 <= num8; num21++) {
							short num22 = szptr [num21];
							num20 += (short)array [0] [num22];
							num19 += (short)array [1] [num22];
							num18 += (short)array [2] [num22];
							num17 += (short)array [3] [num22];
							num16 += (short)array [4] [num22];
							num15 += (short)array [5] [num22];
						}
						array4 [0] = num20;
						array4 [1] = num19;
						array4 [2] = num18;
						array4 [3] = num17;
						array4 [4] = num16;
						array4 [5] = num15;
					} else {
						for (int num23 = num6; num23 <= num8; num23++) {
							short num24 = szptr [num23];
							for (int num25 = 0; num25 < num3; num25++) {
								array4 [num25] += (short)array [num25] [num24];
							}
						}
					}
					int num26 = 999999999;
					int num27 = -1;
					for (int num28 = 0; num28 < num3; num28++) {
						if (array4 [num28] < num26) {
							num26 = array4 [num28];
							num27 = num28;
						}
					}
					num13 += num26;
					array3 [num27]++;
					selector [num] = (char)num27;
					num++;
					for (int num29 = num6; num29 <= num8; num29++) {
						array2 [num27] [szptr [num29]]++;
					}
					num6 = num8 + 1;
				}
				for (int num30 = 0; num30 < num3; num30++) {
					HbMakeCodeLengths (array [num30], array2 [num30], num2, 20);
				}
			}
			array2 = null;
			array3 = null;
			array4 = null;
			if (num3 >= 8) {
				Panic ();
			}
			if (num >= 32768 || num > 18002) {
				Panic ();
			}
			char[] array5 = new char[6];
			for (int num31 = 0; num31 < num3; num31++) {
				array5 [num31] = (char)num31;
			}
			for (int num32 = 0; num32 < num; num32++) {
				char c = selector [num32];
				int num33 = 0;
				char c2 = array5 [num33];
				while (c != c2) {
					num33++;
					char c3 = c2;
					c2 = array5 [num33];
					array5 [num33] = c3;
				}
				array5 [0] = c2;
				selectorMtf [num32] = (char)num33;
			}
			int[][] array6 = new int[6][];
			for (int num34 = 0; num34 < 6; num34++) {
				array6 [num34] = new int[258];
			}
			for (int num35 = 0; num35 < num3; num35++) {
				int num36 = 32;
				int num37 = 0;
				for (int num38 = 0; num38 < num2; num38++) {
					if (array [num35] [num38] > num37) {
						num37 = array [num35] [num38];
					}
					if (array [num35] [num38] < num36) {
						num36 = array [num35] [num38];
					}
				}
				if (num37 > 20) {
					Panic ();
				}
				if (num36 < 1) {
					Panic ();
				}
				HbAssignCodes (array6 [num35], array [num35], num36, num37, num2);
			}
			bool[] array7 = new bool[16];
			for (int num39 = 0; num39 < 16; num39++) {
				array7 [num39] = false;
				for (int num40 = 0; num40 < 16; num40++) {
					if (inUse [num39 * 16 + num40]) {
						array7 [num39] = true;
					}
				}
			}
			for (int num41 = 0; num41 < 16; num41++) {
				if (array7 [num41]) {
					BsW (1, 1);
				} else {
					BsW (1, 0);
				}
			}
			for (int num42 = 0; num42 < 16; num42++) {
				if (!array7 [num42]) {
					continue;
				}
				for (int num43 = 0; num43 < 16; num43++) {
					if (inUse [num42 * 16 + num43]) {
						BsW (1, 1);
					} else {
						BsW (1, 0);
					}
				}
			}
			BsW (3, num3);
			BsW (15, num);
			for (int num44 = 0; num44 < num; num44++) {
				for (int num45 = 0; num45 < selectorMtf [num44]; num45++) {
					BsW (1, 1);
				}
				BsW (1, 0);
			}
			for (int num46 = 0; num46 < num3; num46++) {
				int num47 = array [num46] [0];
				BsW (5, num47);
				for (int num48 = 0; num48 < num2; num48++) {
					for (; num47 < array [num46] [num48]; num47++) {
						BsW (2, 2);
					}
					while (num47 > array [num46] [num48]) {
						BsW (2, 3);
						num47--;
					}
					BsW (1, 0);
				}
			}
			int num49 = 0;
			num6 = 0;
			while (num6 < nMTF) {
				int num8 = num6 + 50 - 1;
				if (num8 >= nMTF) {
					num8 = nMTF - 1;
				}
				for (int num50 = num6; num50 <= num8; num50++) {
					BsW (array [(uint)selector [num49]] [szptr [num50]], array6 [(uint)selector [num49]] [szptr [num50]]);
				}
				num6 = num8 + 1;
				num49++;
			}
			if (num49 != num) {
				Panic ();
			}
		}

		private void MoveToFrontCodeAndSend ()
		{
			BsPutIntVS (24, origPtr);
			GenerateMTFValues ();
			SendMTFValues ();
		}

		private void SimpleSort (int lo, int hi, int d)
		{
			int num = hi - lo + 1;
			if (num < 2) {
				return;
			}
			int i;
			for (i = 0; increments [i] < num; i++) {
			}
			for (i--; i >= 0; i--) {
				int num2 = increments [i];
				int num3 = lo + num2;
				while (num3 <= hi) {
					int num4 = zptr [num3];
					int num5 = num3;
					while (FullGtU (zptr [num5 - num2] + d, num4 + d)) {
						zptr [num5] = zptr [num5 - num2];
						num5 -= num2;
						if (num5 <= lo + num2 - 1) {
							break;
						}
					}
					zptr [num5] = num4;
					num3++;
					if (num3 > hi) {
						break;
					}
					num4 = zptr [num3];
					num5 = num3;
					while (FullGtU (zptr [num5 - num2] + d, num4 + d)) {
						zptr [num5] = zptr [num5 - num2];
						num5 -= num2;
						if (num5 <= lo + num2 - 1) {
							break;
						}
					}
					zptr [num5] = num4;
					num3++;
					if (num3 > hi) {
						break;
					}
					num4 = zptr [num3];
					num5 = num3;
					while (FullGtU (zptr [num5 - num2] + d, num4 + d)) {
						zptr [num5] = zptr [num5 - num2];
						num5 -= num2;
						if (num5 <= lo + num2 - 1) {
							break;
						}
					}
					zptr [num5] = num4;
					num3++;
					if (workDone > workLimit && firstAttempt) {
						return;
					}
				}
			}
		}

		private void Vswap (int p1, int p2, int n)
		{
			int num = 0;
			while (n > 0) {
				num = zptr [p1];
				zptr [p1] = zptr [p2];
				zptr [p2] = num;
				p1++;
				p2++;
				n--;
			}
		}

		private void QSort3 (int loSt, int hiSt, int dSt)
		{
			StackElement[] array = new StackElement[1000];
			int num = 0;
			array [num].ll = loSt;
			array [num].hh = hiSt;
			array [num].dd = dSt;
			num++;
			while (num > 0) {
				if (num >= 1000) {
					Panic ();
				}
				num--;
				int ll = array [num].ll;
				int hh = array [num].hh;
				int dd = array [num].dd;
				if (hh - ll < 20 || dd > 10) {
					SimpleSort (ll, hh, dd);
					if (workDone > workLimit && firstAttempt) {
						break;
					}
					continue;
				}
				int num2 = Med3 (block [zptr [ll] + dd + 1], block [zptr [hh] + dd + 1], block [zptr [ll + hh >> 1] + dd + 1]);
				int num3;
				int num4 = (num3 = ll);
				int num5;
				int num6 = (num5 = hh);
				int num7;
				while (true) {
					if (num4 <= num6) {
						num7 = block [zptr [num4] + dd + 1] - num2;
						if (num7 == 0) {
							int num8 = zptr [num4];
							zptr [num4] = zptr [num3];
							zptr [num3] = num8;
							num3++;
							num4++;
							continue;
						}
						if (num7 <= 0) {
							num4++;
							continue;
						}
					}
					while (num4 <= num6) {
						num7 = block [zptr [num6] + dd + 1] - num2;
						if (num7 == 0) {
							int num9 = zptr [num6];
							zptr [num6] = zptr [num5];
							zptr [num5] = num9;
							num5--;
							num6--;
						} else {
							if (num7 < 0) {
								break;
							}
							num6--;
						}
					}
					if (num4 > num6) {
						break;
					}
					int num10 = zptr [num4];
					zptr [num4] = zptr [num6];
					zptr [num6] = num10;
					num4++;
					num6--;
				}
				if (num5 < num3) {
					array [num].ll = ll;
					array [num].hh = hh;
					array [num].dd = dd + 1;
					num++;
					continue;
				}
				num7 = ((num3 - ll >= num4 - num3) ? (num4 - num3) : (num3 - ll));
				Vswap (ll, num4 - num7, num7);
				int num11 = ((hh - num5 >= num5 - num6) ? (num5 - num6) : (hh - num5));
				Vswap (num4, hh - num11 + 1, num11);
				num7 = ll + num4 - num3 - 1;
				num11 = hh - (num5 - num6) + 1;
				array [num].ll = ll;
				array [num].hh = num7;
				array [num].dd = dd;
				num++;
				array [num].ll = num7 + 1;
				array [num].hh = num11 - 1;
				array [num].dd = dd + 1;
				num++;
				array [num].ll = num11;
				array [num].hh = hh;
				array [num].dd = dd;
				num++;
			}
		}

		private void MainSort ()
		{
			int[] array = new int[256];
			int[] array2 = new int[256];
			bool[] array3 = new bool[256];
			for (int i = 0; i < 20; i++) {
				block [last + i + 2] = block [i % (last + 1) + 1];
			}
			for (int i = 0; i <= last + 20; i++) {
				quadrant [i] = 0;
			}
			block [0] = block [last + 1];
			if (last < 4000) {
				for (int i = 0; i <= last; i++) {
					zptr [i] = i;
				}
				firstAttempt = false;
				workDone = (workLimit = 0);
				SimpleSort (0, last, 0);
				return;
			}
			int num = 0;
			for (int i = 0; i <= 255; i++) {
				array3 [i] = false;
			}
			for (int i = 0; i <= 65536; i++) {
				ftab [i] = 0;
			}
			int num2 = block [0];
			for (int i = 0; i <= last; i++) {
				int num3 = block [i + 1];
				ftab [(num2 << 8) + num3]++;
				num2 = num3;
			}
			for (int i = 1; i <= 65536; i++) {
				ftab [i] += ftab [i - 1];
			}
			num2 = block [1];
			int num4;
			for (int i = 0; i < last; i++) {
				int num3 = block [i + 2];
				num4 = (num2 << 8) + num3;
				num2 = num3;
				ftab [num4]--;
				zptr [ftab [num4]] = i;
			}
			num4 = (block [last + 1] << 8) + block [1];
			ftab [num4]--;
			zptr [ftab [num4]] = last;
			for (int i = 0; i <= 255; i++) {
				array [i] = i;
			}
			int num5 = 1;
			do {
				num5 = 3 * num5 + 1;
			} while (num5 <= 256);
			do {
				num5 /= 3;
				for (int i = num5; i <= 255; i++) {
					int num6 = array [i];
					num4 = i;
					while (ftab [array [num4 - num5] + 1 << 8] - ftab [array [num4 - num5] << 8] > ftab [num6 + 1 << 8] - ftab [num6 << 8]) {
						array [num4] = array [num4 - num5];
						num4 -= num5;
						if (num4 <= num5 - 1) {
							break;
						}
					}
					array [num4] = num6;
				}
			} while (num5 != 1);
			for (int i = 0; i <= 255; i++) {
				int num7 = array [i];
				for (num4 = 0; num4 <= 255; num4++) {
					int num8 = (num7 << 8) + num4;
					if ((ftab [num8] & 0x200000) == 2097152) {
						continue;
					}
					int num9 = ftab [num8] & -2097153;
					int num10 = (ftab [num8 + 1] & -2097153) - 1;
					if (num10 > num9) {
						QSort3 (num9, num10, 2);
						num += num10 - num9 + 1;
						if (workDone > workLimit && firstAttempt) {
							return;
						}
					}
					ftab [num8] |= 2097152;
				}
				array3 [num7] = true;
				if (i < 255) {
					int num11 = ftab [num7 << 8] & -2097153;
					int num12 = (ftab [num7 + 1 << 8] & -2097153) - num11;
					int j;
					for (j = 0; num12 >> j > 65534; j++) {
					}
					for (num4 = 0; num4 < num12; num4++) {
						int num13 = zptr [num11 + num4];
						int num14 = num4 >> j;
						quadrant [num13] = num14;
						if (num13 < 20) {
							quadrant [num13 + last + 1] = num14;
						}
					}
					if (num12 - 1 >> j > 65535) {
						Panic ();
					}
				}
				for (num4 = 0; num4 <= 255; num4++) {
					array2 [num4] = ftab [(num4 << 8) + num7] & -2097153;
				}
				for (num4 = ftab [num7 << 8] & -2097153; num4 < (ftab [num7 + 1 << 8] & -2097153); num4++) {
					num2 = block [zptr [num4]];
					if (!array3 [num2]) {
						zptr [array2 [num2]] = ((zptr [num4] != 0) ? (zptr [num4] - 1) : last);
						array2 [num2]++;
					}
				}
				for (num4 = 0; num4 <= 255; num4++) {
					ftab [(num4 << 8) + num7] |= 2097152;
				}
			}
		}

		private void RandomiseBlock ()
		{
			int num = 0;
			int num2 = 0;
			for (int i = 0; i < 256; i++) {
				inUse [i] = false;
			}
			for (int i = 0; i <= last; i++) {
				if (num == 0) {
					num = BZip2Constants.RandomNumbers [num2];
					num2++;
					if (num2 == 512) {
						num2 = 0;
					}
				}
				num--;
				block [i + 1] ^= ((num == 1) ? ((byte)1) : ((byte)0));
				block [i + 1] &= byte.MaxValue;
				inUse [block [i + 1]] = true;
			}
		}

		private void DoReversibleTransformation ()
		{
			workLimit = workFactor * last;
			workDone = 0;
			blockRandomised = false;
			firstAttempt = true;
			MainSort ();
			if (workDone > workLimit && firstAttempt) {
				RandomiseBlock ();
				workLimit = (workDone = 0);
				blockRandomised = true;
				firstAttempt = false;
				MainSort ();
			}
			origPtr = -1;
			for (int i = 0; i <= last; i++) {
				if (zptr [i] == 0) {
					origPtr = i;
					break;
				}
			}
			if (origPtr == -1) {
				Panic ();
			}
		}

		private bool FullGtU (int i1, int i2)
		{
			byte b = block [i1 + 1];
			byte b2 = block [i2 + 1];
			if (b != b2) {
				return b > b2;
			}
			i1++;
			i2++;
			b = block [i1 + 1];
			b2 = block [i2 + 1];
			if (b != b2) {
				return b > b2;
			}
			i1++;
			i2++;
			b = block [i1 + 1];
			b2 = block [i2 + 1];
			if (b != b2) {
				return b > b2;
			}
			i1++;
			i2++;
			b = block [i1 + 1];
			b2 = block [i2 + 1];
			if (b != b2) {
				return b > b2;
			}
			i1++;
			i2++;
			b = block [i1 + 1];
			b2 = block [i2 + 1];
			if (b != b2) {
				return b > b2;
			}
			i1++;
			i2++;
			b = block [i1 + 1];
			b2 = block [i2 + 1];
			if (b != b2) {
				return b > b2;
			}
			i1++;
			i2++;
			int num = last + 1;
			do {
				b = block [i1 + 1];
				b2 = block [i2 + 1];
				if (b != b2) {
					return b > b2;
				}
				int num2 = quadrant [i1];
				int num3 = quadrant [i2];
				if (num2 != num3) {
					return num2 > num3;
				}
				i1++;
				i2++;
				b = block [i1 + 1];
				b2 = block [i2 + 1];
				if (b != b2) {
					return b > b2;
				}
				num2 = quadrant [i1];
				num3 = quadrant [i2];
				if (num2 != num3) {
					return num2 > num3;
				}
				i1++;
				i2++;
				b = block [i1 + 1];
				b2 = block [i2 + 1];
				if (b != b2) {
					return b > b2;
				}
				num2 = quadrant [i1];
				num3 = quadrant [i2];
				if (num2 != num3) {
					return num2 > num3;
				}
				i1++;
				i2++;
				b = block [i1 + 1];
				b2 = block [i2 + 1];
				if (b != b2) {
					return b > b2;
				}
				num2 = quadrant [i1];
				num3 = quadrant [i2];
				if (num2 != num3) {
					return num2 > num3;
				}
				i1++;
				i2++;
				if (i1 > last) {
					i1 -= last;
					i1--;
				}
				if (i2 > last) {
					i2 -= last;
					i2--;
				}
				num -= 4;
				workDone++;
			} while (num >= 0);
			return false;
		}

		private void AllocateCompressStructures ()
		{
			int num = 100000 * blockSize100k;
			block = new byte[num + 1 + 20];
			quadrant = new int[num + 20];
			zptr = new int[num];
			ftab = new int[65537];
			if (block == null || quadrant == null || zptr == null || ftab == null) {
			}
			szptr = new short[2 * num];
		}

		private void GenerateMTFValues ()
		{
			char[] array = new char[256];
			MakeMaps ();
			int num = nInUse + 1;
			for (int i = 0; i <= num; i++) {
				mtfFreq [i] = 0;
			}
			int num2 = 0;
			int num3 = 0;
			for (int i = 0; i < nInUse; i++) {
				array [i] = (char)i;
			}
			for (int i = 0; i <= last; i++) {
				char c = unseqToSeq [block [zptr [i]]];
				int num4 = 0;
				char c2 = array [num4];
				while (c != c2) {
					num4++;
					char c3 = c2;
					c2 = array [num4];
					array [num4] = c3;
				}
				array [0] = c2;
				if (num4 == 0) {
					num3++;
					continue;
				}
				if (num3 > 0) {
					num3--;
					while (true) {
						switch (num3 % 2) {
						case 0:
							szptr [num2] = 0;
							num2++;
							mtfFreq [0]++;
							break;
						case 1:
							szptr [num2] = 1;
							num2++;
							mtfFreq [1]++;
							break;
						}
						if (num3 < 2) {
							break;
						}
						num3 = (num3 - 2) / 2;
					}
					num3 = 0;
				}
				szptr [num2] = (short)(num4 + 1);
				num2++;
				mtfFreq [num4 + 1]++;
			}
			if (num3 > 0) {
				num3--;
				while (true) {
					switch (num3 % 2) {
					case 0:
						szptr [num2] = 0;
						num2++;
						mtfFreq [0]++;
						break;
					case 1:
						szptr [num2] = 1;
						num2++;
						mtfFreq [1]++;
						break;
					}
					if (num3 < 2) {
						break;
					}
					num3 = (num3 - 2) / 2;
				}
			}
			szptr [num2] = (short)num;
			num2++;
			mtfFreq [num]++;
			nMTF = num2;
		}

		private static void Panic ()
		{
			throw new BZip2Exception ("BZip2 output stream panic");
		}

		private static void HbMakeCodeLengths (char[] len, int[] freq, int alphaSize, int maxLen)
		{
			int[] array = new int[260];
			int[] array2 = new int[516];
			int[] array3 = new int[516];
			for (int i = 0; i < alphaSize; i++) {
				array2 [i + 1] = ((freq [i] == 0) ? 1 : freq [i]) << 8;
			}
			while (true) {
				int num = alphaSize;
				int num2 = 0;
				array [0] = 0;
				array2 [0] = 0;
				array3 [0] = -2;
				for (int j = 1; j <= alphaSize; j++) {
					array3 [j] = -1;
					num2++;
					array [num2] = j;
					int num3 = num2;
					int num4 = array [num3];
					while (array2 [num4] < array2 [array [num3 >> 1]]) {
						array [num3] = array [num3 >> 1];
						num3 >>= 1;
					}
					array [num3] = num4;
				}
				if (num2 >= 260) {
					Panic ();
				}
				while (num2 > 1) {
					int num5 = array [1];
					array [1] = array [num2];
					num2--;
					int num6 = 1;
					int num7 = 0;
					int num8 = array [num6];
					while (true) {
						num7 = num6 << 1;
						if (num7 > num2) {
							break;
						}
						if (num7 < num2 && array2 [array [num7 + 1]] < array2 [array [num7]]) {
							num7++;
						}
						if (array2 [num8] < array2 [array [num7]]) {
							break;
						}
						array [num6] = array [num7];
						num6 = num7;
					}
					array [num6] = num8;
					int num9 = array [1];
					array [1] = array [num2];
					num2--;
					num6 = 1;
					num7 = 0;
					num8 = array [num6];
					while (true) {
						num7 = num6 << 1;
						if (num7 > num2) {
							break;
						}
						if (num7 < num2 && array2 [array [num7 + 1]] < array2 [array [num7]]) {
							num7++;
						}
						if (array2 [num8] < array2 [array [num7]]) {
							break;
						}
						array [num6] = array [num7];
						num6 = num7;
					}
					array [num6] = num8;
					num++;
					array3 [num5] = (array3 [num9] = num);
					array2 [num] = (int)((array2 [num5] & 0xFFFFFF00u) + (array2 [num9] & 0xFFFFFF00u)) | (1 + (((array2 [num5] & 0xFF) <= (array2 [num9] & 0xFF)) ? (array2 [num9] & 0xFF) : (array2 [num5] & 0xFF)));
					array3 [num] = -1;
					num2++;
					array [num2] = num;
					num6 = num2;
					num8 = array [num6];
					while (array2 [num8] < array2 [array [num6 >> 1]]) {
						array [num6] = array [num6 >> 1];
						num6 >>= 1;
					}
					array [num6] = num8;
				}
				if (num >= 516) {
					Panic ();
				}
				bool flag = false;
				for (int k = 1; k <= alphaSize; k++) {
					int num10 = 0;
					int num11 = k;
					while (array3 [num11] >= 0) {
						num11 = array3 [num11];
						num10++;
					}
					len [k - 1] = (char)num10;
					if (num10 > maxLen) {
						flag = true;
					}
				}
				if (!flag) {
					break;
				}
				for (int l = 1; l < alphaSize; l++) {
					int num10 = array2 [l] >> 8;
					num10 = 1 + num10 / 2;
					array2 [l] = num10 << 8;
				}
			}
		}

		private static void HbAssignCodes (int[] code, char[] length, int minLen, int maxLen, int alphaSize)
		{
			int num = 0;
			for (int i = minLen; i <= maxLen; i++) {
				for (int j = 0; j < alphaSize; j++) {
					if (length [j] == i) {
						code [j] = num;
						num++;
					}
				}
				num <<= 1;
			}
		}

		private static byte Med3 (byte a, byte b, byte c)
		{
			if (a > b) {
				byte b2 = a;
				a = b;
				b = b2;
			}
			if (b > c) {
				byte b2 = b;
				b = c;
				c = b2;
			}
			if (a > b) {
				b = a;
			}
			return b;
		}
	}
}
namespace ICSharpCode.SharpZipLib.Checksums
{
	public sealed class Adler32 : IChecksum
	{
		private const uint BASE = 65521u;

		private uint checksum;

		public long Value => checksum;

		public Adler32 ()
		{
			Reset ();
		}

		public void Reset ()
		{
			checksum = 1u;
		}

		public void Update (int value)
		{
			uint num = checksum & 0xFFFFu;
			uint num2 = checksum >> 16;
			num = (uint)((int)num + (value & 0xFF)) % 65521u;
			num2 = (num + num2) % 65521;
			checksum = (num2 << 16) + num;
		}

		public void Update (byte[] buffer)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			Update (buffer, 0, buffer.Length);
		}

		public void Update (byte[] buffer, int offset, int count)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (offset < 0) {
				throw new ArgumentOutOfRangeException ("offset", "cannot be negative");
			}
			if (count < 0) {
				throw new ArgumentOutOfRangeException ("count", "cannot be negative");
			}
			if (offset >= buffer.Length) {
				throw new ArgumentOutOfRangeException ("offset", "not a valid index into buffer");
			}
			if (offset + count > buffer.Length) {
				throw new ArgumentOutOfRangeException ("count", "exceeds buffer size");
			}
			uint num = checksum & 0xFFFFu;
			uint num2 = checksum >> 16;
			while (count > 0) {
				int num3 = 3800;
				if (num3 > count) {
					num3 = count;
				}
				count -= num3;
				while (--num3 >= 0) {
					num += (uint)(buffer [offset++] & 0xFF);
					num2 += num;
				}
				num %= 65521;
				num2 %= 65521;
			}
			checksum = (num2 << 16) | num;
		}
	}
	public sealed class Crc32 : IChecksum
	{
		private const uint CrcSeed = uint.MaxValue;

		private static readonly uint[] CrcTable = new uint[256] {
			0u, 1996959894u, 3993919788u, 2567524794u, 124634137u, 1886057615u, 3915621685u, 2657392035u, 249268274u, 2044508324u,
			3772115230u, 2547177864u, 162941995u, 2125561021u, 3887607047u, 2428444049u, 498536548u, 1789927666u, 4089016648u, 2227061214u,
			450548861u, 1843258603u, 4107580753u, 2211677639u, 325883990u, 1684777152u, 4251122042u, 2321926636u, 335633487u, 1661365465u,
			4195302755u, 2366115317u, 997073096u, 1281953886u, 3579855332u, 2724688242u, 1006888145u, 1258607687u, 3524101629u, 2768942443u,
			901097722u, 1119000684u, 3686517206u, 2898065728u, 853044451u, 1172266101u, 3705015759u, 2882616665u, 651767980u, 1373503546u,
			3369554304u, 3218104598u, 565507253u, 1454621731u, 3485111705u, 3099436303u, 671266974u, 1594198024u, 3322730930u, 2970347812u,
			795835527u, 1483230225u, 3244367275u, 3060149565u, 1994146192u, 31158534u, 2563907772u, 4023717930u, 1907459465u, 112637215u,
			2680153253u, 3904427059u, 2013776290u, 251722036u, 2517215374u, 3775830040u, 2137656763u, 141376813u, 2439277719u, 3865271297u,
			1802195444u, 476864866u, 2238001368u, 4066508878u, 1812370925u, 453092731u, 2181625025u, 4111451223u, 1706088902u, 314042704u,
			2344532202u, 4240017532u, 1658658271u, 366619977u, 2362670323u, 4224994405u, 1303535960u, 984961486u, 2747007092u, 3569037538u,
			1256170817u, 1037604311u, 2765210733u, 3554079995u, 1131014506u, 879679996u, 2909243462u, 3663771856u, 1141124467u, 855842277u,
			2852801631u, 3708648649u, 1342533948u, 654459306u, 3188396048u, 3373015174u, 1466479909u, 544179635u, 3110523913u, 3462522015u,
			1591671054u, 702138776u, 2966460450u, 3352799412u, 1504918807u, 783551873u, 3082640443u, 3233442989u, 3988292384u, 2596254646u,
			62317068u, 1957810842u, 3939845945u, 2647816111u, 81470997u, 1943803523u, 3814918930u, 2489596804u, 225274430u, 2053790376u,
			3826175755u, 2466906013u, 167816743u, 2097651377u, 4027552580u, 2265490386u, 503444072u, 1762050814u, 4150417245u, 2154129355u,
			426522225u, 1852507879u, 4275313526u, 2312317920u, 282753626u, 1742555852u, 4189708143u, 2394877945u, 397917763u, 1622183637u,
			3604390888u, 2714866558u, 953729732u, 1340076626u, 3518719985u, 2797360999u, 1068828381u, 1219638859u, 3624741850u, 2936675148u,
			906185462u, 1090812512u, 3747672003u, 2825379669u, 829329135u, 1181335161u, 3412177804u, 3160834842u, 628085408u, 1382605366u,
			3423369109u, 3138078467u, 570562233u, 1426400815u, 3317316542u, 2998733608u, 733239954u, 1555261956u, 3268935591u, 3050360625u,
			752459403u, 1541320221u, 2607071920u, 3965973030u, 1969922972u, 40735498u, 2617837225u, 3943577151u, 1913087877u, 83908371u,
			2512341634u, 3803740692u, 2075208622u, 213261112u, 2463272603u, 3855990285u, 2094854071u, 198958881u, 2262029012u, 4057260610u,
			1759359992u, 534414190u, 2176718541u, 4139329115u, 1873836001u, 414664567u, 2282248934u, 4279200368u, 1711684554u, 285281116u,
			2405801727u, 4167216745u, 1634467795u, 376229701u, 2685067896u, 3608007406u, 1308918612u, 956543938u, 2808555105u, 3495958263u,
			1231636301u, 1047427035u, 2932959818u, 3654703836u, 1088359270u, 936918000u, 2847714899u, 3736837829u, 1202900863u, 817233897u,
			3183342108u, 3401237130u, 1404277552u, 615818150u, 3134207493u, 3453421203u, 1423857449u, 601450431u, 3009837614u, 3294710456u,
			1567103746u, 711928724u, 3020668471u, 3272380065u, 1510334235u, 755167117u
		};

		private uint crc;

		public long Value {
			get {
				return crc;
			}
			set {
				crc = (uint)value;
			}
		}

		internal static uint ComputeCrc32 (uint oldCrc, byte value)
		{
			return CrcTable [(oldCrc ^ value) & 0xFF] ^ (oldCrc >> 8);
		}

		public void Reset ()
		{
			crc = 0u;
		}

		public void Update (int value)
		{
			crc ^= uint.MaxValue;
			crc = CrcTable [(crc ^ value) & 0xFF] ^ (crc >> 8);
			crc ^= uint.MaxValue;
		}

		public void Update (byte[] buffer)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			Update (buffer, 0, buffer.Length);
		}

		public void Update (byte[] buffer, int offset, int count)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (count < 0) {
				throw new ArgumentOutOfRangeException ("count", "Count cannot be less than zero");
			}
			if (offset < 0 || offset + count > buffer.Length) {
				throw new ArgumentOutOfRangeException ("offset");
			}
			crc ^= uint.MaxValue;
			while (--count >= 0) {
				crc = CrcTable [(crc ^ buffer [offset++]) & 0xFF] ^ (crc >> 8);
			}
			crc ^= uint.MaxValue;
		}
	}
	public interface IChecksum
	{
		long Value { get; }

		void Reset ();

		void Update (int value);

		void Update (byte[] buffer);

		void Update (byte[] buffer, int offset, int count);
	}
	public class StrangeCRC : IChecksum
	{
		private static readonly uint[] crc32Table = new uint[256] {
			0u, 79764919u, 159529838u, 222504665u, 319059676u, 398814059u, 445009330u, 507990021u, 638119352u, 583659535u,
			797628118u, 726387553u, 890018660u, 835552979u, 1015980042u, 944750013u, 1276238704u, 1221641927u, 1167319070u, 1095957929u,
			1595256236u, 1540665371u, 1452775106u, 1381403509u, 1780037320u, 1859660671u, 1671105958u, 1733955601u, 2031960084u, 2111593891u,
			1889500026u, 1952343757u, 2552477408u, 2632100695u, 2443283854u, 2506133561u, 2334638140u, 2414271883u, 2191915858u, 2254759653u,
			3190512472u, 3135915759u, 3081330742u, 3009969537u, 2905550212u, 2850959411u, 2762807018u, 2691435357u, 3560074640u, 3505614887u,
			3719321342u, 3648080713u, 3342211916u, 3287746299u, 3467911202u, 3396681109u, 4063920168u, 4143685023u, 4223187782u, 4286162673u,
			3779000052u, 3858754371u, 3904687514u, 3967668269u, 881225847u, 809987520u, 1023691545u, 969234094u, 662832811u, 591600412u,
			771767749u, 717299826u, 311336399u, 374308984u, 453813921u, 533576470u, 25881363u, 88864420u, 134795389u, 214552010u,
			2023205639u, 2086057648u, 1897238633u, 1976864222u, 1804852699u, 1867694188u, 1645340341u, 1724971778u, 1587496639u, 1516133128u,
			1461550545u, 1406951526u, 1302016099u, 1230646740u, 1142491917u, 1087903418u, 2896545431u, 2825181984u, 2770861561u, 2716262478u,
			3215044683u, 3143675388u, 3055782693u, 3001194130u, 2326604591u, 2389456536u, 2200899649u, 2280525302u, 2578013683u, 2640855108u,
			2418763421u, 2498394922u, 3769900519u, 3832873040u, 3912640137u, 3992402750u, 4088425275u, 4151408268u, 4197601365u, 4277358050u,
			3334271071u, 3263032808u, 3476998961u, 3422541446u, 3585640067u, 3514407732u, 3694837229u, 3640369242u, 1762451694u, 1842216281u,
			1619975040u, 1682949687u, 2047383090u, 2127137669u, 1938468188u, 2001449195u, 1325665622u, 1271206113u, 1183200824u, 1111960463u,
			1543535498u, 1489069629u, 1434599652u, 1363369299u, 622672798u, 568075817u, 748617968u, 677256519u, 907627842u, 853037301u,
			1067152940u, 995781531u, 51762726u, 131386257u, 177728840u, 240578815u, 269590778u, 349224269u, 429104020u, 491947555u,
			4046411278u, 4126034873u, 4172115296u, 4234965207u, 3794477266u, 3874110821u, 3953728444u, 4016571915u, 3609705398u, 3555108353u,
			3735388376u, 3664026991u, 3290680682u, 3236090077u, 3449943556u, 3378572211u, 3174993278u, 3120533705u, 3032266256u, 2961025959u,
			2923101090u, 2868635157u, 2813903052u, 2742672763u, 2604032198u, 2683796849u, 2461293480u, 2524268063u, 2284983834u, 2364738477u,
			2175806836u, 2238787779u, 1569362073u, 1498123566u, 1409854455u, 1355396672u, 1317987909u, 1246755826u, 1192025387u, 1137557660u,
			2072149281u, 2135122070u, 1912620623u, 1992383480u, 1753615357u, 1816598090u, 1627664531u, 1707420964u, 295390185u, 358241886u,
			404320391u, 483945776u, 43990325u, 106832002u, 186451547u, 266083308u, 932423249u, 861060070u, 1041341759u, 986742920u,
			613929101u, 542559546u, 756411363u, 701822548u, 3316196985u, 3244833742u, 3425377559u, 3370778784u, 3601682597u, 3530312978u,
			3744426955u, 3689838204u, 3819031489u, 3881883254u, 3928223919u, 4007849240u, 4037393693u, 4100235434u, 4180117107u, 4259748804u,
			2310601993u, 2373574846u, 2151335527u, 2231098320u, 2596047829u, 2659030626u, 2470359227u, 2550115596u, 2947551409u, 2876312838u,
			2788305887u, 2733848168u, 3165939309u, 3094707162u, 3040238851u, 2985771188u
		};

		private int globalCrc;

		public long Value => ~globalCrc;

		public StrangeCRC ()
		{
			Reset ();
		}

		public void Reset ()
		{
			globalCrc = -1;
		}

		public void Update (int value)
		{
			int num = (globalCrc >> 24) ^ value;
			if (num < 0) {
				num = 256 + num;
			}
			globalCrc = (int)((globalCrc << 8) ^ crc32Table [num]);
		}

		public void Update (byte[] buffer)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			Update (buffer, 0, buffer.Length);
		}

		public void Update (byte[] buffer, int offset, int count)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (offset < 0) {
				throw new ArgumentOutOfRangeException ("offset", "cannot be less than zero");
			}
			if (count < 0) {
				throw new ArgumentOutOfRangeException ("count", "cannot be less than zero");
			}
			if (offset + count > buffer.Length) {
				throw new ArgumentOutOfRangeException ("count");
			}
			for (int i = 0; i < count; i++) {
				Update (buffer [offset++]);
			}
		}
	}
}
namespace ICSharpCode.SharpZipLib.Core
{
	public class ScanEventArgs : EventArgs
	{
		private string name_;

		private bool continueRunning_ = true;

		public string Name => name_;

		public bool ContinueRunning {
			get {
				return continueRunning_;
			}
			set {
				continueRunning_ = value;
			}
		}

		public ScanEventArgs (string name)
		{
			name_ = name;
		}
	}
	public class ProgressEventArgs : EventArgs
	{
		private string name_;

		private long processed_;

		private long target_;

		private bool continueRunning_ = true;

		public string Name => name_;

		public bool ContinueRunning {
			get {
				return continueRunning_;
			}
			set {
				continueRunning_ = value;
			}
		}

		public float PercentComplete {
			get {
				if (target_ <= 0) {
					return 0f;
				}
				return (float)processed_ / (float)target_ * 100f;
			}
		}

		public long Processed => processed_;

		public long Target => target_;

		public ProgressEventArgs (string name, long processed, long target)
		{
			name_ = name;
			processed_ = processed;
			target_ = target;
		}
	}
	public class DirectoryEventArgs : ScanEventArgs
	{
		private bool hasMatchingFiles_;

		public bool HasMatchingFiles => hasMatchingFiles_;

		public DirectoryEventArgs (string name, bool hasMatchingFiles)
			: base (name)
		{
			hasMatchingFiles_ = hasMatchingFiles;
		}
	}
	public class ScanFailureEventArgs : EventArgs
	{
		private string name_;

		private Exception exception_;

		private bool continueRunning_;

		public string Name => name_;

		public Exception Exception => exception_;

		public bool ContinueRunning {
			get {
				return continueRunning_;
			}
			set {
				continueRunning_ = value;
			}
		}

		public ScanFailureEventArgs (string name, Exception e)
		{
			name_ = name;
			exception_ = e;
			continueRunning_ = true;
		}
	}
	public delegate void ProcessDirectoryHandler (object sender, DirectoryEventArgs e);
	public delegate void ProcessFileHandler (object sender, ScanEventArgs e);
	public delegate void ProgressHandler (object sender, ProgressEventArgs e);
	public delegate void CompletedFileHandler (object sender, ScanEventArgs e);
	public delegate void DirectoryFailureHandler (object sender, ScanFailureEventArgs e);
	public delegate void FileFailureHandler (object sender, ScanFailureEventArgs e);
	public class FileSystemScanner
	{
		public ProcessDirectoryHandler ProcessDirectory;

		public ProcessFileHandler ProcessFile;

		public CompletedFileHandler CompletedFile;

		public DirectoryFailureHandler DirectoryFailure;

		public FileFailureHandler FileFailure;

		private IScanFilter fileFilter_;

		private IScanFilter directoryFilter_;

		private bool alive_;

		public FileSystemScanner (string filter)
		{
			fileFilter_ = new PathFilter (filter);
		}

		public FileSystemScanner (string fileFilter, string directoryFilter)
		{
			fileFilter_ = new PathFilter (fileFilter);
			directoryFilter_ = new PathFilter (directoryFilter);
		}

		public FileSystemScanner (IScanFilter fileFilter)
		{
			fileFilter_ = fileFilter;
		}

		public FileSystemScanner (IScanFilter fileFilter, IScanFilter directoryFilter)
		{
			fileFilter_ = fileFilter;
			directoryFilter_ = directoryFilter;
		}

		private bool OnDirectoryFailure (string directory, Exception e)
		{
			DirectoryFailureHandler directoryFailure = DirectoryFailure;
			bool flag = directoryFailure != null;
			if (flag) {
				ScanFailureEventArgs scanFailureEventArgs = new ScanFailureEventArgs (directory, e);
				directoryFailure (this, scanFailureEventArgs);
				alive_ = scanFailureEventArgs.ContinueRunning;
			}
			return flag;
		}

		private bool OnFileFailure (string file, Exception e)
		{
			FileFailureHandler fileFailure = FileFailure;
			bool flag = fileFailure != null;
			if (flag) {
				ScanFailureEventArgs scanFailureEventArgs = new ScanFailureEventArgs (file, e);
				FileFailure (this, scanFailureEventArgs);
				alive_ = scanFailureEventArgs.ContinueRunning;
			}
			return flag;
		}

		private void OnProcessFile (string file)
		{
			ProcessFileHandler processFile = ProcessFile;
			if (processFile != null) {
				ScanEventArgs scanEventArgs = new ScanEventArgs (file);
				processFile (this, scanEventArgs);
				alive_ = scanEventArgs.ContinueRunning;
			}
		}

		private void OnCompleteFile (string file)
		{
			CompletedFileHandler completedFile = CompletedFile;
			if (completedFile != null) {
				ScanEventArgs scanEventArgs = new ScanEventArgs (file);
				completedFile (this, scanEventArgs);
				alive_ = scanEventArgs.ContinueRunning;
			}
		}

		private void OnProcessDirectory (string directory, bool hasMatchingFiles)
		{
			ProcessDirectoryHandler processDirectory = ProcessDirectory;
			if (processDirectory != null) {
				DirectoryEventArgs directoryEventArgs = new DirectoryEventArgs (directory, hasMatchingFiles);
				processDirectory (this, directoryEventArgs);
				alive_ = directoryEventArgs.ContinueRunning;
			}
		}

		public void Scan (string directory, bool recurse)
		{
			alive_ = true;
			ScanDir (directory, recurse);
		}

		private void ScanDir (string directory, bool recurse)
		{
			try {
				string[] files = Directory.GetFiles (directory);
				bool flag = false;
				for (int i = 0; i < files.Length; i++) {
					if (!fileFilter_.IsMatch (files [i])) {
						files [i] = null;
					} else {
						flag = true;
					}
				}
				OnProcessDirectory (directory, flag);
				if (alive_ && flag) {
					string[] array = files;
					foreach (string text in array) {
						try {
							if (text != null) {
								OnProcessFile (text);
								if (!alive_) {
									break;
								}
							}
						} catch (Exception e) {
							if (!OnFileFailure (text, e)) {
								throw;
							}
						}
					}
				}
			} catch (Exception e2) {
				if (!OnDirectoryFailure (directory, e2)) {
					throw;
				}
			}
			if (!alive_ || !recurse) {
				return;
			}
			try {
				string[] directories = Directory.GetDirectories (directory);
				string[] array2 = directories;
				foreach (string text2 in array2) {
					if (directoryFilter_ == null || directoryFilter_.IsMatch (text2)) {
						ScanDir (text2, recurse: true);
						if (!alive_) {
							break;
						}
					}
				}
			} catch (Exception e3) {
				if (!OnDirectoryFailure (directory, e3)) {
					throw;
				}
			}
		}
	}
	public interface INameTransform
	{
		string TransformFile (string name);

		string TransformDirectory (string name);
	}
	public interface IScanFilter
	{
		bool IsMatch (string name);
	}
	public class NameFilter : IScanFilter
	{
		private string filter_;

		private ArrayList inclusions_;

		private ArrayList exclusions_;

		public NameFilter (string filter)
		{
			filter_ = filter;
			inclusions_ = new ArrayList ();
			exclusions_ = new ArrayList ();
			Compile ();
		}

		public static bool IsValidExpression (string expression)
		{
			bool result = true;
			try {
				Regex regex = new Regex (expression, RegexOptions.IgnoreCase | RegexOptions.Singleline);
			} catch (ArgumentException) {
				result = false;
			}
			return result;
		}

		public static bool IsValidFilterExpression (string toTest)
		{
			if (toTest == null) {
				throw new ArgumentNullException ("toTest");
			}
			bool result = true;
			try {
				string[] array = SplitQuoted (toTest);
				for (int i = 0; i < array.Length; i++) {
					if (array [i] != null && array [i].Length > 0) {
						string pattern = ((array [i] [0] == '+') ? array [i].Substring (1, array [i].Length - 1) : ((array [i] [0] != '-') ? array [i] : array [i].Substring (1, array [i].Length - 1)));
						Regex regex = new Regex (pattern, RegexOptions.IgnoreCase | RegexOptions.Singleline);
					}
				}
			} catch (ArgumentException) {
				result = false;
			}
			return result;
		}

		public static string[] SplitQuoted (string original)
		{
			char c = '\\';
			char[] array = new char[1] { ';' };
			ArrayList arrayList = new ArrayList ();
			if (original != null && original.Length > 0) {
				int num = -1;
				StringBuilder stringBuilder = new StringBuilder ();
				while (num < original.Length) {
					num++;
					if (num >= original.Length) {
						arrayList.Add (stringBuilder.ToString ());
					} else if (original [num] == c) {
						num++;
						if (num >= original.Length) {
							throw new ArgumentException ("Missing terminating escape character", "original");
						}
						if (Array.IndexOf (array, original [num]) < 0) {
							stringBuilder.Append (c);
						}
						stringBuilder.Append (original [num]);
					} else if (Array.IndexOf (array, original [num]) >= 0) {
						arrayList.Add (stringBuilder.ToString ());
						stringBuilder.Length = 0;
					} else {
						stringBuilder.Append (original [num]);
					}
				}
			}
			return (string[])arrayList.ToArray (typeof(string));
		}

		public override string ToString ()
		{
			return filter_;
		}

		public bool IsIncluded (string name)
		{
			bool result = false;
			if (inclusions_.Count == 0) {
				result = true;
			} else {
				foreach (Regex item in inclusions_) {
					if (item.IsMatch (name)) {
						result = true;
						break;
					}
				}
			}
			return result;
		}

		public bool IsExcluded (string name)
		{
			bool result = false;
			foreach (Regex item in exclusions_) {
				if (item.IsMatch (name)) {
					result = true;
					break;
				}
			}
			return result;
		}

		public bool IsMatch (string name)
		{
			return IsIncluded (name) && !IsExcluded (name);
		}

		private void Compile ()
		{
			if (filter_ == null) {
				return;
			}
			string[] array = SplitQuoted (filter_);
			for (int i = 0; i < array.Length; i++) {
				if (array [i] != null && array [i].Length > 0) {
					bool flag = array [i] [0] != '-';
					string pattern = ((array [i] [0] == '+') ? array [i].Substring (1, array [i].Length - 1) : ((array [i] [0] != '-') ? array [i] : array [i].Substring (1, array [i].Length - 1)));
					if (flag) {
						inclusions_.Add (new Regex (pattern, RegexOptions.IgnoreCase | RegexOptions.Singleline));
					} else {
						exclusions_.Add (new Regex (pattern, RegexOptions.IgnoreCase | RegexOptions.Singleline));
					}
				}
			}
		}
	}
	public class PathFilter : IScanFilter
	{
		private NameFilter nameFilter_;

		public PathFilter (string filter)
		{
			nameFilter_ = new NameFilter (filter);
		}

		public virtual bool IsMatch (string name)
		{
			bool result = false;
			if (name != null) {
				string name2 = ((name.Length <= 0) ? string.Empty : Path.GetFullPath (name));
				result = nameFilter_.IsMatch (name2);
			}
			return result;
		}
	}
	public class ExtendedPathFilter : PathFilter
	{
		private long minSize_;

		private long maxSize_ = long.MaxValue;

		private DateTime minDate_ = DateTime.MinValue;

		private DateTime maxDate_ = DateTime.MaxValue;

		public long MinSize {
			get {
				return minSize_;
			}
			set {
				if (value < 0 || maxSize_ < value) {
					throw new ArgumentOutOfRangeException ("value");
				}
				minSize_ = value;
			}
		}

		public long MaxSize {
			get {
				return maxSize_;
			}
			set {
				if (value < 0 || minSize_ > value) {
					throw new ArgumentOutOfRangeException ("value");
				}
				maxSize_ = value;
			}
		}

		public DateTime MinDate {
			get {
				return minDate_;
			}
			set {
				if (value > maxDate_) {
					throw new ArgumentOutOfRangeException ("value", "Exceeds MaxDate");
				}
				minDate_ = value;
			}
		}

		public DateTime MaxDate {
			get {
				return maxDate_;
			}
			set {
				if (minDate_ > value) {
					throw new ArgumentOutOfRangeException ("value", "Exceeds MinDate");
				}
				maxDate_ = value;
			}
		}

		public ExtendedPathFilter (string filter, long minSize, long maxSize)
			: base (filter)
		{
			MinSize = minSize;
			MaxSize = maxSize;
		}

		public ExtendedPathFilter (string filter, DateTime minDate, DateTime maxDate)
			: base (filter)
		{
			MinDate = minDate;
			MaxDate = maxDate;
		}

		public ExtendedPathFilter (string filter, long minSize, long maxSize, DateTime minDate, DateTime maxDate)
			: base (filter)
		{
			MinSize = minSize;
			MaxSize = maxSize;
			MinDate = minDate;
			MaxDate = maxDate;
		}

		public override bool IsMatch (string name)
		{
			bool flag = base.IsMatch (name);
			if (flag) {
				FileInfo fileInfo = new FileInfo (name);
				flag = MinSize <= fileInfo.Length && MaxSize >= fileInfo.Length && MinDate <= fileInfo.LastWriteTime && MaxDate >= fileInfo.LastWriteTime;
			}
			return flag;
		}
	}
	[Obsolete ("Use ExtendedPathFilter instead")]
	public class NameAndSizeFilter : PathFilter
	{
		private long minSize_;

		private long maxSize_ = long.MaxValue;

		public long MinSize {
			get {
				return minSize_;
			}
			set {
				if (value < 0 || maxSize_ < value) {
					throw new ArgumentOutOfRangeException ("value");
				}
				minSize_ = value;
			}
		}

		public long MaxSize {
			get {
				return maxSize_;
			}
			set {
				if (value < 0 || minSize_ > value) {
					throw new ArgumentOutOfRangeException ("value");
				}
				maxSize_ = value;
			}
		}

		public NameAndSizeFilter (string filter, long minSize, long maxSize)
			: base (filter)
		{
			MinSize = minSize;
			MaxSize = maxSize;
		}

		public override bool IsMatch (string name)
		{
			bool flag = base.IsMatch (name);
			if (flag) {
				FileInfo fileInfo = new FileInfo (name);
				long length = fileInfo.Length;
				flag = MinSize <= length && MaxSize >= length;
			}
			return flag;
		}
	}
	public sealed class StreamUtils
	{
		private StreamUtils ()
		{
		}

		public static void ReadFully (Stream stream, byte[] buffer)
		{
			ReadFully (stream, buffer, 0, buffer.Length);
		}

		public static void ReadFully (Stream stream, byte[] buffer, int offset, int count)
		{
			if (stream == null) {
				throw new ArgumentNullException ("stream");
			}
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (offset < 0 || offset > buffer.Length) {
				throw new ArgumentOutOfRangeException ("offset");
			}
			if (count < 0 || offset + count > buffer.Length) {
				throw new ArgumentOutOfRangeException ("count");
			}
			while (count > 0) {
				int num = stream.Read (buffer, offset, count);
				if (num <= 0) {
					throw new EndOfStreamException ();
				}
				offset += num;
				count -= num;
			}
		}

		public static void Copy (Stream source, Stream destination, byte[] buffer)
		{
			if (source == null) {
				throw new ArgumentNullException ("source");
			}
			if (destination == null) {
				throw new ArgumentNullException ("destination");
			}
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (buffer.Length < 128) {
				throw new ArgumentException ("Buffer is too small", "buffer");
			}
			bool flag = true;
			while (flag) {
				int num = source.Read (buffer, 0, buffer.Length);
				if (num > 0) {
					destination.Write (buffer, 0, num);
					continue;
				}
				destination.Flush ();
				flag = false;
			}
		}

		public static void Copy (Stream source, Stream destination, byte[] buffer, ProgressHandler progressHandler, TimeSpan updateInterval, object sender, string name)
		{
			Copy (source, destination, buffer, progressHandler, updateInterval, sender, name, -1L);
		}

		public static void Copy (Stream source, Stream destination, byte[] buffer, ProgressHandler progressHandler, TimeSpan updateInterval, object sender, string name, long fixedTarget)
		{
			if (source == null) {
				throw new ArgumentNullException ("source");
			}
			if (destination == null) {
				throw new ArgumentNullException ("destination");
			}
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (buffer.Length < 128) {
				throw new ArgumentException ("Buffer is too small", "buffer");
			}
			if (progressHandler == null) {
				throw new ArgumentNullException ("progressHandler");
			}
			bool flag = true;
			DateTime now = DateTime.Now;
			long num = 0L;
			long target = 0L;
			if (fixedTarget >= 0) {
				target = fixedTarget;
			} else if (source.CanSeek) {
				target = source.Length - source.Position;
			}
			ProgressEventArgs e = new ProgressEventArgs (name, num, target);
			progressHandler (sender, e);
			bool flag2 = true;
			while (flag) {
				int num2 = source.Read (buffer, 0, buffer.Length);
				if (num2 > 0) {
					num += num2;
					flag2 = false;
					destination.Write (buffer, 0, num2);
				} else {
					destination.Flush ();
					flag = false;
				}
				if (DateTime.Now - now > updateInterval) {
					flag2 = true;
					now = DateTime.Now;
					e = new ProgressEventArgs (name, num, target);
					progressHandler (sender, e);
					flag = e.ContinueRunning;
				}
			}
			if (!flag2) {
				e = new ProgressEventArgs (name, num, target);
				progressHandler (sender, e);
			}
		}
	}
	public abstract class WindowsPathUtils
	{
		internal WindowsPathUtils ()
		{
		}

		public static string DropPathRoot (string path)
		{
			string text = path;
			if (path != null && path.Length > 0) {
				if (path [0] == '\\' || path [0] == '/') {
					if (path.Length > 1 && (path [1] == '\\' || path [1] == '/')) {
						int i = 2;
						int num = 2;
						for (; i <= path.Length; i++) {
							if ((path [i] == '\\' || path [i] == '/') && --num <= 0) {
								break;
							}
						}
						i++;
						text = ((i >= path.Length) ? string.Empty : path.Substring (i));
					}
				} else if (path.Length > 1 && path [1] == ':') {
					int count = 2;
					if (path.Length > 2 && (path [2] == '\\' || path [2] == '/')) {
						count = 3;
					}
					text = text.Remove (0, count);
				}
			}
			return text;
		}
	}
}
namespace ICSharpCode.SharpZipLib.Encryption
{
	public abstract class PkzipClassic : SymmetricAlgorithm
	{
		public static byte[] GenerateKeys (byte[] seed)
		{
			if (seed == null) {
				throw new ArgumentNullException ("seed");
			}
			if (seed.Length == 0) {
				throw new ArgumentException ("Length is zero", "seed");
			}
			uint[] array = new uint[3] { 305419896u, 591751049u, 878082192u };
			for (int i = 0; i < seed.Length; i++) {
				array [0] = Crc32.ComputeCrc32 (array [0], seed [i]);
				array [1] = array [1] + (byte)array [0];
				array [1] = array [1] * 134775813 + 1;
				array [2] = Crc32.ComputeCrc32 (array [2], (byte)(array [1] >> 24));
			}
			return new byte[12] {
				(byte)(array [0] & 0xFFu),
				(byte)((array [0] >> 8) & 0xFFu),
				(byte)((array [0] >> 16) & 0xFFu),
				(byte)((array [0] >> 24) & 0xFFu),
				(byte)(array [1] & 0xFFu),
				(byte)((array [1] >> 8) & 0xFFu),
				(byte)((array [1] >> 16) & 0xFFu),
				(byte)((array [1] >> 24) & 0xFFu),
				(byte)(array [2] & 0xFFu),
				(byte)((array [2] >> 8) & 0xFFu),
				(byte)((array [2] >> 16) & 0xFFu),
				(byte)((array [2] >> 24) & 0xFFu)
			};
		}
	}
	internal class PkzipClassicCryptoBase
	{
		private uint[] keys;

		protected byte TransformByte ()
		{
			uint num = (keys [2] & 0xFFFFu) | 2u;
			return (byte)(num * (num ^ 1) >> 8);
		}

		protected void SetKeys (byte[] keyData)
		{
			if (keyData == null) {
				throw new ArgumentNullException ("keyData");
			}
			if (keyData.Length != 12) {
				throw new InvalidOperationException ("Key length is not valid");
			}
			keys = new uint[3];
			keys [0] = (uint)((keyData [3] << 24) | (keyData [2] << 16) | (keyData [1] << 8) | keyData [0]);
			keys [1] = (uint)((keyData [7] << 24) | (keyData [6] << 16) | (keyData [5] << 8) | keyData [4]);
			keys [2] = (uint)((keyData [11] << 24) | (keyData [10] << 16) | (keyData [9] << 8) | keyData [8]);
		}

		protected void UpdateKeys (byte ch)
		{
			keys [0] = Crc32.ComputeCrc32 (keys [0], ch);
			keys [1] = keys [1] + (byte)keys [0];
			keys [1] = keys [1] * 134775813 + 1;
			keys [2] = Crc32.ComputeCrc32 (keys [2], (byte)(keys [1] >> 24));
		}

		protected void Reset ()
		{
			keys [0] = 0u;
			keys [1] = 0u;
			keys [2] = 0u;
		}
	}
	internal class PkzipClassicEncryptCryptoTransform : PkzipClassicCryptoBase, ICryptoTransform, IDisposable
	{
		public bool CanReuseTransform => true;

		public int InputBlockSize => 1;

		public int OutputBlockSize => 1;

		public bool CanTransformMultipleBlocks => true;

		internal PkzipClassicEncryptCryptoTransform (byte[] keyBlock)
		{
			SetKeys (keyBlock);
		}

		public byte[] TransformFinalBlock (byte[] inputBuffer, int inputOffset, int inputCount)
		{
			byte[] array = new byte[inputCount];
			TransformBlock (inputBuffer, inputOffset, inputCount, array, 0);
			return array;
		}

		public int TransformBlock (byte[] inputBuffer, int inputOffset, int inputCount, byte[] outputBuffer, int outputOffset)
		{
			for (int i = inputOffset; i < inputOffset + inputCount; i++) {
				byte ch = inputBuffer [i];
				outputBuffer [outputOffset++] = (byte)(inputBuffer [i] ^ TransformByte ());
				UpdateKeys (ch);
			}
			return inputCount;
		}

		public void Dispose ()
		{
			Reset ();
		}
	}
	internal class PkzipClassicDecryptCryptoTransform : PkzipClassicCryptoBase, ICryptoTransform, IDisposable
	{
		public bool CanReuseTransform => true;

		public int InputBlockSize => 1;

		public int OutputBlockSize => 1;

		public bool CanTransformMultipleBlocks => true;

		internal PkzipClassicDecryptCryptoTransform (byte[] keyBlock)
		{
			SetKeys (keyBlock);
		}

		public byte[] TransformFinalBlock (byte[] inputBuffer, int inputOffset, int inputCount)
		{
			byte[] array = new byte[inputCount];
			TransformBlock (inputBuffer, inputOffset, inputCount, array, 0);
			return array;
		}

		public int TransformBlock (byte[] inputBuffer, int inputOffset, int inputCount, byte[] outputBuffer, int outputOffset)
		{
			for (int i = inputOffset; i < inputOffset + inputCount; i++) {
				byte b = (byte)(inputBuffer [i] ^ TransformByte ());
				outputBuffer [outputOffset++] = b;
				UpdateKeys (b);
			}
			return inputCount;
		}

		public void Dispose ()
		{
			Reset ();
		}
	}
	public sealed class PkzipClassicManaged : PkzipClassic
	{
		private byte[] key_;

		public override int BlockSize {
			get {
				return 8;
			}
			set {
				if (value != 8) {
					throw new CryptographicException ("Block size is invalid");
				}
			}
		}

		public override KeySizes[] LegalKeySizes => new KeySizes[1] {
			new KeySizes (96, 96, 0)
		};

		public override KeySizes[] LegalBlockSizes => new KeySizes[1] {
			new KeySizes (8, 8, 0)
		};

		public override byte[] Key {
			get {
				if (key_ == null) {
					GenerateKey ();
				}
				return (byte[])key_.Clone ();
			}
			set {
				if (value == null) {
					throw new ArgumentNullException ("value");
				}
				if (value.Length != 12) {
					throw new CryptographicException ("Key size is illegal");
				}
				key_ = (byte[])value.Clone ();
			}
		}

		public override void GenerateIV ()
		{
		}

		public override void GenerateKey ()
		{
			key_ = new byte[12];
			System.Random random = new System.Random ();
			random.NextBytes (key_);
		}

		public override ICryptoTransform CreateEncryptor (byte[] rgbKey, byte[] rgbIV)
		{
			key_ = rgbKey;
			return new PkzipClassicEncryptCryptoTransform (Key);
		}

		public override ICryptoTransform CreateDecryptor (byte[] rgbKey, byte[] rgbIV)
		{
			key_ = rgbKey;
			return new PkzipClassicDecryptCryptoTransform (Key);
		}
	}
	internal class ZipAESStream : CryptoStream
	{
		private const int AUTH_CODE_LENGTH = 10;

		private Stream _stream;

		private ZipAESTransform _transform;

		private byte[] _slideBuffer;

		private int _slideBufStartPos;

		private int _slideBufFreePos;

		private const int CRYPTO_BLOCK_SIZE = 16;

		private int _blockAndAuth;

		public ZipAESStream (Stream stream, ZipAESTransform transform, CryptoStreamMode mode)
			: base (stream, transform, mode)
		{
			_stream = stream;
			_transform = transform;
			_slideBuffer = new byte[1024];
			_blockAndAuth = 26;
			if (mode != 0) {
				throw new Exception ("ZipAESStream only for read");
			}
		}

		public override int Read (byte[] outBuffer, int offset, int count)
		{
			int num = 0;
			while (num < count) {
				int num2 = _slideBufFreePos - _slideBufStartPos;
				int num3 = _blockAndAuth - num2;
				if (_slideBuffer.Length - _slideBufFreePos < num3) {
					int num4 = 0;
					int num5 = _slideBufStartPos;
					while (num5 < _slideBufFreePos) {
						_slideBuffer [num4] = _slideBuffer [num5];
						num5++;
						num4++;
					}
					_slideBufFreePos -= _slideBufStartPos;
					_slideBufStartPos = 0;
				}
				int num6 = _stream.Read (_slideBuffer, _slideBufFreePos, num3);
				_slideBufFreePos += num6;
				num2 = _slideBufFreePos - _slideBufStartPos;
				if (num2 >= _blockAndAuth) {
					_transform.TransformBlock (_slideBuffer, _slideBufStartPos, 16, outBuffer, offset);
					num += 16;
					offset += 16;
					_slideBufStartPos += 16;
					continue;
				}
				if (num2 > 10) {
					int num7 = num2 - 10;
					_transform.TransformBlock (_slideBuffer, _slideBufStartPos, num7, outBuffer, offset);
					num += num7;
					_slideBufStartPos += num7;
				} else if (num2 < 10) {
					throw new Exception ("Internal error missed auth code");
				}
				byte[] authCode = _transform.GetAuthCode ();
				for (int i = 0; i < 10; i++) {
					if (authCode [i] != _slideBuffer [_slideBufStartPos + i]) {
						throw new Exception ("AES Authentication Code does not match. This is a super-CRC check on the data in the file after compression and encryption. \r\nThe file may be damaged.");
					}
				}
				break;
			}
			return num;
		}

		public override void Write (byte[] buffer, int offset, int count)
		{
			throw new NotImplementedException ();
		}
	}
	internal class ZipAESTransform : ICryptoTransform, IDisposable
	{
		private const int PWD_VER_LENGTH = 2;

		private const int KEY_ROUNDS = 1000;

		private const int ENCRYPT_BLOCK = 16;

		private int _blockSize;

		private ICryptoTransform _encryptor;

		private readonly byte[] _counterNonce;

		private byte[] _encryptBuffer;

		private int _encrPos;

		private byte[] _pwdVerifier;

		private HMACSHA1 _hmacsha1;

		private bool _finalised;

		private bool _writeMode;

		public byte[] PwdVerifier => _pwdVerifier;

		public int InputBlockSize => _blockSize;

		public int OutputBlockSize => _blockSize;

		public bool CanTransformMultipleBlocks => true;

		public bool CanReuseTransform => true;

		public ZipAESTransform (string key, byte[] saltBytes, int blockSize, bool writeMode)
		{
			if (blockSize != 16 && blockSize != 32) {
				throw new Exception ("Invalid blocksize " + blockSize + ". Must be 16 or 32.");
			}
			if (saltBytes.Length != blockSize / 2) {
				throw new Exception ("Invalid salt len. Must be " + blockSize / 2 + " for blocksize " + blockSize);
			}
			_blockSize = blockSize;
			_encryptBuffer = new byte[_blockSize];
			_encrPos = 16;
			Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes (key, saltBytes, 1000);
			RijndaelManaged rijndaelManaged = new RijndaelManaged {
				Mode = CipherMode.ECB
			};
			_counterNonce = new byte[_blockSize];
			byte[] bytes = rfc2898DeriveBytes.GetBytes (_blockSize);
			byte[] bytes2 = rfc2898DeriveBytes.GetBytes (_blockSize);
			_encryptor = rijndaelManaged.CreateEncryptor (bytes, bytes2);
			_pwdVerifier = rfc2898DeriveBytes.GetBytes (2);
			_hmacsha1 = new HMACSHA1 (bytes2);
			_writeMode = writeMode;
		}

		public int TransformBlock (byte[] inputBuffer, int inputOffset, int inputCount, byte[] outputBuffer, int outputOffset)
		{
			if (!_writeMode) {
				_hmacsha1.TransformBlock (inputBuffer, inputOffset, inputCount, inputBuffer, inputOffset);
			}
			for (int i = 0; i < inputCount; i++) {
				if (_encrPos == 16) {
					int num = 0;
					while (++_counterNonce [num] == 0) {
						num++;
					}
					_encryptor.TransformBlock (_counterNonce, 0, _blockSize, _encryptBuffer, 0);
					_encrPos = 0;
				}
				outputBuffer [i + outputOffset] = (byte)(inputBuffer [i + inputOffset] ^ _encryptBuffer [_encrPos++]);
			}
			if (_writeMode) {
				_hmacsha1.TransformBlock (outputBuffer, outputOffset, inputCount, outputBuffer, outputOffset);
			}
			return inputCount;
		}

		public byte[] GetAuthCode ()
		{
			if (!_finalised) {
				byte[] inputBuffer = new byte[0];
				_hmacsha1.TransformFinalBlock (inputBuffer, 0, 0);
				_finalised = true;
			}
			return _hmacsha1.Hash;
		}

		public byte[] TransformFinalBlock (byte[] inputBuffer, int inputOffset, int inputCount)
		{
			throw new NotImplementedException ("ZipAESTransform.TransformFinalBlock");
		}

		public void Dispose ()
		{
			_encryptor.Dispose ();
		}
	}
}
namespace ICSharpCode.SharpZipLib.GZip
{
	public sealed class GZipConstants
	{
		public const int GZIP_MAGIC = 8075;

		public const int FTEXT = 1;

		public const int FHCRC = 2;

		public const int FEXTRA = 4;

		public const int FNAME = 8;

		public const int FCOMMENT = 16;

		private GZipConstants ()
		{
		}
	}
	[Serializable]
	public class GZipException : SharpZipBaseException
	{
		protected GZipException (SerializationInfo info, StreamingContext context)
			: base (info, context)
		{
		}

		public GZipException ()
		{
		}

		public GZipException (string message)
			: base (message)
		{
		}

		public GZipException (string message, Exception innerException)
			: base (message, innerException)
		{
		}
	}
	public class GZipInputStream : InflaterInputStream
	{
		protected Crc32 crc;

		private bool readGZIPHeader;

		public GZipInputStream (Stream baseInputStream)
			: this (baseInputStream, 4096)
		{
		}

		public GZipInputStream (Stream baseInputStream, int size)
			: base (baseInputStream, new Inflater (noHeader: true), size)
		{
		}

		public override int Read (byte[] buffer, int offset, int count)
		{
			int num;
			do {
				if (!readGZIPHeader && !ReadHeader ()) {
					return 0;
				}
				num = base.Read (buffer, offset, count);
				if (num > 0) {
					crc.Update (buffer, offset, num);
				}
				if (inf.IsFinished) {
					ReadFooter ();
				}
			} while (num <= 0);
			return num;
		}

		private bool ReadHeader ()
		{
			this.crc = new Crc32 ();
			if (inputBuffer.Available <= 0) {
				inputBuffer.Fill ();
				if (inputBuffer.Available <= 0) {
					return false;
				}
			}
			Crc32 crc = new Crc32 ();
			int num = inputBuffer.ReadLeByte ();
			if (num < 0) {
				throw new EndOfStreamException ("EOS reading GZIP header");
			}
			crc.Update (num);
			if (num != 31) {
				throw new GZipException ("Error GZIP header, first magic byte doesn't match");
			}
			num = inputBuffer.ReadLeByte ();
			if (num < 0) {
				throw new EndOfStreamException ("EOS reading GZIP header");
			}
			if (num != 139) {
				throw new GZipException ("Error GZIP header,  second magic byte doesn't match");
			}
			crc.Update (num);
			int num2 = inputBuffer.ReadLeByte ();
			if (num2 < 0) {
				throw new EndOfStreamException ("EOS reading GZIP header");
			}
			if (num2 != 8) {
				throw new GZipException ("Error GZIP header, data not in deflate format");
			}
			crc.Update (num2);
			int num3 = inputBuffer.ReadLeByte ();
			if (num3 < 0) {
				throw new EndOfStreamException ("EOS reading GZIP header");
			}
			crc.Update (num3);
			if (((uint)num3 & 0xE0u) != 0) {
				throw new GZipException ("Reserved flag bits in GZIP header != 0");
			}
			for (int i = 0; i < 6; i++) {
				int num4 = inputBuffer.ReadLeByte ();
				if (num4 < 0) {
					throw new EndOfStreamException ("EOS reading GZIP header");
				}
				crc.Update (num4);
			}
			if (((uint)num3 & 4u) != 0) {
				for (int j = 0; j < 2; j++) {
					int num5 = inputBuffer.ReadLeByte ();
					if (num5 < 0) {
						throw new EndOfStreamException ("EOS reading GZIP header");
					}
					crc.Update (num5);
				}
				if (inputBuffer.ReadLeByte () < 0 || inputBuffer.ReadLeByte () < 0) {
					throw new EndOfStreamException ("EOS reading GZIP header");
				}
				int num6 = inputBuffer.ReadLeByte ();
				int num7 = inputBuffer.ReadLeByte ();
				if (num6 < 0 || num7 < 0) {
					throw new EndOfStreamException ("EOS reading GZIP header");
				}
				crc.Update (num6);
				crc.Update (num7);
				int num8 = (num6 << 8) | num7;
				for (int k = 0; k < num8; k++) {
					int num9 = inputBuffer.ReadLeByte ();
					if (num9 < 0) {
						throw new EndOfStreamException ("EOS reading GZIP header");
					}
					crc.Update (num9);
				}
			}
			if (((uint)num3 & 8u) != 0) {
				int num10;
				while ((num10 = inputBuffer.ReadLeByte ()) > 0) {
					crc.Update (num10);
				}
				if (num10 < 0) {
					throw new EndOfStreamException ("EOS reading GZIP header");
				}
				crc.Update (num10);
			}
			if (((uint)num3 & 0x10u) != 0) {
				int num11;
				while ((num11 = inputBuffer.ReadLeByte ()) > 0) {
					crc.Update (num11);
				}
				if (num11 < 0) {
					throw new EndOfStreamException ("EOS reading GZIP header");
				}
				crc.Update (num11);
			}
			if (((uint)num3 & 2u) != 0) {
				int num12 = inputBuffer.ReadLeByte ();
				if (num12 < 0) {
					throw new EndOfStreamException ("EOS reading GZIP header");
				}
				int num13 = inputBuffer.ReadLeByte ();
				if (num13 < 0) {
					throw new EndOfStreamException ("EOS reading GZIP header");
				}
				num12 = (num12 << 8) | num13;
				if (num12 != ((int)crc.Value & 0xFFFF)) {
					throw new GZipException ("Header CRC value mismatch");
				}
			}
			readGZIPHeader = true;
			return true;
		}

		private void ReadFooter ()
		{
			byte[] array = new byte[8];
			long num = inf.TotalOut & 0xFFFFFFFFu;
			inputBuffer.Available += inf.RemainingInput;
			inf.Reset ();
			int num2 = 8;
			while (num2 > 0) {
				int num3 = inputBuffer.ReadClearTextBuffer (array, 8 - num2, num2);
				if (num3 <= 0) {
					throw new EndOfStreamException ("EOS reading GZIP footer");
				}
				num2 -= num3;
			}
			int num4 = (array [0] & 0xFF) | ((array [1] & 0xFF) << 8) | ((array [2] & 0xFF) << 16) | (array [3] << 24);
			if (num4 != (int)crc.Value) {
				throw new GZipException ("GZIP crc sum mismatch, theirs \"" + num4 + "\" and ours \"" + (int)crc.Value);
			}
			uint num5 = (array [4] & 0xFFu) | (uint)((array [5] & 0xFF) << 8) | (uint)((array [6] & 0xFF) << 16) | (uint)(array [7] << 24);
			if (num != num5) {
				throw new GZipException ("Number of bytes mismatch in footer");
			}
			readGZIPHeader = false;
		}
	}
	public class GZipOutputStream : DeflaterOutputStream
	{
		private enum OutputState
		{
			Header,
			Footer,
			Finished,
			Closed
		}

		protected Crc32 crc = new Crc32 ();

		private OutputState state_;

		public GZipOutputStream (Stream baseOutputStream)
			: this (baseOutputStream, 4096)
		{
		}

		public GZipOutputStream (Stream baseOutputStream, int size)
			: base (baseOutputStream, new Deflater (-1, noZlibHeaderOrFooter: true), size)
		{
		}

		public void SetLevel (int level)
		{
			if (level < 1) {
				throw new ArgumentOutOfRangeException ("level");
			}
			deflater_.SetLevel (level);
		}

		public int GetLevel ()
		{
			return deflater_.GetLevel ();
		}

		public override void Write (byte[] buffer, int offset, int count)
		{
			if (state_ == OutputState.Header) {
				WriteHeader ();
			}
			if (state_ != OutputState.Footer) {
				throw new InvalidOperationException ("Write not permitted in current state");
			}
			crc.Update (buffer, offset, count);
			base.Write (buffer, offset, count);
		}

		public override void Close ()
		{
			try {
				Finish ();
			} finally {
				if (state_ != OutputState.Closed) {
					state_ = OutputState.Closed;
					if (base.IsStreamOwner) {
						baseOutputStream_.Close ();
					}
				}
			}
		}

		public override void Finish ()
		{
			if (state_ == OutputState.Header) {
				WriteHeader ();
			}
			if (state_ == OutputState.Footer) {
				state_ = OutputState.Finished;
				base.Finish ();
				uint num = (uint)(deflater_.TotalIn & 0xFFFFFFFFu);
				uint num2 = (uint)(crc.Value & 0xFFFFFFFFu);
				byte[] array = new byte[8] {
					(byte)num2,
					(byte)(num2 >> 8),
					(byte)(num2 >> 16),
					(byte)(num2 >> 24),
					(byte)num,
					(byte)(num >> 8),
					(byte)(num >> 16),
					(byte)(num >> 24)
				};
				baseOutputStream_.Write (array, 0, array.Length);
			}
		}

		private void WriteHeader ()
		{
			if (state_ == OutputState.Header) {
				state_ = OutputState.Footer;
				int num = (int)((DateTime.Now.Ticks - new DateTime (1970, 1, 1).Ticks) / 10000000);
				byte[] obj = new byte[10] { 31, 139, 8, 0, 0, 0, 0, 0, 0, 255 };
				obj [4] = (byte)num;
				obj [5] = (byte)(num >> 8);
				obj [6] = (byte)(num >> 16);
				obj [7] = (byte)(num >> 24);
				byte[] array = obj;
				baseOutputStream_.Write (array, 0, array.Length);
			}
		}
	}
}
namespace ICSharpCode.SharpZipLib.LZW
{
	public sealed class LzwConstants
	{
		public const int MAGIC = 8093;

		public const int MAX_BITS = 16;

		public const int BIT_MASK = 31;

		public const int EXTENDED_MASK = 32;

		public const int RESERVED_MASK = 96;

		public const int BLOCK_MODE_MASK = 128;

		public const int HDR_SIZE = 3;

		public const int INIT_BITS = 9;

		private LzwConstants ()
		{
		}
	}
	[Serializable]
	public class LzwException : SharpZipBaseException
	{
		protected LzwException (SerializationInfo info, StreamingContext context)
			: base (info, context)
		{
		}

		public LzwException ()
		{
		}

		public LzwException (string message)
			: base (message)
		{
		}

		public LzwException (string message, Exception innerException)
			: base (message, innerException)
		{
		}
	}
	public class LzwInputStream : Stream
	{
		private Stream baseInputStream;

		private bool isStreamOwner = true;

		private bool isClosed;

		private readonly byte[] one = new byte[1];

		private bool headerParsed;

		private const int TBL_CLEAR = 256;

		private const int TBL_FIRST = 257;

		private int[] tabPrefix;

		private byte[] tabSuffix;

		private readonly int[] zeros = new int[256];

		private byte[] stack;

		private bool blockMode;

		private int nBits;

		private int maxBits;

		private int maxMaxCode;

		private int maxCode;

		private int bitMask;

		private int oldCode;

		private byte finChar;

		private int stackP;

		private int freeEnt;

		private readonly byte[] data = new byte[8192];

		private int bitPos;

		private int end;

		private int got;

		private bool eof;

		private const int EXTRA = 64;

		public bool IsStreamOwner {
			get {
				return isStreamOwner;
			}
			set {
				isStreamOwner = value;
			}
		}

		public override bool CanRead => baseInputStream.CanRead;

		public override bool CanSeek => false;

		public override bool CanWrite => false;

		public override long Length => got;

		public override long Position {
			get {
				return baseInputStream.Position;
			}
			set {
				throw new NotSupportedException ("InflaterInputStream Position not supported");
			}
		}

		public LzwInputStream (Stream baseInputStream)
		{
			this.baseInputStream = baseInputStream;
		}

		public override int ReadByte ()
		{
			int num = Read (one, 0, 1);
			if (num == 1) {
				return one [0] & 0xFF;
			}
			return -1;
		}

		public override int Read (byte[] buffer, int offset, int count)
		{
			if (!headerParsed) {
				ParseHeader ();
			}
			if (eof) {
				return -1;
			}
			int num = offset;
			int[] array = tabPrefix;
			byte[] array2 = tabSuffix;
			byte[] array3 = stack;
			int num2 = nBits;
			int num3 = maxCode;
			int num4 = maxMaxCode;
			int num5 = bitMask;
			int num6 = oldCode;
			byte b = finChar;
			int num7 = stackP;
			int num8 = freeEnt;
			byte[] array4 = data;
			int num9 = bitPos;
			int num10 = array3.Length - num7;
			if (num10 > 0) {
				int num11 = ((num10 < count) ? num10 : count);
				Array.Copy (array3, num7, buffer, offset, num11);
				offset += num11;
				count -= num11;
				num7 += num11;
			}
			if (count == 0) {
				stackP = num7;
				return offset - num;
			}
			while (true) {
				if (end < 64) {
					Fill ();
				}
				int num12 = ((got <= 0) ? ((end << 3) - (num2 - 1)) : (end - end % num2 << 3));
				while (true) {
					if (num9 < num12) {
						if (count == 0) {
							nBits = num2;
							maxCode = num3;
							maxMaxCode = num4;
							bitMask = num5;
							oldCode = num6;
							finChar = b;
							stackP = num7;
							freeEnt = num8;
							bitPos = num9;
							return offset - num;
						}
						if (num8 > num3) {
							int num13 = num2 << 3;
							num9 = num9 - 1 + num13 - (num9 - 1 + num13) % num13;
							num2++;
							num3 = ((num2 != maxBits) ? ((1 << num2) - 1) : num4);
							num5 = (1 << num2) - 1;
							num9 = ResetBuf (num9);
							break;
						}
						int num14 = num9 >> 3;
						int num15 = (((array4 [num14] & 0xFF) | ((array4 [num14 + 1] & 0xFF) << 8) | ((array4 [num14 + 2] & 0xFF) << 16)) >> (num9 & 7)) & num5;
						num9 += num2;
						if (num6 == -1) {
							if (num15 >= 256) {
								throw new LzwException ("corrupt input: " + num15 + " > 255");
							}
							b = (byte)(num6 = num15);
							buffer [offset++] = b;
							count--;
							continue;
						}
						if (num15 == 256 && blockMode) {
							Array.Copy (zeros, 0, array, 0, zeros.Length);
							num8 = 256;
							int num16 = num2 << 3;
							num9 = num9 - 1 + num16 - (num9 - 1 + num16) % num16;
							num2 = 9;
							num3 = (1 << num2) - 1;
							num5 = num3;
							num9 = ResetBuf (num9);
							break;
						}
						int num17 = num15;
						num7 = array3.Length;
						if (num15 >= num8) {
							if (num15 > num8) {
								throw new LzwException ("corrupt input: code=" + num15 + ", freeEnt=" + num8);
							}
							array3 [--num7] = b;
							num15 = num6;
						}
						while (num15 >= 256) {
							array3 [--num7] = array2 [num15];
							num15 = array [num15];
						}
						b = array2 [num15];
						buffer [offset++] = b;
						count--;
						num10 = array3.Length - num7;
						int num18 = ((num10 < count) ? num10 : count);
						Array.Copy (array3, num7, buffer, offset, num18);
						offset += num18;
						count -= num18;
						num7 += num18;
						if (num8 < num4) {
							array [num8] = num6;
							array2 [num8] = b;
							num8++;
						}
						num6 = num17;
						if (count != 0) {
							continue;
						}
						nBits = num2;
						maxCode = num3;
						bitMask = num5;
						oldCode = num6;
						finChar = b;
						stackP = num7;
						freeEnt = num8;
						bitPos = num9;
						return offset - num;
					}
					num9 = ResetBuf (num9);
					if (got > 0) {
						break;
					}
					nBits = num2;
					maxCode = num3;
					bitMask = num5;
					oldCode = num6;
					finChar = b;
					stackP = num7;
					freeEnt = num8;
					bitPos = num9;
					eof = true;
					return offset - num;
				}
			}
		}

		private int ResetBuf (int bitPosition)
		{
			int num = bitPosition >> 3;
			Array.Copy (data, num, data, 0, end - num);
			end -= num;
			return 0;
		}

		private void Fill ()
		{
			got = baseInputStream.Read (data, end, data.Length - 1 - end);
			if (got > 0) {
				end += got;
			}
		}

		private void ParseHeader ()
		{
			headerParsed = true;
			byte[] array = new byte[3];
			int num = baseInputStream.Read (array, 0, array.Length);
			if (num < 0) {
				throw new LzwException ("Failed to read LZW header");
			}
			if (array [0] != 31 || array [1] != 157) {
				throw new LzwException ($"Wrong LZW header. Magic bytes don't match. 0x{array [0]:x2} 0x{array [1]:x2}");
			}
			blockMode = (array [2] & 0x80) > 0;
			maxBits = array [2] & 0x1F;
			if (maxBits > 16) {
				throw new LzwException ("Stream compressed with " + maxBits + " bits, but decompression can only handle " + 16 + " bits.");
			}
			if ((array [2] & 0x60) > 0) {
				throw new LzwException ("Unsupported bits set in the header.");
			}
			maxMaxCode = 1 << maxBits;
			nBits = 9;
			maxCode = (1 << nBits) - 1;
			bitMask = maxCode;
			oldCode = -1;
			finChar = 0;
			freeEnt = ((!blockMode) ? 256 : 257);
			tabPrefix = new int[1 << maxBits];
			tabSuffix = new byte[1 << maxBits];
			stack = new byte[1 << maxBits];
			stackP = stack.Length;
			for (int num2 = 255; num2 >= 0; num2--) {
				tabSuffix [num2] = (byte)num2;
			}
		}

		public override void Flush ()
		{
			baseInputStream.Flush ();
		}

		public override long Seek (long offset, SeekOrigin origin)
		{
			throw new NotSupportedException ("Seek not supported");
		}

		public override void SetLength (long value)
		{
			throw new NotSupportedException ("InflaterInputStream SetLength not supported");
		}

		public override void Write (byte[] buffer, int offset, int count)
		{
			throw new NotSupportedException ("InflaterInputStream Write not supported");
		}

		public override void WriteByte (byte value)
		{
			throw new NotSupportedException ("InflaterInputStream WriteByte not supported");
		}

		public override IAsyncResult BeginWrite (byte[] buffer, int offset, int count, AsyncCallback callback, object state)
		{
			throw new NotSupportedException ("InflaterInputStream BeginWrite not supported");
		}

		public override void Close ()
		{
			if (!isClosed) {
				isClosed = true;
				if (isStreamOwner) {
					baseInputStream.Close ();
				}
			}
		}
	}
}
namespace ICSharpCode.SharpZipLib
{
	[Serializable]
	public class SharpZipBaseException : ApplicationException
	{
		protected SharpZipBaseException (SerializationInfo info, StreamingContext context)
			: base (info, context)
		{
		}

		public SharpZipBaseException ()
		{
		}

		public SharpZipBaseException (string message)
			: base (message)
		{
		}

		public SharpZipBaseException (string message, Exception innerException)
			: base (message, innerException)
		{
		}
	}
}
namespace Compression
{
	public class Utility
	{
		public static byte[] Compress (byte[] buffer)
		{
			MemoryStream memoryStream = new MemoryStream ();
			GZipOutputStream gZipOutputStream = new GZipOutputStream (memoryStream);
			gZipOutputStream.Write (buffer, 0, buffer.Length);
			gZipOutputStream.IsStreamOwner = false;
			gZipOutputStream.Close ();
			memoryStream.Seek (0L, SeekOrigin.Begin);
			byte[] array = new byte[memoryStream.Length];
			memoryStream.Read (array, 0, array.Length);
			return array;
		}

		public static string Compress2 (string text)
		{
			byte[] bytes = Encoding.UTF8.GetBytes (text);
			MemoryStream memoryStream = new MemoryStream ();
			GZipOutputStream gZipOutputStream = new GZipOutputStream (memoryStream);
			gZipOutputStream.Write (bytes, 0, bytes.Length);
			gZipOutputStream.IsStreamOwner = false;
			gZipOutputStream.Close ();
			memoryStream.Seek (0L, SeekOrigin.Begin);
			byte[] array = new byte[memoryStream.Length];
			memoryStream.Read (array, 0, array.Length);
			return Convert.ToBase64String (array);
		}

		public static List<byte> DecompressToBytes (byte[] bytes)
		{
			byte[] array = new byte[65536];
			List<byte> list = new List<byte> ();
			using MemoryStream baseInputStream = new MemoryStream (bytes, writable: false);
			using GZipInputStream gZipInputStream = new GZipInputStream (baseInputStream);
			while (true) {
				int num = 0;
				try {
					num = gZipInputStream.Read (array, 0, array.Length);
				} catch (GZipException) {
				}
				if (num == 0) {
					break;
				}
				for (int i = 0; i < num; i++) {
					list.Add (array [i]);
				}
			}
			return list;
		}

		public static string Decompress (byte[] bytes)
		{
			MemoryStream baseInputStream = new MemoryStream (bytes, writable: false);
			GZipInputStream gZipInputStream = new GZipInputStream (baseInputStream);
			byte[] array = new byte[65536];
			char[] array2 = new char[65536];
			Decoder decoder = Encoding.UTF8.GetDecoder ();
			StringBuilder stringBuilder = new StringBuilder ();
			long num = 0L;
			try {
				while (true) {
					int num2 = gZipInputStream.Read (array, 0, array.Length);
					if (num2 == 0) {
						break;
					}
					num += num2;
					int chars = decoder.GetChars (array, 0, num2, array2, 0);
					stringBuilder.Append (array2, 0, chars);
				}
			} catch (GZipException) {
			}
			gZipInputStream.Close ();
			return stringBuilder.ToString ();
		}
	}
}
namespace ICSharpCode.SharpZipLib.Tar
{
	[Serializable]
	public class InvalidHeaderException : TarException
	{
		protected InvalidHeaderException (SerializationInfo information, StreamingContext context)
			: base (information, context)
		{
		}

		public InvalidHeaderException ()
		{
		}

		public InvalidHeaderException (string message)
			: base (message)
		{
		}

		public InvalidHeaderException (string message, Exception exception)
			: base (message, exception)
		{
		}
	}
	public delegate void ProgressMessageHandler (TarArchive archive, TarEntry entry, string message);
	public class TarArchive : IDisposable
	{
		private bool keepOldFiles;

		private bool asciiTranslate;

		private int userId;

		private string userName = string.Empty;

		private int groupId;

		private string groupName = string.Empty;

		private string rootPath;

		private string pathPrefix;

		private bool applyUserInfoOverrides;

		private TarInputStream tarIn;

		private TarOutputStream tarOut;

		private bool isDisposed;

		public bool AsciiTranslate {
			get {
				if (isDisposed) {
					throw new ObjectDisposedException ("TarArchive");
				}
				return asciiTranslate;
			}
			set {
				if (isDisposed) {
					throw new ObjectDisposedException ("TarArchive");
				}
				asciiTranslate = value;
			}
		}

		public string PathPrefix {
			get {
				if (isDisposed) {
					throw new ObjectDisposedException ("TarArchive");
				}
				return pathPrefix;
			}
			set {
				if (isDisposed) {
					throw new ObjectDisposedException ("TarArchive");
				}
				pathPrefix = value;
			}
		}

		public string RootPath {
			get {
				if (isDisposed) {
					throw new ObjectDisposedException ("TarArchive");
				}
				return rootPath;
			}
			set {
				if (isDisposed) {
					throw new ObjectDisposedException ("TarArchive");
				}
				rootPath = value;
			}
		}

		public bool ApplyUserInfoOverrides {
			get {
				if (isDisposed) {
					throw new ObjectDisposedException ("TarArchive");
				}
				return applyUserInfoOverrides;
			}
			set {
				if (isDisposed) {
					throw new ObjectDisposedException ("TarArchive");
				}
				applyUserInfoOverrides = value;
			}
		}

		public int UserId {
			get {
				if (isDisposed) {
					throw new ObjectDisposedException ("TarArchive");
				}
				return userId;
			}
		}

		public string UserName {
			get {
				if (isDisposed) {
					throw new ObjectDisposedException ("TarArchive");
				}
				return userName;
			}
		}

		public int GroupId {
			get {
				if (isDisposed) {
					throw new ObjectDisposedException ("TarArchive");
				}
				return groupId;
			}
		}

		public string GroupName {
			get {
				if (isDisposed) {
					throw new ObjectDisposedException ("TarArchive");
				}
				return groupName;
			}
		}

		public int RecordSize {
			get {
				if (isDisposed) {
					throw new ObjectDisposedException ("TarArchive");
				}
				if (tarIn != null) {
					return tarIn.RecordSize;
				}
				if (tarOut != null) {
					return tarOut.RecordSize;
				}
				return 10240;
			}
		}

		public bool IsStreamOwner {
			set {
				if (tarIn != null) {
					tarIn.IsStreamOwner = value;
				} else {
					tarOut.IsStreamOwner = value;
				}
			}
		}

		public event ProgressMessageHandler ProgressMessageEvent;

		protected TarArchive ()
		{
		}

		protected TarArchive (TarInputStream stream)
		{
			if (stream == null) {
				throw new ArgumentNullException ("stream");
			}
			tarIn = stream;
		}

		protected TarArchive (TarOutputStream stream)
		{
			if (stream == null) {
				throw new ArgumentNullException ("stream");
			}
			tarOut = stream;
		}

		protected virtual void OnProgressMessageEvent (TarEntry entry, string message)
		{
			this.ProgressMessageEvent?.Invoke (this, entry, message);
		}

		public static TarArchive CreateInputTarArchive (Stream inputStream)
		{
			if (inputStream == null) {
				throw new ArgumentNullException ("inputStream");
			}
			if (inputStream is TarInputStream stream) {
				return new TarArchive (stream);
			}
			return CreateInputTarArchive (inputStream, 20);
		}

		public static TarArchive CreateInputTarArchive (Stream inputStream, int blockFactor)
		{
			if (inputStream == null) {
				throw new ArgumentNullException ("inputStream");
			}
			if (inputStream is TarInputStream) {
				throw new ArgumentException ("TarInputStream not valid");
			}
			return new TarArchive (new TarInputStream (inputStream, blockFactor));
		}

		public static TarArchive CreateOutputTarArchive (Stream outputStream)
		{
			if (outputStream == null) {
				throw new ArgumentNullException ("outputStream");
			}
			if (outputStream is TarOutputStream stream) {
				return new TarArchive (stream);
			}
			return CreateOutputTarArchive (outputStream, 20);
		}

		public static TarArchive CreateOutputTarArchive (Stream outputStream, int blockFactor)
		{
			if (outputStream == null) {
				throw new ArgumentNullException ("outputStream");
			}
			if (outputStream is TarOutputStream) {
				throw new ArgumentException ("TarOutputStream is not valid");
			}
			return new TarArchive (new TarOutputStream (outputStream, blockFactor));
		}

		public void SetKeepOldFiles (bool keepExistingFiles)
		{
			if (isDisposed) {
				throw new ObjectDisposedException ("TarArchive");
			}
			keepOldFiles = keepExistingFiles;
		}

		[Obsolete ("Use the AsciiTranslate property")]
		public void SetAsciiTranslation (bool translateAsciiFiles)
		{
			if (isDisposed) {
				throw new ObjectDisposedException ("TarArchive");
			}
			asciiTranslate = translateAsciiFiles;
		}

		public void SetUserInfo (int userId, string userName, int groupId, string groupName)
		{
			if (isDisposed) {
				throw new ObjectDisposedException ("TarArchive");
			}
			this.userId = userId;
			this.userName = userName;
			this.groupId = groupId;
			this.groupName = groupName;
			applyUserInfoOverrides = true;
		}

		[Obsolete ("Use Close instead")]
		public void CloseArchive ()
		{
			Close ();
		}

		public void ListContents ()
		{
			if (isDisposed) {
				throw new ObjectDisposedException ("TarArchive");
			}
			while (true) {
				TarEntry nextEntry = tarIn.GetNextEntry ();
				if (nextEntry == null) {
					break;
				}
				OnProgressMessageEvent (nextEntry, null);
			}
		}

		public void ExtractContents (string destinationDirectory)
		{
			if (isDisposed) {
				throw new ObjectDisposedException ("TarArchive");
			}
			while (true) {
				TarEntry nextEntry = tarIn.GetNextEntry ();
				if (nextEntry == null) {
					break;
				}
				ExtractEntry (destinationDirectory, nextEntry);
			}
		}

		private void ExtractEntry (string destDir, TarEntry entry)
		{
			OnProgressMessageEvent (entry, null);
			string text = entry.Name;
			if (Path.IsPathRooted (text)) {
				text = text.Substring (Path.GetPathRoot (text).Length);
			}
			text = text.Replace ('/', Path.DirectorySeparatorChar);
			string text2 = Path.Combine (destDir, text);
			if (entry.IsDirectory) {
				EnsureDirectoryExists (text2);
				return;
			}
			string directoryName = Path.GetDirectoryName (text2);
			EnsureDirectoryExists (directoryName);
			bool flag = true;
			FileInfo fileInfo = new FileInfo (text2);
			if (fileInfo.Exists) {
				if (keepOldFiles) {
					OnProgressMessageEvent (entry, "Destination file already exists");
					flag = false;
				} else if ((fileInfo.Attributes & FileAttributes.ReadOnly) != 0) {
					OnProgressMessageEvent (entry, "Destination file already exists, and is read-only");
					flag = false;
				}
			}
			if (!flag) {
				return;
			}
			bool flag2 = false;
			Stream stream = File.Create (text2);
			if (asciiTranslate) {
				flag2 = !IsBinary (text2);
			}
			StreamWriter streamWriter = null;
			if (flag2) {
				streamWriter = new StreamWriter (stream);
			}
			byte[] array = new byte[32768];
			while (true) {
				int num = tarIn.Read (array, 0, array.Length);
				if (num <= 0) {
					break;
				}
				if (flag2) {
					int num2 = 0;
					for (int i = 0; i < num; i++) {
						if (array [i] == 10) {
							string @string = Encoding.ASCII.GetString (array, num2, i - num2);
							streamWriter.WriteLine (@string);
							num2 = i + 1;
						}
					}
				} else {
					stream.Write (array, 0, num);
				}
			}
			if (flag2) {
				streamWriter.Close ();
			} else {
				stream.Close ();
			}
		}

		public void WriteEntry (TarEntry sourceEntry, bool recurse)
		{
			if (sourceEntry == null) {
				throw new ArgumentNullException ("sourceEntry");
			}
			if (isDisposed) {
				throw new ObjectDisposedException ("TarArchive");
			}
			try {
				if (recurse) {
					TarHeader.SetValueDefaults (sourceEntry.UserId, sourceEntry.UserName, sourceEntry.GroupId, sourceEntry.GroupName);
				}
				WriteEntryCore (sourceEntry, recurse);
			} finally {
				if (recurse) {
					TarHeader.RestoreSetValues ();
				}
			}
		}

		private void WriteEntryCore (TarEntry sourceEntry, bool recurse)
		{
			string text = null;
			string text2 = sourceEntry.File;
			TarEntry tarEntry = (TarEntry)sourceEntry.Clone ();
			if (applyUserInfoOverrides) {
				tarEntry.GroupId = groupId;
				tarEntry.GroupName = groupName;
				tarEntry.UserId = userId;
				tarEntry.UserName = userName;
			}
			OnProgressMessageEvent (tarEntry, null);
			if (asciiTranslate && !tarEntry.IsDirectory && !IsBinary (text2)) {
				text = Path.GetTempFileName ();
				using (StreamReader streamReader = File.OpenText (text2)) {
					using Stream stream = File.Create (text);
					while (true) {
						string text3 = streamReader.ReadLine ();
						if (text3 == null) {
							break;
						}
						byte[] bytes = Encoding.ASCII.GetBytes (text3);
						stream.Write (bytes, 0, bytes.Length);
						stream.WriteByte (10);
					}
					stream.Flush ();
				}
				tarEntry.Size = new FileInfo (text).Length;
				text2 = text;
			}
			string text4 = null;
			if (rootPath != null && tarEntry.Name.StartsWith (rootPath)) {
				text4 = tarEntry.Name.Substring (rootPath.Length + 1);
			}
			if (pathPrefix != null) {
				text4 = ((text4 != null) ? (pathPrefix + "/" + text4) : (pathPrefix + "/" + tarEntry.Name));
			}
			if (text4 != null) {
				tarEntry.Name = text4;
			}
			tarOut.PutNextEntry (tarEntry);
			if (tarEntry.IsDirectory) {
				if (recurse) {
					TarEntry[] directoryEntries = tarEntry.GetDirectoryEntries ();
					for (int i = 0; i < directoryEntries.Length; i++) {
						WriteEntryCore (directoryEntries [i], recurse);
					}
				}
				return;
			}
			using (Stream stream2 = File.OpenRead (text2)) {
				byte[] array = new byte[32768];
				while (true) {
					int num = stream2.Read (array, 0, array.Length);
					if (num <= 0) {
						break;
					}
					tarOut.Write (array, 0, num);
				}
			}
			if (text != null && text.Length > 0) {
				File.Delete (text);
			}
			tarOut.CloseEntry ();
		}

		public void Dispose ()
		{
			Dispose (disposing: true);
			GC.SuppressFinalize (this);
		}

		protected virtual void Dispose (bool disposing)
		{
			if (isDisposed) {
				return;
			}
			isDisposed = true;
			if (disposing) {
				if (tarOut != null) {
					tarOut.Flush ();
					tarOut.Close ();
				}
				if (tarIn != null) {
					tarIn.Close ();
				}
			}
		}

		public virtual void Close ()
		{
			Dispose (disposing: true);
		}

		~TarArchive ()
		{
			Dispose (disposing: false);
		}

		private static void EnsureDirectoryExists (string directoryName)
		{
			if (!Directory.Exists (directoryName)) {
				try {
					Directory.CreateDirectory (directoryName);
				} catch (Exception ex) {
					throw new TarException ("Exception creating directory '" + directoryName + "', " + ex.Message, ex);
				}
			}
		}

		private static bool IsBinary (string filename)
		{
			using (FileStream fileStream = File.OpenRead (filename)) {
				int num = Math.Min (4096, (int)fileStream.Length);
				byte[] array = new byte[num];
				int num2 = fileStream.Read (array, 0, num);
				for (int i = 0; i < num2; i++) {
					byte b = array [i];
					if (b < 8 || (b > 13 && b < 32) || b == byte.MaxValue) {
						return true;
					}
				}
			}
			return false;
		}
	}
	public class TarBuffer
	{
		public const int BlockSize = 512;

		public const int DefaultBlockFactor = 20;

		public const int DefaultRecordSize = 10240;

		private Stream inputStream;

		private Stream outputStream;

		private byte[] recordBuffer;

		private int currentBlockIndex;

		private int currentRecordIndex;

		private int recordSize = 10240;

		private int blockFactor = 20;

		private bool isStreamOwner_ = true;

		public int RecordSize => recordSize;

		public int BlockFactor => blockFactor;

		public int CurrentBlock => currentBlockIndex;

		public bool IsStreamOwner {
			get {
				return isStreamOwner_;
			}
			set {
				isStreamOwner_ = value;
			}
		}

		public int CurrentRecord => currentRecordIndex;

		protected TarBuffer ()
		{
		}

		[Obsolete ("Use RecordSize property instead")]
		public int GetRecordSize ()
		{
			return recordSize;
		}

		[Obsolete ("Use BlockFactor property instead")]
		public int GetBlockFactor ()
		{
			return blockFactor;
		}

		public static TarBuffer CreateInputTarBuffer (Stream inputStream)
		{
			if (inputStream == null) {
				throw new ArgumentNullException ("inputStream");
			}
			return CreateInputTarBuffer (inputStream, 20);
		}

		public static TarBuffer CreateInputTarBuffer (Stream inputStream, int blockFactor)
		{
			if (inputStream == null) {
				throw new ArgumentNullException ("inputStream");
			}
			if (blockFactor <= 0) {
				throw new ArgumentOutOfRangeException ("blockFactor", "Factor cannot be negative");
			}
			TarBuffer tarBuffer = new TarBuffer ();
			tarBuffer.inputStream = inputStream;
			tarBuffer.outputStream = null;
			tarBuffer.Initialize (blockFactor);
			return tarBuffer;
		}

		public static TarBuffer CreateOutputTarBuffer (Stream outputStream)
		{
			if (outputStream == null) {
				throw new ArgumentNullException ("outputStream");
			}
			return CreateOutputTarBuffer (outputStream, 20);
		}

		public static TarBuffer CreateOutputTarBuffer (Stream outputStream, int blockFactor)
		{
			if (outputStream == null) {
				throw new ArgumentNullException ("outputStream");
			}
			if (blockFactor <= 0) {
				throw new ArgumentOutOfRangeException ("blockFactor", "Factor cannot be negative");
			}
			TarBuffer tarBuffer = new TarBuffer ();
			tarBuffer.inputStream = null;
			tarBuffer.outputStream = outputStream;
			tarBuffer.Initialize (blockFactor);
			return tarBuffer;
		}

		private void Initialize (int archiveBlockFactor)
		{
			blockFactor = archiveBlockFactor;
			recordSize = archiveBlockFactor * 512;
			recordBuffer = new byte[RecordSize];
			if (inputStream != null) {
				currentRecordIndex = -1;
				currentBlockIndex = BlockFactor;
			} else {
				currentRecordIndex = 0;
				currentBlockIndex = 0;
			}
		}

		[Obsolete ("Use IsEndOfArchiveBlock instead")]
		public bool IsEOFBlock (byte[] block)
		{
			if (block == null) {
				throw new ArgumentNullException ("block");
			}
			if (block.Length != 512) {
				throw new ArgumentException ("block length is invalid");
			}
			for (int i = 0; i < 512; i++) {
				if (block [i] != 0) {
					return false;
				}
			}
			return true;
		}

		public static bool IsEndOfArchiveBlock (byte[] block)
		{
			if (block == null) {
				throw new ArgumentNullException ("block");
			}
			if (block.Length != 512) {
				throw new ArgumentException ("block length is invalid");
			}
			for (int i = 0; i < 512; i++) {
				if (block [i] != 0) {
					return false;
				}
			}
			return true;
		}

		public void SkipBlock ()
		{
			if (inputStream == null) {
				throw new TarException ("no input stream defined");
			}
			if (currentBlockIndex >= BlockFactor && !ReadRecord ()) {
				throw new TarException ("Failed to read a record");
			}
			currentBlockIndex++;
		}

		public byte[] ReadBlock ()
		{
			if (inputStream == null) {
				throw new TarException ("TarBuffer.ReadBlock - no input stream defined");
			}
			if (currentBlockIndex >= BlockFactor && !ReadRecord ()) {
				throw new TarException ("Failed to read a record");
			}
			byte[] array = new byte[512];
			Array.Copy (recordBuffer, currentBlockIndex * 512, array, 0, 512);
			currentBlockIndex++;
			return array;
		}

		private bool ReadRecord ()
		{
			if (inputStream == null) {
				throw new TarException ("no input stream stream defined");
			}
			currentBlockIndex = 0;
			int num = 0;
			int num2 = RecordSize;
			while (num2 > 0) {
				long num3 = inputStream.Read (recordBuffer, num, num2);
				if (num3 <= 0) {
					break;
				}
				num += (int)num3;
				num2 -= (int)num3;
			}
			currentRecordIndex++;
			return true;
		}

		[Obsolete ("Use CurrentBlock property instead")]
		public int GetCurrentBlockNum ()
		{
			return currentBlockIndex;
		}

		[Obsolete ("Use CurrentRecord property instead")]
		public int GetCurrentRecordNum ()
		{
			return currentRecordIndex;
		}

		public void WriteBlock (byte[] block)
		{
			if (block == null) {
				throw new ArgumentNullException ("block");
			}
			if (outputStream == null) {
				throw new TarException ("TarBuffer.WriteBlock - no output stream defined");
			}
			if (block.Length != 512) {
				string message = $"TarBuffer.WriteBlock - block to write has length '{block.Length}' which is not the block size of '{512}'";
				throw new TarException (message);
			}
			if (currentBlockIndex >= BlockFactor) {
				WriteRecord ();
			}
			Array.Copy (block, 0, recordBuffer, currentBlockIndex * 512, 512);
			currentBlockIndex++;
		}

		public void WriteBlock (byte[] buffer, int offset)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (outputStream == null) {
				throw new TarException ("TarBuffer.WriteBlock - no output stream stream defined");
			}
			if (offset < 0 || offset >= buffer.Length) {
				throw new ArgumentOutOfRangeException ("offset");
			}
			if (offset + 512 > buffer.Length) {
				string message = $"TarBuffer.WriteBlock - record has length '{buffer.Length}' with offset '{offset}' which is less than the record size of '{recordSize}'";
				throw new TarException (message);
			}
			if (currentBlockIndex >= BlockFactor) {
				WriteRecord ();
			}
			Array.Copy (buffer, offset, recordBuffer, currentBlockIndex * 512, 512);
			currentBlockIndex++;
		}

		private void WriteRecord ()
		{
			if (outputStream == null) {
				throw new TarException ("TarBuffer.WriteRecord no output stream defined");
			}
			outputStream.Write (recordBuffer, 0, RecordSize);
			outputStream.Flush ();
			currentBlockIndex = 0;
			currentRecordIndex++;
		}

		private void WriteFinalRecord ()
		{
			if (outputStream == null) {
				throw new TarException ("TarBuffer.WriteFinalRecord no output stream defined");
			}
			if (currentBlockIndex > 0) {
				int num = currentBlockIndex * 512;
				Array.Clear (recordBuffer, num, RecordSize - num);
				WriteRecord ();
			}
			outputStream.Flush ();
		}

		public void Close ()
		{
			if (outputStream != null) {
				WriteFinalRecord ();
				if (isStreamOwner_) {
					outputStream.Close ();
				}
				outputStream = null;
			} else if (inputStream != null) {
				if (isStreamOwner_) {
					inputStream.Close ();
				}
				inputStream = null;
			}
		}
	}
	public class TarEntry : ICloneable
	{
		private string file;

		private TarHeader header;

		public TarHeader TarHeader => header;

		public string Name {
			get {
				return header.Name;
			}
			set {
				header.Name = value;
			}
		}

		public int UserId {
			get {
				return header.UserId;
			}
			set {
				header.UserId = value;
			}
		}

		public int GroupId {
			get {
				return header.GroupId;
			}
			set {
				header.GroupId = value;
			}
		}

		public string UserName {
			get {
				return header.UserName;
			}
			set {
				header.UserName = value;
			}
		}

		public string GroupName {
			get {
				return header.GroupName;
			}
			set {
				header.GroupName = value;
			}
		}

		public DateTime ModTime {
			get {
				return header.ModTime;
			}
			set {
				header.ModTime = value;
			}
		}

		public string File => file;

		public long Size {
			get {
				return header.Size;
			}
			set {
				header.Size = value;
			}
		}

		public bool IsDirectory {
			get {
				if (file != null) {
					return Directory.Exists (file);
				}
				if (header != null && (header.TypeFlag == 53 || Name.EndsWith ("/"))) {
					return true;
				}
				return false;
			}
		}

		private TarEntry ()
		{
			header = new TarHeader ();
		}

		public TarEntry (byte[] headerBuffer)
		{
			header = new TarHeader ();
			header.ParseBuffer (headerBuffer);
		}

		public TarEntry (TarHeader header)
		{
			if (header == null) {
				throw new ArgumentNullException ("header");
			}
			this.header = (TarHeader)header.Clone ();
		}

		public object Clone ()
		{
			TarEntry tarEntry = new TarEntry ();
			tarEntry.file = file;
			tarEntry.header = (TarHeader)header.Clone ();
			tarEntry.Name = Name;
			return tarEntry;
		}

		public static TarEntry CreateTarEntry (string name)
		{
			TarEntry tarEntry = new TarEntry ();
			NameTarHeader (tarEntry.header, name);
			return tarEntry;
		}

		public static TarEntry CreateEntryFromFile (string fileName)
		{
			TarEntry tarEntry = new TarEntry ();
			tarEntry.GetFileTarHeader (tarEntry.header, fileName);
			return tarEntry;
		}

		public override bool Equals (object obj)
		{
			if (obj is TarEntry tarEntry) {
				return Name.Equals (tarEntry.Name);
			}
			return false;
		}

		public override int GetHashCode ()
		{
			return Name.GetHashCode ();
		}

		public bool IsDescendent (TarEntry toTest)
		{
			if (toTest == null) {
				throw new ArgumentNullException ("toTest");
			}
			return toTest.Name.StartsWith (Name);
		}

		public void SetIds (int userId, int groupId)
		{
			UserId = userId;
			GroupId = groupId;
		}

		public void SetNames (string userName, string groupName)
		{
			UserName = userName;
			GroupName = groupName;
		}

		public void GetFileTarHeader (TarHeader header, string file)
		{
			if (header == null) {
				throw new ArgumentNullException ("header");
			}
			if (file == null) {
				throw new ArgumentNullException ("file");
			}
			this.file = file;
			string text = file;
			if (text.IndexOf (Environment.CurrentDirectory) == 0) {
				text = text.Substring (Environment.CurrentDirectory.Length);
			}
			text = text.Replace (Path.DirectorySeparatorChar, '/');
			while (text.StartsWith ("/")) {
				text = text.Substring (1);
			}
			header.LinkName = string.Empty;
			header.Name = text;
			if (Directory.Exists (file)) {
				header.Mode = 1003;
				header.TypeFlag = 53;
				if (header.Name.Length == 0 || header.Name [header.Name.Length - 1] != '/') {
					header.Name += "/";
				}
				header.Size = 0L;
			} else {
				header.Mode = 33216;
				header.TypeFlag = 48;
				header.Size = new FileInfo (file.Replace ('/', Path.DirectorySeparatorChar)).Length;
			}
			header.ModTime = System.IO.File.GetLastWriteTime (file.Replace ('/', Path.DirectorySeparatorChar)).ToUniversalTime ();
			header.DevMajor = 0;
			header.DevMinor = 0;
		}

		public TarEntry[] GetDirectoryEntries ()
		{
			if (file == null || !Directory.Exists (file)) {
				return new TarEntry[0];
			}
			string[] fileSystemEntries = Directory.GetFileSystemEntries (file);
			TarEntry[] array = new TarEntry[fileSystemEntries.Length];
			for (int i = 0; i < fileSystemEntries.Length; i++) {
				array [i] = CreateEntryFromFile (fileSystemEntries [i]);
			}
			return array;
		}

		public void WriteEntryHeader (byte[] outBuffer)
		{
			header.WriteHeader (outBuffer);
		}

		public static void AdjustEntryName (byte[] buffer, string newName)
		{
			TarHeader.GetNameBytes (newName, buffer, 0, 100);
		}

		public static void NameTarHeader (TarHeader header, string name)
		{
			if (header == null) {
				throw new ArgumentNullException ("header");
			}
			if (name == null) {
				throw new ArgumentNullException ("name");
			}
			bool flag = name.EndsWith ("/");
			header.Name = name;
			header.Mode = ((!flag) ? 33216 : 1003);
			header.UserId = 0;
			header.GroupId = 0;
			header.Size = 0L;
			header.ModTime = DateTime.UtcNow;
			header.TypeFlag = (byte)((!flag) ? 48 : 53);
			header.LinkName = string.Empty;
			header.UserName = string.Empty;
			header.GroupName = string.Empty;
			header.DevMajor = 0;
			header.DevMinor = 0;
		}
	}
	[Serializable]
	public class TarException : SharpZipBaseException
	{
		protected TarException (SerializationInfo info, StreamingContext context)
			: base (info, context)
		{
		}

		public TarException ()
		{
		}

		public TarException (string message)
			: base (message)
		{
		}

		public TarException (string message, Exception exception)
			: base (message, exception)
		{
		}
	}
	public class TarHeader : ICloneable
	{
		public const int NAMELEN = 100;

		public const int MODELEN = 8;

		public const int UIDLEN = 8;

		public const int GIDLEN = 8;

		public const int CHKSUMLEN = 8;

		public const int CHKSUMOFS = 148;

		public const int SIZELEN = 12;

		public const int MAGICLEN = 6;

		public const int VERSIONLEN = 2;

		public const int MODTIMELEN = 12;

		public const int UNAMELEN = 32;

		public const int GNAMELEN = 32;

		public const int DEVLEN = 8;

		public const byte LF_OLDNORM = 0;

		public const byte LF_NORMAL = 48;

		public const byte LF_LINK = 49;

		public const byte LF_SYMLINK = 50;

		public const byte LF_CHR = 51;

		public const byte LF_BLK = 52;

		public const byte LF_DIR = 53;

		public const byte LF_FIFO = 54;

		public const byte LF_CONTIG = 55;

		public const byte LF_GHDR = 103;

		public const byte LF_XHDR = 120;

		public const byte LF_ACL = 65;

		public const byte LF_GNU_DUMPDIR = 68;

		public const byte LF_EXTATTR = 69;

		public const byte LF_META = 73;

		public const byte LF_GNU_LONGLINK = 75;

		public const byte LF_GNU_LONGNAME = 76;

		public const byte LF_GNU_MULTIVOL = 77;

		public const byte LF_GNU_NAMES = 78;

		public const byte LF_GNU_SPARSE = 83;

		public const byte LF_GNU_VOLHDR = 86;

		public const string TMAGIC = "ustar ";

		public const string GNU_TMAGIC = "ustar  ";

		private const long timeConversionFactor = 10000000L;

		private static readonly DateTime dateTime1970 = new DateTime (1970, 1, 1, 0, 0, 0, 0);

		private string name;

		private int mode;

		private int userId;

		private int groupId;

		private long size;

		private DateTime modTime;

		private int checksum;

		private bool isChecksumValid;

		private byte typeFlag;

		private string linkName;

		private string magic;

		private string version;

		private string userName;

		private string groupName;

		private int devMajor;

		private int devMinor;

		internal static int userIdAsSet;

		internal static int groupIdAsSet;

		internal static string userNameAsSet;

		internal static string groupNameAsSet = "None";

		internal static int defaultUserId;

		internal static int defaultGroupId;

		internal static string defaultGroupName = "None";

		internal static string defaultUser;

		public string Name {
			get {
				return name;
			}
			set {
				if (value == null) {
					throw new ArgumentNullException ("value");
				}
				name = value;
			}
		}

		public int Mode {
			get {
				return mode;
			}
			set {
				mode = value;
			}
		}

		public int UserId {
			get {
				return userId;
			}
			set {
				userId = value;
			}
		}

		public int GroupId {
			get {
				return groupId;
			}
			set {
				groupId = value;
			}
		}

		public long Size {
			get {
				return size;
			}
			set {
				if (value < 0) {
					throw new ArgumentOutOfRangeException ("value", "Cannot be less than zero");
				}
				size = value;
			}
		}

		public DateTime ModTime {
			get {
				return modTime;
			}
			set {
				if (value < dateTime1970) {
					throw new ArgumentOutOfRangeException ("value", "ModTime cannot be before Jan 1st 1970");
				}
				modTime = new DateTime (value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second);
			}
		}

		public int Checksum => checksum;

		public bool IsChecksumValid => isChecksumValid;

		public byte TypeFlag {
			get {
				return typeFlag;
			}
			set {
				typeFlag = value;
			}
		}

		public string LinkName {
			get {
				return linkName;
			}
			set {
				if (value == null) {
					throw new ArgumentNullException ("value");
				}
				linkName = value;
			}
		}

		public string Magic {
			get {
				return magic;
			}
			set {
				if (value == null) {
					throw new ArgumentNullException ("value");
				}
				magic = value;
			}
		}

		public string Version {
			get {
				return version;
			}
			set {
				if (value == null) {
					throw new ArgumentNullException ("value");
				}
				version = value;
			}
		}

		public string UserName {
			get {
				return userName;
			}
			set {
				if (value != null) {
					userName = value.Substring (0, Math.Min (32, value.Length));
					return;
				}
				string text = "gwt_tar";
				if (text.Length > 32) {
					text = text.Substring (0, 32);
				}
				userName = text;
			}
		}

		public string GroupName {
			get {
				return groupName;
			}
			set {
				if (value == null) {
					groupName = "None";
				} else {
					groupName = value;
				}
			}
		}

		public int DevMajor {
			get {
				return devMajor;
			}
			set {
				devMajor = value;
			}
		}

		public int DevMinor {
			get {
				return devMinor;
			}
			set {
				devMinor = value;
			}
		}

		public TarHeader ()
		{
			Magic = "ustar ";
			Version = " ";
			Name = string.Empty;
			LinkName = string.Empty;
			UserId = defaultUserId;
			GroupId = defaultGroupId;
			UserName = defaultUser;
			GroupName = defaultGroupName;
			Size = 0L;
		}

		[Obsolete ("Use the Name property instead", true)]
		public string GetName ()
		{
			return name;
		}

		public object Clone ()
		{
			return MemberwiseClone ();
		}

		public void ParseBuffer (byte[] header)
		{
			if (header == null) {
				throw new ArgumentNullException ("header");
			}
			int num = 0;
			name = ParseName (header, num, 100).ToString ();
			num += 100;
			mode = (int)ParseOctal (header, num, 8);
			num += 8;
			UserId = (int)ParseOctal (header, num, 8);
			num += 8;
			GroupId = (int)ParseOctal (header, num, 8);
			num += 8;
			Size = ParseOctal (header, num, 12);
			num += 12;
			ModTime = GetDateTimeFromCTime (ParseOctal (header, num, 12));
			num += 12;
			checksum = (int)ParseOctal (header, num, 8);
			num += 8;
			TypeFlag = header [num++];
			LinkName = ParseName (header, num, 100).ToString ();
			num += 100;
			Magic = ParseName (header, num, 6).ToString ();
			num += 6;
			Version = ParseName (header, num, 2).ToString ();
			num += 2;
			UserName = ParseName (header, num, 32).ToString ();
			num += 32;
			GroupName = ParseName (header, num, 32).ToString ();
			num += 32;
			DevMajor = (int)ParseOctal (header, num, 8);
			num += 8;
			DevMinor = (int)ParseOctal (header, num, 8);
			isChecksumValid = Checksum == MakeCheckSum (header);
		}

		public void WriteHeader (byte[] outBuffer)
		{
			if (outBuffer == null) {
				throw new ArgumentNullException ("outBuffer");
			}
			int offset = 0;
			offset = GetNameBytes (Name, outBuffer, offset, 100);
			offset = GetOctalBytes (mode, outBuffer, offset, 8);
			offset = GetOctalBytes (UserId, outBuffer, offset, 8);
			offset = GetOctalBytes (GroupId, outBuffer, offset, 8);
			offset = GetLongOctalBytes (Size, outBuffer, offset, 12);
			offset = GetLongOctalBytes (GetCTime (ModTime), outBuffer, offset, 12);
			int offset2 = offset;
			for (int i = 0; i < 8; i++) {
				outBuffer [offset++] = 32;
			}
			outBuffer [offset++] = TypeFlag;
			offset = GetNameBytes (LinkName, outBuffer, offset, 100);
			offset = GetAsciiBytes (Magic, 0, outBuffer, offset, 6);
			offset = GetNameBytes (Version, outBuffer, offset, 2);
			offset = GetNameBytes (UserName, outBuffer, offset, 32);
			offset = GetNameBytes (GroupName, outBuffer, offset, 32);
			if (TypeFlag == 51 || TypeFlag == 52) {
				offset = GetOctalBytes (DevMajor, outBuffer, offset, 8);
				offset = GetOctalBytes (DevMinor, outBuffer, offset, 8);
			}
			while (offset < outBuffer.Length) {
				outBuffer [offset++] = 0;
			}
			checksum = ComputeCheckSum (outBuffer);
			GetCheckSumOctalBytes (checksum, outBuffer, offset2, 8);
			isChecksumValid = true;
		}

		public override int GetHashCode ()
		{
			return Name.GetHashCode ();
		}

		public override bool Equals (object obj)
		{
			if (obj is TarHeader tarHeader) {
				return name == tarHeader.name && mode == tarHeader.mode && UserId == tarHeader.UserId && GroupId == tarHeader.GroupId && Size == tarHeader.Size && ModTime == tarHeader.ModTime && Checksum == tarHeader.Checksum && TypeFlag == tarHeader.TypeFlag && LinkName == tarHeader.LinkName && Magic == tarHeader.Magic && Version == tarHeader.Version && UserName == tarHeader.UserName && GroupName == tarHeader.GroupName && DevMajor == tarHeader.DevMajor && DevMinor == tarHeader.DevMinor;
			}
			return false;
		}

		internal static void SetValueDefaults (int userId, string userName, int groupId, string groupName)
		{
			defaultUserId = (userIdAsSet = userId);
			defaultUser = (userNameAsSet = userName);
			defaultGroupId = (groupIdAsSet = groupId);
			defaultGroupName = (groupNameAsSet = groupName);
		}

		internal static void RestoreSetValues ()
		{
			defaultUserId = userIdAsSet;
			defaultUser = userNameAsSet;
			defaultGroupId = groupIdAsSet;
			defaultGroupName = groupNameAsSet;
		}

		public static long ParseOctal (byte[] header, int offset, int length)
		{
			if (header == null) {
				throw new ArgumentNullException ("header");
			}
			long num = 0L;
			bool flag = true;
			int num2 = offset + length;
			for (int i = offset; i < num2 && header [i] != 0; i++) {
				if (header [i] == 32 || header [i] == 48) {
					if (flag) {
						continue;
					}
					if (header [i] == 32) {
						break;
					}
				}
				flag = false;
				num = (num << 3) + (header [i] - 48);
			}
			return num;
		}

		public static StringBuilder ParseName (byte[] header, int offset, int length)
		{
			if (header == null) {
				throw new ArgumentNullException ("header");
			}
			if (offset < 0) {
				throw new ArgumentOutOfRangeException ("offset", "Cannot be less than zero");
			}
			if (length < 0) {
				throw new ArgumentOutOfRangeException ("length", "Cannot be less than zero");
			}
			if (offset + length > header.Length) {
				throw new ArgumentException ("Exceeds header size", "length");
			}
			StringBuilder stringBuilder = new StringBuilder (length);
			for (int i = offset; i < offset + length && header [i] != 0; i++) {
				stringBuilder.Append ((char)header [i]);
			}
			return stringBuilder;
		}

		public static int GetNameBytes (StringBuilder name, int nameOffset, byte[] buffer, int bufferOffset, int length)
		{
			if (name == null) {
				throw new ArgumentNullException ("name");
			}
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			return GetNameBytes (name.ToString (), nameOffset, buffer, bufferOffset, length);
		}

		public static int GetNameBytes (string name, int nameOffset, byte[] buffer, int bufferOffset, int length)
		{
			if (name == null) {
				throw new ArgumentNullException ("name");
			}
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			int i;
			for (i = 0; i < length - 1 && nameOffset + i < name.Length; i++) {
				buffer [bufferOffset + i] = (byte)name [nameOffset + i];
			}
			for (; i < length; i++) {
				buffer [bufferOffset + i] = 0;
			}
			return bufferOffset + length;
		}

		public static int GetNameBytes (StringBuilder name, byte[] buffer, int offset, int length)
		{
			if (name == null) {
				throw new ArgumentNullException ("name");
			}
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			return GetNameBytes (name.ToString (), 0, buffer, offset, length);
		}

		public static int GetNameBytes (string name, byte[] buffer, int offset, int length)
		{
			if (name == null) {
				throw new ArgumentNullException ("name");
			}
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			return GetNameBytes (name, 0, buffer, offset, length);
		}

		public static int GetAsciiBytes (string toAdd, int nameOffset, byte[] buffer, int bufferOffset, int length)
		{
			if (toAdd == null) {
				throw new ArgumentNullException ("toAdd");
			}
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			for (int i = 0; i < length && nameOffset + i < toAdd.Length; i++) {
				buffer [bufferOffset + i] = (byte)toAdd [nameOffset + i];
			}
			return bufferOffset + length;
		}

		public static int GetOctalBytes (long value, byte[] buffer, int offset, int length)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			int num = length - 1;
			buffer [offset + num] = 0;
			num--;
			if (value > 0) {
				long num2 = value;
				while (num >= 0 && num2 > 0) {
					buffer [offset + num] = (byte)(48 + (byte)(num2 & 7));
					num2 >>= 3;
					num--;
				}
			}
			while (num >= 0) {
				buffer [offset + num] = 48;
				num--;
			}
			return offset + length;
		}

		public static int GetLongOctalBytes (long value, byte[] buffer, int offset, int length)
		{
			return GetOctalBytes (value, buffer, offset, length);
		}

		private static int GetCheckSumOctalBytes (long value, byte[] buffer, int offset, int length)
		{
			GetOctalBytes (value, buffer, offset, length - 1);
			return offset + length;
		}

		private static int ComputeCheckSum (byte[] buffer)
		{
			int num = 0;
			for (int i = 0; i < buffer.Length; i++) {
				num += buffer [i];
			}
			return num;
		}

		private static int MakeCheckSum (byte[] buffer)
		{
			int num = 0;
			for (int i = 0; i < 148; i++) {
				num += buffer [i];
			}
			for (int j = 0; j < 8; j++) {
				num += 32;
			}
			for (int k = 156; k < buffer.Length; k++) {
				num += buffer [k];
			}
			return num;
		}

		private static int GetCTime (DateTime dateTime)
		{
			return (int)((dateTime.Ticks - dateTime1970.Ticks) / 10000000);
		}

		private static DateTime GetDateTimeFromCTime (long ticks)
		{
			DateTime result;
			try {
				result = new DateTime (dateTime1970.Ticks + ticks * 10000000);
			} catch (ArgumentOutOfRangeException) {
				return dateTime1970;
			}
			return result;
		}
	}
	public class TarInputStream : Stream
	{
		public interface IEntryFactory
		{
			TarEntry CreateEntry (string name);

			TarEntry CreateEntryFromFile (string fileName);

			TarEntry CreateEntry (byte[] headerBuffer);
		}

		public class EntryFactoryAdapter : IEntryFactory
		{
			public TarEntry CreateEntry (string name)
			{
				return TarEntry.CreateTarEntry (name);
			}

			public TarEntry CreateEntryFromFile (string fileName)
			{
				return TarEntry.CreateEntryFromFile (fileName);
			}

			public TarEntry CreateEntry (byte[] headerBuffer)
			{
				return new TarEntry (headerBuffer);
			}
		}

		protected bool hasHitEOF;

		protected long entrySize;

		protected long entryOffset;

		protected byte[] readBuffer;

		protected TarBuffer tarBuffer;

		private TarEntry currentEntry;

		protected IEntryFactory entryFactory;

		private readonly Stream inputStream;

		public bool IsStreamOwner {
			get {
				return tarBuffer.IsStreamOwner;
			}
			set {
				tarBuffer.IsStreamOwner = value;
			}
		}

		public override bool CanRead => inputStream.CanRead;

		public override bool CanSeek => false;

		public override bool CanWrite => false;

		public override long Length => inputStream.Length;

		public override long Position {
			get {
				return inputStream.Position;
			}
			set {
				throw new NotSupportedException ("TarInputStream Seek not supported");
			}
		}

		public int RecordSize => tarBuffer.RecordSize;

		public long Available => entrySize - entryOffset;

		public bool IsMarkSupported => false;

		public TarInputStream (Stream inputStream)
			: this (inputStream, 20)
		{
		}

		public TarInputStream (Stream inputStream, int blockFactor)
		{
			this.inputStream = inputStream;
			tarBuffer = TarBuffer.CreateInputTarBuffer (inputStream, blockFactor);
		}

		public override void Flush ()
		{
			inputStream.Flush ();
		}

		public override long Seek (long offset, SeekOrigin origin)
		{
			throw new NotSupportedException ("TarInputStream Seek not supported");
		}

		public override void SetLength (long value)
		{
			throw new NotSupportedException ("TarInputStream SetLength not supported");
		}

		public override void Write (byte[] buffer, int offset, int count)
		{
			throw new NotSupportedException ("TarInputStream Write not supported");
		}

		public override void WriteByte (byte value)
		{
			throw new NotSupportedException ("TarInputStream WriteByte not supported");
		}

		public override int ReadByte ()
		{
			byte[] array = new byte[1];
			int num = Read (array, 0, 1);
			if (num <= 0) {
				return -1;
			}
			return array [0];
		}

		public override int Read (byte[] buffer, int offset, int count)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			int num = 0;
			if (entryOffset >= entrySize) {
				return 0;
			}
			long num2 = count;
			if (num2 + entryOffset > entrySize) {
				num2 = entrySize - entryOffset;
			}
			if (readBuffer != null) {
				int num3 = (int)((num2 <= readBuffer.Length) ? num2 : readBuffer.Length);
				Array.Copy (readBuffer, 0, buffer, offset, num3);
				if (num3 >= readBuffer.Length) {
					readBuffer = null;
				} else {
					int num4 = readBuffer.Length - num3;
					byte[] destinationArray = new byte[num4];
					Array.Copy (readBuffer, num3, destinationArray, 0, num4);
					readBuffer = destinationArray;
				}
				num += num3;
				num2 -= num3;
				offset += num3;
			}
			while (num2 > 0) {
				byte[] array = tarBuffer.ReadBlock ();
				if (array == null) {
					throw new TarException ("unexpected EOF with " + num2 + " bytes unread");
				}
				int num5 = (int)num2;
				int num6 = array.Length;
				if (num6 > num5) {
					Array.Copy (array, 0, buffer, offset, num5);
					readBuffer = new byte[num6 - num5];
					Array.Copy (array, num5, readBuffer, 0, num6 - num5);
				} else {
					num5 = num6;
					Array.Copy (array, 0, buffer, offset, num6);
				}
				num += num5;
				num2 -= num5;
				offset += num5;
			}
			entryOffset += num;
			return num;
		}

		public override void Close ()
		{
			tarBuffer.Close ();
		}

		public void SetEntryFactory (IEntryFactory factory)
		{
			entryFactory = factory;
		}

		[Obsolete ("Use RecordSize property instead")]
		public int GetRecordSize ()
		{
			return tarBuffer.RecordSize;
		}

		public void Skip (long skipCount)
		{
			byte[] array = new byte[8192];
			long num = skipCount;
			while (num > 0) {
				int count = (int)((num <= array.Length) ? num : array.Length);
				int num2 = Read (array, 0, count);
				if (num2 == -1) {
					break;
				}
				num -= num2;
			}
		}

		public void Mark (int markLimit)
		{
		}

		public void Reset ()
		{
		}

		public TarEntry GetNextEntry ()
		{
			if (hasHitEOF) {
				return null;
			}
			if (currentEntry != null) {
				SkipToNextEntry ();
			}
			byte[] array = tarBuffer.ReadBlock ();
			if (array == null) {
				hasHitEOF = true;
			} else if (TarBuffer.IsEndOfArchiveBlock (array)) {
				hasHitEOF = true;
			}
			if (hasHitEOF) {
				currentEntry = null;
			} else {
				try {
					TarHeader tarHeader = new TarHeader ();
					tarHeader.ParseBuffer (array);
					if (!tarHeader.IsChecksumValid) {
						throw new TarException ("Header checksum is invalid");
					}
					entryOffset = 0L;
					entrySize = tarHeader.Size;
					StringBuilder stringBuilder = null;
					if (tarHeader.TypeFlag == 76) {
						byte[] array2 = new byte[512];
						long num = entrySize;
						stringBuilder = new StringBuilder ();
						while (num > 0) {
							int num2 = Read (array2, 0, (int)((num <= array2.Length) ? num : array2.Length));
							if (num2 == -1) {
								throw new InvalidHeaderException ("Failed to read long name entry");
							}
							stringBuilder.Append (TarHeader.ParseName (array2, 0, num2).ToString ());
							num -= num2;
						}
						SkipToNextEntry ();
						array = tarBuffer.ReadBlock ();
					} else if (tarHeader.TypeFlag == 103) {
						SkipToNextEntry ();
						array = tarBuffer.ReadBlock ();
					} else if (tarHeader.TypeFlag == 120) {
						SkipToNextEntry ();
						array = tarBuffer.ReadBlock ();
					} else if (tarHeader.TypeFlag == 86) {
						SkipToNextEntry ();
						array = tarBuffer.ReadBlock ();
					} else if (tarHeader.TypeFlag != 48 && tarHeader.TypeFlag != 0 && tarHeader.TypeFlag != 53) {
						SkipToNextEntry ();
						array = tarBuffer.ReadBlock ();
					}
					if (entryFactory == null) {
						currentEntry = new TarEntry (array);
						if (stringBuilder != null) {
							currentEntry.Name = stringBuilder.ToString ();
						}
					} else {
						currentEntry = entryFactory.CreateEntry (array);
					}
					entryOffset = 0L;
					entrySize = currentEntry.Size;
				} catch (InvalidHeaderException ex) {
					entrySize = 0L;
					entryOffset = 0L;
					currentEntry = null;
					string message = $"Bad header in record {tarBuffer.CurrentRecord} block {tarBuffer.CurrentBlock} {ex.Message}";
					throw new InvalidHeaderException (message);
				}
			}
			return currentEntry;
		}

		public void CopyEntryContents (Stream outputStream)
		{
			byte[] array = new byte[32768];
			while (true) {
				int num = Read (array, 0, array.Length);
				if (num <= 0) {
					break;
				}
				outputStream.Write (array, 0, num);
			}
		}

		private void SkipToNextEntry ()
		{
			long num = entrySize - entryOffset;
			if (num > 0) {
				Skip (num);
			}
			readBuffer = null;
		}
	}
	public class TarOutputStream : Stream
	{
		private long currBytes;

		private int assemblyBufferLength;

		private bool isClosed;

		protected long currSize;

		protected byte[] blockBuffer;

		protected byte[] assemblyBuffer;

		protected TarBuffer buffer;

		protected Stream outputStream;

		public bool IsStreamOwner {
			get {
				return buffer.IsStreamOwner;
			}
			set {
				buffer.IsStreamOwner = value;
			}
		}

		public override bool CanRead => outputStream.CanRead;

		public override bool CanSeek => outputStream.CanSeek;

		public override bool CanWrite => outputStream.CanWrite;

		public override long Length => outputStream.Length;

		public override long Position {
			get {
				return outputStream.Position;
			}
			set {
				outputStream.Position = value;
			}
		}

		public int RecordSize => buffer.RecordSize;

		private bool IsEntryOpen => currBytes < currSize;

		public TarOutputStream (Stream outputStream)
			: this (outputStream, 20)
		{
		}

		public TarOutputStream (Stream outputStream, int blockFactor)
		{
			if (outputStream == null) {
				throw new ArgumentNullException ("outputStream");
			}
			this.outputStream = outputStream;
			buffer = TarBuffer.CreateOutputTarBuffer (outputStream, blockFactor);
			assemblyBuffer = new byte[512];
			blockBuffer = new byte[512];
		}

		public override long Seek (long offset, SeekOrigin origin)
		{
			return outputStream.Seek (offset, origin);
		}

		public override void SetLength (long value)
		{
			outputStream.SetLength (value);
		}

		public override int ReadByte ()
		{
			return outputStream.ReadByte ();
		}

		public override int Read (byte[] buffer, int offset, int count)
		{
			return outputStream.Read (buffer, offset, count);
		}

		public override void Flush ()
		{
			outputStream.Flush ();
		}

		public void Finish ()
		{
			if (IsEntryOpen) {
				CloseEntry ();
			}
			WriteEofBlock ();
		}

		public override void Close ()
		{
			if (!isClosed) {
				isClosed = true;
				Finish ();
				buffer.Close ();
			}
		}

		[Obsolete ("Use RecordSize property instead")]
		public int GetRecordSize ()
		{
			return buffer.RecordSize;
		}

		public void PutNextEntry (TarEntry entry)
		{
			if (entry == null) {
				throw new ArgumentNullException ("entry");
			}
			if (entry.TarHeader.Name.Length >= 100) {
				TarHeader tarHeader = new TarHeader ();
				tarHeader.TypeFlag = 76;
				tarHeader.Name += "././@LongLink";
				tarHeader.UserId = 0;
				tarHeader.GroupId = 0;
				tarHeader.GroupName = string.Empty;
				tarHeader.UserName = string.Empty;
				tarHeader.LinkName = string.Empty;
				tarHeader.Size = entry.TarHeader.Name.Length;
				tarHeader.WriteHeader (blockBuffer);
				buffer.WriteBlock (blockBuffer);
				int num = 0;
				while (num < entry.TarHeader.Name.Length) {
					Array.Clear (blockBuffer, 0, blockBuffer.Length);
					TarHeader.GetAsciiBytes (entry.TarHeader.Name, num, blockBuffer, 0, 512);
					num += 512;
					buffer.WriteBlock (blockBuffer);
				}
			}
			entry.WriteEntryHeader (blockBuffer);
			buffer.WriteBlock (blockBuffer);
			currBytes = 0L;
			currSize = ((!entry.IsDirectory) ? entry.Size : 0);
		}

		public void CloseEntry ()
		{
			if (assemblyBufferLength > 0) {
				Array.Clear (assemblyBuffer, assemblyBufferLength, assemblyBuffer.Length - assemblyBufferLength);
				buffer.WriteBlock (assemblyBuffer);
				currBytes += assemblyBufferLength;
				assemblyBufferLength = 0;
			}
			if (currBytes < currSize) {
				string message = $"Entry closed at '{currBytes}' before the '{currSize}' bytes specified in the header were written";
				throw new TarException (message);
			}
		}

		public override void WriteByte (byte value)
		{
			Write (new byte[1] { value }, 0, 1);
		}

		public override void Write (byte[] buffer, int offset, int count)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (offset < 0) {
				throw new ArgumentOutOfRangeException ("offset", "Cannot be negative");
			}
			if (buffer.Length - offset < count) {
				throw new ArgumentException ("offset and count combination is invalid");
			}
			if (count < 0) {
				throw new ArgumentOutOfRangeException ("count", "Cannot be negative");
			}
			if (currBytes + count > currSize) {
				string message = $"request to write '{count}' bytes exceeds size in header of '{currSize}' bytes";
				throw new ArgumentOutOfRangeException ("count", message);
			}
			if (assemblyBufferLength > 0) {
				if (assemblyBufferLength + count >= blockBuffer.Length) {
					int num = blockBuffer.Length - assemblyBufferLength;
					Array.Copy (assemblyBuffer, 0, blockBuffer, 0, assemblyBufferLength);
					Array.Copy (buffer, offset, blockBuffer, assemblyBufferLength, num);
					this.buffer.WriteBlock (blockBuffer);
					currBytes += blockBuffer.Length;
					offset += num;
					count -= num;
					assemblyBufferLength = 0;
				} else {
					Array.Copy (buffer, offset, assemblyBuffer, assemblyBufferLength, count);
					offset += count;
					assemblyBufferLength += count;
					count -= count;
				}
			}
			while (count > 0) {
				if (count < blockBuffer.Length) {
					Array.Copy (buffer, offset, assemblyBuffer, assemblyBufferLength, count);
					assemblyBufferLength += count;
					break;
				}
				this.buffer.WriteBlock (buffer, offset);
				int num2 = blockBuffer.Length;
				currBytes += num2;
				count -= num2;
				offset += num2;
			}
		}

		private void WriteEofBlock ()
		{
			Array.Clear (blockBuffer, 0, blockBuffer.Length);
			buffer.WriteBlock (blockBuffer);
		}
	}
}
namespace ICSharpCode.SharpZipLib.Zip.Compression
{
	public class Deflater
	{
		public const int BEST_COMPRESSION = 9;

		public const int BEST_SPEED = 1;

		public const int DEFAULT_COMPRESSION = -1;

		public const int NO_COMPRESSION = 0;

		public const int DEFLATED = 8;

		private const int IS_SETDICT = 1;

		private const int IS_FLUSHING = 4;

		private const int IS_FINISHING = 8;

		private const int INIT_STATE = 0;

		private const int SETDICT_STATE = 1;

		private const int BUSY_STATE = 16;

		private const int FLUSHING_STATE = 20;

		private const int FINISHING_STATE = 28;

		private const int FINISHED_STATE = 30;

		private const int CLOSED_STATE = 127;

		private int level;

		private bool noZlibHeaderOrFooter;

		private int state;

		private long totalOut;

		private DeflaterPending pending;

		private DeflaterEngine engine;

		public int Adler => engine.Adler;

		public long TotalIn => engine.TotalIn;

		public long TotalOut => totalOut;

		public bool IsFinished => state == 30 && pending.IsFlushed;

		public bool IsNeedingInput => engine.NeedsInput ();

		public Deflater ()
			: this (-1, noZlibHeaderOrFooter: false)
		{
		}

		public Deflater (int level)
			: this (level, noZlibHeaderOrFooter: false)
		{
		}

		public Deflater (int level, bool noZlibHeaderOrFooter)
		{
			switch (level) {
			case -1:
				level = 6;
				break;
			default:
				throw new ArgumentOutOfRangeException ("level");
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
				break;
			}
			pending = new DeflaterPending ();
			engine = new DeflaterEngine (pending);
			this.noZlibHeaderOrFooter = noZlibHeaderOrFooter;
			SetStrategy (DeflateStrategy.Default);
			SetLevel (level);
			Reset ();
		}

		public void Reset ()
		{
			state = (noZlibHeaderOrFooter ? 16 : 0);
			totalOut = 0L;
			pending.Reset ();
			engine.Reset ();
		}

		public void Flush ()
		{
			state |= 4;
		}

		public void Finish ()
		{
			state |= 12;
		}

		public void SetInput (byte[] input)
		{
			SetInput (input, 0, input.Length);
		}

		public void SetInput (byte[] input, int offset, int count)
		{
			if (((uint)state & 8u) != 0) {
				throw new InvalidOperationException ("Finish() already called");
			}
			engine.SetInput (input, offset, count);
		}

		public void SetLevel (int level)
		{
			switch (level) {
			case -1:
				level = 6;
				break;
			default:
				throw new ArgumentOutOfRangeException ("level");
			case 0:
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
				break;
			}
			if (this.level != level) {
				this.level = level;
				engine.SetLevel (level);
			}
		}

		public int GetLevel ()
		{
			return level;
		}

		public void SetStrategy (DeflateStrategy strategy)
		{
			engine.Strategy = strategy;
		}

		public int Deflate (byte[] output)
		{
			return Deflate (output, 0, output.Length);
		}

		public int Deflate (byte[] output, int offset, int length)
		{
			int num = length;
			if (state == 127) {
				throw new InvalidOperationException ("Deflater closed");
			}
			if (state < 16) {
				int num2 = 30720;
				int num3 = level - 1 >> 1;
				if (num3 < 0 || num3 > 3) {
					num3 = 3;
				}
				num2 |= num3 << 6;
				if (((uint)state & (true ? 1u : 0u)) != 0) {
					num2 |= 0x20;
				}
				num2 += 31 - num2 % 31;
				pending.WriteShortMSB (num2);
				if (((uint)state & (true ? 1u : 0u)) != 0) {
					int adler = engine.Adler;
					engine.ResetAdler ();
					pending.WriteShortMSB (adler >> 16);
					pending.WriteShortMSB (adler & 0xFFFF);
				}
				state = 0x10 | (state & 0xC);
			}
			while (true) {
				int num4 = pending.Flush (output, offset, length);
				offset += num4;
				totalOut += num4;
				length -= num4;
				if (length == 0 || state == 30) {
					break;
				}
				if (engine.Deflate ((state & 4) != 0, (state & 8) != 0)) {
					continue;
				}
				if (state == 16) {
					return num - length;
				}
				if (state == 20) {
					if (level != 0) {
						for (int num5 = 8 + (-pending.BitCount & 7); num5 > 0; num5 -= 10) {
							pending.WriteBits (2, 10);
						}
					}
					state = 16;
				} else if (state == 28) {
					pending.AlignToByte ();
					if (!noZlibHeaderOrFooter) {
						int adler2 = engine.Adler;
						pending.WriteShortMSB (adler2 >> 16);
						pending.WriteShortMSB (adler2 & 0xFFFF);
					}
					state = 30;
				}
			}
			return num - length;
		}

		public void SetDictionary (byte[] dictionary)
		{
			SetDictionary (dictionary, 0, dictionary.Length);
		}

		public void SetDictionary (byte[] dictionary, int index, int count)
		{
			if (state != 0) {
				throw new InvalidOperationException ();
			}
			state = 1;
			engine.SetDictionary (dictionary, index, count);
		}
	}
	public class DeflaterConstants
	{
		public const bool DEBUGGING = false;

		public const int STORED_BLOCK = 0;

		public const int STATIC_TREES = 1;

		public const int DYN_TREES = 2;

		public const int PRESET_DICT = 32;

		public const int DEFAULT_MEM_LEVEL = 8;

		public const int MAX_MATCH = 258;

		public const int MIN_MATCH = 3;

		public const int MAX_WBITS = 15;

		public const int WSIZE = 32768;

		public const int WMASK = 32767;

		public const int HASH_BITS = 15;

		public const int HASH_SIZE = 32768;

		public const int HASH_MASK = 32767;

		public const int HASH_SHIFT = 5;

		public const int MIN_LOOKAHEAD = 262;

		public const int MAX_DIST = 32506;

		public const int PENDING_BUF_SIZE = 65536;

		public static int MAX_BLOCK_SIZE = Math.Min (65535, 65531);

		public const int DEFLATE_STORED = 0;

		public const int DEFLATE_FAST = 1;

		public const int DEFLATE_SLOW = 2;

		public static int[] GOOD_LENGTH = new int[10] { 0, 4, 4, 4, 4, 8, 8, 8, 32, 32 };

		public static int[] MAX_LAZY = new int[10] { 0, 4, 5, 6, 4, 16, 16, 32, 128, 258 };

		public static int[] NICE_LENGTH = new int[10] { 0, 8, 16, 32, 16, 32, 128, 128, 258, 258 };

		public static int[] MAX_CHAIN = new int[10] { 0, 4, 8, 32, 16, 32, 128, 256, 1024, 4096 };

		public static int[] COMPR_FUNC = new int[10] { 0, 1, 1, 1, 1, 2, 2, 2, 2, 2 };
	}
	public enum DeflateStrategy
	{
		Default,
		Filtered,
		HuffmanOnly
	}
	public class DeflaterEngine : DeflaterConstants
	{
		private const int TooFar = 4096;

		private int ins_h;

		private short[] head;

		private short[] prev;

		private int matchStart;

		private int matchLen;

		private bool prevAvailable;

		private int blockStart;

		private int strstart;

		private int lookahead;

		private byte[] window;

		private DeflateStrategy strategy;

		private int max_chain;

		private int max_lazy;

		private int niceLength;

		private int goodLength;

		private int compressionFunction;

		private byte[] inputBuf;

		private long totalIn;

		private int inputOff;

		private int inputEnd;

		private DeflaterPending pending;

		private DeflaterHuffman huffman;

		private Adler32 adler;

		public int Adler => (int)adler.Value;

		public long TotalIn => totalIn;

		public DeflateStrategy Strategy {
			get {
				return strategy;
			}
			set {
				strategy = value;
			}
		}

		public DeflaterEngine (DeflaterPending pending)
		{
			this.pending = pending;
			huffman = new DeflaterHuffman (pending);
			adler = new Adler32 ();
			window = new byte[65536];
			head = new short[32768];
			prev = new short[32768];
			blockStart = (strstart = 1);
		}

		public bool Deflate (bool flush, bool finish)
		{
			bool flag;
			do {
				FillWindow ();
				bool flush2 = flush && inputOff == inputEnd;
				flag = compressionFunction switch {
					0 => DeflateStored (flush2, finish), 
					1 => DeflateFast (flush2, finish), 
					2 => DeflateSlow (flush2, finish), 
					_ => throw new InvalidOperationException ("unknown compressionFunction"), 
				};
			} while (pending.IsFlushed && flag);
			return flag;
		}

		public void SetInput (byte[] buffer, int offset, int count)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (offset < 0) {
				throw new ArgumentOutOfRangeException ("offset");
			}
			if (count < 0) {
				throw new ArgumentOutOfRangeException ("count");
			}
			if (inputOff < inputEnd) {
				throw new InvalidOperationException ("Old input was not completely processed");
			}
			int num = offset + count;
			if (offset > num || num > buffer.Length) {
				throw new ArgumentOutOfRangeException ("count");
			}
			inputBuf = buffer;
			inputOff = offset;
			inputEnd = num;
		}

		public bool NeedsInput ()
		{
			return inputEnd == inputOff;
		}

		public void SetDictionary (byte[] buffer, int offset, int length)
		{
			adler.Update (buffer, offset, length);
			if (length >= 3) {
				if (length > 32506) {
					offset += length - 32506;
					length = 32506;
				}
				Array.Copy (buffer, offset, window, strstart, length);
				UpdateHash ();
				length--;
				while (--length > 0) {
					InsertString ();
					strstart++;
				}
				strstart += 2;
				blockStart = strstart;
			}
		}

		public void Reset ()
		{
			huffman.Reset ();
			adler.Reset ();
			blockStart = (strstart = 1);
			lookahead = 0;
			totalIn = 0L;
			prevAvailable = false;
			matchLen = 2;
			for (int i = 0; i < 32768; i++) {
				head [i] = 0;
			}
			for (int j = 0; j < 32768; j++) {
				prev [j] = 0;
			}
		}

		public void ResetAdler ()
		{
			adler.Reset ();
		}

		public void SetLevel (int level)
		{
			if (level < 0 || level > 9) {
				throw new ArgumentOutOfRangeException ("level");
			}
			goodLength = DeflaterConstants.GOOD_LENGTH [level];
			max_lazy = DeflaterConstants.MAX_LAZY [level];
			niceLength = DeflaterConstants.NICE_LENGTH [level];
			max_chain = DeflaterConstants.MAX_CHAIN [level];
			if (DeflaterConstants.COMPR_FUNC [level] == compressionFunction) {
				return;
			}
			switch (compressionFunction) {
			case 0:
				if (strstart > blockStart) {
					huffman.FlushStoredBlock (window, blockStart, strstart - blockStart, lastBlock: false);
					blockStart = strstart;
				}
				UpdateHash ();
				break;
			case 1:
				if (strstart > blockStart) {
					huffman.FlushBlock (window, blockStart, strstart - blockStart, lastBlock: false);
					blockStart = strstart;
				}
				break;
			case 2:
				if (prevAvailable) {
					huffman.TallyLit (window [strstart - 1] & 0xFF);
				}
				if (strstart > blockStart) {
					huffman.FlushBlock (window, blockStart, strstart - blockStart, lastBlock: false);
					blockStart = strstart;
				}
				prevAvailable = false;
				matchLen = 2;
				break;
			}
			compressionFunction = DeflaterConstants.COMPR_FUNC [level];
		}

		public void FillWindow ()
		{
			if (strstart >= 65274) {
				SlideWindow ();
			}
			while (lookahead < 262 && inputOff < inputEnd) {
				int num = 65536 - lookahead - strstart;
				if (num > inputEnd - inputOff) {
					num = inputEnd - inputOff;
				}
				Array.Copy (inputBuf, inputOff, window, strstart + lookahead, num);
				adler.Update (inputBuf, inputOff, num);
				inputOff += num;
				totalIn += num;
				lookahead += num;
			}
			if (lookahead >= 3) {
				UpdateHash ();
			}
		}

		private void UpdateHash ()
		{
			ins_h = (window [strstart] << 5) ^ window [strstart + 1];
		}

		private int InsertString ()
		{
			int num = ((ins_h << 5) ^ window [strstart + 2]) & 0x7FFF;
			short num2 = (prev [strstart & 0x7FFF] = head [num]);
			head [num] = (short)strstart;
			ins_h = num;
			return num2 & 0xFFFF;
		}

		private void SlideWindow ()
		{
			Array.Copy (window, 32768, window, 0, 32768);
			matchStart -= 32768;
			strstart -= 32768;
			blockStart -= 32768;
			for (int i = 0; i < 32768; i++) {
				int num = head [i] & 0xFFFF;
				head [i] = (short)((num >= 32768) ? (num - 32768) : 0);
			}
			for (int j = 0; j < 32768; j++) {
				int num2 = prev [j] & 0xFFFF;
				prev [j] = (short)((num2 >= 32768) ? (num2 - 32768) : 0);
			}
		}

		private bool FindLongestMatch (int curMatch)
		{
			int num = max_chain;
			int num2 = niceLength;
			short[] array = prev;
			int num3 = strstart;
			int num4 = strstart + matchLen;
			int num5 = Math.Max (matchLen, 2);
			int num6 = Math.Max (strstart - 32506, 0);
			int num7 = strstart + 258 - 1;
			byte b = window [num4 - 1];
			byte b2 = window [num4];
			if (num5 >= goodLength) {
				num >>= 2;
			}
			if (num2 > lookahead) {
				num2 = lookahead;
			}
			do {
				if (window [curMatch + num5] != b2 || window [curMatch + num5 - 1] != b || window [curMatch] != window [num3] || window [curMatch + 1] != window [num3 + 1]) {
					continue;
				}
				int num8 = curMatch + 2;
				num3 += 2;
				while (window [++num3] == window [++num8] && window [++num3] == window [++num8] && window [++num3] == window [++num8] && window [++num3] == window [++num8] && window [++num3] == window [++num8] && window [++num3] == window [++num8] && window [++num3] == window [++num8] && window [++num3] == window [++num8] && num3 < num7) {
				}
				if (num3 > num4) {
					matchStart = curMatch;
					num4 = num3;
					num5 = num3 - strstart;
					if (num5 >= num2) {
						break;
					}
					b = window [num4 - 1];
					b2 = window [num4];
				}
				num3 = strstart;
			} while ((curMatch = array [curMatch & 0x7FFF] & 0xFFFF) > num6 && --num != 0);
			matchLen = Math.Min (num5, lookahead);
			return matchLen >= 3;
		}

		private bool DeflateStored (bool flush, bool finish)
		{
			if (!flush && lookahead == 0) {
				return false;
			}
			strstart += lookahead;
			lookahead = 0;
			int num = strstart - blockStart;
			if (num >= DeflaterConstants.MAX_BLOCK_SIZE || (blockStart < 32768 && num >= 32506) || flush) {
				bool flag = finish;
				if (num > DeflaterConstants.MAX_BLOCK_SIZE) {
					num = DeflaterConstants.MAX_BLOCK_SIZE;
					flag = false;
				}
				huffman.FlushStoredBlock (window, blockStart, num, flag);
				blockStart += num;
				return !flag;
			}
			return true;
		}

		private bool DeflateFast (bool flush, bool finish)
		{
			if (lookahead < 262 && !flush) {
				return false;
			}
			while (lookahead >= 262 || flush) {
				if (lookahead == 0) {
					huffman.FlushBlock (window, blockStart, strstart - blockStart, finish);
					blockStart = strstart;
					return false;
				}
				if (strstart > 65274) {
					SlideWindow ();
				}
				int num;
				if (lookahead >= 3 && (num = InsertString ()) != 0 && strategy != DeflateStrategy.HuffmanOnly && strstart - num <= 32506 && FindLongestMatch (num)) {
					bool flag = huffman.TallyDist (strstart - matchStart, matchLen);
					lookahead -= matchLen;
					if (matchLen <= max_lazy && lookahead >= 3) {
						while (--matchLen > 0) {
							strstart++;
							InsertString ();
						}
						strstart++;
					} else {
						strstart += matchLen;
						if (lookahead >= 2) {
							UpdateHash ();
						}
					}
					matchLen = 2;
					if (!flag) {
						continue;
					}
				} else {
					huffman.TallyLit (window [strstart] & 0xFF);
					strstart++;
					lookahead--;
				}
				if (huffman.IsFull ()) {
					bool flag2 = finish && lookahead == 0;
					huffman.FlushBlock (window, blockStart, strstart - blockStart, flag2);
					blockStart = strstart;
					return !flag2;
				}
			}
			return true;
		}

		private bool DeflateSlow (bool flush, bool finish)
		{
			if (lookahead < 262 && !flush) {
				return false;
			}
			while (lookahead >= 262 || flush) {
				if (lookahead == 0) {
					if (prevAvailable) {
						huffman.TallyLit (window [strstart - 1] & 0xFF);
					}
					prevAvailable = false;
					huffman.FlushBlock (window, blockStart, strstart - blockStart, finish);
					blockStart = strstart;
					return false;
				}
				if (strstart >= 65274) {
					SlideWindow ();
				}
				int num = matchStart;
				int num2 = matchLen;
				if (lookahead >= 3) {
					int num3 = InsertString ();
					if (strategy != DeflateStrategy.HuffmanOnly && num3 != 0 && strstart - num3 <= 32506 && FindLongestMatch (num3) && matchLen <= 5 && (strategy == DeflateStrategy.Filtered || (matchLen == 3 && strstart - matchStart > 4096))) {
						matchLen = 2;
					}
				}
				if (num2 >= 3 && matchLen <= num2) {
					huffman.TallyDist (strstart - 1 - num, num2);
					num2 -= 2;
					do {
						strstart++;
						lookahead--;
						if (lookahead >= 3) {
							InsertString ();
						}
					} while (--num2 > 0);
					strstart++;
					lookahead--;
					prevAvailable = false;
					matchLen = 2;
				} else {
					if (prevAvailable) {
						huffman.TallyLit (window [strstart - 1] & 0xFF);
					}
					prevAvailable = true;
					strstart++;
					lookahead--;
				}
				if (huffman.IsFull ()) {
					int num4 = strstart - blockStart;
					if (prevAvailable) {
						num4--;
					}
					bool flag = finish && lookahead == 0 && !prevAvailable;
					huffman.FlushBlock (window, blockStart, num4, flag);
					blockStart += num4;
					return !flag;
				}
			}
			return true;
		}
	}
	public class DeflaterHuffman
	{
		private class Tree
		{
			public short[] freqs;

			public byte[] length;

			public int minNumCodes;

			public int numCodes;

			private short[] codes;

			private int[] bl_counts;

			private int maxLength;

			private DeflaterHuffman dh;

			public Tree (DeflaterHuffman dh, int elems, int minCodes, int maxLength)
			{
				this.dh = dh;
				minNumCodes = minCodes;
				this.maxLength = maxLength;
				freqs = new short[elems];
				bl_counts = new int[maxLength];
			}

			public void Reset ()
			{
				for (int i = 0; i < freqs.Length; i++) {
					freqs [i] = 0;
				}
				codes = null;
				length = null;
			}

			public void WriteSymbol (int code)
			{
				dh.pending.WriteBits (codes [code] & 0xFFFF, length [code]);
			}

			public void CheckEmpty ()
			{
				bool flag = true;
				for (int i = 0; i < freqs.Length; i++) {
					if (freqs [i] != 0) {
						flag = false;
					}
				}
				if (!flag) {
					throw new SharpZipBaseException ("!Empty");
				}
			}

			public void SetStaticCodes (short[] staticCodes, byte[] staticLengths)
			{
				codes = staticCodes;
				length = staticLengths;
			}

			public void BuildCodes ()
			{
				int num = freqs.Length;
				int[] array = new int[maxLength];
				int num2 = 0;
				codes = new short[freqs.Length];
				for (int i = 0; i < maxLength; i++) {
					array [i] = num2;
					num2 += bl_counts [i] << 15 - i;
				}
				for (int j = 0; j < numCodes; j++) {
					int num3 = length [j];
					if (num3 > 0) {
						codes [j] = BitReverse (array [num3 - 1]);
						array [num3 - 1] += 1 << 16 - num3;
					}
				}
			}

			public void BuildTree ()
			{
				int num = freqs.Length;
				int[] array = new int[num];
				int num2 = 0;
				int num3 = 0;
				for (int i = 0; i < num; i++) {
					int num4 = freqs [i];
					if (num4 != 0) {
						int num5 = num2++;
						int num6;
						while (num5 > 0 && freqs [array [num6 = (num5 - 1) / 2]] > num4) {
							array [num5] = array [num6];
							num5 = num6;
						}
						array [num5] = i;
						num3 = i;
					}
				}
				while (num2 < 2) {
					int num7 = ((num3 < 2) ? (++num3) : 0);
					array [num2++] = num7;
				}
				numCodes = Math.Max (num3 + 1, minNumCodes);
				int num8 = num2;
				int[] array2 = new int[4 * num2 - 2];
				int[] array3 = new int[2 * num2 - 1];
				int num9 = num8;
				for (int j = 0; j < num2; j++) {
					int num10 = (array2 [2 * j] = array [j]);
					array2 [2 * j + 1] = -1;
					array3 [j] = freqs [num10] << 8;
					array [j] = j;
				}
				do {
					int num11 = array [0];
					int num12 = array [--num2];
					int num13 = 0;
					int num14;
					for (num14 = 1; num14 < num2; num14 = num14 * 2 + 1) {
						if (num14 + 1 < num2 && array3 [array [num14]] > array3 [array [num14 + 1]]) {
							num14++;
						}
						array [num13] = array [num14];
						num13 = num14;
					}
					int num15 = array3 [num12];
					while ((num14 = num13) > 0 && array3 [array [num13 = (num14 - 1) / 2]] > num15) {
						array [num14] = array [num13];
					}
					array [num14] = num12;
					int num16 = array [0];
					num12 = num9++;
					array2 [2 * num12] = num11;
					array2 [2 * num12 + 1] = num16;
					int num17 = Math.Min (array3 [num11] & 0xFF, array3 [num16] & 0xFF);
					num15 = (array3 [num12] = array3 [num11] + array3 [num16] - num17 + 1);
					num13 = 0;
					for (num14 = 1; num14 < num2; num14 = num13 * 2 + 1) {
						if (num14 + 1 < num2 && array3 [array [num14]] > array3 [array [num14 + 1]]) {
							num14++;
						}
						array [num13] = array [num14];
						num13 = num14;
					}
					while ((num14 = num13) > 0 && array3 [array [num13 = (num14 - 1) / 2]] > num15) {
						array [num14] = array [num13];
					}
					array [num14] = num12;
				} while (num2 > 1);
				if (array [0] != array2.Length / 2 - 1) {
					throw new SharpZipBaseException ("Heap invariant violated");
				}
				BuildLength (array2);
			}

			public int GetEncodedLength ()
			{
				int num = 0;
				for (int i = 0; i < freqs.Length; i++) {
					num += freqs [i] * length [i];
				}
				return num;
			}

			public void CalcBLFreq (Tree blTree)
			{
				int num = -1;
				int num2 = 0;
				while (num2 < numCodes) {
					int num3 = 1;
					int num4 = length [num2];
					int num5;
					int num6;
					if (num4 == 0) {
						num5 = 138;
						num6 = 3;
					} else {
						num5 = 6;
						num6 = 3;
						if (num != num4) {
							blTree.freqs [num4]++;
							num3 = 0;
						}
					}
					num = num4;
					num2++;
					while (num2 < numCodes && num == length [num2]) {
						num2++;
						if (++num3 >= num5) {
							break;
						}
					}
					if (num3 < num6) {
						blTree.freqs [num] += (short)num3;
					} else if (num != 0) {
						blTree.freqs [16]++;
					} else if (num3 <= 10) {
						blTree.freqs [17]++;
					} else {
						blTree.freqs [18]++;
					}
				}
			}

			public void WriteTree (Tree blTree)
			{
				int num = -1;
				int num2 = 0;
				while (num2 < numCodes) {
					int num3 = 1;
					int num4 = length [num2];
					int num5;
					int num6;
					if (num4 == 0) {
						num5 = 138;
						num6 = 3;
					} else {
						num5 = 6;
						num6 = 3;
						if (num != num4) {
							blTree.WriteSymbol (num4);
							num3 = 0;
						}
					}
					num = num4;
					num2++;
					while (num2 < numCodes && num == length [num2]) {
						num2++;
						if (++num3 >= num5) {
							break;
						}
					}
					if (num3 < num6) {
						while (num3-- > 0) {
							blTree.WriteSymbol (num);
						}
					} else if (num != 0) {
						blTree.WriteSymbol (16);
						dh.pending.WriteBits (num3 - 3, 2);
					} else if (num3 <= 10) {
						blTree.WriteSymbol (17);
						dh.pending.WriteBits (num3 - 3, 3);
					} else {
						blTree.WriteSymbol (18);
						dh.pending.WriteBits (num3 - 11, 7);
					}
				}
			}

			private void BuildLength (int[] childs)
			{
				length = new byte[freqs.Length];
				int num = childs.Length / 2;
				int num2 = (num + 1) / 2;
				int num3 = 0;
				for (int i = 0; i < maxLength; i++) {
					bl_counts [i] = 0;
				}
				int[] array = new int[num];
				array [num - 1] = 0;
				for (int num4 = num - 1; num4 >= 0; num4--) {
					if (childs [2 * num4 + 1] != -1) {
						int num5 = array [num4] + 1;
						if (num5 > maxLength) {
							num5 = maxLength;
							num3++;
						}
						array [childs [2 * num4]] = (array [childs [2 * num4 + 1]] = num5);
					} else {
						int num6 = array [num4];
						bl_counts [num6 - 1]++;
						length [childs [2 * num4]] = (byte)array [num4];
					}
				}
				if (num3 == 0) {
					return;
				}
				int num7 = maxLength - 1;
				while (true) {
					if (bl_counts [--num7] != 0) {
						do {
							bl_counts [num7]--;
							bl_counts [++num7]++;
							num3 -= 1 << maxLength - 1 - num7;
						} while (num3 > 0 && num7 < maxLength - 1);
						if (num3 <= 0) {
							break;
						}
					}
				}
				bl_counts [maxLength - 1] += num3;
				bl_counts [maxLength - 2] -= num3;
				int num8 = 2 * num2;
				for (int num9 = maxLength; num9 != 0; num9--) {
					int num10 = bl_counts [num9 - 1];
					while (num10 > 0) {
						int num11 = 2 * childs [num8++];
						if (childs [num11 + 1] == -1) {
							length [childs [num11]] = (byte)num9;
							num10--;
						}
					}
				}
			}
		}

		private const int BUFSIZE = 16384;

		private const int LITERAL_NUM = 286;

		private const int DIST_NUM = 30;

		private const int BITLEN_NUM = 19;

		private const int REP_3_6 = 16;

		private const int REP_3_10 = 17;

		private const int REP_11_138 = 18;

		private const int EOF_SYMBOL = 256;

		private static readonly int[] BL_ORDER;

		private static readonly byte[] bit4Reverse;

		private static short[] staticLCodes;

		private static byte[] staticLLength;

		private static short[] staticDCodes;

		private static byte[] staticDLength;

		public DeflaterPending pending;

		private Tree literalTree;

		private Tree distTree;

		private Tree blTree;

		private short[] d_buf;

		private byte[] l_buf;

		private int last_lit;

		private int extra_bits;

		static DeflaterHuffman ()
		{
			BL_ORDER = new int[19] {
				16, 17, 18, 0, 8, 7, 9, 6, 10, 5,
				11, 4, 12, 3, 13, 2, 14, 1, 15
			};
			bit4Reverse = new byte[16] {
				0, 8, 4, 12, 2, 10, 6, 14, 1, 9,
				5, 13, 3, 11, 7, 15
			};
			staticLCodes = new short[286];
			staticLLength = new byte[286];
			int num = 0;
			while (num < 144) {
				staticLCodes [num] = BitReverse (48 + num << 8);
				staticLLength [num++] = 8;
			}
			while (num < 256) {
				staticLCodes [num] = BitReverse (256 + num << 7);
				staticLLength [num++] = 9;
			}
			while (num < 280) {
				staticLCodes [num] = BitReverse (-256 + num << 9);
				staticLLength [num++] = 7;
			}
			while (num < 286) {
				staticLCodes [num] = BitReverse (-88 + num << 8);
				staticLLength [num++] = 8;
			}
			staticDCodes = new short[30];
			staticDLength = new byte[30];
			for (num = 0; num < 30; num++) {
				staticDCodes [num] = BitReverse (num << 11);
				staticDLength [num] = 5;
			}
		}

		public DeflaterHuffman (DeflaterPending pending)
		{
			this.pending = pending;
			literalTree = new Tree (this, 286, 257, 15);
			distTree = new Tree (this, 30, 1, 15);
			blTree = new Tree (this, 19, 4, 7);
			d_buf = new short[16384];
			l_buf = new byte[16384];
		}

		public void Reset ()
		{
			last_lit = 0;
			extra_bits = 0;
			literalTree.Reset ();
			distTree.Reset ();
			blTree.Reset ();
		}

		public void SendAllTrees (int blTreeCodes)
		{
			blTree.BuildCodes ();
			literalTree.BuildCodes ();
			distTree.BuildCodes ();
			pending.WriteBits (literalTree.numCodes - 257, 5);
			pending.WriteBits (distTree.numCodes - 1, 5);
			pending.WriteBits (blTreeCodes - 4, 4);
			for (int i = 0; i < blTreeCodes; i++) {
				pending.WriteBits (blTree.length [BL_ORDER [i]], 3);
			}
			literalTree.WriteTree (blTree);
			distTree.WriteTree (blTree);
		}

		public void CompressBlock ()
		{
			for (int i = 0; i < last_lit; i++) {
				int num = l_buf [i] & 0xFF;
				int num2 = d_buf [i];
				if (num2-- != 0) {
					int num3 = Lcode (num);
					literalTree.WriteSymbol (num3);
					int num4 = (num3 - 261) / 4;
					if (num4 > 0 && num4 <= 5) {
						pending.WriteBits (num & ((1 << num4) - 1), num4);
					}
					int num5 = Dcode (num2);
					distTree.WriteSymbol (num5);
					num4 = num5 / 2 - 1;
					if (num4 > 0) {
						pending.WriteBits (num2 & ((1 << num4) - 1), num4);
					}
				} else {
					literalTree.WriteSymbol (num);
				}
			}
			literalTree.WriteSymbol (256);
		}

		public void FlushStoredBlock (byte[] stored, int storedOffset, int storedLength, bool lastBlock)
		{
			pending.WriteBits (lastBlock ? 1 : 0, 3);
			pending.AlignToByte ();
			pending.WriteShort (storedLength);
			pending.WriteShort (~storedLength);
			pending.WriteBlock (stored, storedOffset, storedLength);
			Reset ();
		}

		public void FlushBlock (byte[] stored, int storedOffset, int storedLength, bool lastBlock)
		{
			literalTree.freqs [256]++;
			literalTree.BuildTree ();
			distTree.BuildTree ();
			literalTree.CalcBLFreq (blTree);
			distTree.CalcBLFreq (blTree);
			blTree.BuildTree ();
			int num = 4;
			for (int num2 = 18; num2 > num; num2--) {
				if (blTree.length [BL_ORDER [num2]] > 0) {
					num = num2 + 1;
				}
			}
			int num3 = 14 + num * 3 + blTree.GetEncodedLength () + literalTree.GetEncodedLength () + distTree.GetEncodedLength () + extra_bits;
			int num4 = extra_bits;
			for (int i = 0; i < 286; i++) {
				num4 += literalTree.freqs [i] * staticLLength [i];
			}
			for (int j = 0; j < 30; j++) {
				num4 += distTree.freqs [j] * staticDLength [j];
			}
			if (num3 >= num4) {
				num3 = num4;
			}
			if (storedOffset >= 0 && storedLength + 4 < num3 >> 3) {
				FlushStoredBlock (stored, storedOffset, storedLength, lastBlock);
			} else if (num3 == num4) {
				pending.WriteBits (2 + (lastBlock ? 1 : 0), 3);
				literalTree.SetStaticCodes (staticLCodes, staticLLength);
				distTree.SetStaticCodes (staticDCodes, staticDLength);
				CompressBlock ();
				Reset ();
			} else {
				pending.WriteBits (4 + (lastBlock ? 1 : 0), 3);
				SendAllTrees (num);
				CompressBlock ();
				Reset ();
			}
		}

		public bool IsFull ()
		{
			return last_lit >= 16384;
		}

		public bool TallyLit (int literal)
		{
			d_buf [last_lit] = 0;
			l_buf [last_lit++] = (byte)literal;
			literalTree.freqs [literal]++;
			return IsFull ();
		}

		public bool TallyDist (int distance, int length)
		{
			d_buf [last_lit] = (short)distance;
			l_buf [last_lit++] = (byte)(length - 3);
			int num = Lcode (length - 3);
			literalTree.freqs [num]++;
			if (num >= 265 && num < 285) {
				extra_bits += (num - 261) / 4;
			}
			int num2 = Dcode (distance - 1);
			distTree.freqs [num2]++;
			if (num2 >= 4) {
				extra_bits += num2 / 2 - 1;
			}
			return IsFull ();
		}

		public static short BitReverse (int toReverse)
		{
			return (short)((bit4Reverse [toReverse & 0xF] << 12) | (bit4Reverse [(toReverse >> 4) & 0xF] << 8) | (bit4Reverse [(toReverse >> 8) & 0xF] << 4) | bit4Reverse [toReverse >> 12]);
		}

		private static int Lcode (int length)
		{
			if (length == 255) {
				return 285;
			}
			int num = 257;
			while (length >= 8) {
				num += 4;
				length >>= 1;
			}
			return num + length;
		}

		private static int Dcode (int distance)
		{
			int num = 0;
			while (distance >= 4) {
				num += 2;
				distance >>= 1;
			}
			return num + distance;
		}
	}
	public class DeflaterPending : PendingBuffer
	{
		public DeflaterPending ()
			: base (65536)
		{
		}
	}
	public class Inflater
	{
		private static readonly int[] CPLENS = new int[29] {
			3, 4, 5, 6, 7, 8, 9, 10, 11, 13,
			15, 17, 19, 23, 27, 31, 35, 43, 51, 59,
			67, 83, 99, 115, 131, 163, 195, 227, 258
		};

		private static readonly int[] CPLEXT = new int[29] {
			0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
			1, 1, 2, 2, 2, 2, 3, 3, 3, 3,
			4, 4, 4, 4, 5, 5, 5, 5, 0
		};

		private static readonly int[] CPDIST = new int[30] {
			1, 2, 3, 4, 5, 7, 9, 13, 17, 25,
			33, 49, 65, 97, 129, 193, 257, 385, 513, 769,
			1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577
		};

		private static readonly int[] CPDEXT = new int[30] {
			0, 0, 0, 0, 1, 1, 2, 2, 3, 3,
			4, 4, 5, 5, 6, 6, 7, 7, 8, 8,
			9, 9, 10, 10, 11, 11, 12, 12, 13, 13
		};

		private const int DECODE_HEADER = 0;

		private const int DECODE_DICT = 1;

		private const int DECODE_BLOCKS = 2;

		private const int DECODE_STORED_LEN1 = 3;

		private const int DECODE_STORED_LEN2 = 4;

		private const int DECODE_STORED = 5;

		private const int DECODE_DYN_HEADER = 6;

		private const int DECODE_HUFFMAN = 7;

		private const int DECODE_HUFFMAN_LENBITS = 8;

		private const int DECODE_HUFFMAN_DIST = 9;

		private const int DECODE_HUFFMAN_DISTBITS = 10;

		private const int DECODE_CHKSUM = 11;

		private const int FINISHED = 12;

		private int mode;

		private int readAdler;

		private int neededBits;

		private int repLength;

		private int repDist;

		private int uncomprLen;

		private bool isLastBlock;

		private long totalOut;

		private long totalIn;

		private bool noHeader;

		private StreamManipulator input;

		private OutputWindow outputWindow;

		private InflaterDynHeader dynHeader;

		private InflaterHuffmanTree litlenTree;

		private InflaterHuffmanTree distTree;

		private Adler32 adler;

		public bool IsNeedingInput => input.IsNeedingInput;

		public bool IsNeedingDictionary => mode == 1 && neededBits == 0;

		public bool IsFinished => mode == 12 && outputWindow.GetAvailable () == 0;

		public int Adler => (int)((!IsNeedingDictionary) ? adler.Value : readAdler);

		public long TotalOut => totalOut;

		public long TotalIn => totalIn - RemainingInput;

		public int RemainingInput => input.AvailableBytes;

		public Inflater ()
			: this (noHeader: false)
		{
		}

		public Inflater (bool noHeader)
		{
			this.noHeader = noHeader;
			adler = new Adler32 ();
			input = new StreamManipulator ();
			outputWindow = new OutputWindow ();
			mode = (noHeader ? 2 : 0);
		}

		public void Reset ()
		{
			mode = (noHeader ? 2 : 0);
			totalIn = 0L;
			totalOut = 0L;
			input.Reset ();
			outputWindow.Reset ();
			dynHeader = null;
			litlenTree = null;
			distTree = null;
			isLastBlock = false;
			adler.Reset ();
		}

		private bool DecodeHeader ()
		{
			int num = input.PeekBits (16);
			if (num < 0) {
				return false;
			}
			input.DropBits (16);
			num = ((num << 8) | (num >> 8)) & 0xFFFF;
			if (num % 31 != 0) {
				throw new SharpZipBaseException ("Header checksum illegal");
			}
			if ((num & 0xF00) != 2048) {
				throw new SharpZipBaseException ("Compression Method unknown");
			}
			if ((num & 0x20) == 0) {
				mode = 2;
			} else {
				mode = 1;
				neededBits = 32;
			}
			return true;
		}

		private bool DecodeDict ()
		{
			while (neededBits > 0) {
				int num = input.PeekBits (8);
				if (num < 0) {
					return false;
				}
				input.DropBits (8);
				readAdler = (readAdler << 8) | num;
				neededBits -= 8;
			}
			return false;
		}

		private bool DecodeHuffman ()
		{
			int num = outputWindow.GetFreeSpace ();
			while (num >= 258) {
				switch (mode) {
				case 7: {
					int symbol;
					while (((symbol = litlenTree.GetSymbol (input)) & -256) == 0) {
						outputWindow.Write (symbol);
						if (--num < 258) {
							return true;
						}
					}
					if (symbol < 257) {
						if (symbol < 0) {
							return false;
						}
						distTree = null;
						litlenTree = null;
						mode = 2;
						return true;
					}
					try {
						repLength = CPLENS [symbol - 257];
						neededBits = CPLEXT [symbol - 257];
					} catch (Exception) {
						throw new SharpZipBaseException ("Illegal rep length code");
					}
					goto case 8;
				}
				case 8:
					if (neededBits > 0) {
						mode = 8;
						int num2 = input.PeekBits (neededBits);
						if (num2 < 0) {
							return false;
						}
						input.DropBits (neededBits);
						repLength += num2;
					}
					mode = 9;
					goto case 9;
				case 9: {
					int symbol = distTree.GetSymbol (input);
					if (symbol < 0) {
						return false;
					}
					try {
						repDist = CPDIST [symbol];
						neededBits = CPDEXT [symbol];
					} catch (Exception) {
						throw new SharpZipBaseException ("Illegal rep dist code");
					}
					goto case 10;
				}
				case 10:
					if (neededBits > 0) {
						mode = 10;
						int num3 = input.PeekBits (neededBits);
						if (num3 < 0) {
							return false;
						}
						input.DropBits (neededBits);
						repDist += num3;
					}
					break;
				default:
					throw new SharpZipBaseException ("Inflater unknown mode");
				}
				outputWindow.Repeat (repLength, repDist);
				num -= repLength;
				mode = 7;
			}
			return true;
		}

		private bool DecodeChksum ()
		{
			while (neededBits > 0) {
				int num = input.PeekBits (8);
				if (num < 0) {
					return false;
				}
				input.DropBits (8);
				readAdler = (readAdler << 8) | num;
				neededBits -= 8;
			}
			if ((int)adler.Value != readAdler) {
				throw new SharpZipBaseException ("Adler chksum doesn't match: " + (int)adler.Value + " vs. " + readAdler);
			}
			mode = 12;
			return false;
		}

		private bool Decode ()
		{
			switch (mode) {
			case 0:
				return DecodeHeader ();
			case 1:
				return DecodeDict ();
			case 11:
				return DecodeChksum ();
			case 2: {
				if (isLastBlock) {
					if (noHeader) {
						mode = 12;
						return false;
					}
					input.SkipToByteBoundary ();
					neededBits = 32;
					mode = 11;
					return true;
				}
				int num = input.PeekBits (3);
				if (num < 0) {
					return false;
				}
				input.DropBits (3);
				if (((uint)num & (true ? 1u : 0u)) != 0) {
					isLastBlock = true;
				}
				switch (num >> 1) {
				case 0:
					input.SkipToByteBoundary ();
					mode = 3;
					break;
				case 1:
					litlenTree = InflaterHuffmanTree.defLitLenTree;
					distTree = InflaterHuffmanTree.defDistTree;
					mode = 7;
					break;
				case 2:
					dynHeader = new InflaterDynHeader ();
					mode = 6;
					break;
				default:
					throw new SharpZipBaseException ("Unknown block type " + num);
				}
				return true;
			}
			case 3:
				if ((uncomprLen = input.PeekBits (16)) < 0) {
					return false;
				}
				input.DropBits (16);
				mode = 4;
				goto case 4;
			case 4: {
				int num3 = input.PeekBits (16);
				if (num3 < 0) {
					return false;
				}
				input.DropBits (16);
				if (num3 != (uncomprLen ^ 0xFFFF)) {
					throw new SharpZipBaseException ("broken uncompressed block");
				}
				mode = 5;
				goto case 5;
			}
			case 5: {
				int num2 = outputWindow.CopyStored (input, uncomprLen);
				uncomprLen -= num2;
				if (uncomprLen == 0) {
					mode = 2;
					return true;
				}
				return !input.IsNeedingInput;
			}
			case 6:
				if (!dynHeader.Decode (input)) {
					return false;
				}
				litlenTree = dynHeader.BuildLitLenTree ();
				distTree = dynHeader.BuildDistTree ();
				mode = 7;
				goto case 7;
			case 7:
			case 8:
			case 9:
			case 10:
				return DecodeHuffman ();
			case 12:
				return false;
			default:
				throw new SharpZipBaseException ("Inflater.Decode unknown mode");
			}
		}

		public void SetDictionary (byte[] buffer)
		{
			SetDictionary (buffer, 0, buffer.Length);
		}

		public void SetDictionary (byte[] buffer, int index, int count)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (index < 0) {
				throw new ArgumentOutOfRangeException ("index");
			}
			if (count < 0) {
				throw new ArgumentOutOfRangeException ("count");
			}
			if (!IsNeedingDictionary) {
				throw new InvalidOperationException ("Dictionary is not needed");
			}
			adler.Update (buffer, index, count);
			if ((int)adler.Value != readAdler) {
				throw new SharpZipBaseException ("Wrong adler checksum");
			}
			adler.Reset ();
			outputWindow.CopyDict (buffer, index, count);
			mode = 2;
		}

		public void SetInput (byte[] buffer)
		{
			SetInput (buffer, 0, buffer.Length);
		}

		public void SetInput (byte[] buffer, int index, int count)
		{
			input.SetInput (buffer, index, count);
			totalIn += count;
		}

		public int Inflate (byte[] buffer)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			return Inflate (buffer, 0, buffer.Length);
		}

		public int Inflate (byte[] buffer, int offset, int count)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (count < 0) {
				throw new ArgumentOutOfRangeException ("count", "count cannot be negative");
			}
			if (offset < 0) {
				throw new ArgumentOutOfRangeException ("offset", "offset cannot be negative");
			}
			if (offset + count > buffer.Length) {
				throw new ArgumentException ("count exceeds buffer bounds");
			}
			if (count == 0) {
				if (!IsFinished) {
					Decode ();
				}
				return 0;
			}
			int num = 0;
			do {
				if (mode == 11) {
					continue;
				}
				int num2 = outputWindow.CopyOutput (buffer, offset, count);
				if (num2 > 0) {
					adler.Update (buffer, offset, num2);
					offset += num2;
					num += num2;
					totalOut += num2;
					count -= num2;
					if (count == 0) {
						return num;
					}
				}
			} while (Decode () || (outputWindow.GetAvailable () > 0 && mode != 11));
			return num;
		}
	}
	internal class InflaterDynHeader
	{
		private const int LNUM = 0;

		private const int DNUM = 1;

		private const int BLNUM = 2;

		private const int BLLENS = 3;

		private const int LENS = 4;

		private const int REPS = 5;

		private static readonly int[] repMin = new int[3] { 3, 3, 11 };

		private static readonly int[] repBits = new int[3] { 2, 3, 7 };

		private static readonly int[] BL_ORDER = new int[19] {
			16, 17, 18, 0, 8, 7, 9, 6, 10, 5,
			11, 4, 12, 3, 13, 2, 14, 1, 15
		};

		private byte[] blLens;

		private byte[] litdistLens;

		private InflaterHuffmanTree blTree;

		private int mode;

		private int lnum;

		private int dnum;

		private int blnum;

		private int num;

		private int repSymbol;

		private byte lastLen;

		private int ptr;

		public bool Decode (StreamManipulator input)
		{
			while (true) {
				switch (mode) {
				default:
					continue;
				case 0:
					lnum = input.PeekBits (5);
					if (lnum < 0) {
						return false;
					}
					lnum += 257;
					input.DropBits (5);
					mode = 1;
					goto case 1;
				case 1:
					dnum = input.PeekBits (5);
					if (dnum < 0) {
						return false;
					}
					dnum++;
					input.DropBits (5);
					this.num = lnum + dnum;
					litdistLens = new byte[this.num];
					mode = 2;
					goto case 2;
				case 2:
					blnum = input.PeekBits (4);
					if (blnum < 0) {
						return false;
					}
					blnum += 4;
					input.DropBits (4);
					blLens = new byte[19];
					ptr = 0;
					mode = 3;
					goto case 3;
				case 3:
					while (ptr < blnum) {
						int num = input.PeekBits (3);
						if (num < 0) {
							return false;
						}
						input.DropBits (3);
						blLens [BL_ORDER [ptr]] = (byte)num;
						ptr++;
					}
					blTree = new InflaterHuffmanTree (blLens);
					blLens = null;
					ptr = 0;
					mode = 4;
					goto case 4;
				case 4: {
					int symbol;
					while (((symbol = blTree.GetSymbol (input)) & -16) == 0) {
						litdistLens [ptr++] = (lastLen = (byte)symbol);
						if (ptr == this.num) {
							return true;
						}
					}
					if (symbol < 0) {
						return false;
					}
					if (symbol >= 17) {
						lastLen = 0;
					} else if (ptr == 0) {
						throw new SharpZipBaseException ();
					}
					repSymbol = symbol - 16;
					mode = 5;
					break;
				}
				case 5:
					break;
				}
				int bitCount = repBits [repSymbol];
				int num2 = input.PeekBits (bitCount);
				if (num2 < 0) {
					return false;
				}
				input.DropBits (bitCount);
				num2 += repMin [repSymbol];
				if (ptr + num2 > this.num) {
					throw new SharpZipBaseException ();
				}
				while (num2-- > 0) {
					litdistLens [ptr++] = lastLen;
				}
				if (ptr == this.num) {
					break;
				}
				mode = 4;
			}
			return true;
		}

		public InflaterHuffmanTree BuildLitLenTree ()
		{
			byte[] array = new byte[lnum];
			Array.Copy (litdistLens, 0, array, 0, lnum);
			return new InflaterHuffmanTree (array);
		}

		public InflaterHuffmanTree BuildDistTree ()
		{
			byte[] array = new byte[dnum];
			Array.Copy (litdistLens, lnum, array, 0, dnum);
			return new InflaterHuffmanTree (array);
		}
	}
	public class InflaterHuffmanTree
	{
		private const int MAX_BITLEN = 15;

		private short[] tree;

		public static InflaterHuffmanTree defLitLenTree;

		public static InflaterHuffmanTree defDistTree;

		static InflaterHuffmanTree ()
		{
			try {
				byte[] array = new byte[288];
				int num = 0;
				while (num < 144) {
					array [num++] = 8;
				}
				while (num < 256) {
					array [num++] = 9;
				}
				while (num < 280) {
					array [num++] = 7;
				}
				while (num < 288) {
					array [num++] = 8;
				}
				defLitLenTree = new InflaterHuffmanTree (array);
				array = new byte[32];
				num = 0;
				while (num < 32) {
					array [num++] = 5;
				}
				defDistTree = new InflaterHuffmanTree (array);
			} catch (Exception) {
				throw new SharpZipBaseException ("InflaterHuffmanTree: static tree length illegal");
			}
		}

		public InflaterHuffmanTree (byte[] codeLengths)
		{
			BuildTree (codeLengths);
		}

		private void BuildTree (byte[] codeLengths)
		{
			int[] array = new int[16];
			int[] array2 = new int[16];
			foreach (int num in codeLengths) {
				if (num > 0) {
					array [num]++;
				}
			}
			int num2 = 0;
			int num3 = 512;
			for (int j = 1; j <= 15; j++) {
				array2 [j] = num2;
				num2 += array [j] << 16 - j;
				if (j >= 10) {
					int num4 = array2 [j] & 0x1FF80;
					int num5 = num2 & 0x1FF80;
					num3 += num5 - num4 >> 16 - j;
				}
			}
			tree = new short[num3];
			int num6 = 512;
			for (int num7 = 15; num7 >= 10; num7--) {
				int num8 = num2 & 0x1FF80;
				num2 -= array [num7] << 16 - num7;
				int num9 = num2 & 0x1FF80;
				for (int k = num9; k < num8; k += 128) {
					tree [DeflaterHuffman.BitReverse (k)] = (short)((-num6 << 4) | num7);
					num6 += 1 << num7 - 9;
				}
			}
			for (int l = 0; l < codeLengths.Length; l++) {
				int num10 = codeLengths [l];
				if (num10 == 0) {
					continue;
				}
				num2 = array2 [num10];
				int num11 = DeflaterHuffman.BitReverse (num2);
				if (num10 <= 9) {
					do {
						tree [num11] = (short)((l << 4) | num10);
						num11 += 1 << num10;
					} while (num11 < 512);
				} else {
					int num12 = tree [num11 & 0x1FF];
					int num13 = 1 << (num12 & 0xF);
					num12 = -(num12 >> 4);
					do {
						tree [num12 | (num11 >> 9)] = (short)((l << 4) | num10);
						num11 += 1 << num10;
					} while (num11 < num13);
				}
				array2 [num10] = num2 + (1 << 16 - num10);
			}
		}

		public int GetSymbol (StreamManipulator input)
		{
			int num;
			int num2;
			if ((num = input.PeekBits (9)) >= 0) {
				if ((num2 = tree [num]) >= 0) {
					input.DropBits (num2 & 0xF);
					return num2 >> 4;
				}
				int num3 = -(num2 >> 4);
				int bitCount = num2 & 0xF;
				if ((num = input.PeekBits (bitCount)) >= 0) {
					num2 = tree [num3 | (num >> 9)];
					input.DropBits (num2 & 0xF);
					return num2 >> 4;
				}
				int availableBits = input.AvailableBits;
				num = input.PeekBits (availableBits);
				num2 = tree [num3 | (num >> 9)];
				if ((num2 & 0xF) <= availableBits) {
					input.DropBits (num2 & 0xF);
					return num2 >> 4;
				}
				return -1;
			}
			int availableBits2 = input.AvailableBits;
			num = input.PeekBits (availableBits2);
			num2 = tree [num];
			if (num2 >= 0 && (num2 & 0xF) <= availableBits2) {
				input.DropBits (num2 & 0xF);
				return num2 >> 4;
			}
			return -1;
		}
	}
	public class PendingBuffer
	{
		private byte[] buffer_;

		private int start;

		private int end;

		private uint bits;

		private int bitCount;

		public int BitCount => bitCount;

		public bool IsFlushed => end == 0;

		public PendingBuffer ()
			: this (4096)
		{
		}

		public PendingBuffer (int bufferSize)
		{
			buffer_ = new byte[bufferSize];
		}

		public void Reset ()
		{
			start = (end = (bitCount = 0));
		}

		public void WriteByte (int value)
		{
			buffer_ [end++] = (byte)value;
		}

		public void WriteShort (int value)
		{
			buffer_ [end++] = (byte)value;
			buffer_ [end++] = (byte)(value >> 8);
		}

		public void WriteInt (int value)
		{
			buffer_ [end++] = (byte)value;
			buffer_ [end++] = (byte)(value >> 8);
			buffer_ [end++] = (byte)(value >> 16);
			buffer_ [end++] = (byte)(value >> 24);
		}

		public void WriteBlock (byte[] block, int offset, int length)
		{
			Array.Copy (block, offset, buffer_, end, length);
			end += length;
		}

		public void AlignToByte ()
		{
			if (bitCount > 0) {
				buffer_ [end++] = (byte)bits;
				if (bitCount > 8) {
					buffer_ [end++] = (byte)(bits >> 8);
				}
			}
			bits = 0u;
			bitCount = 0;
		}

		public void WriteBits (int b, int count)
		{
			bits |= (uint)(b << bitCount);
			bitCount += count;
			if (bitCount >= 16) {
				buffer_ [end++] = (byte)bits;
				buffer_ [end++] = (byte)(bits >> 8);
				bits >>= 16;
				bitCount -= 16;
			}
		}

		public void WriteShortMSB (int s)
		{
			buffer_ [end++] = (byte)(s >> 8);
			buffer_ [end++] = (byte)s;
		}

		public int Flush (byte[] output, int offset, int length)
		{
			if (bitCount >= 8) {
				buffer_ [end++] = (byte)bits;
				bits >>= 8;
				bitCount -= 8;
			}
			if (length > end - start) {
				length = end - start;
				Array.Copy (buffer_, start, output, offset, length);
				start = 0;
				end = 0;
			} else {
				Array.Copy (buffer_, start, output, offset, length);
				start += length;
			}
			return length;
		}

		public byte[] ToByteArray ()
		{
			byte[] array = new byte[end - start];
			Array.Copy (buffer_, start, array, 0, array.Length);
			start = 0;
			end = 0;
			return array;
		}
	}
}
namespace ICSharpCode.SharpZipLib.Zip.Compression.Streams
{
	public class DeflaterOutputStream : Stream
	{
		private string password;

		private ICryptoTransform cryptoTransform_;

		protected byte[] AESAuthCode;

		private byte[] buffer_;

		protected Deflater deflater_;

		protected Stream baseOutputStream_;

		private bool isClosed_;

		private bool isStreamOwner_ = true;

		private static RNGCryptoServiceProvider _aesRnd;

		public bool IsStreamOwner {
			get {
				return isStreamOwner_;
			}
			set {
				isStreamOwner_ = value;
			}
		}

		public bool CanPatchEntries => baseOutputStream_.CanSeek;

		public string Password {
			get {
				return password;
			}
			set {
				if (value != null && value.Length == 0) {
					password = null;
				} else {
					password = value;
				}
			}
		}

		public override bool CanRead => false;

		public override bool CanSeek => false;

		public override bool CanWrite => baseOutputStream_.CanWrite;

		public override long Length => baseOutputStream_.Length;

		public override long Position {
			get {
				return baseOutputStream_.Position;
			}
			set {
				throw new NotSupportedException ("Position property not supported");
			}
		}

		public DeflaterOutputStream (Stream baseOutputStream)
			: this (baseOutputStream, new Deflater (), 512)
		{
		}

		public DeflaterOutputStream (Stream baseOutputStream, Deflater deflater)
			: this (baseOutputStream, deflater, 512)
		{
		}

		public DeflaterOutputStream (Stream baseOutputStream, Deflater deflater, int bufferSize)
		{
			if (baseOutputStream == null) {
				throw new ArgumentNullException ("baseOutputStream");
			}
			if (!baseOutputStream.CanWrite) {
				throw new ArgumentException ("Must support writing", "baseOutputStream");
			}
			if (deflater == null) {
				throw new ArgumentNullException ("deflater");
			}
			if (bufferSize < 512) {
				throw new ArgumentOutOfRangeException ("bufferSize");
			}
			baseOutputStream_ = baseOutputStream;
			buffer_ = new byte[bufferSize];
			deflater_ = deflater;
		}

		public virtual void Finish ()
		{
			deflater_.Finish ();
			while (!deflater_.IsFinished) {
				int num = deflater_.Deflate (buffer_, 0, buffer_.Length);
				if (num <= 0) {
					break;
				}
				if (cryptoTransform_ != null) {
					EncryptBlock (buffer_, 0, num);
				}
				baseOutputStream_.Write (buffer_, 0, num);
			}
			if (!deflater_.IsFinished) {
				throw new SharpZipBaseException ("Can't deflate all input?");
			}
			baseOutputStream_.Flush ();
			if (cryptoTransform_ != null) {
				if (cryptoTransform_ is ZipAESTransform) {
					AESAuthCode = ((ZipAESTransform)cryptoTransform_).GetAuthCode ();
				}
				cryptoTransform_.Dispose ();
				cryptoTransform_ = null;
			}
		}

		protected void EncryptBlock (byte[] buffer, int offset, int length)
		{
			cryptoTransform_.TransformBlock (buffer, 0, length, buffer, 0);
		}

		protected void InitializePassword (string password)
		{
			PkzipClassicManaged pkzipClassicManaged = new PkzipClassicManaged ();
			byte[] rgbKey = PkzipClassic.GenerateKeys (ZipConstants.ConvertToArray (password));
			cryptoTransform_ = pkzipClassicManaged.CreateEncryptor (rgbKey, null);
		}

		protected void InitializeAESPassword (ZipEntry entry, string rawPassword, out byte[] salt, out byte[] pwdVerifier)
		{
			salt = new byte[entry.AESSaltLen];
			if (_aesRnd == null) {
				_aesRnd = new RNGCryptoServiceProvider ();
			}
			_aesRnd.GetBytes (salt);
			int blockSize = entry.AESKeySize / 8;
			cryptoTransform_ = new ZipAESTransform (rawPassword, salt, blockSize, writeMode: true);
			pwdVerifier = ((ZipAESTransform)cryptoTransform_).PwdVerifier;
		}

		protected void Deflate ()
		{
			while (!deflater_.IsNeedingInput) {
				int num = deflater_.Deflate (buffer_, 0, buffer_.Length);
				if (num <= 0) {
					break;
				}
				if (cryptoTransform_ != null) {
					EncryptBlock (buffer_, 0, num);
				}
				baseOutputStream_.Write (buffer_, 0, num);
			}
			if (!deflater_.IsNeedingInput) {
				throw new SharpZipBaseException ("DeflaterOutputStream can't deflate all input?");
			}
		}

		public override long Seek (long offset, SeekOrigin origin)
		{
			throw new NotSupportedException ("DeflaterOutputStream Seek not supported");
		}

		public override void SetLength (long value)
		{
			throw new NotSupportedException ("DeflaterOutputStream SetLength not supported");
		}

		public override int ReadByte ()
		{
			throw new NotSupportedException ("DeflaterOutputStream ReadByte not supported");
		}

		public override int Read (byte[] buffer, int offset, int count)
		{
			throw new NotSupportedException ("DeflaterOutputStream Read not supported");
		}

		public override IAsyncResult BeginRead (byte[] buffer, int offset, int count, AsyncCallback callback, object state)
		{
			throw new NotSupportedException ("DeflaterOutputStream BeginRead not currently supported");
		}

		public override IAsyncResult BeginWrite (byte[] buffer, int offset, int count, AsyncCallback callback, object state)
		{
			throw new NotSupportedException ("BeginWrite is not supported");
		}

		public override void Flush ()
		{
			deflater_.Flush ();
			Deflate ();
			baseOutputStream_.Flush ();
		}

		public override void Close ()
		{
			if (isClosed_) {
				return;
			}
			isClosed_ = true;
			try {
				Finish ();
				if (cryptoTransform_ != null) {
					GetAuthCodeIfAES ();
					cryptoTransform_.Dispose ();
					cryptoTransform_ = null;
				}
			} finally {
				if (isStreamOwner_) {
					baseOutputStream_.Close ();
				}
			}
		}

		private void GetAuthCodeIfAES ()
		{
			if (cryptoTransform_ is ZipAESTransform) {
				AESAuthCode = ((ZipAESTransform)cryptoTransform_).GetAuthCode ();
			}
		}

		public override void WriteByte (byte value)
		{
			Write (new byte[1] { value }, 0, 1);
		}

		public override void Write (byte[] buffer, int offset, int count)
		{
			deflater_.SetInput (buffer, offset, count);
			Deflate ();
		}
	}
	public class InflaterInputBuffer
	{
		private int rawLength;

		private byte[] rawData;

		private int clearTextLength;

		private byte[] clearText;

		private byte[] internalClearText;

		private int available;

		private ICryptoTransform cryptoTransform;

		private Stream inputStream;

		public int RawLength => rawLength;

		public byte[] RawData => rawData;

		public int ClearTextLength => clearTextLength;

		public byte[] ClearText => clearText;

		public int Available {
			get {
				return available;
			}
			set {
				available = value;
			}
		}

		public ICryptoTransform CryptoTransform {
			set {
				cryptoTransform = value;
				if (cryptoTransform != null) {
					if (rawData == clearText) {
						if (internalClearText == null) {
							internalClearText = new byte[rawData.Length];
						}
						clearText = internalClearText;
					}
					clearTextLength = rawLength;
					if (available > 0) {
						cryptoTransform.TransformBlock (rawData, rawLength - available, available, clearText, rawLength - available);
					}
				} else {
					clearText = rawData;
					clearTextLength = rawLength;
				}
			}
		}

		public InflaterInputBuffer (Stream stream)
			: this (stream, 4096)
		{
		}

		public InflaterInputBuffer (Stream stream, int bufferSize)
		{
			inputStream = stream;
			if (bufferSize < 1024) {
				bufferSize = 1024;
			}
			rawData = new byte[bufferSize];
			clearText = rawData;
		}

		public void SetInflaterInput (Inflater inflater)
		{
			if (available > 0) {
				inflater.SetInput (clearText, clearTextLength - available, available);
				available = 0;
			}
		}

		public void Fill ()
		{
			rawLength = 0;
			int num = rawData.Length;
			while (num > 0) {
				int num2 = inputStream.Read (rawData, rawLength, num);
				if (num2 <= 0) {
					break;
				}
				rawLength += num2;
				num -= num2;
			}
			if (cryptoTransform != null) {
				clearTextLength = cryptoTransform.TransformBlock (rawData, 0, rawLength, clearText, 0);
			} else {
				clearTextLength = rawLength;
			}
			available = clearTextLength;
		}

		public int ReadRawBuffer (byte[] buffer)
		{
			return ReadRawBuffer (buffer, 0, buffer.Length);
		}

		public int ReadRawBuffer (byte[] outBuffer, int offset, int length)
		{
			if (length < 0) {
				throw new ArgumentOutOfRangeException ("length");
			}
			int num = offset;
			int num2 = length;
			while (num2 > 0) {
				if (available <= 0) {
					Fill ();
					if (available <= 0) {
						return 0;
					}
				}
				int num3 = Math.Min (num2, available);
				Array.Copy (rawData, rawLength - available, outBuffer, num, num3);
				num += num3;
				num2 -= num3;
				available -= num3;
			}
			return length;
		}

		public int ReadClearTextBuffer (byte[] outBuffer, int offset, int length)
		{
			if (length < 0) {
				throw new ArgumentOutOfRangeException ("length");
			}
			int num = offset;
			int num2 = length;
			while (num2 > 0) {
				if (available <= 0) {
					Fill ();
					if (available <= 0) {
						return 0;
					}
				}
				int num3 = Math.Min (num2, available);
				Array.Copy (clearText, clearTextLength - available, outBuffer, num, num3);
				num += num3;
				num2 -= num3;
				available -= num3;
			}
			return length;
		}

		public int ReadLeByte ()
		{
			if (available <= 0) {
				Fill ();
				if (available <= 0) {
					throw new ZipException ("EOF in header");
				}
			}
			byte result = rawData [rawLength - available];
			available--;
			return result;
		}

		public int ReadLeShort ()
		{
			return ReadLeByte () | (ReadLeByte () << 8);
		}

		public int ReadLeInt ()
		{
			return ReadLeShort () | (ReadLeShort () << 16);
		}

		public long ReadLeLong ()
		{
			return (uint)ReadLeInt () | ((long)ReadLeInt () << 32);
		}
	}
	public class InflaterInputStream : Stream
	{
		protected Inflater inf;

		protected InflaterInputBuffer inputBuffer;

		private Stream baseInputStream;

		protected long csize;

		private bool isClosed;

		private bool isStreamOwner = true;

		public bool IsStreamOwner {
			get {
				return isStreamOwner;
			}
			set {
				isStreamOwner = value;
			}
		}

		public virtual int Available => (!inf.IsFinished) ? 1 : 0;

		public override bool CanRead => baseInputStream.CanRead;

		public override bool CanSeek => false;

		public override bool CanWrite => false;

		public override long Length => inputBuffer.RawLength;

		public override long Position {
			get {
				return baseInputStream.Position;
			}
			set {
				throw new NotSupportedException ("InflaterInputStream Position not supported");
			}
		}

		public InflaterInputStream (Stream baseInputStream)
			: this (baseInputStream, new Inflater (), 4096)
		{
		}

		public InflaterInputStream (Stream baseInputStream, Inflater inf)
			: this (baseInputStream, inf, 4096)
		{
		}

		public InflaterInputStream (Stream baseInputStream, Inflater inflater, int bufferSize)
		{
			if (baseInputStream == null) {
				throw new ArgumentNullException ("baseInputStream");
			}
			if (inflater == null) {
				throw new ArgumentNullException ("inflater");
			}
			if (bufferSize <= 0) {
				throw new ArgumentOutOfRangeException ("bufferSize");
			}
			this.baseInputStream = baseInputStream;
			inf = inflater;
			inputBuffer = new InflaterInputBuffer (baseInputStream, bufferSize);
		}

		public long Skip (long count)
		{
			if (count <= 0) {
				throw new ArgumentOutOfRangeException ("count");
			}
			if (baseInputStream.CanSeek) {
				baseInputStream.Seek (count, SeekOrigin.Current);
				return count;
			}
			int num = 2048;
			if (count < num) {
				num = (int)count;
			}
			byte[] buffer = new byte[num];
			int num2 = 1;
			long num3 = count;
			while (num3 > 0 && num2 > 0) {
				if (num3 < num) {
					num = (int)num3;
				}
				num2 = baseInputStream.Read (buffer, 0, num);
				num3 -= num2;
			}
			return count - num3;
		}

		protected void StopDecrypting ()
		{
			inputBuffer.CryptoTransform = null;
		}

		protected void Fill ()
		{
			if (inputBuffer.Available <= 0) {
				inputBuffer.Fill ();
				if (inputBuffer.Available <= 0) {
					throw new SharpZipBaseException ("Unexpected EOF");
				}
			}
			inputBuffer.SetInflaterInput (inf);
		}

		public override void Flush ()
		{
			baseInputStream.Flush ();
		}

		public override long Seek (long offset, SeekOrigin origin)
		{
			throw new NotSupportedException ("Seek not supported");
		}

		public override void SetLength (long value)
		{
			throw new NotSupportedException ("InflaterInputStream SetLength not supported");
		}

		public override void Write (byte[] buffer, int offset, int count)
		{
			throw new NotSupportedException ("InflaterInputStream Write not supported");
		}

		public override void WriteByte (byte value)
		{
			throw new NotSupportedException ("InflaterInputStream WriteByte not supported");
		}

		public override IAsyncResult BeginWrite (byte[] buffer, int offset, int count, AsyncCallback callback, object state)
		{
			throw new NotSupportedException ("InflaterInputStream BeginWrite not supported");
		}

		public override void Close ()
		{
			if (!isClosed) {
				isClosed = true;
				if (isStreamOwner) {
					baseInputStream.Close ();
				}
			}
		}

		public override int Read (byte[] buffer, int offset, int count)
		{
			if (inf.IsNeedingDictionary) {
				throw new SharpZipBaseException ("Need a dictionary");
			}
			int num = count;
			while (true) {
				int num2 = inf.Inflate (buffer, offset, num);
				offset += num2;
				num -= num2;
				if (num == 0 || inf.IsFinished) {
					break;
				}
				if (inf.IsNeedingInput) {
					Fill ();
				} else if (num2 == 0) {
					throw new ZipException ("Dont know what to do");
				}
			}
			return count - num;
		}
	}
	public class OutputWindow
	{
		private const int WindowSize = 32768;

		private const int WindowMask = 32767;

		private byte[] window = new byte[32768];

		private int windowEnd;

		private int windowFilled;

		public void Write (int value)
		{
			if (windowFilled++ == 32768) {
				throw new InvalidOperationException ("Window full");
			}
			window [windowEnd++] = (byte)value;
			windowEnd &= 32767;
		}

		private void SlowRepeat (int repStart, int length, int distance)
		{
			while (length-- > 0) {
				window [windowEnd++] = window [repStart++];
				windowEnd &= 32767;
				repStart &= 0x7FFF;
			}
		}

		public void Repeat (int length, int distance)
		{
			if ((windowFilled += length) > 32768) {
				throw new InvalidOperationException ("Window full");
			}
			int num = (windowEnd - distance) & 0x7FFF;
			int num2 = 32768 - length;
			if (num <= num2 && windowEnd < num2) {
				if (length <= distance) {
					Array.Copy (window, num, window, windowEnd, length);
					windowEnd += length;
				} else {
					while (length-- > 0) {
						window [windowEnd++] = window [num++];
					}
				}
			} else {
				SlowRepeat (num, length, distance);
			}
		}

		public int CopyStored (StreamManipulator input, int length)
		{
			length = Math.Min (Math.Min (length, 32768 - windowFilled), input.AvailableBytes);
			int num = 32768 - windowEnd;
			int num2;
			if (length > num) {
				num2 = input.CopyBytes (window, windowEnd, num);
				if (num2 == num) {
					num2 += input.CopyBytes (window, 0, length - num);
				}
			} else {
				num2 = input.CopyBytes (window, windowEnd, length);
			}
			windowEnd = (windowEnd + num2) & 0x7FFF;
			windowFilled += num2;
			return num2;
		}

		public void CopyDict (byte[] dictionary, int offset, int length)
		{
			if (dictionary == null) {
				throw new ArgumentNullException ("dictionary");
			}
			if (windowFilled > 0) {
				throw new InvalidOperationException ();
			}
			if (length > 32768) {
				offset += length - 32768;
				length = 32768;
			}
			Array.Copy (dictionary, offset, window, 0, length);
			windowEnd = length & 0x7FFF;
		}

		public int GetFreeSpace ()
		{
			return 32768 - windowFilled;
		}

		public int GetAvailable ()
		{
			return windowFilled;
		}

		public int CopyOutput (byte[] output, int offset, int len)
		{
			int num = windowEnd;
			if (len > windowFilled) {
				len = windowFilled;
			} else {
				num = (windowEnd - windowFilled + len) & 0x7FFF;
			}
			int num2 = len;
			int num3 = len - num;
			if (num3 > 0) {
				Array.Copy (window, 32768 - num3, output, offset, num3);
				offset += num3;
				len = num;
			}
			Array.Copy (window, num - len, output, offset, len);
			windowFilled -= num2;
			if (windowFilled < 0) {
				throw new InvalidOperationException ();
			}
			return num2;
		}

		public void Reset ()
		{
			windowFilled = (windowEnd = 0);
		}
	}
	public class StreamManipulator
	{
		private byte[] window_;

		private int windowStart_;

		private int windowEnd_;

		private uint buffer_;

		private int bitsInBuffer_;

		public int AvailableBits => bitsInBuffer_;

		public int AvailableBytes => windowEnd_ - windowStart_ + (bitsInBuffer_ >> 3);

		public bool IsNeedingInput => windowStart_ == windowEnd_;

		public int PeekBits (int bitCount)
		{
			if (bitsInBuffer_ < bitCount) {
				if (windowStart_ == windowEnd_) {
					return -1;
				}
				buffer_ |= (uint)(((window_ [windowStart_++] & 0xFF) | ((window_ [windowStart_++] & 0xFF) << 8)) << bitsInBuffer_);
				bitsInBuffer_ += 16;
			}
			return (int)(buffer_ & ((1 << bitCount) - 1));
		}

		public void DropBits (int bitCount)
		{
			buffer_ >>= bitCount;
			bitsInBuffer_ -= bitCount;
		}

		public int GetBits (int bitCount)
		{
			int num = PeekBits (bitCount);
			if (num >= 0) {
				DropBits (bitCount);
			}
			return num;
		}

		public void SkipToByteBoundary ()
		{
			buffer_ >>= bitsInBuffer_ & 7;
			bitsInBuffer_ &= -8;
		}

		public int CopyBytes (byte[] output, int offset, int length)
		{
			if (length < 0) {
				throw new ArgumentOutOfRangeException ("length");
			}
			if (((uint)bitsInBuffer_ & 7u) != 0) {
				throw new InvalidOperationException ("Bit buffer is not byte aligned!");
			}
			int num = 0;
			while (bitsInBuffer_ > 0 && length > 0) {
				output [offset++] = (byte)buffer_;
				buffer_ >>= 8;
				bitsInBuffer_ -= 8;
				length--;
				num++;
			}
			if (length == 0) {
				return num;
			}
			int num2 = windowEnd_ - windowStart_;
			if (length > num2) {
				length = num2;
			}
			Array.Copy (window_, windowStart_, output, offset, length);
			windowStart_ += length;
			if (((uint)(windowStart_ - windowEnd_) & (true ? 1u : 0u)) != 0) {
				buffer_ = window_ [windowStart_++] & 0xFFu;
				bitsInBuffer_ = 8;
			}
			return num + length;
		}

		public void Reset ()
		{
			buffer_ = 0u;
			windowStart_ = (windowEnd_ = (bitsInBuffer_ = 0));
		}

		public void SetInput (byte[] buffer, int offset, int count)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (offset < 0) {
				throw new ArgumentOutOfRangeException ("offset", "Cannot be negative");
			}
			if (count < 0) {
				throw new ArgumentOutOfRangeException ("count", "Cannot be negative");
			}
			if (windowStart_ < windowEnd_) {
				throw new InvalidOperationException ("Old input was not completely processed");
			}
			int num = offset + count;
			if (offset > num || num > buffer.Length) {
				throw new ArgumentOutOfRangeException ("count");
			}
			if (((uint)count & (true ? 1u : 0u)) != 0) {
				buffer_ |= (uint)((buffer [offset++] & 0xFF) << bitsInBuffer_);
				bitsInBuffer_ += 8;
			}
			window_ = buffer;
			windowStart_ = offset;
			windowEnd_ = num;
		}
	}
}
namespace ICSharpCode.SharpZipLib.Zip
{
	public class FastZipEvents
	{
		public ProcessDirectoryHandler ProcessDirectory;

		public ProcessFileHandler ProcessFile;

		public ProgressHandler Progress;

		public CompletedFileHandler CompletedFile;

		public DirectoryFailureHandler DirectoryFailure;

		public FileFailureHandler FileFailure;

		private TimeSpan progressInterval_ = TimeSpan.FromSeconds (3.0);

		public TimeSpan ProgressInterval {
			get {
				return progressInterval_;
			}
			set {
				progressInterval_ = value;
			}
		}

		public bool OnDirectoryFailure (string directory, Exception e)
		{
			bool result = false;
			DirectoryFailureHandler directoryFailure = DirectoryFailure;
			if (directoryFailure != null) {
				ScanFailureEventArgs scanFailureEventArgs = new ScanFailureEventArgs (directory, e);
				directoryFailure (this, scanFailureEventArgs);
				result = scanFailureEventArgs.ContinueRunning;
			}
			return result;
		}

		public bool OnFileFailure (string file, Exception e)
		{
			FileFailureHandler fileFailure = FileFailure;
			bool flag = fileFailure != null;
			if (flag) {
				ScanFailureEventArgs scanFailureEventArgs = new ScanFailureEventArgs (file, e);
				fileFailure (this, scanFailureEventArgs);
				flag = scanFailureEventArgs.ContinueRunning;
			}
			return flag;
		}

		public bool OnProcessFile (string file)
		{
			bool result = true;
			ProcessFileHandler processFile = ProcessFile;
			if (processFile != null) {
				ScanEventArgs scanEventArgs = new ScanEventArgs (file);
				processFile (this, scanEventArgs);
				result = scanEventArgs.ContinueRunning;
			}
			return result;
		}

		public bool OnCompletedFile (string file)
		{
			bool result = true;
			CompletedFileHandler completedFile = CompletedFile;
			if (completedFile != null) {
				ScanEventArgs scanEventArgs = new ScanEventArgs (file);
				completedFile (this, scanEventArgs);
				result = scanEventArgs.ContinueRunning;
			}
			return result;
		}

		public bool OnProcessDirectory (string directory, bool hasMatchingFiles)
		{
			bool result = true;
			ProcessDirectoryHandler processDirectory = ProcessDirectory;
			if (processDirectory != null) {
				DirectoryEventArgs directoryEventArgs = new DirectoryEventArgs (directory, hasMatchingFiles);
				processDirectory (this, directoryEventArgs);
				result = directoryEventArgs.ContinueRunning;
			}
			return result;
		}
	}
	public class FastZip
	{
		public enum Overwrite
		{
			Prompt,
			Never,
			Always
		}

		public delegate bool ConfirmOverwriteDelegate (string fileName);

		private bool continueRunning_;

		private byte[] buffer_;

		private ZipOutputStream outputStream_;

		private ZipFile zipFile_;

		private string sourceDirectory_;

		private NameFilter fileFilter_;

		private NameFilter directoryFilter_;

		private Overwrite overwrite_;

		private ConfirmOverwriteDelegate confirmDelegate_;

		private bool restoreDateTimeOnExtract_;

		private bool restoreAttributesOnExtract_;

		private bool createEmptyDirectories_;

		private FastZipEvents events_;

		private IEntryFactory entryFactory_ = new ZipEntryFactory ();

		private INameTransform extractNameTransform_;

		private UseZip64 useZip64_ = UseZip64.Dynamic;

		private string password_;

		public bool CreateEmptyDirectories {
			get {
				return createEmptyDirectories_;
			}
			set {
				createEmptyDirectories_ = value;
			}
		}

		public string Password {
			get {
				return password_;
			}
			set {
				password_ = value;
			}
		}

		public INameTransform NameTransform {
			get {
				return entryFactory_.NameTransform;
			}
			set {
				entryFactory_.NameTransform = value;
			}
		}

		public IEntryFactory EntryFactory {
			get {
				return entryFactory_;
			}
			set {
				if (value == null) {
					entryFactory_ = new ZipEntryFactory ();
				} else {
					entryFactory_ = value;
				}
			}
		}

		public UseZip64 UseZip64 {
			get {
				return useZip64_;
			}
			set {
				useZip64_ = value;
			}
		}

		public bool RestoreDateTimeOnExtract {
			get {
				return restoreDateTimeOnExtract_;
			}
			set {
				restoreDateTimeOnExtract_ = value;
			}
		}

		public bool RestoreAttributesOnExtract {
			get {
				return restoreAttributesOnExtract_;
			}
			set {
				restoreAttributesOnExtract_ = value;
			}
		}

		public FastZip ()
		{
		}

		public FastZip (FastZipEvents events)
		{
			events_ = events;
		}

		public void CreateZip (string zipFileName, string sourceDirectory, bool recurse, string fileFilter, string directoryFilter)
		{
			CreateZip (File.Create (zipFileName), sourceDirectory, recurse, fileFilter, directoryFilter);
		}

		public void CreateZip (string zipFileName, string sourceDirectory, bool recurse, string fileFilter)
		{
			CreateZip (File.Create (zipFileName), sourceDirectory, recurse, fileFilter, null);
		}

		public void CreateZip (Stream outputStream, string sourceDirectory, bool recurse, string fileFilter, string directoryFilter)
		{
			NameTransform = new ZipNameTransform (sourceDirectory);
			sourceDirectory_ = sourceDirectory;
			using (outputStream_ = new ZipOutputStream (outputStream)) {
				if (password_ != null) {
					outputStream_.Password = password_;
				}
				outputStream_.UseZip64 = UseZip64;
				FileSystemScanner fileSystemScanner = new FileSystemScanner (fileFilter, directoryFilter);
				fileSystemScanner.ProcessFile = (ProcessFileHandler)Delegate.Combine (fileSystemScanner.ProcessFile, new ProcessFileHandler (ProcessFile));
				if (CreateEmptyDirectories) {
					fileSystemScanner.ProcessDirectory = (ProcessDirectoryHandler)Delegate.Combine (fileSystemScanner.ProcessDirectory, new ProcessDirectoryHandler (ProcessDirectory));
				}
				if (events_ != null) {
					if (events_.FileFailure != null) {
						fileSystemScanner.FileFailure = (FileFailureHandler)Delegate.Combine (fileSystemScanner.FileFailure, events_.FileFailure);
					}
					if (events_.DirectoryFailure != null) {
						fileSystemScanner.DirectoryFailure = (DirectoryFailureHandler)Delegate.Combine (fileSystemScanner.DirectoryFailure, events_.DirectoryFailure);
					}
				}
				fileSystemScanner.Scan (sourceDirectory, recurse);
			}
		}

		public void ExtractZip (string zipFileName, string targetDirectory, string fileFilter)
		{
			ExtractZip (zipFileName, targetDirectory, Overwrite.Always, null, fileFilter, null, restoreDateTimeOnExtract_);
		}

		public void ExtractZip (string zipFileName, string targetDirectory, Overwrite overwrite, ConfirmOverwriteDelegate confirmDelegate, string fileFilter, string directoryFilter, bool restoreDateTime)
		{
			Stream inputStream = File.Open (zipFileName, FileMode.Open, FileAccess.Read, FileShare.Read);
			ExtractZip (inputStream, targetDirectory, overwrite, confirmDelegate, fileFilter, directoryFilter, restoreDateTime, isStreamOwner: true);
		}

		public void ExtractZip (Stream inputStream, string targetDirectory, Overwrite overwrite, ConfirmOverwriteDelegate confirmDelegate, string fileFilter, string directoryFilter, bool restoreDateTime, bool isStreamOwner)
		{
			if (overwrite == Overwrite.Prompt && confirmDelegate == null) {
				throw new ArgumentNullException ("confirmDelegate");
			}
			continueRunning_ = true;
			overwrite_ = overwrite;
			confirmDelegate_ = confirmDelegate;
			extractNameTransform_ = new WindowsNameTransform (targetDirectory);
			fileFilter_ = new NameFilter (fileFilter);
			directoryFilter_ = new NameFilter (directoryFilter);
			restoreDateTimeOnExtract_ = restoreDateTime;
			using (zipFile_ = new ZipFile (inputStream)) {
				if (password_ != null) {
					zipFile_.Password = password_;
				}
				zipFile_.IsStreamOwner = isStreamOwner;
				IEnumerator enumerator = zipFile_.GetEnumerator ();
				while (continueRunning_ && enumerator.MoveNext ()) {
					ZipEntry zipEntry = (ZipEntry)enumerator.Current;
					if (zipEntry.IsFile) {
						if (directoryFilter_.IsMatch (Path.GetDirectoryName (zipEntry.Name)) && fileFilter_.IsMatch (zipEntry.Name)) {
							ExtractEntry (zipEntry);
						}
					} else if (zipEntry.IsDirectory && directoryFilter_.IsMatch (zipEntry.Name) && CreateEmptyDirectories) {
						ExtractEntry (zipEntry);
					}
				}
			}
		}

		private void ProcessDirectory (object sender, DirectoryEventArgs e)
		{
			if (!e.HasMatchingFiles && CreateEmptyDirectories) {
				if (events_ != null) {
					events_.OnProcessDirectory (e.Name, e.HasMatchingFiles);
				}
				if (e.ContinueRunning && e.Name != sourceDirectory_) {
					ZipEntry entry = entryFactory_.MakeDirectoryEntry (e.Name);
					outputStream_.PutNextEntry (entry);
				}
			}
		}

		private void ProcessFile (object sender, ScanEventArgs e)
		{
			if (events_ != null && events_.ProcessFile != null) {
				events_.ProcessFile (sender, e);
			}
			if (!e.ContinueRunning) {
				return;
			}
			try {
				using FileStream stream = File.Open (e.Name, FileMode.Open, FileAccess.Read, FileShare.Read);
				ZipEntry entry = entryFactory_.MakeFileEntry (e.Name);
				outputStream_.PutNextEntry (entry);
				AddFileContents (e.Name, stream);
			} catch (Exception e2) {
				if (events_ != null) {
					continueRunning_ = events_.OnFileFailure (e.Name, e2);
					return;
				}
				continueRunning_ = false;
				throw;
			}
		}

		private void AddFileContents (string name, Stream stream)
		{
			if (stream == null) {
				throw new ArgumentNullException ("stream");
			}
			if (buffer_ == null) {
				buffer_ = new byte[4096];
			}
			if (events_ != null && events_.Progress != null) {
				StreamUtils.Copy (stream, outputStream_, buffer_, events_.Progress, events_.ProgressInterval, this, name);
			} else {
				StreamUtils.Copy (stream, outputStream_, buffer_);
			}
			if (events_ != null) {
				continueRunning_ = events_.OnCompletedFile (name);
			}
		}

		private void ExtractFileEntry (ZipEntry entry, string targetName)
		{
			bool flag = true;
			if (overwrite_ != Overwrite.Always && File.Exists (targetName)) {
				flag = overwrite_ == Overwrite.Prompt && confirmDelegate_ != null && confirmDelegate_ (targetName);
			}
			if (!flag) {
				return;
			}
			if (events_ != null) {
				continueRunning_ = events_.OnProcessFile (entry.Name);
			}
			if (!continueRunning_) {
				return;
			}
			try {
				using (FileStream destination = File.Create (targetName)) {
					if (buffer_ == null) {
						buffer_ = new byte[4096];
					}
					if (events_ != null && events_.Progress != null) {
						StreamUtils.Copy (zipFile_.GetInputStream (entry), destination, buffer_, events_.Progress, events_.ProgressInterval, this, entry.Name, entry.Size);
					} else {
						StreamUtils.Copy (zipFile_.GetInputStream (entry), destination, buffer_);
					}
					if (events_ != null) {
						continueRunning_ = events_.OnCompletedFile (entry.Name);
					}
				}
				if (restoreDateTimeOnExtract_) {
					File.SetLastWriteTime (targetName, entry.DateTime);
				}
				if (RestoreAttributesOnExtract && entry.IsDOSEntry && entry.ExternalFileAttributes != -1) {
					FileAttributes externalFileAttributes = (FileAttributes)entry.ExternalFileAttributes;
					externalFileAttributes &= FileAttributes.Archive | FileAttributes.Hidden | FileAttributes.Normal | FileAttributes.ReadOnly;
					File.SetAttributes (targetName, externalFileAttributes);
				}
			} catch (Exception e) {
				if (events_ != null) {
					continueRunning_ = events_.OnFileFailure (targetName, e);
					return;
				}
				continueRunning_ = false;
				throw;
			}
		}

		private void ExtractEntry (ZipEntry entry)
		{
			bool flag = entry.IsCompressionMethodSupported ();
			string text = entry.Name;
			if (flag) {
				if (entry.IsFile) {
					text = extractNameTransform_.TransformFile (text);
				} else if (entry.IsDirectory) {
					text = extractNameTransform_.TransformDirectory (text);
				}
				flag = text != null && text.Length != 0;
			}
			string path = null;
			if (flag) {
				path = ((!entry.IsDirectory) ? Path.GetDirectoryName (Path.GetFullPath (text)) : text);
			}
			if (flag && !Directory.Exists (path) && (!entry.IsDirectory || CreateEmptyDirectories)) {
				try {
					Directory.CreateDirectory (path);
				} catch (Exception e) {
					flag = false;
					if (events_ == null) {
						continueRunning_ = false;
						throw;
					}
					if (entry.IsDirectory) {
						continueRunning_ = events_.OnDirectoryFailure (text, e);
					} else {
						continueRunning_ = events_.OnFileFailure (text, e);
					}
				}
			}
			if (flag && entry.IsFile) {
				ExtractFileEntry (entry, text);
			}
		}

		private static int MakeExternalAttributes (FileInfo info)
		{
			return (int)info.Attributes;
		}

		private static bool NameIsValid (string name)
		{
			return name != null && name.Length > 0 && name.IndexOfAny (Path.GetInvalidPathChars ()) < 0;
		}
	}
	public interface IEntryFactory
	{
		INameTransform NameTransform { get; set; }

		ZipEntry MakeFileEntry (string fileName);

		ZipEntry MakeFileEntry (string fileName, bool useFileSystem);

		ZipEntry MakeDirectoryEntry (string directoryName);

		ZipEntry MakeDirectoryEntry (string directoryName, bool useFileSystem);
	}
	public class WindowsNameTransform : INameTransform
	{
		private const int MaxPath = 260;

		private string _baseDirectory;

		private bool _trimIncomingPaths;

		private char _replacementChar = '_';

		private static readonly char[] InvalidEntryChars;

		public string BaseDirectory {
			get {
				return _baseDirectory;
			}
			set {
				if (value == null) {
					throw new ArgumentNullException ("value");
				}
				_baseDirectory = Path.GetFullPath (value);
			}
		}

		public bool TrimIncomingPaths {
			get {
				return _trimIncomingPaths;
			}
			set {
				_trimIncomingPaths = value;
			}
		}

		public char Replacement {
			get {
				return _replacementChar;
			}
			set {
				for (int i = 0; i < InvalidEntryChars.Length; i++) {
					if (InvalidEntryChars [i] == value) {
						throw new ArgumentException ("invalid path character");
					}
				}
				if (value == '\\' || value == '/') {
					throw new ArgumentException ("invalid replacement character");
				}
				_replacementChar = value;
			}
		}

		public WindowsNameTransform (string baseDirectory)
		{
			if (baseDirectory == null) {
				throw new ArgumentNullException ("baseDirectory", "Directory name is invalid");
			}
			BaseDirectory = baseDirectory;
		}

		public WindowsNameTransform ()
		{
		}

		static WindowsNameTransform ()
		{
			char[] invalidPathChars = Path.GetInvalidPathChars ();
			int num = invalidPathChars.Length + 3;
			InvalidEntryChars = new char[num];
			Array.Copy (invalidPathChars, 0, InvalidEntryChars, 0, invalidPathChars.Length);
			InvalidEntryChars [num - 1] = '*';
			InvalidEntryChars [num - 2] = '?';
			InvalidEntryChars [num - 3] = ':';
		}

		public string TransformDirectory (string name)
		{
			name = TransformFile (name);
			if (name.Length > 0) {
				while (name.EndsWith ("\\")) {
					name = name.Remove (name.Length - 1, 1);
				}
				return name;
			}
			throw new ZipException ("Cannot have an empty directory name");
		}

		public string TransformFile (string name)
		{
			if (name != null) {
				name = MakeValidName (name, _replacementChar);
				if (_trimIncomingPaths) {
					name = Path.GetFileName (name);
				}
				if (_baseDirectory != null) {
					name = Path.Combine (_baseDirectory, name);
				}
			} else {
				name = string.Empty;
			}
			return name;
		}

		public static bool IsValidName (string name)
		{
			return name != null && name.Length <= 260 && string.Compare (name, MakeValidName (name, '_')) == 0;
		}

		public static string MakeValidName (string name, char replacement)
		{
			if (name == null) {
				throw new ArgumentNullException ("name");
			}
			name = WindowsPathUtils.DropPathRoot (name.Replace ("/", "\\"));
			while (name.Length > 0 && name [0] == '\\') {
				name = name.Remove (0, 1);
			}
			while (name.Length > 0 && name [name.Length - 1] == '\\') {
				name = name.Remove (name.Length - 1, 1);
			}
			int num;
			for (num = name.IndexOf ("\\\\"); num >= 0; num = name.IndexOf ("\\\\")) {
				name = name.Remove (num, 1);
			}
			num = name.IndexOfAny (InvalidEntryChars);
			if (num >= 0) {
				StringBuilder stringBuilder = new StringBuilder (name);
				while (num >= 0) {
					stringBuilder [num] = replacement;
					num = ((num < name.Length) ? name.IndexOfAny (InvalidEntryChars, num + 1) : (-1));
				}
				name = stringBuilder.ToString ();
			}
			if (name.Length > 260) {
				throw new PathTooLongException ();
			}
			return name;
		}
	}
	public enum UseZip64
	{
		Off,
		On,
		Dynamic
	}
	public enum CompressionMethod
	{
		Stored = 0,
		Deflated = 8,
		Deflate64 = 9,
		BZip2 = 11,
		WinZipAES = 99
	}
	public enum EncryptionAlgorithm
	{
		None = 0,
		PkzipClassic = 1,
		Des = 26113,
		RC2 = 26114,
		TripleDes168 = 26115,
		TripleDes112 = 26121,
		Aes128 = 26126,
		Aes192 = 26127,
		Aes256 = 26128,
		RC2Corrected = 26370,
		Blowfish = 26400,
		Twofish = 26401,
		RC4 = 26625,
		Unknown = 65535
	}
	[Flags]
	public enum GeneralBitFlags
	{
		Encrypted = 1,
		Method = 6,
		Descriptor = 8,
		ReservedPKware4 = 0x10,
		Patched = 0x20,
		StrongEncryption = 0x40,
		Unused7 = 0x80,
		Unused8 = 0x100,
		Unused9 = 0x200,
		Unused10 = 0x400,
		UnicodeText = 0x800,
		EnhancedCompress = 0x1000,
		HeaderMasked = 0x2000,
		ReservedPkware14 = 0x4000,
		ReservedPkware15 = 0x8000
	}
	public sealed class ZipConstants
	{
		public const int VersionMadeBy = 51;

		[Obsolete ("Use VersionMadeBy instead")]
		public const int VERSION_MADE_BY = 51;

		public const int VersionStrongEncryption = 50;

		[Obsolete ("Use VersionStrongEncryption instead")]
		public const int VERSION_STRONG_ENCRYPTION = 50;

		public const int VERSION_AES = 51;

		public const int VersionZip64 = 45;

		public const int LocalHeaderBaseSize = 30;

		[Obsolete ("Use LocalHeaderBaseSize instead")]
		public const int LOCHDR = 30;

		public const int Zip64DataDescriptorSize = 24;

		public const int DataDescriptorSize = 16;

		[Obsolete ("Use DataDescriptorSize instead")]
		public const int EXTHDR = 16;

		public const int CentralHeaderBaseSize = 46;

		[Obsolete ("Use CentralHeaderBaseSize instead")]
		public const int CENHDR = 46;

		public const int EndOfCentralRecordBaseSize = 22;

		[Obsolete ("Use EndOfCentralRecordBaseSize instead")]
		public const int ENDHDR = 22;

		public const int CryptoHeaderSize = 12;

		[Obsolete ("Use CryptoHeaderSize instead")]
		public const int CRYPTO_HEADER_SIZE = 12;

		public const int LocalHeaderSignature = 67324752;

		[Obsolete ("Use LocalHeaderSignature instead")]
		public const int LOCSIG = 67324752;

		public const int SpanningSignature = 134695760;

		[Obsolete ("Use SpanningSignature instead")]
		public const int SPANNINGSIG = 134695760;

		public const int SpanningTempSignature = 808471376;

		[Obsolete ("Use SpanningTempSignature instead")]
		public const int SPANTEMPSIG = 808471376;

		public const int DataDescriptorSignature = 134695760;

		[Obsolete ("Use DataDescriptorSignature instead")]
		public const int EXTSIG = 134695760;

		[Obsolete ("Use CentralHeaderSignature instead")]
		public const int CENSIG = 33639248;

		public const int CentralHeaderSignature = 33639248;

		public const int Zip64CentralFileHeaderSignature = 101075792;

		[Obsolete ("Use Zip64CentralFileHeaderSignature instead")]
		public const int CENSIG64 = 101075792;

		public const int Zip64CentralDirLocatorSignature = 117853008;

		public const int ArchiveExtraDataSignature = 117853008;

		public const int CentralHeaderDigitalSignature = 84233040;

		[Obsolete ("Use CentralHeaderDigitalSignaure instead")]
		public const int CENDIGITALSIG = 84233040;

		public const int EndOfCentralDirectorySignature = 101010256;

		[Obsolete ("Use EndOfCentralDirectorySignature instead")]
		public const int ENDSIG = 101010256;

		private static int defaultCodePage = Thread.CurrentThread.CurrentCulture.TextInfo.OEMCodePage;

		public static int DefaultCodePage {
			get {
				return defaultCodePage;
			}
			set {
				defaultCodePage = value;
			}
		}

		private ZipConstants ()
		{
		}

		public static string ConvertToString (byte[] data, int count)
		{
			if (data == null) {
				return string.Empty;
			}
			return Encoding.GetEncoding (DefaultCodePage).GetString (data, 0, count);
		}

		public static string ConvertToString (byte[] data)
		{
			if (data == null) {
				return string.Empty;
			}
			return ConvertToString (data, data.Length);
		}

		public static string ConvertToStringExt (int flags, byte[] data, int count)
		{
			if (data == null) {
				return string.Empty;
			}
			return Encoding.UTF8.GetString (data, 0, count);
		}

		public static string ConvertToStringExt (int flags, byte[] data)
		{
			if (data == null) {
				return string.Empty;
			}
			return Encoding.UTF8.GetString (data, 0, data.Length);
		}

		public static byte[] ConvertToArray (string str)
		{
			if (str == null) {
				return new byte[0];
			}
			return Encoding.GetEncoding (DefaultCodePage).GetBytes (str);
		}

		public static byte[] ConvertToArray (int flags, string str)
		{
			if (str == null) {
				return new byte[0];
			}
			if (((uint)flags & 0x800u) != 0) {
				return Encoding.UTF8.GetBytes (str);
			}
			return ConvertToArray (str);
		}
	}
	public enum HostSystemID
	{
		Msdos = 0,
		Amiga = 1,
		OpenVms = 2,
		Unix = 3,
		VMCms = 4,
		AtariST = 5,
		OS2 = 6,
		Macintosh = 7,
		ZSystem = 8,
		Cpm = 9,
		WindowsNT = 10,
		MVS = 11,
		Vse = 12,
		AcornRisc = 13,
		Vfat = 14,
		AlternateMvs = 15,
		BeOS = 16,
		Tandem = 17,
		OS400 = 18,
		OSX = 19,
		WinZipAES = 99
	}
	public class ZipEntry : ICloneable
	{
		[Flags]
		private enum Known : byte
		{
			None = 0,
			Size = 1,
			CompressedSize = 2,
			Crc = 4,
			Time = 8,
			ExternalAttributes = 0x10
		}

		private Known known;

		private int externalFileAttributes = -1;

		private ushort versionMadeBy;

		private string name;

		private ulong size;

		private ulong compressedSize;

		private ushort versionToExtract;

		private uint crc;

		private uint dosTime;

		private CompressionMethod method = CompressionMethod.Deflated;

		private byte[] extra;

		private string comment;

		private int flags;

		private long zipFileIndex = -1L;

		private long offset;

		private bool forceZip64_;

		private byte cryptoCheckValue_;

		private int _aesVer;

		private int _aesEncryptionStrength;

		public bool HasCrc => (known & Known.Crc) != 0;

		public bool IsCrypted {
			get {
				return (flags & 1) != 0;
			}
			set {
				if (value) {
					flags |= 1;
				} else {
					flags &= -2;
				}
			}
		}

		public bool IsUnicodeText {
			get {
				return (flags & 0x800) != 0;
			}
			set {
				if (value) {
					flags |= 2048;
				} else {
					flags &= -2049;
				}
			}
		}

		internal byte CryptoCheckValue {
			get {
				return cryptoCheckValue_;
			}
			set {
				cryptoCheckValue_ = value;
			}
		}

		public int Flags {
			get {
				return flags;
			}
			set {
				flags = value;
			}
		}

		public long ZipFileIndex {
			get {
				return zipFileIndex;
			}
			set {
				zipFileIndex = value;
			}
		}

		public long Offset {
			get {
				return offset;
			}
			set {
				offset = value;
			}
		}

		public int ExternalFileAttributes {
			get {
				if ((known & Known.ExternalAttributes) == 0) {
					return -1;
				}
				return externalFileAttributes;
			}
			set {
				externalFileAttributes = value;
				known |= Known.ExternalAttributes;
			}
		}

		public int VersionMadeBy => versionMadeBy & 0xFF;

		public bool IsDOSEntry => HostSystem == 0 || HostSystem == 10;

		public int HostSystem {
			get {
				return (versionMadeBy >> 8) & 0xFF;
			}
			set {
				versionMadeBy &= 255;
				versionMadeBy |= (ushort)((value & 0xFF) << 8);
			}
		}

		public int Version {
			get {
				if (versionToExtract != 0) {
					return versionToExtract;
				}
				int result = 10;
				if (AESKeySize > 0) {
					result = 51;
				} else if (CentralHeaderRequiresZip64) {
					result = 45;
				} else if (method == CompressionMethod.Deflated) {
					result = 20;
				} else if (IsDirectory) {
					result = 20;
				} else if (IsCrypted) {
					result = 20;
				} else if (HasDosAttributes (8)) {
					result = 11;
				}
				return result;
			}
		}

		public bool CanDecompress => Version <= 51 && (Version == 10 || Version == 11 || Version == 20 || Version == 45 || Version == 51) && IsCompressionMethodSupported ();

		public bool LocalHeaderRequiresZip64 {
			get {
				bool flag = forceZip64_;
				if (!flag) {
					ulong num = compressedSize;
					if (versionToExtract == 0 && IsCrypted) {
						num += 12;
					}
					flag = (size >= uint.MaxValue || num >= uint.MaxValue) && (versionToExtract == 0 || versionToExtract >= 45);
				}
				return flag;
			}
		}

		public bool CentralHeaderRequiresZip64 => LocalHeaderRequiresZip64 || offset >= uint.MaxValue;

		public long DosTime {
			get {
				if ((known & Known.Time) == 0) {
					return 0L;
				}
				return dosTime;
			}
			set {
				dosTime = (uint)value;
				known |= Known.Time;
			}
		}

		public DateTime DateTime {
			get {
				uint second = Math.Min (59u, 2 * (dosTime & 0x1F));
				uint minute = Math.Min (59u, (dosTime >> 5) & 0x3Fu);
				uint hour = Math.Min (23u, (dosTime >> 11) & 0x1Fu);
				uint month = Math.Max (1u, Math.Min (12u, (dosTime >> 21) & 0xFu));
				uint year = ((dosTime >> 25) & 0x7F) + 1980;
				int day = Math.Max (1, Math.Min (DateTime.DaysInMonth ((int)year, (int)month), (int)((dosTime >> 16) & 0x1F)));
				return new DateTime ((int)year, (int)month, day, (int)hour, (int)minute, (int)second);
			}
			set {
				uint num = (uint)value.Year;
				uint num2 = (uint)value.Month;
				uint num3 = (uint)value.Day;
				uint num4 = (uint)value.Hour;
				uint num5 = (uint)value.Minute;
				uint num6 = (uint)value.Second;
				if (num < 1980) {
					num = 1980u;
					num2 = 1u;
					num3 = 1u;
					num4 = 0u;
					num5 = 0u;
					num6 = 0u;
				} else if (num > 2107) {
					num = 2107u;
					num2 = 12u;
					num3 = 31u;
					num4 = 23u;
					num5 = 59u;
					num6 = 59u;
				}
				DosTime = (((num - 1980) & 0x7F) << 25) | (num2 << 21) | (num3 << 16) | (num4 << 11) | (num5 << 5) | (num6 >> 1);
			}
		}

		public string Name => name;

		public long Size {
			get {
				return ((known & Known.Size) == 0) ? (-1L) : ((long)size);
			}
			set {
				size = (ulong)value;
				known |= Known.Size;
			}
		}

		public long CompressedSize {
			get {
				return ((known & Known.CompressedSize) == 0) ? (-1L) : ((long)compressedSize);
			}
			set {
				compressedSize = (ulong)value;
				known |= Known.CompressedSize;
			}
		}

		public long Crc {
			get {
				return ((known & Known.Crc) == 0) ? (-1) : ((long)crc & 0xFFFFFFFFL);
			}
			set {
				if ((crc & -4294967296L) != 0) {
					throw new ArgumentOutOfRangeException ("value");
				}
				crc = (uint)value;
				known |= Known.Crc;
			}
		}

		public CompressionMethod CompressionMethod {
			get {
				return method;
			}
			set {
				if (!IsCompressionMethodSupported (value)) {
					throw new NotSupportedException ("Compression method not supported");
				}
				method = value;
			}
		}

		internal CompressionMethod CompressionMethodForHeader => (AESKeySize <= 0) ? method : CompressionMethod.WinZipAES;

		public byte[] ExtraData {
			get {
				return extra;
			}
			set {
				if (value == null) {
					extra = null;
					return;
				}
				if (value.Length > 65535) {
					throw new ArgumentOutOfRangeException ("value");
				}
				extra = new byte[value.Length];
				Array.Copy (value, 0, extra, 0, value.Length);
			}
		}

		public int AESKeySize {
			get {
				return _aesEncryptionStrength switch {
					0 => 0, 
					1 => 128, 
					2 => 192, 
					3 => 256, 
					_ => throw new ZipException ("Invalid AESEncryptionStrength " + _aesEncryptionStrength), 
				};
			}
			set {
				switch (value) {
				case 0:
					_aesEncryptionStrength = 0;
					break;
				case 128:
					_aesEncryptionStrength = 1;
					break;
				case 256:
					_aesEncryptionStrength = 3;
					break;
				default:
					throw new ZipException ("AESKeySize must be 0, 128 or 256: " + value);
				}
			}
		}

		internal byte AESEncryptionStrength => (byte)_aesEncryptionStrength;

		internal int AESSaltLen => AESKeySize / 16;

		internal int AESOverheadSize => 12 + AESSaltLen;

		public string Comment {
			get {
				return comment;
			}
			set {
				if (value != null && value.Length > 65535) {
					throw new ArgumentOutOfRangeException ("value", "cannot exceed 65535");
				}
				comment = value;
			}
		}

		public bool IsDirectory {
			get {
				int length = name.Length;
				return (length > 0 && (name [length - 1] == '/' || name [length - 1] == '\\')) || HasDosAttributes (16);
			}
		}

		public bool IsFile => !IsDirectory && !HasDosAttributes (8);

		public ZipEntry (string name)
			: this (name, 0, 51, CompressionMethod.Deflated)
		{
		}

		internal ZipEntry (string name, int versionRequiredToExtract)
			: this (name, versionRequiredToExtract, 51, CompressionMethod.Deflated)
		{
		}

		internal ZipEntry (string name, int versionRequiredToExtract, int madeByInfo, CompressionMethod method)
		{
			if (name == null) {
				throw new ArgumentNullException ("name");
			}
			if (name.Length > 65535) {
				throw new ArgumentException ("Name is too long", "name");
			}
			if (versionRequiredToExtract != 0 && versionRequiredToExtract < 10) {
				throw new ArgumentOutOfRangeException ("versionRequiredToExtract");
			}
			DateTime = DateTime.Now;
			this.name = name;
			versionMadeBy = (ushort)madeByInfo;
			versionToExtract = (ushort)versionRequiredToExtract;
			this.method = method;
		}

		[Obsolete ("Use Clone instead")]
		public ZipEntry (ZipEntry entry)
		{
			if (entry == null) {
				throw new ArgumentNullException ("entry");
			}
			known = entry.known;
			name = entry.name;
			size = entry.size;
			compressedSize = entry.compressedSize;
			crc = entry.crc;
			dosTime = entry.dosTime;
			method = entry.method;
			comment = entry.comment;
			versionToExtract = entry.versionToExtract;
			versionMadeBy = entry.versionMadeBy;
			externalFileAttributes = entry.externalFileAttributes;
			flags = entry.flags;
			zipFileIndex = entry.zipFileIndex;
			offset = entry.offset;
			forceZip64_ = entry.forceZip64_;
			if (entry.extra != null) {
				extra = new byte[entry.extra.Length];
				Array.Copy (entry.extra, 0, extra, 0, entry.extra.Length);
			}
		}

		private bool HasDosAttributes (int attributes)
		{
			bool result = false;
			if ((known & Known.ExternalAttributes) != 0 && (HostSystem == 0 || HostSystem == 10) && (ExternalFileAttributes & attributes) == attributes) {
				result = true;
			}
			return result;
		}

		public void ForceZip64 ()
		{
			forceZip64_ = true;
		}

		public bool IsZip64Forced ()
		{
			return forceZip64_;
		}

		internal void ProcessExtraData (bool localHeader)
		{
			ZipExtraData zipExtraData = new ZipExtraData (extra);
			if (zipExtraData.Find (1)) {
				forceZip64_ = true;
				if (zipExtraData.ValueLength < 4) {
					throw new ZipException ("Extra data extended Zip64 information length is invalid");
				}
				if (localHeader || size == uint.MaxValue) {
					size = (ulong)zipExtraData.ReadLong ();
				}
				if (localHeader || compressedSize == uint.MaxValue) {
					compressedSize = (ulong)zipExtraData.ReadLong ();
				}
				if (!localHeader && offset == uint.MaxValue) {
					offset = zipExtraData.ReadLong ();
				}
			} else if ((versionToExtract & 0xFF) >= 45 && (size == uint.MaxValue || compressedSize == uint.MaxValue)) {
				throw new ZipException ("Zip64 Extended information required but is missing.");
			}
			if (zipExtraData.Find (10)) {
				if (zipExtraData.ValueLength < 4) {
					throw new ZipException ("NTFS Extra data invalid");
				}
				zipExtraData.ReadInt ();
				while (zipExtraData.UnreadCount >= 4) {
					int num = zipExtraData.ReadShort ();
					int num2 = zipExtraData.ReadShort ();
					if (num == 1) {
						if (num2 >= 24) {
							long fileTime = zipExtraData.ReadLong ();
							long num3 = zipExtraData.ReadLong ();
							long num4 = zipExtraData.ReadLong ();
							DateTime = DateTime.FromFileTime (fileTime);
						}
						break;
					}
					zipExtraData.Skip (num2);
				}
			} else if (zipExtraData.Find (21589)) {
				int valueLength = zipExtraData.ValueLength;
				int num5 = zipExtraData.ReadByte ();
				if (((uint)num5 & (true ? 1u : 0u)) != 0 && valueLength >= 5) {
					int seconds = zipExtraData.ReadInt ();
					DateTime = (new DateTime (1970, 1, 1, 0, 0, 0).ToUniversalTime () + new TimeSpan (0, 0, 0, seconds, 0)).ToLocalTime ();
				}
			}
			if (method == CompressionMethod.WinZipAES) {
				ProcessAESExtraData (zipExtraData);
			}
		}

		private void ProcessAESExtraData (ZipExtraData extraData)
		{
			if (extraData.Find (39169)) {
				versionToExtract = 51;
				Flags |= 64;
				int valueLength = extraData.ValueLength;
				if (valueLength < 7) {
					throw new ZipException ("AES Extra Data Length " + valueLength + " invalid.");
				}
				int aesVer = extraData.ReadShort ();
				int num = extraData.ReadShort ();
				int aesEncryptionStrength = extraData.ReadByte ();
				int num2 = extraData.ReadShort ();
				_aesVer = aesVer;
				_aesEncryptionStrength = aesEncryptionStrength;
				method = (CompressionMethod)num2;
				return;
			}
			throw new ZipException ("AES Extra Data missing");
		}

		public bool IsCompressionMethodSupported ()
		{
			return IsCompressionMethodSupported (CompressionMethod);
		}

		public object Clone ()
		{
			ZipEntry zipEntry = (ZipEntry)MemberwiseClone ();
			if (extra != null) {
				zipEntry.extra = new byte[extra.Length];
				Array.Copy (extra, 0, zipEntry.extra, 0, extra.Length);
			}
			return zipEntry;
		}

		public override string ToString ()
		{
			return name;
		}

		public static bool IsCompressionMethodSupported (CompressionMethod method)
		{
			return method == CompressionMethod.Deflated || method == CompressionMethod.Stored;
		}

		public static string CleanName (string name)
		{
			if (name == null) {
				return string.Empty;
			}
			if (Path.IsPathRooted (name)) {
				name = name.Substring (Path.GetPathRoot (name).Length);
			}
			name = name.Replace ("\\", "/");
			while (name.Length > 0 && name [0] == '/') {
				name = name.Remove (0, 1);
			}
			return name;
		}
	}
	public class ZipEntryFactory : IEntryFactory
	{
		public enum TimeSetting
		{
			LastWriteTime,
			LastWriteTimeUtc,
			CreateTime,
			CreateTimeUtc,
			LastAccessTime,
			LastAccessTimeUtc,
			Fixed
		}

		private INameTransform nameTransform_;

		private DateTime fixedDateTime_ = DateTime.Now;

		private TimeSetting timeSetting_;

		private bool isUnicodeText_;

		private int getAttributes_ = -1;

		private int setAttributes_;

		public INameTransform NameTransform {
			get {
				return nameTransform_;
			}
			set {
				if (value == null) {
					nameTransform_ = new ZipNameTransform ();
				} else {
					nameTransform_ = value;
				}
			}
		}

		public TimeSetting Setting {
			get {
				return timeSetting_;
			}
			set {
				timeSetting_ = value;
			}
		}

		public DateTime FixedDateTime {
			get {
				return fixedDateTime_;
			}
			set {
				if (value.Year < 1970) {
					throw new ArgumentException ("Value is too old to be valid", "value");
				}
				fixedDateTime_ = value;
			}
		}

		public int GetAttributes {
			get {
				return getAttributes_;
			}
			set {
				getAttributes_ = value;
			}
		}

		public int SetAttributes {
			get {
				return setAttributes_;
			}
			set {
				setAttributes_ = value;
			}
		}

		public bool IsUnicodeText {
			get {
				return isUnicodeText_;
			}
			set {
				isUnicodeText_ = value;
			}
		}

		public ZipEntryFactory ()
		{
			nameTransform_ = new ZipNameTransform ();
		}

		public ZipEntryFactory (TimeSetting timeSetting)
		{
			timeSetting_ = timeSetting;
			nameTransform_ = new ZipNameTransform ();
		}

		public ZipEntryFactory (DateTime time)
		{
			timeSetting_ = TimeSetting.Fixed;
			FixedDateTime = time;
			nameTransform_ = new ZipNameTransform ();
		}

		public ZipEntry MakeFileEntry (string fileName)
		{
			return MakeFileEntry (fileName, useFileSystem: true);
		}

		public ZipEntry MakeFileEntry (string fileName, bool useFileSystem)
		{
			ZipEntry zipEntry = new ZipEntry (nameTransform_.TransformFile (fileName));
			zipEntry.IsUnicodeText = isUnicodeText_;
			int num = 0;
			bool flag = setAttributes_ != 0;
			FileInfo fileInfo = null;
			if (useFileSystem) {
				fileInfo = new FileInfo (fileName);
			}
			if (fileInfo != null && fileInfo.Exists) {
				switch (timeSetting_) {
				case TimeSetting.CreateTime:
					zipEntry.DateTime = fileInfo.CreationTime;
					break;
				case TimeSetting.CreateTimeUtc:
					zipEntry.DateTime = fileInfo.CreationTimeUtc;
					break;
				case TimeSetting.LastAccessTime:
					zipEntry.DateTime = fileInfo.LastAccessTime;
					break;
				case TimeSetting.LastAccessTimeUtc:
					zipEntry.DateTime = fileInfo.LastAccessTimeUtc;
					break;
				case TimeSetting.LastWriteTime:
					zipEntry.DateTime = fileInfo.LastWriteTime;
					break;
				case TimeSetting.LastWriteTimeUtc:
					zipEntry.DateTime = fileInfo.LastWriteTimeUtc;
					break;
				case TimeSetting.Fixed:
					zipEntry.DateTime = fixedDateTime_;
					break;
				default:
					throw new ZipException ("Unhandled time setting in MakeFileEntry");
				}
				zipEntry.Size = fileInfo.Length;
				flag = true;
				num = (int)fileInfo.Attributes & getAttributes_;
			} else if (timeSetting_ == TimeSetting.Fixed) {
				zipEntry.DateTime = fixedDateTime_;
			}
			if (flag) {
				num |= setAttributes_;
				zipEntry.ExternalFileAttributes = num;
			}
			return zipEntry;
		}

		public ZipEntry MakeDirectoryEntry (string directoryName)
		{
			return MakeDirectoryEntry (directoryName, useFileSystem: true);
		}

		public ZipEntry MakeDirectoryEntry (string directoryName, bool useFileSystem)
		{
			ZipEntry zipEntry = new ZipEntry (nameTransform_.TransformDirectory (directoryName));
			zipEntry.IsUnicodeText = isUnicodeText_;
			zipEntry.Size = 0L;
			int num = 0;
			DirectoryInfo directoryInfo = null;
			if (useFileSystem) {
				directoryInfo = new DirectoryInfo (directoryName);
			}
			if (directoryInfo != null && directoryInfo.Exists) {
				switch (timeSetting_) {
				case TimeSetting.CreateTime:
					zipEntry.DateTime = directoryInfo.CreationTime;
					break;
				case TimeSetting.CreateTimeUtc:
					zipEntry.DateTime = directoryInfo.CreationTimeUtc;
					break;
				case TimeSetting.LastAccessTime:
					zipEntry.DateTime = directoryInfo.LastAccessTime;
					break;
				case TimeSetting.LastAccessTimeUtc:
					zipEntry.DateTime = directoryInfo.LastAccessTimeUtc;
					break;
				case TimeSetting.LastWriteTime:
					zipEntry.DateTime = directoryInfo.LastWriteTime;
					break;
				case TimeSetting.LastWriteTimeUtc:
					zipEntry.DateTime = directoryInfo.LastWriteTimeUtc;
					break;
				case TimeSetting.Fixed:
					zipEntry.DateTime = fixedDateTime_;
					break;
				default:
					throw new ZipException ("Unhandled time setting in MakeDirectoryEntry");
				}
				num = (int)directoryInfo.Attributes & getAttributes_;
			} else if (timeSetting_ == TimeSetting.Fixed) {
				zipEntry.DateTime = fixedDateTime_;
			}
			num |= setAttributes_ | 0x10;
			zipEntry.ExternalFileAttributes = num;
			return zipEntry;
		}
	}
	[Serializable]
	public class ZipException : SharpZipBaseException
	{
		protected ZipException (SerializationInfo info, StreamingContext context)
			: base (info, context)
		{
		}

		public ZipException ()
		{
		}

		public ZipException (string message)
			: base (message)
		{
		}

		public ZipException (string message, Exception exception)
			: base (message, exception)
		{
		}
	}
	public interface ITaggedData
	{
		short TagID { get; }

		void SetData (byte[] data, int offset, int count);

		byte[] GetData ();
	}
	public class RawTaggedData : ITaggedData
	{
		private short _tag;

		private byte[] _data;

		public short TagID {
			get {
				return _tag;
			}
			set {
				_tag = value;
			}
		}

		public byte[] Data {
			get {
				return _data;
			}
			set {
				_data = value;
			}
		}

		public RawTaggedData (short tag)
		{
			_tag = tag;
		}

		public void SetData (byte[] data, int offset, int count)
		{
			if (data == null) {
				throw new ArgumentNullException ("data");
			}
			_data = new byte[count];
			Array.Copy (data, offset, _data, 0, count);
		}

		public byte[] GetData ()
		{
			return _data;
		}
	}
	public class ExtendedUnixData : ITaggedData
	{
		[Flags]
		public enum Flags : byte
		{
			ModificationTime = 1,
			AccessTime = 2,
			CreateTime = 4
		}

		private Flags _flags;

		private DateTime _modificationTime = new DateTime (1970, 1, 1);

		private DateTime _lastAccessTime = new DateTime (1970, 1, 1);

		private DateTime _createTime = new DateTime (1970, 1, 1);

		public short TagID => 21589;

		public DateTime ModificationTime {
			get {
				return _modificationTime;
			}
			set {
				if (!IsValidValue (value)) {
					throw new ArgumentOutOfRangeException ("value");
				}
				_flags |= Flags.ModificationTime;
				_modificationTime = value;
			}
		}

		public DateTime AccessTime {
			get {
				return _lastAccessTime;
			}
			set {
				if (!IsValidValue (value)) {
					throw new ArgumentOutOfRangeException ("value");
				}
				_flags |= Flags.AccessTime;
				_lastAccessTime = value;
			}
		}

		public DateTime CreateTime {
			get {
				return _createTime;
			}
			set {
				if (!IsValidValue (value)) {
					throw new ArgumentOutOfRangeException ("value");
				}
				_flags |= Flags.CreateTime;
				_createTime = value;
			}
		}

		private Flags Include {
			get {
				return _flags;
			}
			set {
				_flags = value;
			}
		}

		public void SetData (byte[] data, int index, int count)
		{
			using MemoryStream stream = new MemoryStream (data, index, count, writable: false);
			using ZipHelperStream zipHelperStream = new ZipHelperStream (stream);
			_flags = (Flags)zipHelperStream.ReadByte ();
			if ((_flags & Flags.ModificationTime) != 0 && count >= 5) {
				int seconds = zipHelperStream.ReadLEInt ();
				_modificationTime = (new DateTime (1970, 1, 1, 0, 0, 0).ToUniversalTime () + new TimeSpan (0, 0, 0, seconds, 0)).ToLocalTime ();
			}
			if ((_flags & Flags.AccessTime) != 0) {
				int seconds2 = zipHelperStream.ReadLEInt ();
				_lastAccessTime = (new DateTime (1970, 1, 1, 0, 0, 0).ToUniversalTime () + new TimeSpan (0, 0, 0, seconds2, 0)).ToLocalTime ();
			}
			if ((_flags & Flags.CreateTime) != 0) {
				int seconds3 = zipHelperStream.ReadLEInt ();
				_createTime = (new DateTime (1970, 1, 1, 0, 0, 0).ToUniversalTime () + new TimeSpan (0, 0, 0, seconds3, 0)).ToLocalTime ();
			}
		}

		public byte[] GetData ()
		{
			using MemoryStream memoryStream = new MemoryStream ();
			using ZipHelperStream zipHelperStream = new ZipHelperStream (memoryStream);
			zipHelperStream.IsStreamOwner = false;
			zipHelperStream.WriteByte ((byte)_flags);
			if ((_flags & Flags.ModificationTime) != 0) {
				int value = (int)(_modificationTime.ToUniversalTime () - new DateTime (1970, 1, 1, 0, 0, 0).ToUniversalTime ()).TotalSeconds;
				zipHelperStream.WriteLEInt (value);
			}
			if ((_flags & Flags.AccessTime) != 0) {
				int value2 = (int)(_lastAccessTime.ToUniversalTime () - new DateTime (1970, 1, 1, 0, 0, 0).ToUniversalTime ()).TotalSeconds;
				zipHelperStream.WriteLEInt (value2);
			}
			if ((_flags & Flags.CreateTime) != 0) {
				int value3 = (int)(_createTime.ToUniversalTime () - new DateTime (1970, 1, 1, 0, 0, 0).ToUniversalTime ()).TotalSeconds;
				zipHelperStream.WriteLEInt (value3);
			}
			return memoryStream.ToArray ();
		}

		public static bool IsValidValue (DateTime value)
		{
			return value >= new DateTime (1901, 12, 13, 20, 45, 52) || value <= new DateTime (2038, 1, 19, 3, 14, 7);
		}
	}
	public class NTTaggedData : ITaggedData
	{
		private DateTime _lastAccessTime = DateTime.FromFileTime (0L);

		private DateTime _lastModificationTime = DateTime.FromFileTime (0L);

		private DateTime _createTime = DateTime.FromFileTime (0L);

		public short TagID => 10;

		public DateTime LastModificationTime {
			get {
				return _lastModificationTime;
			}
			set {
				if (!IsValidValue (value)) {
					throw new ArgumentOutOfRangeException ("value");
				}
				_lastModificationTime = value;
			}
		}

		public DateTime CreateTime {
			get {
				return _createTime;
			}
			set {
				if (!IsValidValue (value)) {
					throw new ArgumentOutOfRangeException ("value");
				}
				_createTime = value;
			}
		}

		public DateTime LastAccessTime {
			get {
				return _lastAccessTime;
			}
			set {
				if (!IsValidValue (value)) {
					throw new ArgumentOutOfRangeException ("value");
				}
				_lastAccessTime = value;
			}
		}

		public void SetData (byte[] data, int index, int count)
		{
			using MemoryStream stream = new MemoryStream (data, index, count, writable: false);
			using ZipHelperStream zipHelperStream = new ZipHelperStream (stream);
			zipHelperStream.ReadLEInt ();
			while (zipHelperStream.Position < zipHelperStream.Length) {
				int num = zipHelperStream.ReadLEShort ();
				int num2 = zipHelperStream.ReadLEShort ();
				if (num == 1) {
					if (num2 >= 24) {
						long fileTime = zipHelperStream.ReadLELong ();
						_lastModificationTime = DateTime.FromFileTime (fileTime);
						long fileTime2 = zipHelperStream.ReadLELong ();
						_lastAccessTime = DateTime.FromFileTime (fileTime2);
						long fileTime3 = zipHelperStream.ReadLELong ();
						_createTime = DateTime.FromFileTime (fileTime3);
					}
					break;
				}
				zipHelperStream.Seek (num2, SeekOrigin.Current);
			}
		}

		public byte[] GetData ()
		{
			using MemoryStream memoryStream = new MemoryStream ();
			using ZipHelperStream zipHelperStream = new ZipHelperStream (memoryStream);
			zipHelperStream.IsStreamOwner = false;
			zipHelperStream.WriteLEInt (0);
			zipHelperStream.WriteLEShort (1);
			zipHelperStream.WriteLEShort (24);
			zipHelperStream.WriteLELong (_lastModificationTime.ToFileTime ());
			zipHelperStream.WriteLELong (_lastAccessTime.ToFileTime ());
			zipHelperStream.WriteLELong (_createTime.ToFileTime ());
			return memoryStream.ToArray ();
		}

		public static bool IsValidValue (DateTime value)
		{
			bool result = true;
			try {
				value.ToFileTimeUtc ();
			} catch {
				result = false;
			}
			return result;
		}
	}
	internal interface ITaggedDataFactory
	{
		ITaggedData Create (short tag, byte[] data, int offset, int count);
	}
	public sealed class ZipExtraData : IDisposable
	{
		private int _index;

		private int _readValueStart;

		private int _readValueLength;

		private MemoryStream _newEntry;

		private byte[] _data;

		public int Length => _data.Length;

		public int ValueLength => _readValueLength;

		public int CurrentReadIndex => _index;

		public int UnreadCount {
			get {
				if (_readValueStart > _data.Length || _readValueStart < 4) {
					throw new ZipException ("Find must be called before calling a Read method");
				}
				return _readValueStart + _readValueLength - _index;
			}
		}

		public ZipExtraData ()
		{
			Clear ();
		}

		public ZipExtraData (byte[] data)
		{
			if (data == null) {
				_data = new byte[0];
			} else {
				_data = data;
			}
		}

		public byte[] GetEntryData ()
		{
			if (Length > 65535) {
				throw new ZipException ("Data exceeds maximum length");
			}
			return (byte[])_data.Clone ();
		}

		public void Clear ()
		{
			if (_data == null || _data.Length != 0) {
				_data = new byte[0];
			}
		}

		public Stream GetStreamForTag (int tag)
		{
			Stream result = null;
			if (Find (tag)) {
				result = new MemoryStream (_data, _index, _readValueLength, writable: false);
			}
			return result;
		}

		private ITaggedData GetData (short tag)
		{
			ITaggedData result = null;
			if (Find (tag)) {
				result = Create (tag, _data, _readValueStart, _readValueLength);
			}
			return result;
		}

		private static ITaggedData Create (short tag, byte[] data, int offset, int count)
		{
			ITaggedData taggedData = null;
			taggedData = tag switch {
				10 => new NTTaggedData (), 
				21589 => new ExtendedUnixData (), 
				_ => new RawTaggedData (tag), 
			};
			taggedData.SetData (data, offset, count);
			return taggedData;
		}

		public bool Find (int headerID)
		{
			_readValueStart = _data.Length;
			_readValueLength = 0;
			_index = 0;
			int num = _readValueStart;
			int num2 = headerID - 1;
			while (num2 != headerID && _index < _data.Length - 3) {
				num2 = ReadShortInternal ();
				num = ReadShortInternal ();
				if (num2 != headerID) {
					_index += num;
				}
			}
			bool flag = num2 == headerID && _index + num <= _data.Length;
			if (flag) {
				_readValueStart = _index;
				_readValueLength = num;
			}
			return flag;
		}

		public void AddEntry (ITaggedData taggedData)
		{
			if (taggedData == null) {
				throw new ArgumentNullException ("taggedData");
			}
			AddEntry (taggedData.TagID, taggedData.GetData ());
		}

		public void AddEntry (int headerID, byte[] fieldData)
		{
			if (headerID > 65535 || headerID < 0) {
				throw new ArgumentOutOfRangeException ("headerID");
			}
			int num = ((fieldData != null) ? fieldData.Length : 0);
			if (num > 65535) {
				throw new ArgumentOutOfRangeException ("fieldData", "exceeds maximum length");
			}
			int num2 = _data.Length + num + 4;
			if (Find (headerID)) {
				num2 -= ValueLength + 4;
			}
			if (num2 > 65535) {
				throw new ZipException ("Data exceeds maximum length");
			}
			Delete (headerID);
			byte[] array = new byte[num2];
			_data.CopyTo (array, 0);
			int index = _data.Length;
			_data = array;
			SetShort (ref index, headerID);
			SetShort (ref index, num);
			fieldData?.CopyTo (array, index);
		}

		public void StartNewEntry ()
		{
			_newEntry = new MemoryStream ();
		}

		public void AddNewEntry (int headerID)
		{
			byte[] fieldData = _newEntry.ToArray ();
			_newEntry = null;
			AddEntry (headerID, fieldData);
		}

		public void AddData (byte data)
		{
			_newEntry.WriteByte (data);
		}

		public void AddData (byte[] data)
		{
			if (data == null) {
				throw new ArgumentNullException ("data");
			}
			_newEntry.Write (data, 0, data.Length);
		}

		public void AddLeShort (int toAdd)
		{
			_newEntry.WriteByte ((byte)toAdd);
			_newEntry.WriteByte ((byte)(toAdd >> 8));
		}

		public void AddLeInt (int toAdd)
		{
			AddLeShort ((short)toAdd);
			AddLeShort ((short)(toAdd >> 16));
		}

		public void AddLeLong (long toAdd)
		{
			AddLeInt ((int)(toAdd & 0xFFFFFFFFu));
			AddLeInt ((int)(toAdd >> 32));
		}

		public bool Delete (int headerID)
		{
			bool result = false;
			if (Find (headerID)) {
				result = true;
				int num = _readValueStart - 4;
				byte[] array = new byte[_data.Length - (ValueLength + 4)];
				Array.Copy (_data, 0, array, 0, num);
				int num2 = num + ValueLength + 4;
				Array.Copy (_data, num2, array, num, _data.Length - num2);
				_data = array;
			}
			return result;
		}

		public long ReadLong ()
		{
			ReadCheck (8);
			return (ReadInt () & 0xFFFFFFFFu) | ((long)ReadInt () << 32);
		}

		public int ReadInt ()
		{
			ReadCheck (4);
			int result = _data [_index] + (_data [_index + 1] << 8) + (_data [_index + 2] << 16) + (_data [_index + 3] << 24);
			_index += 4;
			return result;
		}

		public int ReadShort ()
		{
			ReadCheck (2);
			int result = _data [_index] + (_data [_index + 1] << 8);
			_index += 2;
			return result;
		}

		public int ReadByte ()
		{
			int result = -1;
			if (_index < _data.Length && _readValueStart + _readValueLength > _index) {
				result = _data [_index];
				_index++;
			}
			return result;
		}

		public void Skip (int amount)
		{
			ReadCheck (amount);
			_index += amount;
		}

		private void ReadCheck (int length)
		{
			if (_readValueStart > _data.Length || _readValueStart < 4) {
				throw new ZipException ("Find must be called before calling a Read method");
			}
			if (_index > _readValueStart + _readValueLength - length) {
				throw new ZipException ("End of extra data");
			}
			if (_index + length < 4) {
				throw new ZipException ("Cannot read before start of tag");
			}
		}

		private int ReadShortInternal ()
		{
			if (_index > _data.Length - 2) {
				throw new ZipException ("End of extra data");
			}
			int result = _data [_index] + (_data [_index + 1] << 8);
			_index += 2;
			return result;
		}

		private void SetShort (ref int index, int source)
		{
			_data [index] = (byte)source;
			_data [index + 1] = (byte)(source >> 8);
			index += 2;
		}

		public void Dispose ()
		{
			if (_newEntry != null) {
				_newEntry.Close ();
			}
		}
	}
	public class KeysRequiredEventArgs : EventArgs
	{
		private string fileName;

		private byte[] key;

		public string FileName => fileName;

		public byte[] Key {
			get {
				return key;
			}
			set {
				key = value;
			}
		}

		public KeysRequiredEventArgs (string name)
		{
			fileName = name;
		}

		public KeysRequiredEventArgs (string name, byte[] keyValue)
		{
			fileName = name;
			key = keyValue;
		}
	}
	public enum TestStrategy
	{
		FindFirstError,
		FindAllErrors
	}
	public enum TestOperation
	{
		Initialising,
		EntryHeader,
		EntryData,
		EntryComplete,
		MiscellaneousTests,
		Complete
	}
	public class TestStatus
	{
		private ZipFile file_;

		private ZipEntry entry_;

		private bool entryValid_;

		private int errorCount_;

		private long bytesTested_;

		private TestOperation operation_;

		public TestOperation Operation => operation_;

		public ZipFile File => file_;

		public ZipEntry Entry => entry_;

		public int ErrorCount => errorCount_;

		public long BytesTested => bytesTested_;

		public bool EntryValid => entryValid_;

		public TestStatus (ZipFile file)
		{
			file_ = file;
		}

		internal void AddError ()
		{
			errorCount_++;
			entryValid_ = false;
		}

		internal void SetOperation (TestOperation operation)
		{
			operation_ = operation;
		}

		internal void SetEntry (ZipEntry entry)
		{
			entry_ = entry;
			entryValid_ = true;
			bytesTested_ = 0L;
		}

		internal void SetBytesTested (long value)
		{
			bytesTested_ = value;
		}
	}
	public delegate void ZipTestResultHandler (TestStatus status, string message);
	public enum FileUpdateMode
	{
		Safe,
		Direct
	}
	public class ZipFile : IEnumerable, IDisposable
	{
		public delegate void KeysRequiredEventHandler (object sender, KeysRequiredEventArgs e);

		[Flags]
		private enum HeaderTest
		{
			Extract = 1,
			Header = 2
		}

		private enum UpdateCommand
		{
			Copy,
			Modify,
			Add
		}

		private class UpdateComparer : IComparer
		{
			public int Compare (object x, object y)
			{
				ZipUpdate zipUpdate = x as ZipUpdate;
				ZipUpdate zipUpdate2 = y as ZipUpdate;
				int num;
				if (zipUpdate == null) {
					num = ((zipUpdate2 != null) ? (-1) : 0);
				} else if (zipUpdate2 == null) {
					num = 1;
				} else {
					int num2 = ((zipUpdate.Command != 0 && zipUpdate.Command != UpdateCommand.Modify) ? 1 : 0);
					int num3 = ((zipUpdate2.Command != 0 && zipUpdate2.Command != UpdateCommand.Modify) ? 1 : 0);
					num = num2 - num3;
					if (num == 0) {
						long num4 = zipUpdate.Entry.Offset - zipUpdate2.Entry.Offset;
						num = ((num4 < 0) ? (-1) : ((num4 != 0) ? 1 : 0));
					}
				}
				return num;
			}
		}

		private class ZipUpdate
		{
			private ZipEntry entry_;

			private ZipEntry outEntry_;

			private UpdateCommand command_;

			private IStaticDataSource dataSource_;

			private string filename_;

			private long sizePatchOffset_ = -1L;

			private long crcPatchOffset_ = -1L;

			private long _offsetBasedSize = -1L;

			public ZipEntry Entry => entry_;

			public ZipEntry OutEntry {
				get {
					if (outEntry_ == null) {
						outEntry_ = (ZipEntry)entry_.Clone ();
					}
					return outEntry_;
				}
			}

			public UpdateCommand Command => command_;

			public string Filename => filename_;

			public long SizePatchOffset {
				get {
					return sizePatchOffset_;
				}
				set {
					sizePatchOffset_ = value;
				}
			}

			public long CrcPatchOffset {
				get {
					return crcPatchOffset_;
				}
				set {
					crcPatchOffset_ = value;
				}
			}

			public long OffsetBasedSize {
				get {
					return _offsetBasedSize;
				}
				set {
					_offsetBasedSize = value;
				}
			}

			public ZipUpdate (string fileName, ZipEntry entry)
			{
				command_ = UpdateCommand.Add;
				entry_ = entry;
				filename_ = fileName;
			}

			[Obsolete]
			public ZipUpdate (string fileName, string entryName, CompressionMethod compressionMethod)
			{
				command_ = UpdateCommand.Add;
				entry_ = new ZipEntry (entryName);
				entry_.CompressionMethod = compressionMethod;
				filename_ = fileName;
			}

			[Obsolete]
			public ZipUpdate (string fileName, string entryName)
				: this (fileName, entryName, CompressionMethod.Deflated)
			{
			}

			[Obsolete]
			public ZipUpdate (IStaticDataSource dataSource, string entryName, CompressionMethod compressionMethod)
			{
				command_ = UpdateCommand.Add;
				entry_ = new ZipEntry (entryName);
				entry_.CompressionMethod = compressionMethod;
				dataSource_ = dataSource;
			}

			public ZipUpdate (IStaticDataSource dataSource, ZipEntry entry)
			{
				command_ = UpdateCommand.Add;
				entry_ = entry;
				dataSource_ = dataSource;
			}

			public ZipUpdate (ZipEntry original, ZipEntry updated)
			{
				throw new ZipException ("Modify not currently supported");
			}

			public ZipUpdate (UpdateCommand command, ZipEntry entry)
			{
				command_ = command;
				entry_ = (ZipEntry)entry.Clone ();
			}

			public ZipUpdate (ZipEntry entry)
				: this (UpdateCommand.Copy, entry)
			{
			}

			public Stream GetSource ()
			{
				Stream result = null;
				if (dataSource_ != null) {
					result = dataSource_.GetSource ();
				}
				return result;
			}
		}

		private class ZipString
		{
			private string comment_;

			private byte[] rawComment_;

			private bool isSourceString_;

			public bool IsSourceString => isSourceString_;

			public int RawLength {
				get {
					MakeBytesAvailable ();
					return rawComment_.Length;
				}
			}

			public byte[] RawComment {
				get {
					MakeBytesAvailable ();
					return (byte[])rawComment_.Clone ();
				}
			}

			public ZipString (string comment)
			{
				comment_ = comment;
				isSourceString_ = true;
			}

			public ZipString (byte[] rawString)
			{
				rawComment_ = rawString;
			}

			public void Reset ()
			{
				if (isSourceString_) {
					rawComment_ = null;
				} else {
					comment_ = null;
				}
			}

			private void MakeTextAvailable ()
			{
				if (comment_ == null) {
					comment_ = ZipConstants.ConvertToString (rawComment_);
				}
			}

			private void MakeBytesAvailable ()
			{
				if (rawComment_ == null) {
					rawComment_ = ZipConstants.ConvertToArray (comment_);
				}
			}

			public static implicit operator string (ZipString zipString)
			{
				zipString.MakeTextAvailable ();
				return zipString.comment_;
			}
		}

		private class ZipEntryEnumerator : IEnumerator
		{
			private ZipEntry[] array;

			private int index = -1;

			public object Current => array [index];

			public ZipEntryEnumerator (ZipEntry[] entries)
			{
				array = entries;
			}

			public void Reset ()
			{
				index = -1;
			}

			public bool MoveNext ()
			{
				return ++index < array.Length;
			}
		}

		private class UncompressedStream : Stream
		{
			private Stream baseStream_;

			public override bool CanRead => false;

			public override bool CanWrite => baseStream_.CanWrite;

			public override bool CanSeek => false;

			public override long Length => 0L;

			public override long Position {
				get {
					return baseStream_.Position;
				}
				set {
				}
			}

			public UncompressedStream (Stream baseStream)
			{
				baseStream_ = baseStream;
			}

			public override void Close ()
			{
			}

			public override void Flush ()
			{
				baseStream_.Flush ();
			}

			public override int Read (byte[] buffer, int offset, int count)
			{
				return 0;
			}

			public override long Seek (long offset, SeekOrigin origin)
			{
				return 0L;
			}

			public override void SetLength (long value)
			{
			}

			public override void Write (byte[] buffer, int offset, int count)
			{
				baseStream_.Write (buffer, offset, count);
			}
		}

		private class PartialInputStream : Stream
		{
			private ZipFile zipFile_;

			private Stream baseStream_;

			private long start_;

			private long length_;

			private long readPos_;

			private long end_;

			public override long Position {
				get {
					return readPos_ - start_;
				}
				set {
					long num = start_ + value;
					if (num < start_) {
						throw new ArgumentException ("Negative position is invalid");
					}
					if (num >= end_) {
						throw new InvalidOperationException ("Cannot seek past end");
					}
					readPos_ = num;
				}
			}

			public override long Length => length_;

			public override bool CanWrite => false;

			public override bool CanSeek => true;

			public override bool CanRead => true;

			public override bool CanTimeout => baseStream_.CanTimeout;

			public PartialInputStream (ZipFile zipFile, long start, long length)
			{
				start_ = start;
				length_ = length;
				zipFile_ = zipFile;
				baseStream_ = zipFile_.baseStream_;
				readPos_ = start;
				end_ = start + length;
			}

			public override int ReadByte ()
			{
				if (readPos_ >= end_) {
					return -1;
				}
				lock (baseStream_) {
					baseStream_.Seek (readPos_++, SeekOrigin.Begin);
					return baseStream_.ReadByte ();
				}
			}

			public override void Close ()
			{
			}

			public override int Read (byte[] buffer, int offset, int count)
			{
				lock (baseStream_) {
					if (count > end_ - readPos_) {
						count = (int)(end_ - readPos_);
						if (count == 0) {
							return 0;
						}
					}
					baseStream_.Seek (readPos_, SeekOrigin.Begin);
					int num = baseStream_.Read (buffer, offset, count);
					if (num > 0) {
						readPos_ += num;
					}
					return num;
				}
			}

			public override void Write (byte[] buffer, int offset, int count)
			{
				throw new NotSupportedException ();
			}

			public override void SetLength (long value)
			{
				throw new NotSupportedException ();
			}

			public override long Seek (long offset, SeekOrigin origin)
			{
				long num = readPos_;
				switch (origin) {
				case SeekOrigin.Begin:
					num = start_ + offset;
					break;
				case SeekOrigin.Current:
					num = readPos_ + offset;
					break;
				case SeekOrigin.End:
					num = end_ + offset;
					break;
				}
				if (num < start_) {
					throw new ArgumentException ("Negative position is invalid");
				}
				if (num >= end_) {
					throw new IOException ("Cannot seek past end");
				}
				readPos_ = num;
				return readPos_;
			}

			public override void Flush ()
			{
			}
		}

		public KeysRequiredEventHandler KeysRequired;

		private const int DefaultBufferSize = 4096;

		private bool isDisposed_;

		private string name_;

		private string comment_;

		private string rawPassword_;

		private Stream baseStream_;

		private bool isStreamOwner;

		private long offsetOfFirstEntry;

		private ZipEntry[] entries_;

		private byte[] key;

		private bool isNewArchive_;

		private UseZip64 useZip64_ = UseZip64.Dynamic;

		private ArrayList updates_;

		private long updateCount_;

		private Hashtable updateIndex_;

		private IArchiveStorage archiveStorage_;

		private IDynamicDataSource updateDataSource_;

		private bool contentsEdited_;

		private int bufferSize_ = 4096;

		private byte[] copyBuffer_;

		private ZipString newComment_;

		private bool commentEdited_;

		private IEntryFactory updateEntryFactory_ = new ZipEntryFactory ();

		private byte[] Key {
			get {
				return key;
			}
			set {
				key = value;
			}
		}

		public string Password {
			set {
				if (value == null || value.Length == 0) {
					key = null;
					return;
				}
				rawPassword_ = value;
				key = PkzipClassic.GenerateKeys (ZipConstants.ConvertToArray (value));
			}
		}

		private bool HaveKeys => key != null;

		public bool IsStreamOwner {
			get {
				return isStreamOwner;
			}
			set {
				isStreamOwner = value;
			}
		}

		public bool IsEmbeddedArchive => offsetOfFirstEntry > 0;

		public bool IsNewArchive => isNewArchive_;

		public string ZipFileComment => comment_;

		public string Name => name_;

		[Obsolete ("Use the Count property instead")]
		public int Size => entries_.Length;

		public long Count => entries_.Length;

		[IndexerName ("EntryByIndex")]
		public ZipEntry this [int index] => (ZipEntry)entries_ [index].Clone ();

		public INameTransform NameTransform {
			get {
				return updateEntryFactory_.NameTransform;
			}
			set {
				updateEntryFactory_.NameTransform = value;
			}
		}

		public IEntryFactory EntryFactory {
			get {
				return updateEntryFactory_;
			}
			set {
				if (value == null) {
					updateEntryFactory_ = new ZipEntryFactory ();
				} else {
					updateEntryFactory_ = value;
				}
			}
		}

		public int BufferSize {
			get {
				return bufferSize_;
			}
			set {
				if (value < 1024) {
					throw new ArgumentOutOfRangeException ("value", "cannot be below 1024");
				}
				if (bufferSize_ != value) {
					bufferSize_ = value;
					copyBuffer_ = null;
				}
			}
		}

		public bool IsUpdating => updates_ != null;

		public UseZip64 UseZip64 {
			get {
				return useZip64_;
			}
			set {
				useZip64_ = value;
			}
		}

		public ZipFile (string name)
		{
			if (name == null) {
				throw new ArgumentNullException ("name");
			}
			name_ = name;
			baseStream_ = File.Open (name, FileMode.Open, FileAccess.Read, FileShare.Read);
			isStreamOwner = true;
			try {
				ReadEntries ();
			} catch {
				DisposeInternal (disposing: true);
				throw;
			}
		}

		public ZipFile (FileStream file)
		{
			if (file == null) {
				throw new ArgumentNullException ("file");
			}
			if (!file.CanSeek) {
				throw new ArgumentException ("Stream is not seekable", "file");
			}
			baseStream_ = file;
			name_ = file.Name;
			isStreamOwner = true;
			try {
				ReadEntries ();
			} catch {
				DisposeInternal (disposing: true);
				throw;
			}
		}

		public ZipFile (Stream stream)
		{
			if (stream == null) {
				throw new ArgumentNullException ("stream");
			}
			if (!stream.CanSeek) {
				throw new ArgumentException ("Stream is not seekable", "stream");
			}
			baseStream_ = stream;
			isStreamOwner = true;
			if (baseStream_.Length > 0) {
				try {
					ReadEntries ();
					return;
				} catch {
					DisposeInternal (disposing: true);
					throw;
				}
			}
			entries_ = new ZipEntry[0];
			isNewArchive_ = true;
		}

		internal ZipFile ()
		{
			entries_ = new ZipEntry[0];
			isNewArchive_ = true;
		}

		private void OnKeysRequired (string fileName)
		{
			if (KeysRequired != null) {
				KeysRequiredEventArgs keysRequiredEventArgs = new KeysRequiredEventArgs (fileName, key);
				KeysRequired (this, keysRequiredEventArgs);
				key = keysRequiredEventArgs.Key;
			}
		}

		~ZipFile ()
		{
			Dispose (disposing: false);
		}

		public void Close ()
		{
			DisposeInternal (disposing: true);
			GC.SuppressFinalize (this);
		}

		public static ZipFile Create (string fileName)
		{
			if (fileName == null) {
				throw new ArgumentNullException ("fileName");
			}
			FileStream fileStream = File.Create (fileName);
			ZipFile zipFile = new ZipFile ();
			zipFile.name_ = fileName;
			zipFile.baseStream_ = fileStream;
			zipFile.isStreamOwner = true;
			return zipFile;
		}

		public static ZipFile Create (Stream outStream)
		{
			if (outStream == null) {
				throw new ArgumentNullException ("outStream");
			}
			if (!outStream.CanWrite) {
				throw new ArgumentException ("Stream is not writeable", "outStream");
			}
			if (!outStream.CanSeek) {
				throw new ArgumentException ("Stream is not seekable", "outStream");
			}
			ZipFile zipFile = new ZipFile ();
			zipFile.baseStream_ = outStream;
			return zipFile;
		}

		public IEnumerator GetEnumerator ()
		{
			if (isDisposed_) {
				throw new ObjectDisposedException ("ZipFile");
			}
			return new ZipEntryEnumerator (entries_);
		}

		public int FindEntry (string name, bool ignoreCase)
		{
			if (isDisposed_) {
				throw new ObjectDisposedException ("ZipFile");
			}
			for (int i = 0; i < entries_.Length; i++) {
				if (string.Compare (name, entries_ [i].Name, ignoreCase, CultureInfo.InvariantCulture) == 0) {
					return i;
				}
			}
			return -1;
		}

		public ZipEntry GetEntry (string name)
		{
			if (isDisposed_) {
				throw new ObjectDisposedException ("ZipFile");
			}
			int num = FindEntry (name, ignoreCase: true);
			return (num < 0) ? null : ((ZipEntry)entries_ [num].Clone ());
		}

		public Stream GetInputStream (ZipEntry entry)
		{
			if (entry == null) {
				throw new ArgumentNullException ("entry");
			}
			if (isDisposed_) {
				throw new ObjectDisposedException ("ZipFile");
			}
			long num = entry.ZipFileIndex;
			if (num < 0 || num >= entries_.Length || entries_ [num].Name != entry.Name) {
				num = FindEntry (entry.Name, ignoreCase: true);
				if (num < 0) {
					throw new ZipException ("Entry cannot be found");
				}
			}
			return GetInputStream (num);
		}

		public Stream GetInputStream (long entryIndex)
		{
			if (isDisposed_) {
				throw new ObjectDisposedException ("ZipFile");
			}
			long start = LocateEntry (entries_ [entryIndex]);
			CompressionMethod compressionMethod = entries_ [entryIndex].CompressionMethod;
			Stream stream = new PartialInputStream (this, start, entries_ [entryIndex].CompressedSize);
			if (entries_ [entryIndex].IsCrypted) {
				stream = CreateAndInitDecryptionStream (stream, entries_ [entryIndex]);
				if (stream == null) {
					throw new ZipException ("Unable to decrypt this entry");
				}
			}
			switch (compressionMethod) {
			case CompressionMethod.Deflated:
				stream = new InflaterInputStream (stream, new Inflater (noHeader: true));
				break;
			default:
				throw new ZipException ("Unsupported compression method " + compressionMethod);
			case CompressionMethod.Stored:
				break;
			}
			return stream;
		}

		public bool TestArchive (bool testData)
		{
			return TestArchive (testData, TestStrategy.FindFirstError, null);
		}

		public bool TestArchive (bool testData, TestStrategy strategy, ZipTestResultHandler resultHandler)
		{
			if (isDisposed_) {
				throw new ObjectDisposedException ("ZipFile");
			}
			TestStatus testStatus = new TestStatus (this);
			resultHandler?.Invoke (testStatus, null);
			HeaderTest tests = ((!testData) ? HeaderTest.Header : (HeaderTest.Extract | HeaderTest.Header));
			bool flag = true;
			try {
				int num = 0;
				while (flag && num < Count) {
					if (resultHandler != null) {
						testStatus.SetEntry (this [num]);
						testStatus.SetOperation (TestOperation.EntryHeader);
						resultHandler (testStatus, null);
					}
					try {
						TestLocalHeader (this [num], tests);
					} catch (ZipException ex) {
						testStatus.AddError ();
						resultHandler?.Invoke (testStatus, $"Exception during test - '{ex.Message}'");
						if (strategy == TestStrategy.FindFirstError) {
							flag = false;
						}
					}
					if (flag && testData && this [num].IsFile) {
						if (resultHandler != null) {
							testStatus.SetOperation (TestOperation.EntryData);
							resultHandler (testStatus, null);
						}
						Crc32 crc = new Crc32 ();
						using (Stream stream = GetInputStream (this [num])) {
							byte[] array = new byte[4096];
							long num2 = 0L;
							int num3;
							while ((num3 = stream.Read (array, 0, array.Length)) > 0) {
								crc.Update (array, 0, num3);
								if (resultHandler != null) {
									num2 += num3;
									testStatus.SetBytesTested (num2);
									resultHandler (testStatus, null);
								}
							}
						}
						if (this [num].Crc != crc.Value) {
							testStatus.AddError ();
							resultHandler?.Invoke (testStatus, "CRC mismatch");
							if (strategy == TestStrategy.FindFirstError) {
								flag = false;
							}
						}
						if (((uint)this [num].Flags & 8u) != 0) {
							ZipHelperStream zipHelperStream = new ZipHelperStream (baseStream_);
							DescriptorData descriptorData = new DescriptorData ();
							zipHelperStream.ReadDataDescriptor (this [num].LocalHeaderRequiresZip64, descriptorData);
							if (this [num].Crc != descriptorData.Crc) {
								testStatus.AddError ();
							}
							if (this [num].CompressedSize != descriptorData.CompressedSize) {
								testStatus.AddError ();
							}
							if (this [num].Size != descriptorData.Size) {
								testStatus.AddError ();
							}
						}
					}
					if (resultHandler != null) {
						testStatus.SetOperation (TestOperation.EntryComplete);
						resultHandler (testStatus, null);
					}
					num++;
				}
				if (resultHandler != null) {
					testStatus.SetOperation (TestOperation.MiscellaneousTests);
					resultHandler (testStatus, null);
				}
			} catch (Exception ex2) {
				testStatus.AddError ();
				resultHandler?.Invoke (testStatus, $"Exception during test - '{ex2.Message}'");
			}
			if (resultHandler != null) {
				testStatus.SetOperation (TestOperation.Complete);
				testStatus.SetEntry (null);
				resultHandler (testStatus, null);
			}
			return testStatus.ErrorCount == 0;
		}

		private long TestLocalHeader (ZipEntry entry, HeaderTest tests)
		{
			lock (baseStream_) {
				bool flag = (tests & HeaderTest.Header) != 0;
				bool flag2 = (tests & HeaderTest.Extract) != 0;
				baseStream_.Seek (offsetOfFirstEntry + entry.Offset, SeekOrigin.Begin);
				if (ReadLEUint () != 67324752) {
					throw new ZipException ($"Wrong local header signature @{offsetOfFirstEntry + entry.Offset:X}");
				}
				short num = (short)ReadLEUshort ();
				short num2 = (short)ReadLEUshort ();
				short num3 = (short)ReadLEUshort ();
				short num4 = (short)ReadLEUshort ();
				short num5 = (short)ReadLEUshort ();
				uint num6 = ReadLEUint ();
				long num7 = ReadLEUint ();
				long num8 = ReadLEUint ();
				int num9 = ReadLEUshort ();
				int num10 = ReadLEUshort ();
				byte[] array = new byte[num9];
				StreamUtils.ReadFully (baseStream_, array);
				byte[] array2 = new byte[num10];
				StreamUtils.ReadFully (baseStream_, array2);
				ZipExtraData zipExtraData = new ZipExtraData (array2);
				if (zipExtraData.Find (1)) {
					num8 = zipExtraData.ReadLong ();
					num7 = zipExtraData.ReadLong ();
					if (((uint)num2 & 8u) != 0) {
						if (num8 != -1 && num8 != entry.Size) {
							throw new ZipException ("Size invalid for descriptor");
						}
						if (num7 != -1 && num7 != entry.CompressedSize) {
							throw new ZipException ("Compressed size invalid for descriptor");
						}
					}
				} else if (num >= 45 && ((int)num8 == -1 || (int)num7 == -1)) {
					throw new ZipException ("Required Zip64 extended information missing");
				}
				if (flag2 && entry.IsFile) {
					if (!entry.IsCompressionMethodSupported ()) {
						throw new ZipException ("Compression method not supported");
					}
					if (num > 51 || (num > 20 && num < 45)) {
						throw new ZipException ($"Version required to extract this entry not supported ({num})");
					}
					if (((uint)num2 & 0x3060u) != 0) {
						throw new ZipException ("The library does not support the zip version required to extract this entry");
					}
				}
				if (flag) {
					if (num <= 63 && num != 10 && num != 11 && num != 20 && num != 21 && num != 25 && num != 27 && num != 45 && num != 46 && num != 50 && num != 51 && num != 52 && num != 61 && num != 62 && num != 63) {
						throw new ZipException ($"Version required to extract this entry is invalid ({num})");
					}
					if (((uint)num2 & 0xC010u) != 0) {
						throw new ZipException ("Reserved bit flags cannot be set.");
					}
					if (((uint)num2 & (true ? 1u : 0u)) != 0 && num < 20) {
						throw new ZipException ($"Version required to extract this entry is too low for encryption ({num})");
					}
					if (((uint)num2 & 0x40u) != 0) {
						if ((num2 & 1) == 0) {
							throw new ZipException ("Strong encryption flag set but encryption flag is not set");
						}
						if (num < 50) {
							throw new ZipException ($"Version required to extract this entry is too low for encryption ({num})");
						}
					}
					if (((uint)num2 & 0x20u) != 0 && num < 27) {
						throw new ZipException ($"Patched data requires higher version than ({num})");
					}
					if (num2 != entry.Flags) {
						throw new ZipException ("Central header/local header flags mismatch");
					}
					if (entry.CompressionMethod != (CompressionMethod)num3) {
						throw new ZipException ("Central header/local header compression method mismatch");
					}
					if (entry.Version != num) {
						throw new ZipException ("Extract version mismatch");
					}
					if (((uint)num2 & 0x40u) != 0 && num < 62) {
						throw new ZipException ("Strong encryption flag set but version not high enough");
					}
					if (((uint)num2 & 0x2000u) != 0 && (num4 != 0 || num5 != 0)) {
						throw new ZipException ("Header masked set but date/time values non-zero");
					}
					if ((num2 & 8) == 0 && num6 != (uint)entry.Crc) {
						throw new ZipException ("Central header/local header crc mismatch");
					}
					if (num8 == 0 && num7 == 0 && num6 != 0) {
						throw new ZipException ("Invalid CRC for empty entry");
					}
					if (entry.Name.Length > num9) {
						throw new ZipException ("File name length mismatch");
					}
					string text = ZipConstants.ConvertToStringExt (num2, array);
					if (text != entry.Name) {
						throw new ZipException ("Central header and local header file name mismatch");
					}
					if (entry.IsDirectory) {
						if (num8 > 0) {
							throw new ZipException ("Directory cannot have size");
						}
						if (entry.IsCrypted) {
							if (num7 > 14) {
								throw new ZipException ("Directory compressed size invalid");
							}
						} else if (num7 > 2) {
							throw new ZipException ("Directory compressed size invalid");
						}
					}
					if (!ZipNameTransform.IsValidName (text, relaxed: true)) {
						throw new ZipException ("Name is invalid");
					}
				}
				if ((num2 & 8) == 0 || num8 > 0 || num7 > 0) {
					if (num8 != entry.Size) {
						throw new ZipException ($"Size mismatch between central header({entry.Size}) and local header({num8})");
					}
					if (num7 != entry.CompressedSize && num7 != uint.MaxValue && num7 != -1) {
						throw new ZipException ($"Compressed size mismatch between central header({entry.CompressedSize}) and local header({num7})");
					}
				}
				int num11 = num9 + num10;
				return offsetOfFirstEntry + entry.Offset + 30 + num11;
			}
		}

		public void BeginUpdate (IArchiveStorage archiveStorage, IDynamicDataSource dataSource)
		{
			if (archiveStorage == null) {
				throw new ArgumentNullException ("archiveStorage");
			}
			if (dataSource == null) {
				throw new ArgumentNullException ("dataSource");
			}
			if (isDisposed_) {
				throw new ObjectDisposedException ("ZipFile");
			}
			if (IsEmbeddedArchive) {
				throw new ZipException ("Cannot update embedded/SFX archives");
			}
			archiveStorage_ = archiveStorage;
			updateDataSource_ = dataSource;
			updateIndex_ = new Hashtable ();
			updates_ = new ArrayList (entries_.Length);
			ZipEntry[] array = entries_;
			foreach (ZipEntry zipEntry in array) {
				int num = updates_.Add (new ZipUpdate (zipEntry));
				updateIndex_.Add (zipEntry.Name, num);
			}
			updates_.Sort (new UpdateComparer ());
			int num2 = 0;
			foreach (ZipUpdate item in updates_) {
				if (num2 == updates_.Count - 1) {
					break;
				}
				item.OffsetBasedSize = ((ZipUpdate)updates_ [num2 + 1]).Entry.Offset - item.Entry.Offset;
				num2++;
			}
			updateCount_ = updates_.Count;
			contentsEdited_ = false;
			commentEdited_ = false;
			newComment_ = null;
		}

		public void BeginUpdate (IArchiveStorage archiveStorage)
		{
			BeginUpdate (archiveStorage, new DynamicDiskDataSource ());
		}

		public void BeginUpdate ()
		{
			if (Name == null) {
				BeginUpdate (new MemoryArchiveStorage (), new DynamicDiskDataSource ());
			} else {
				BeginUpdate (new DiskArchiveStorage (this), new DynamicDiskDataSource ());
			}
		}

		public void CommitUpdate ()
		{
			if (isDisposed_) {
				throw new ObjectDisposedException ("ZipFile");
			}
			CheckUpdating ();
			try {
				updateIndex_.Clear ();
				updateIndex_ = null;
				if (contentsEdited_) {
					RunUpdates ();
				} else if (commentEdited_) {
					UpdateCommentOnly ();
				} else if (entries_.Length == 0) {
					byte[] comment = ((newComment_ == null) ? ZipConstants.ConvertToArray (comment_) : newComment_.RawComment);
					using ZipHelperStream zipHelperStream = new ZipHelperStream (baseStream_);
					zipHelperStream.WriteEndOfCentralDirectory (0L, 0L, 0L, comment);
					return;
				}
			} finally {
				PostUpdateCleanup ();
			}
		}

		public void AbortUpdate ()
		{
			PostUpdateCleanup ();
		}

		public void SetComment (string comment)
		{
			if (isDisposed_) {
				throw new ObjectDisposedException ("ZipFile");
			}
			CheckUpdating ();
			newComment_ = new ZipString (comment);
			if (newComment_.RawLength > 65535) {
				newComment_ = null;
				throw new ZipException ("Comment length exceeds maximum - 65535");
			}
			commentEdited_ = true;
		}

		private void AddUpdate (ZipUpdate update)
		{
			contentsEdited_ = true;
			int num = FindExistingUpdate (update.Entry.Name);
			if (num >= 0) {
				if (updates_ [num] == null) {
					updateCount_++;
				}
				updates_ [num] = update;
			} else {
				num = updates_.Add (update);
				updateCount_++;
				updateIndex_.Add (update.Entry.Name, num);
			}
		}

		public void Add (string fileName, CompressionMethod compressionMethod, bool useUnicodeText)
		{
			if (fileName == null) {
				throw new ArgumentNullException ("fileName");
			}
			if (isDisposed_) {
				throw new ObjectDisposedException ("ZipFile");
			}
			if (!ZipEntry.IsCompressionMethodSupported (compressionMethod)) {
				throw new ArgumentOutOfRangeException ("compressionMethod");
			}
			CheckUpdating ();
			contentsEdited_ = true;
			ZipEntry zipEntry = EntryFactory.MakeFileEntry (fileName);
			zipEntry.IsUnicodeText = useUnicodeText;
			zipEntry.CompressionMethod = compressionMethod;
			AddUpdate (new ZipUpdate (fileName, zipEntry));
		}

		public void Add (string fileName, CompressionMethod compressionMethod)
		{
			if (fileName == null) {
				throw new ArgumentNullException ("fileName");
			}
			if (!ZipEntry.IsCompressionMethodSupported (compressionMethod)) {
				throw new ArgumentOutOfRangeException ("compressionMethod");
			}
			CheckUpdating ();
			contentsEdited_ = true;
			ZipEntry zipEntry = EntryFactory.MakeFileEntry (fileName);
			zipEntry.CompressionMethod = compressionMethod;
			AddUpdate (new ZipUpdate (fileName, zipEntry));
		}

		public void Add (string fileName)
		{
			if (fileName == null) {
				throw new ArgumentNullException ("fileName");
			}
			CheckUpdating ();
			AddUpdate (new ZipUpdate (fileName, EntryFactory.MakeFileEntry (fileName)));
		}

		public void Add (string fileName, string entryName)
		{
			if (fileName == null) {
				throw new ArgumentNullException ("fileName");
			}
			if (entryName == null) {
				throw new ArgumentNullException ("entryName");
			}
			CheckUpdating ();
			AddUpdate (new ZipUpdate (fileName, EntryFactory.MakeFileEntry (entryName)));
		}

		public void Add (IStaticDataSource dataSource, string entryName)
		{
			if (dataSource == null) {
				throw new ArgumentNullException ("dataSource");
			}
			if (entryName == null) {
				throw new ArgumentNullException ("entryName");
			}
			CheckUpdating ();
			AddUpdate (new ZipUpdate (dataSource, EntryFactory.MakeFileEntry (entryName, useFileSystem: false)));
		}

		public void Add (IStaticDataSource dataSource, string entryName, CompressionMethod compressionMethod)
		{
			if (dataSource == null) {
				throw new ArgumentNullException ("dataSource");
			}
			if (entryName == null) {
				throw new ArgumentNullException ("entryName");
			}
			CheckUpdating ();
			ZipEntry zipEntry = EntryFactory.MakeFileEntry (entryName, useFileSystem: false);
			zipEntry.CompressionMethod = compressionMethod;
			AddUpdate (new ZipUpdate (dataSource, zipEntry));
		}

		public void Add (IStaticDataSource dataSource, string entryName, CompressionMethod compressionMethod, bool useUnicodeText)
		{
			if (dataSource == null) {
				throw new ArgumentNullException ("dataSource");
			}
			if (entryName == null) {
				throw new ArgumentNullException ("entryName");
			}
			CheckUpdating ();
			ZipEntry zipEntry = EntryFactory.MakeFileEntry (entryName, useFileSystem: false);
			zipEntry.IsUnicodeText = useUnicodeText;
			zipEntry.CompressionMethod = compressionMethod;
			AddUpdate (new ZipUpdate (dataSource, zipEntry));
		}

		public void Add (ZipEntry entry)
		{
			if (entry == null) {
				throw new ArgumentNullException ("entry");
			}
			CheckUpdating ();
			if (entry.Size != 0 || entry.CompressedSize != 0) {
				throw new ZipException ("Entry cannot have any data");
			}
			AddUpdate (new ZipUpdate (UpdateCommand.Add, entry));
		}

		public void AddDirectory (string directoryName)
		{
			if (directoryName == null) {
				throw new ArgumentNullException ("directoryName");
			}
			CheckUpdating ();
			ZipEntry entry = EntryFactory.MakeDirectoryEntry (directoryName);
			AddUpdate (new ZipUpdate (UpdateCommand.Add, entry));
		}

		public bool Delete (string fileName)
		{
			if (fileName == null) {
				throw new ArgumentNullException ("fileName");
			}
			CheckUpdating ();
			bool flag = false;
			int num = FindExistingUpdate (fileName);
			if (num >= 0 && updates_ [num] != null) {
				flag = true;
				contentsEdited_ = true;
				updates_ [num] = null;
				updateCount_--;
				return flag;
			}
			throw new ZipException ("Cannot find entry to delete");
		}

		public void Delete (ZipEntry entry)
		{
			if (entry == null) {
				throw new ArgumentNullException ("entry");
			}
			CheckUpdating ();
			int num = FindExistingUpdate (entry);
			if (num >= 0) {
				contentsEdited_ = true;
				updates_ [num] = null;
				updateCount_--;
				return;
			}
			throw new ZipException ("Cannot find entry to delete");
		}

		private void WriteLEShort (int value)
		{
			baseStream_.WriteByte ((byte)((uint)value & 0xFFu));
			baseStream_.WriteByte ((byte)((uint)(value >> 8) & 0xFFu));
		}

		private void WriteLEUshort (ushort value)
		{
			baseStream_.WriteByte ((byte)(value & 0xFFu));
			baseStream_.WriteByte ((byte)(value >> 8));
		}

		private void WriteLEInt (int value)
		{
			WriteLEShort (value & 0xFFFF);
			WriteLEShort (value >> 16);
		}

		private void WriteLEUint (uint value)
		{
			WriteLEUshort ((ushort)(value & 0xFFFFu));
			WriteLEUshort ((ushort)(value >> 16));
		}

		private void WriteLeLong (long value)
		{
			WriteLEInt ((int)(value & 0xFFFFFFFFu));
			WriteLEInt ((int)(value >> 32));
		}

		private void WriteLEUlong (ulong value)
		{
			WriteLEUint ((uint)(value & 0xFFFFFFFFu));
			WriteLEUint ((uint)(value >> 32));
		}

		private void WriteLocalEntryHeader (ZipUpdate update)
		{
			ZipEntry outEntry = update.OutEntry;
			outEntry.Offset = baseStream_.Position;
			if (update.Command != 0) {
				if (outEntry.CompressionMethod == CompressionMethod.Deflated) {
					if (outEntry.Size == 0) {
						outEntry.CompressedSize = outEntry.Size;
						outEntry.Crc = 0L;
						outEntry.CompressionMethod = CompressionMethod.Stored;
					}
				} else if (outEntry.CompressionMethod == CompressionMethod.Stored) {
					outEntry.Flags &= -9;
				}
				if (HaveKeys) {
					outEntry.IsCrypted = true;
					if (outEntry.Crc < 0) {
						outEntry.Flags |= 8;
					}
				} else {
					outEntry.IsCrypted = false;
				}
				switch (useZip64_) {
				case UseZip64.Dynamic:
					if (outEntry.Size < 0) {
						outEntry.ForceZip64 ();
					}
					break;
				case UseZip64.On:
					outEntry.ForceZip64 ();
					break;
				}
			}
			WriteLEInt (67324752);
			WriteLEShort (outEntry.Version);
			WriteLEShort (outEntry.Flags);
			WriteLEShort ((byte)outEntry.CompressionMethod);
			WriteLEInt ((int)outEntry.DosTime);
			if (!outEntry.HasCrc) {
				update.CrcPatchOffset = baseStream_.Position;
				WriteLEInt (0);
			} else {
				WriteLEInt ((int)outEntry.Crc);
			}
			if (outEntry.LocalHeaderRequiresZip64) {
				WriteLEInt (-1);
				WriteLEInt (-1);
			} else {
				if (outEntry.CompressedSize < 0 || outEntry.Size < 0) {
					update.SizePatchOffset = baseStream_.Position;
				}
				WriteLEInt ((int)outEntry.CompressedSize);
				WriteLEInt ((int)outEntry.Size);
			}
			byte[] array = ZipConstants.ConvertToArray (outEntry.Flags, outEntry.Name);
			if (array.Length > 65535) {
				throw new ZipException ("Entry name too long.");
			}
			ZipExtraData zipExtraData = new ZipExtraData (outEntry.ExtraData);
			if (outEntry.LocalHeaderRequiresZip64) {
				zipExtraData.StartNewEntry ();
				zipExtraData.AddLeLong (outEntry.Size);
				zipExtraData.AddLeLong (outEntry.CompressedSize);
				zipExtraData.AddNewEntry (1);
			} else {
				zipExtraData.Delete (1);
			}
			outEntry.ExtraData = zipExtraData.GetEntryData ();
			WriteLEShort (array.Length);
			WriteLEShort (outEntry.ExtraData.Length);
			if (array.Length > 0) {
				baseStream_.Write (array, 0, array.Length);
			}
			if (outEntry.LocalHeaderRequiresZip64) {
				if (!zipExtraData.Find (1)) {
					throw new ZipException ("Internal error cannot find extra data");
				}
				update.SizePatchOffset = baseStream_.Position + zipExtraData.CurrentReadIndex;
			}
			if (outEntry.ExtraData.Length > 0) {
				baseStream_.Write (outEntry.ExtraData, 0, outEntry.ExtraData.Length);
			}
		}

		private int WriteCentralDirectoryHeader (ZipEntry entry)
		{
			if (entry.CompressedSize < 0) {
				throw new ZipException ("Attempt to write central directory entry with unknown csize");
			}
			if (entry.Size < 0) {
				throw new ZipException ("Attempt to write central directory entry with unknown size");
			}
			if (entry.Crc < 0) {
				throw new ZipException ("Attempt to write central directory entry with unknown crc");
			}
			WriteLEInt (33639248);
			WriteLEShort (51);
			WriteLEShort (entry.Version);
			WriteLEShort (entry.Flags);
			WriteLEShort ((byte)entry.CompressionMethod);
			WriteLEInt ((int)entry.DosTime);
			WriteLEInt ((int)entry.Crc);
			if (entry.IsZip64Forced () || entry.CompressedSize >= uint.MaxValue) {
				WriteLEInt (-1);
			} else {
				WriteLEInt ((int)(entry.CompressedSize & 0xFFFFFFFFu));
			}
			if (entry.IsZip64Forced () || entry.Size >= uint.MaxValue) {
				WriteLEInt (-1);
			} else {
				WriteLEInt ((int)entry.Size);
			}
			byte[] array = ZipConstants.ConvertToArray (entry.Flags, entry.Name);
			if (array.Length > 65535) {
				throw new ZipException ("Entry name is too long.");
			}
			WriteLEShort (array.Length);
			ZipExtraData zipExtraData = new ZipExtraData (entry.ExtraData);
			if (entry.CentralHeaderRequiresZip64) {
				zipExtraData.StartNewEntry ();
				if (entry.Size >= uint.MaxValue || useZip64_ == UseZip64.On) {
					zipExtraData.AddLeLong (entry.Size);
				}
				if (entry.CompressedSize >= uint.MaxValue || useZip64_ == UseZip64.On) {
					zipExtraData.AddLeLong (entry.CompressedSize);
				}
				if (entry.Offset >= uint.MaxValue) {
					zipExtraData.AddLeLong (entry.Offset);
				}
				zipExtraData.AddNewEntry (1);
			} else {
				zipExtraData.Delete (1);
			}
			byte[] entryData = zipExtraData.GetEntryData ();
			WriteLEShort (entryData.Length);
			WriteLEShort ((entry.Comment != null) ? entry.Comment.Length : 0);
			WriteLEShort (0);
			WriteLEShort (0);
			if (entry.ExternalFileAttributes != -1) {
				WriteLEInt (entry.ExternalFileAttributes);
			} else if (entry.IsDirectory) {
				WriteLEUint (16u);
			} else {
				WriteLEUint (0u);
			}
			if (entry.Offset >= uint.MaxValue) {
				WriteLEUint (uint.MaxValue);
			} else {
				WriteLEUint ((uint)entry.Offset);
			}
			if (array.Length > 0) {
				baseStream_.Write (array, 0, array.Length);
			}
			if (entryData.Length > 0) {
				baseStream_.Write (entryData, 0, entryData.Length);
			}
			byte[] array2 = ((entry.Comment == null) ? new byte[0] : Encoding.ASCII.GetBytes (entry.Comment));
			if (array2.Length > 0) {
				baseStream_.Write (array2, 0, array2.Length);
			}
			return 46 + array.Length + entryData.Length + array2.Length;
		}

		private void PostUpdateCleanup ()
		{
			updateDataSource_ = null;
			updates_ = null;
			updateIndex_ = null;
			if (archiveStorage_ != null) {
				archiveStorage_.Dispose ();
				archiveStorage_ = null;
			}
		}

		private string GetTransformedFileName (string name)
		{
			INameTransform nameTransform = NameTransform;
			return (nameTransform == null) ? name : nameTransform.TransformFile (name);
		}

		private string GetTransformedDirectoryName (string name)
		{
			INameTransform nameTransform = NameTransform;
			return (nameTransform == null) ? name : nameTransform.TransformDirectory (name);
		}

		private byte[] GetBuffer ()
		{
			if (copyBuffer_ == null) {
				copyBuffer_ = new byte[bufferSize_];
			}
			return copyBuffer_;
		}

		private void CopyDescriptorBytes (ZipUpdate update, Stream dest, Stream source)
		{
			int num = GetDescriptorSize (update);
			if (num <= 0) {
				return;
			}
			byte[] buffer = GetBuffer ();
			while (num > 0) {
				int count = Math.Min (buffer.Length, num);
				int num2 = source.Read (buffer, 0, count);
				if (num2 > 0) {
					dest.Write (buffer, 0, num2);
					num -= num2;
					continue;
				}
				throw new ZipException ("Unxpected end of stream");
			}
		}

		private void CopyBytes (ZipUpdate update, Stream destination, Stream source, long bytesToCopy, bool updateCrc)
		{
			if (destination == source) {
				throw new InvalidOperationException ("Destination and source are the same");
			}
			Crc32 crc = new Crc32 ();
			byte[] buffer = GetBuffer ();
			long num = bytesToCopy;
			long num2 = 0L;
			int num4;
			do {
				int num3 = buffer.Length;
				if (bytesToCopy < num3) {
					num3 = (int)bytesToCopy;
				}
				num4 = source.Read (buffer, 0, num3);
				if (num4 > 0) {
					if (updateCrc) {
						crc.Update (buffer, 0, num4);
					}
					destination.Write (buffer, 0, num4);
					bytesToCopy -= num4;
					num2 += num4;
				}
			} while (num4 > 0 && bytesToCopy > 0);
			if (num2 != num) {
				throw new ZipException ($"Failed to copy bytes expected {num} read {num2}");
			}
			if (updateCrc) {
				update.OutEntry.Crc = crc.Value;
			}
		}

		private int GetDescriptorSize (ZipUpdate update)
		{
			int result = 0;
			if (((uint)update.Entry.Flags & 8u) != 0) {
				result = 12;
				if (update.Entry.LocalHeaderRequiresZip64) {
					result = 20;
				}
			}
			return result;
		}

		private void CopyDescriptorBytesDirect (ZipUpdate update, Stream stream, ref long destinationPosition, long sourcePosition)
		{
			int num = GetDescriptorSize (update);
			while (num > 0) {
				int count = num;
				byte[] buffer = GetBuffer ();
				stream.Position = sourcePosition;
				int num2 = stream.Read (buffer, 0, count);
				if (num2 > 0) {
					stream.Position = destinationPosition;
					stream.Write (buffer, 0, num2);
					num -= num2;
					destinationPosition += num2;
					sourcePosition += num2;
					continue;
				}
				throw new ZipException ("Unxpected end of stream");
			}
		}

		private void CopyEntryDataDirect (ZipUpdate update, Stream stream, bool updateCrc, ref long destinationPosition, ref long sourcePosition)
		{
			long num = update.Entry.CompressedSize;
			Crc32 crc = new Crc32 ();
			byte[] buffer = GetBuffer ();
			long num2 = num;
			long num3 = 0L;
			int num5;
			do {
				int num4 = buffer.Length;
				if (num < num4) {
					num4 = (int)num;
				}
				stream.Position = sourcePosition;
				num5 = stream.Read (buffer, 0, num4);
				if (num5 > 0) {
					if (updateCrc) {
						crc.Update (buffer, 0, num5);
					}
					stream.Position = destinationPosition;
					stream.Write (buffer, 0, num5);
					destinationPosition += num5;
					sourcePosition += num5;
					num -= num5;
					num3 += num5;
				}
			} while (num5 > 0 && num > 0);
			if (num3 != num2) {
				throw new ZipException ($"Failed to copy bytes expected {num2} read {num3}");
			}
			if (updateCrc) {
				update.OutEntry.Crc = crc.Value;
			}
		}

		private int FindExistingUpdate (ZipEntry entry)
		{
			int result = -1;
			string transformedFileName = GetTransformedFileName (entry.Name);
			if (updateIndex_.ContainsKey (transformedFileName)) {
				result = (int)updateIndex_ [transformedFileName];
			}
			return result;
		}

		private int FindExistingUpdate (string fileName)
		{
			int result = -1;
			string transformedFileName = GetTransformedFileName (fileName);
			if (updateIndex_.ContainsKey (transformedFileName)) {
				result = (int)updateIndex_ [transformedFileName];
			}
			return result;
		}

		private Stream GetOutputStream (ZipEntry entry)
		{
			Stream stream = baseStream_;
			if (entry.IsCrypted) {
				stream = CreateAndInitEncryptionStream (stream, entry);
			}
			switch (entry.CompressionMethod) {
			case CompressionMethod.Stored:
				return new UncompressedStream (stream);
			case CompressionMethod.Deflated: {
				DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream (stream, new Deflater (9, noZlibHeaderOrFooter: true));
				deflaterOutputStream.IsStreamOwner = false;
				return deflaterOutputStream;
			}
			default:
				throw new ZipException ("Unknown compression method " + entry.CompressionMethod);
			}
		}

		private void AddEntry (ZipFile workFile, ZipUpdate update)
		{
			Stream stream = null;
			if (update.Entry.IsFile) {
				stream = update.GetSource ();
				if (stream == null) {
					stream = updateDataSource_.GetSource (update.Entry, update.Filename);
				}
			}
			if (stream != null) {
				using (stream) {
					long length = stream.Length;
					if (update.OutEntry.Size < 0) {
						update.OutEntry.Size = length;
					} else if (update.OutEntry.Size != length) {
						throw new ZipException ("Entry size/stream size mismatch");
					}
					workFile.WriteLocalEntryHeader (update);
					long position = workFile.baseStream_.Position;
					using (Stream destination = workFile.GetOutputStream (update.OutEntry)) {
						CopyBytes (update, destination, stream, length, updateCrc: true);
					}
					long position2 = workFile.baseStream_.Position;
					update.OutEntry.CompressedSize = position2 - position;
					if ((update.OutEntry.Flags & 8) == 8) {
						ZipHelperStream zipHelperStream = new ZipHelperStream (workFile.baseStream_);
						zipHelperStream.WriteDataDescriptor (update.OutEntry);
					}
					return;
				}
			}
			workFile.WriteLocalEntryHeader (update);
			update.OutEntry.CompressedSize = 0L;
		}

		private void ModifyEntry (ZipFile workFile, ZipUpdate update)
		{
			workFile.WriteLocalEntryHeader (update);
			long position = workFile.baseStream_.Position;
			if (update.Entry.IsFile && update.Filename != null) {
				using Stream destination = workFile.GetOutputStream (update.OutEntry);
				using Stream stream = GetInputStream (update.Entry);
				CopyBytes (update, destination, stream, stream.Length, updateCrc: true);
			}
			long position2 = workFile.baseStream_.Position;
			update.Entry.CompressedSize = position2 - position;
		}

		private void CopyEntryDirect (ZipFile workFile, ZipUpdate update, ref long destinationPosition)
		{
			bool flag = false;
			if (update.Entry.Offset == destinationPosition) {
				flag = true;
			}
			if (!flag) {
				baseStream_.Position = destinationPosition;
				workFile.WriteLocalEntryHeader (update);
				destinationPosition = baseStream_.Position;
			}
			long num = 0L;
			long num2 = update.Entry.Offset + 26;
			baseStream_.Seek (num2, SeekOrigin.Begin);
			uint num3 = ReadLEUshort ();
			uint num4 = ReadLEUshort ();
			num = baseStream_.Position + num3 + num4;
			if (flag) {
				if (update.OffsetBasedSize != -1) {
					destinationPosition += update.OffsetBasedSize;
				} else {
					destinationPosition += num - num2 + 26 + update.Entry.CompressedSize + GetDescriptorSize (update);
				}
				return;
			}
			if (update.Entry.CompressedSize > 0) {
				CopyEntryDataDirect (update, baseStream_, updateCrc: false, ref destinationPosition, ref num);
			}
			CopyDescriptorBytesDirect (update, baseStream_, ref destinationPosition, num);
		}

		private void CopyEntry (ZipFile workFile, ZipUpdate update)
		{
			workFile.WriteLocalEntryHeader (update);
			if (update.Entry.CompressedSize > 0) {
				long offset = update.Entry.Offset + 26;
				baseStream_.Seek (offset, SeekOrigin.Begin);
				uint num = ReadLEUshort ();
				uint num2 = ReadLEUshort ();
				baseStream_.Seek (num + num2, SeekOrigin.Current);
				CopyBytes (update, workFile.baseStream_, baseStream_, update.Entry.CompressedSize, updateCrc: false);
			}
			CopyDescriptorBytes (update, workFile.baseStream_, baseStream_);
		}

		private void Reopen (Stream source)
		{
			if (source == null) {
				throw new ZipException ("Failed to reopen archive - no source");
			}
			isNewArchive_ = false;
			baseStream_ = source;
			ReadEntries ();
		}

		private void Reopen ()
		{
			if (Name == null) {
				throw new InvalidOperationException ("Name is not known cannot Reopen");
			}
			Reopen (File.Open (Name, FileMode.Open, FileAccess.Read, FileShare.Read));
		}

		private void UpdateCommentOnly ()
		{
			long length = baseStream_.Length;
			ZipHelperStream zipHelperStream = null;
			if (archiveStorage_.UpdateMode == FileUpdateMode.Safe) {
				Stream stream = archiveStorage_.MakeTemporaryCopy (baseStream_);
				zipHelperStream = new ZipHelperStream (stream);
				zipHelperStream.IsStreamOwner = true;
				baseStream_.Close ();
				baseStream_ = null;
			} else if (archiveStorage_.UpdateMode == FileUpdateMode.Direct) {
				baseStream_ = archiveStorage_.OpenForDirectUpdate (baseStream_);
				zipHelperStream = new ZipHelperStream (baseStream_);
			} else {
				baseStream_.Close ();
				baseStream_ = null;
				zipHelperStream = new ZipHelperStream (Name);
			}
			using (zipHelperStream) {
				long num = zipHelperStream.LocateBlockWithSignature (101010256, length, 22, 65535);
				if (num < 0) {
					throw new ZipException ("Cannot find central directory");
				}
				zipHelperStream.Position += 16L;
				byte[] rawComment = newComment_.RawComment;
				zipHelperStream.WriteLEShort (rawComment.Length);
				zipHelperStream.Write (rawComment, 0, rawComment.Length);
				zipHelperStream.SetLength (zipHelperStream.Position);
			}
			if (archiveStorage_.UpdateMode == FileUpdateMode.Safe) {
				Reopen (archiveStorage_.ConvertTemporaryToFinal ());
			} else {
				ReadEntries ();
			}
		}

		private void RunUpdates ()
		{
			long num = 0L;
			long num2 = 0L;
			bool flag = false;
			long destinationPosition = 0L;
			ZipFile zipFile;
			if (IsNewArchive) {
				zipFile = this;
				zipFile.baseStream_.Position = 0L;
				flag = true;
			} else if (archiveStorage_.UpdateMode == FileUpdateMode.Direct) {
				zipFile = this;
				zipFile.baseStream_.Position = 0L;
				flag = true;
				updates_.Sort (new UpdateComparer ());
			} else {
				zipFile = Create (archiveStorage_.GetTemporaryOutput ());
				zipFile.UseZip64 = UseZip64;
				if (key != null) {
					zipFile.key = (byte[])key.Clone ();
				}
			}
			try {
				foreach (ZipUpdate item in updates_) {
					if (item == null) {
						continue;
					}
					switch (item.Command) {
					case UpdateCommand.Copy:
						if (flag) {
							CopyEntryDirect (zipFile, item, ref destinationPosition);
						} else {
							CopyEntry (zipFile, item);
						}
						break;
					case UpdateCommand.Modify:
						ModifyEntry (zipFile, item);
						break;
					case UpdateCommand.Add:
						if (!IsNewArchive && flag) {
							zipFile.baseStream_.Position = destinationPosition;
						}
						AddEntry (zipFile, item);
						if (flag) {
							destinationPosition = zipFile.baseStream_.Position;
						}
						break;
					}
				}
				if (!IsNewArchive && flag) {
					zipFile.baseStream_.Position = destinationPosition;
				}
				long position = zipFile.baseStream_.Position;
				foreach (ZipUpdate item2 in updates_) {
					if (item2 != null) {
						num += zipFile.WriteCentralDirectoryHeader (item2.OutEntry);
					}
				}
				byte[] comment = ((newComment_ == null) ? ZipConstants.ConvertToArray (comment_) : newComment_.RawComment);
				using (ZipHelperStream zipHelperStream = new ZipHelperStream (zipFile.baseStream_)) {
					zipHelperStream.WriteEndOfCentralDirectory (updateCount_, num, position, comment);
				}
				num2 = zipFile.baseStream_.Position;
				foreach (ZipUpdate item3 in updates_) {
					if (item3 == null) {
						continue;
					}
					if (item3.CrcPatchOffset > 0 && item3.OutEntry.CompressedSize > 0) {
						zipFile.baseStream_.Position = item3.CrcPatchOffset;
						zipFile.WriteLEInt ((int)item3.OutEntry.Crc);
					}
					if (item3.SizePatchOffset > 0) {
						zipFile.baseStream_.Position = item3.SizePatchOffset;
						if (item3.OutEntry.LocalHeaderRequiresZip64) {
							zipFile.WriteLeLong (item3.OutEntry.Size);
							zipFile.WriteLeLong (item3.OutEntry.CompressedSize);
						} else {
							zipFile.WriteLEInt ((int)item3.OutEntry.CompressedSize);
							zipFile.WriteLEInt ((int)item3.OutEntry.Size);
						}
					}
				}
			} catch {
				zipFile.Close ();
				if (!flag && zipFile.Name != null) {
					File.Delete (zipFile.Name);
				}
				throw;
			}
			if (flag) {
				zipFile.baseStream_.SetLength (num2);
				zipFile.baseStream_.Flush ();
				isNewArchive_ = false;
				ReadEntries ();
			} else {
				baseStream_.Close ();
				Reopen (archiveStorage_.ConvertTemporaryToFinal ());
			}
		}

		private void CheckUpdating ()
		{
			if (updates_ == null) {
				throw new InvalidOperationException ("BeginUpdate has not been called");
			}
		}

		void IDisposable.Dispose ()
		{
			Close ();
		}

		private void DisposeInternal (bool disposing)
		{
			if (isDisposed_) {
				return;
			}
			isDisposed_ = true;
			entries_ = new ZipEntry[0];
			if (IsStreamOwner && baseStream_ != null) {
				lock (baseStream_) {
					baseStream_.Close ();
				}
			}
			PostUpdateCleanup ();
		}

		protected virtual void Dispose (bool disposing)
		{
			DisposeInternal (disposing);
		}

		private ushort ReadLEUshort ()
		{
			int num = baseStream_.ReadByte ();
			if (num < 0) {
				throw new EndOfStreamException ("End of stream");
			}
			int num2 = baseStream_.ReadByte ();
			if (num2 < 0) {
				throw new EndOfStreamException ("End of stream");
			}
			return (ushort)((ushort)num | (ushort)(num2 << 8));
		}

		private uint ReadLEUint ()
		{
			return (uint)(ReadLEUshort () | (ReadLEUshort () << 16));
		}

		private ulong ReadLEUlong ()
		{
			return ReadLEUint () | ((ulong)ReadLEUint () << 32);
		}

		private long LocateBlockWithSignature (int signature, long endLocation, int minimumBlockSize, int maximumVariableData)
		{
			using ZipHelperStream zipHelperStream = new ZipHelperStream (baseStream_);
			return zipHelperStream.LocateBlockWithSignature (signature, endLocation, minimumBlockSize, maximumVariableData);
		}

		private void ReadEntries ()
		{
			if (!baseStream_.CanSeek) {
				throw new ZipException ("ZipFile stream must be seekable");
			}
			long num = LocateBlockWithSignature (101010256, baseStream_.Length, 22, 65535);
			if (num < 0) {
				throw new ZipException ("Cannot find central directory");
			}
			ushort num2 = ReadLEUshort ();
			ushort num3 = ReadLEUshort ();
			ulong num4 = ReadLEUshort ();
			ulong num5 = ReadLEUshort ();
			ulong num6 = ReadLEUint ();
			long num7 = ReadLEUint ();
			uint num8 = ReadLEUshort ();
			if (num8 != 0) {
				byte[] array = new byte[num8];
				StreamUtils.ReadFully (baseStream_, array);
				comment_ = ZipConstants.ConvertToString (array);
			} else {
				comment_ = string.Empty;
			}
			bool flag = false;
			if (num2 == ushort.MaxValue || num3 == ushort.MaxValue || num4 == 65535 || num5 == 65535 || num6 == uint.MaxValue || num7 == uint.MaxValue) {
				flag = true;
				long num9 = LocateBlockWithSignature (117853008, num, 0, 4096);
				if (num9 < 0) {
					throw new ZipException ("Cannot find Zip64 locator");
				}
				ReadLEUint ();
				ulong num10 = ReadLEUlong ();
				uint num11 = ReadLEUint ();
				baseStream_.Position = (long)num10;
				long num12 = ReadLEUint ();
				if (num12 != 101075792) {
					throw new ZipException ($"Invalid Zip64 Central directory signature at {num10:X}");
				}
				ulong num13 = ReadLEUlong ();
				int num14 = ReadLEUshort ();
				int num15 = ReadLEUshort ();
				uint num16 = ReadLEUint ();
				uint num17 = ReadLEUint ();
				num4 = ReadLEUlong ();
				num5 = ReadLEUlong ();
				num6 = ReadLEUlong ();
				num7 = (long)ReadLEUlong ();
			}
			entries_ = new ZipEntry[num4];
			if (!flag && num7 < num - (long)(4 + num6)) {
				offsetOfFirstEntry = num - ((long)(4 + num6) + num7);
				if (offsetOfFirstEntry <= 0) {
					throw new ZipException ("Invalid embedded zip archive");
				}
			}
			baseStream_.Seek (offsetOfFirstEntry + num7, SeekOrigin.Begin);
			for (ulong num18 = 0uL; num18 < num4; num18++) {
				if (ReadLEUint () != 33639248) {
					throw new ZipException ("Wrong Central Directory signature");
				}
				int madeByInfo = ReadLEUshort ();
				int versionRequiredToExtract = ReadLEUshort ();
				int num19 = ReadLEUshort ();
				int method = ReadLEUshort ();
				uint num20 = ReadLEUint ();
				uint num21 = ReadLEUint ();
				long num22 = ReadLEUint ();
				long num23 = ReadLEUint ();
				int num24 = ReadLEUshort ();
				int num25 = ReadLEUshort ();
				int num26 = ReadLEUshort ();
				int num27 = ReadLEUshort ();
				int num28 = ReadLEUshort ();
				uint externalFileAttributes = ReadLEUint ();
				long offset = ReadLEUint ();
				byte[] array2 = new byte[Math.Max (num24, num26)];
				StreamUtils.ReadFully (baseStream_, array2, 0, num24);
				string name = ZipConstants.ConvertToStringExt (num19, array2, num24);
				ZipEntry zipEntry = new ZipEntry (name, versionRequiredToExtract, madeByInfo, (CompressionMethod)method);
				zipEntry.Crc = (long)num21 & 0xFFFFFFFFL;
				zipEntry.Size = num23 & 0xFFFFFFFFu;
				zipEntry.CompressedSize = num22 & 0xFFFFFFFFu;
				zipEntry.Flags = num19;
				zipEntry.DosTime = num20;
				zipEntry.ZipFileIndex = (long)num18;
				zipEntry.Offset = offset;
				zipEntry.ExternalFileAttributes = (int)externalFileAttributes;
				if ((num19 & 8) == 0) {
					zipEntry.CryptoCheckValue = (byte)(num21 >> 24);
				} else {
					zipEntry.CryptoCheckValue = (byte)((num20 >> 8) & 0xFFu);
				}
				if (num25 > 0) {
					byte[] array3 = new byte[num25];
					StreamUtils.ReadFully (baseStream_, array3);
					zipEntry.ExtraData = array3;
				}
				zipEntry.ProcessExtraData (localHeader: false);
				if (num26 > 0) {
					StreamUtils.ReadFully (baseStream_, array2, 0, num26);
					zipEntry.Comment = ZipConstants.ConvertToStringExt (num19, array2, num26);
				}
				entries_ [num18] = zipEntry;
			}
		}

		private long LocateEntry (ZipEntry entry)
		{
			return TestLocalHeader (entry, HeaderTest.Extract);
		}

		private Stream CreateAndInitDecryptionStream (Stream baseStream, ZipEntry entry)
		{
			CryptoStream cryptoStream = null;
			if (entry.Version < 50 || (entry.Flags & 0x40) == 0) {
				PkzipClassicManaged pkzipClassicManaged = new PkzipClassicManaged ();
				OnKeysRequired (entry.Name);
				if (!HaveKeys) {
					throw new ZipException ("No password available for encrypted stream");
				}
				cryptoStream = new CryptoStream (baseStream, pkzipClassicManaged.CreateDecryptor (key, null), CryptoStreamMode.Read);
				CheckClassicPassword (cryptoStream, entry);
			} else {
				if (entry.Version != 51) {
					throw new ZipException ("Decryption method not supported");
				}
				OnKeysRequired (entry.Name);
				if (!HaveKeys) {
					throw new ZipException ("No password available for AES encrypted stream");
				}
				int aESSaltLen = entry.AESSaltLen;
				byte[] array = new byte[aESSaltLen];
				int num = baseStream.Read (array, 0, aESSaltLen);
				if (num != aESSaltLen) {
					throw new ZipException ("AES Salt expected " + aESSaltLen + " got " + num);
				}
				byte[] array2 = new byte[2];
				baseStream.Read (array2, 0, 2);
				int blockSize = entry.AESKeySize / 8;
				ZipAESTransform zipAESTransform = new ZipAESTransform (rawPassword_, array, blockSize, writeMode: false);
				byte[] pwdVerifier = zipAESTransform.PwdVerifier;
				if (pwdVerifier [0] != array2 [0] || pwdVerifier [1] != array2 [1]) {
					throw new Exception ("Invalid password for AES");
				}
				cryptoStream = new ZipAESStream (baseStream, zipAESTransform, CryptoStreamMode.Read);
			}
			return cryptoStream;
		}

		private Stream CreateAndInitEncryptionStream (Stream baseStream, ZipEntry entry)
		{
			CryptoStream cryptoStream = null;
			if (entry.Version < 50 || (entry.Flags & 0x40) == 0) {
				PkzipClassicManaged pkzipClassicManaged = new PkzipClassicManaged ();
				OnKeysRequired (entry.Name);
				if (!HaveKeys) {
					throw new ZipException ("No password available for encrypted stream");
				}
				cryptoStream = new CryptoStream (new UncompressedStream (baseStream), pkzipClassicManaged.CreateEncryptor (key, null), CryptoStreamMode.Write);
				if (entry.Crc < 0 || ((uint)entry.Flags & 8u) != 0) {
					WriteEncryptionHeader (cryptoStream, entry.DosTime << 16);
				} else {
					WriteEncryptionHeader (cryptoStream, entry.Crc);
				}
			}
			return cryptoStream;
		}

		private static void CheckClassicPassword (CryptoStream classicCryptoStream, ZipEntry entry)
		{
			byte[] array = new byte[12];
			StreamUtils.ReadFully (classicCryptoStream, array);
			if (array [11] != entry.CryptoCheckValue) {
				throw new ZipException ("Invalid password");
			}
		}

		private static void WriteEncryptionHeader (Stream stream, long crcValue)
		{
			byte[] array = new byte[12];
			System.Random random = new System.Random ();
			random.NextBytes (array);
			array [11] = (byte)(crcValue >> 24);
			stream.Write (array, 0, array.Length);
		}
	}
	public interface IStaticDataSource
	{
		Stream GetSource ();
	}
	public interface IDynamicDataSource
	{
		Stream GetSource (ZipEntry entry, string name);
	}
	public class StaticDiskDataSource : IStaticDataSource
	{
		private string fileName_;

		public StaticDiskDataSource (string fileName)
		{
			fileName_ = fileName;
		}

		public Stream GetSource ()
		{
			return File.Open (fileName_, FileMode.Open, FileAccess.Read, FileShare.Read);
		}
	}
	public class DynamicDiskDataSource : IDynamicDataSource
	{
		public Stream GetSource (ZipEntry entry, string name)
		{
			Stream result = null;
			if (name != null) {
				result = File.Open (name, FileMode.Open, FileAccess.Read, FileShare.Read);
			}
			return result;
		}
	}
	public interface IArchiveStorage
	{
		FileUpdateMode UpdateMode { get; }

		Stream GetTemporaryOutput ();

		Stream ConvertTemporaryToFinal ();

		Stream MakeTemporaryCopy (Stream stream);

		Stream OpenForDirectUpdate (Stream stream);

		void Dispose ();
	}
	public abstract class BaseArchiveStorage : IArchiveStorage
	{
		private FileUpdateMode updateMode_;

		public FileUpdateMode UpdateMode => updateMode_;

		protected BaseArchiveStorage (FileUpdateMode updateMode)
		{
			updateMode_ = updateMode;
		}

		public abstract Stream GetTemporaryOutput ();

		public abstract Stream ConvertTemporaryToFinal ();

		public abstract Stream MakeTemporaryCopy (Stream stream);

		public abstract Stream OpenForDirectUpdate (Stream stream);

		public abstract void Dispose ();
	}
	public class DiskArchiveStorage : BaseArchiveStorage
	{
		private Stream temporaryStream_;

		private string fileName_;

		private string temporaryName_;

		public DiskArchiveStorage (ZipFile file, FileUpdateMode updateMode)
			: base (updateMode)
		{
			if (file.Name == null) {
				throw new ZipException ("Cant handle non file archives");
			}
			fileName_ = file.Name;
		}

		public DiskArchiveStorage (ZipFile file)
			: this (file, FileUpdateMode.Safe)
		{
		}

		public override Stream GetTemporaryOutput ()
		{
			if (temporaryName_ != null) {
				temporaryName_ = GetTempFileName (temporaryName_, makeTempFile: true);
				temporaryStream_ = File.Open (temporaryName_, FileMode.OpenOrCreate, FileAccess.Write, FileShare.None);
			} else {
				temporaryName_ = Path.GetTempFileName ();
				temporaryStream_ = File.Open (temporaryName_, FileMode.OpenOrCreate, FileAccess.Write, FileShare.None);
			}
			return temporaryStream_;
		}

		public override Stream ConvertTemporaryToFinal ()
		{
			if (temporaryStream_ == null) {
				throw new ZipException ("No temporary stream has been created");
			}
			Stream stream = null;
			string tempFileName = GetTempFileName (fileName_, makeTempFile: false);
			bool flag = false;
			try {
				temporaryStream_.Close ();
				File.Move (fileName_, tempFileName);
				File.Move (temporaryName_, fileName_);
				flag = true;
				File.Delete (tempFileName);
				return File.Open (fileName_, FileMode.Open, FileAccess.Read, FileShare.Read);
			} catch (Exception) {
				stream = null;
				if (!flag) {
					File.Move (tempFileName, fileName_);
					File.Delete (temporaryName_);
				}
				throw;
			}
		}

		public override Stream MakeTemporaryCopy (Stream stream)
		{
			stream.Close ();
			temporaryName_ = GetTempFileName (fileName_, makeTempFile: true);
			File.Copy (fileName_, temporaryName_, overwrite: true);
			temporaryStream_ = new FileStream (temporaryName_, FileMode.Open, FileAccess.ReadWrite);
			return temporaryStream_;
		}

		public override Stream OpenForDirectUpdate (Stream stream)
		{
			if (stream == null || !stream.CanWrite) {
				stream?.Close ();
				return new FileStream (fileName_, FileMode.Open, FileAccess.ReadWrite);
			}
			return stream;
		}

		public override void Dispose ()
		{
			if (temporaryStream_ != null) {
				temporaryStream_.Close ();
			}
		}

		private static string GetTempFileName (string original, bool makeTempFile)
		{
			string text = null;
			if (original == null) {
				text = Path.GetTempFileName ();
			} else {
				int num = 0;
				int second = DateTime.Now.Second;
				while (text == null) {
					num++;
					string text2 = $"{original}.{second}{num}.tmp";
					if (File.Exists (text2)) {
						continue;
					}
					if (makeTempFile) {
						try {
							using (File.Create (text2)) {
							}
							text = text2;
						} catch {
							second = DateTime.Now.Second;
						}
					} else {
						text = text2;
					}
				}
			}
			return text;
		}
	}
	public class MemoryArchiveStorage : BaseArchiveStorage
	{
		private MemoryStream temporaryStream_;

		private MemoryStream finalStream_;

		public MemoryStream FinalStream => finalStream_;

		public MemoryArchiveStorage ()
			: base (FileUpdateMode.Direct)
		{
		}

		public MemoryArchiveStorage (FileUpdateMode updateMode)
			: base (updateMode)
		{
		}

		public override Stream GetTemporaryOutput ()
		{
			temporaryStream_ = new MemoryStream ();
			return temporaryStream_;
		}

		public override Stream ConvertTemporaryToFinal ()
		{
			if (temporaryStream_ == null) {
				throw new ZipException ("No temporary stream has been created");
			}
			finalStream_ = new MemoryStream (temporaryStream_.ToArray ());
			return finalStream_;
		}

		public override Stream MakeTemporaryCopy (Stream stream)
		{
			temporaryStream_ = new MemoryStream ();
			stream.Position = 0L;
			StreamUtils.Copy (stream, temporaryStream_, new byte[4096]);
			return temporaryStream_;
		}

		public override Stream OpenForDirectUpdate (Stream stream)
		{
			Stream stream2;
			if (stream == null || !stream.CanWrite) {
				stream2 = new MemoryStream ();
				if (stream != null) {
					stream.Position = 0L;
					StreamUtils.Copy (stream, stream2, new byte[4096]);
					stream.Close ();
				}
			} else {
				stream2 = stream;
			}
			return stream2;
		}

		public override void Dispose ()
		{
			if (temporaryStream_ != null) {
				temporaryStream_.Close ();
			}
		}
	}
	public class DescriptorData
	{
		private long size;

		private long compressedSize;

		private long crc;

		public long CompressedSize {
			get {
				return compressedSize;
			}
			set {
				compressedSize = value;
			}
		}

		public long Size {
			get {
				return size;
			}
			set {
				size = value;
			}
		}

		public long Crc {
			get {
				return crc;
			}
			set {
				crc = value & 0xFFFFFFFFu;
			}
		}
	}
	internal class EntryPatchData
	{
		private long sizePatchOffset_;

		private long crcPatchOffset_;

		public long SizePatchOffset {
			get {
				return sizePatchOffset_;
			}
			set {
				sizePatchOffset_ = value;
			}
		}

		public long CrcPatchOffset {
			get {
				return crcPatchOffset_;
			}
			set {
				crcPatchOffset_ = value;
			}
		}
	}
	internal class ZipHelperStream : Stream
	{
		private bool isOwner_;

		private Stream stream_;

		public bool IsStreamOwner {
			get {
				return isOwner_;
			}
			set {
				isOwner_ = value;
			}
		}

		public override bool CanRead => stream_.CanRead;

		public override bool CanSeek => stream_.CanSeek;

		public override bool CanTimeout => stream_.CanTimeout;

		public override long Length => stream_.Length;

		public override long Position {
			get {
				return stream_.Position;
			}
			set {
				stream_.Position = value;
			}
		}

		public override bool CanWrite => stream_.CanWrite;

		public ZipHelperStream (string name)
		{
			stream_ = new FileStream (name, FileMode.Open, FileAccess.ReadWrite);
			isOwner_ = true;
		}

		public ZipHelperStream (Stream stream)
		{
			stream_ = stream;
		}

		public override void Flush ()
		{
			stream_.Flush ();
		}

		public override long Seek (long offset, SeekOrigin origin)
		{
			return stream_.Seek (offset, origin);
		}

		public override void SetLength (long value)
		{
			stream_.SetLength (value);
		}

		public override int Read (byte[] buffer, int offset, int count)
		{
			return stream_.Read (buffer, offset, count);
		}

		public override void Write (byte[] buffer, int offset, int count)
		{
			stream_.Write (buffer, offset, count);
		}

		public override void Close ()
		{
			Stream stream = stream_;
			stream_ = null;
			if (isOwner_ && stream != null) {
				isOwner_ = false;
				stream.Close ();
			}
		}

		private void WriteLocalHeader (ZipEntry entry, EntryPatchData patchData)
		{
			CompressionMethod compressionMethod = entry.CompressionMethod;
			bool flag = true;
			bool flag2 = false;
			WriteLEInt (67324752);
			WriteLEShort (entry.Version);
			WriteLEShort (entry.Flags);
			WriteLEShort ((byte)compressionMethod);
			WriteLEInt ((int)entry.DosTime);
			if (flag) {
				WriteLEInt ((int)entry.Crc);
				if (entry.LocalHeaderRequiresZip64) {
					WriteLEInt (-1);
					WriteLEInt (-1);
				} else {
					WriteLEInt ((int)((!entry.IsCrypted) ? entry.CompressedSize : ((int)entry.CompressedSize + 12)));
					WriteLEInt ((int)entry.Size);
				}
			} else {
				if (patchData != null) {
					patchData.CrcPatchOffset = stream_.Position;
				}
				WriteLEInt (0);
				if (patchData != null) {
					patchData.SizePatchOffset = stream_.Position;
				}
				if (entry.LocalHeaderRequiresZip64 && flag2) {
					WriteLEInt (-1);
					WriteLEInt (-1);
				} else {
					WriteLEInt (0);
					WriteLEInt (0);
				}
			}
			byte[] array = ZipConstants.ConvertToArray (entry.Flags, entry.Name);
			if (array.Length > 65535) {
				throw new ZipException ("Entry name too long.");
			}
			ZipExtraData zipExtraData = new ZipExtraData (entry.ExtraData);
			if (entry.LocalHeaderRequiresZip64 && (flag || flag2)) {
				zipExtraData.StartNewEntry ();
				if (flag) {
					zipExtraData.AddLeLong (entry.Size);
					zipExtraData.AddLeLong (entry.CompressedSize);
				} else {
					zipExtraData.AddLeLong (-1L);
					zipExtraData.AddLeLong (-1L);
				}
				zipExtraData.AddNewEntry (1);
				if (!zipExtraData.Find (1)) {
					throw new ZipException ("Internal error cant find extra data");
				}
				if (patchData != null) {
					patchData.SizePatchOffset = zipExtraData.CurrentReadIndex;
				}
			} else {
				zipExtraData.Delete (1);
			}
			byte[] entryData = zipExtraData.GetEntryData ();
			WriteLEShort (array.Length);
			WriteLEShort (entryData.Length);
			if (array.Length > 0) {
				stream_.Write (array, 0, array.Length);
			}
			if (entry.LocalHeaderRequiresZip64 && flag2) {
				patchData.SizePatchOffset += stream_.Position;
			}
			if (entryData.Length > 0) {
				stream_.Write (entryData, 0, entryData.Length);
			}
		}

		public long LocateBlockWithSignature (int signature, long endLocation, int minimumBlockSize, int maximumVariableData)
		{
			long num = endLocation - minimumBlockSize;
			if (num < 0) {
				return -1L;
			}
			long num2 = Math.Max (num - maximumVariableData, 0L);
			do {
				if (num < num2) {
					return -1L;
				}
				Seek (num--, SeekOrigin.Begin);
			} while (ReadLEInt () != signature);
			return Position;
		}

		public void WriteZip64EndOfCentralDirectory (long noOfEntries, long sizeEntries, long centralDirOffset)
		{
			long position = stream_.Position;
			WriteLEInt (101075792);
			WriteLELong (44L);
			WriteLEShort (51);
			WriteLEShort (45);
			WriteLEInt (0);
			WriteLEInt (0);
			WriteLELong (noOfEntries);
			WriteLELong (noOfEntries);
			WriteLELong (sizeEntries);
			WriteLELong (centralDirOffset);
			WriteLEInt (117853008);
			WriteLEInt (0);
			WriteLELong (position);
			WriteLEInt (1);
		}

		public void WriteEndOfCentralDirectory (long noOfEntries, long sizeEntries, long startOfCentralDirectory, byte[] comment)
		{
			if (noOfEntries >= 65535 || startOfCentralDirectory >= uint.MaxValue || sizeEntries >= uint.MaxValue) {
				WriteZip64EndOfCentralDirectory (noOfEntries, sizeEntries, startOfCentralDirectory);
			}
			WriteLEInt (101010256);
			WriteLEShort (0);
			WriteLEShort (0);
			if (noOfEntries >= 65535) {
				WriteLEUshort (ushort.MaxValue);
				WriteLEUshort (ushort.MaxValue);
			} else {
				WriteLEShort ((short)noOfEntries);
				WriteLEShort ((short)noOfEntries);
			}
			if (sizeEntries >= uint.MaxValue) {
				WriteLEUint (uint.MaxValue);
			} else {
				WriteLEInt ((int)sizeEntries);
			}
			if (startOfCentralDirectory >= uint.MaxValue) {
				WriteLEUint (uint.MaxValue);
			} else {
				WriteLEInt ((int)startOfCentralDirectory);
			}
			int num = ((comment != null) ? comment.Length : 0);
			if (num > 65535) {
				throw new ZipException ($"Comment length({num}) is too long can only be 64K");
			}
			WriteLEShort (num);
			if (num > 0) {
				Write (comment, 0, comment.Length);
			}
		}

		public int ReadLEShort ()
		{
			int num = stream_.ReadByte ();
			if (num < 0) {
				throw new EndOfStreamException ();
			}
			int num2 = stream_.ReadByte ();
			if (num2 < 0) {
				throw new EndOfStreamException ();
			}
			return num | (num2 << 8);
		}

		public int ReadLEInt ()
		{
			return ReadLEShort () | (ReadLEShort () << 16);
		}

		public long ReadLELong ()
		{
			return (uint)ReadLEInt () | ((long)ReadLEInt () << 32);
		}

		public void WriteLEShort (int value)
		{
			stream_.WriteByte ((byte)((uint)value & 0xFFu));
			stream_.WriteByte ((byte)((uint)(value >> 8) & 0xFFu));
		}

		public void WriteLEUshort (ushort value)
		{
			stream_.WriteByte ((byte)(value & 0xFFu));
			stream_.WriteByte ((byte)(value >> 8));
		}

		public void WriteLEInt (int value)
		{
			WriteLEShort (value);
			WriteLEShort (value >> 16);
		}

		public void WriteLEUint (uint value)
		{
			WriteLEUshort ((ushort)(value & 0xFFFFu));
			WriteLEUshort ((ushort)(value >> 16));
		}

		public void WriteLELong (long value)
		{
			WriteLEInt ((int)value);
			WriteLEInt ((int)(value >> 32));
		}

		public void WriteLEUlong (ulong value)
		{
			WriteLEUint ((uint)(value & 0xFFFFFFFFu));
			WriteLEUint ((uint)(value >> 32));
		}

		public int WriteDataDescriptor (ZipEntry entry)
		{
			if (entry == null) {
				throw new ArgumentNullException ("entry");
			}
			int num = 0;
			if (((uint)entry.Flags & 8u) != 0) {
				WriteLEInt (134695760);
				WriteLEInt ((int)entry.Crc);
				num += 8;
				if (entry.LocalHeaderRequiresZip64) {
					WriteLELong (entry.CompressedSize);
					WriteLELong (entry.Size);
					num += 16;
				} else {
					WriteLEInt ((int)entry.CompressedSize);
					WriteLEInt ((int)entry.Size);
					num += 8;
				}
			}
			return num;
		}

		public void ReadDataDescriptor (bool zip64, DescriptorData data)
		{
			int num = ReadLEInt ();
			if (num != 134695760) {
				throw new ZipException ("Data descriptor signature not found");
			}
			data.Crc = ReadLEInt ();
			if (zip64) {
				data.CompressedSize = ReadLELong ();
				data.Size = ReadLELong ();
			} else {
				data.CompressedSize = ReadLEInt ();
				data.Size = ReadLEInt ();
			}
		}
	}
	public class ZipInputStream : InflaterInputStream
	{
		private delegate int ReadDataHandler (byte[] b, int offset, int length);

		private ReadDataHandler internalReader;

		private Crc32 crc = new Crc32 ();

		private ZipEntry entry;

		private long size;

		private int method;

		private int flags;

		private string password;

		public string Password {
			get {
				return password;
			}
			set {
				password = value;
			}
		}

		public bool CanDecompressEntry => entry != null && entry.CanDecompress;

		public override int Available => (entry != null) ? 1 : 0;

		public override long Length {
			get {
				if (entry != null) {
					if (entry.Size >= 0) {
						return entry.Size;
					}
					throw new ZipException ("Length not available for the current entry");
				}
				throw new InvalidOperationException ("No current entry");
			}
		}

		public ZipInputStream (Stream baseInputStream)
			: base (baseInputStream, new Inflater (noHeader: true))
		{
			internalReader = ReadingNotAvailable;
		}

		public ZipInputStream (Stream baseInputStream, int bufferSize)
			: base (baseInputStream, new Inflater (noHeader: true), bufferSize)
		{
			internalReader = ReadingNotAvailable;
		}

		public ZipEntry GetNextEntry ()
		{
			if (crc == null) {
				throw new InvalidOperationException ("Closed.");
			}
			if (entry != null) {
				CloseEntry ();
			}
			int num = inputBuffer.ReadLeInt ();
			switch (num) {
			case 33639248:
			case 84233040:
			case 101010256:
			case 101075792:
			case 117853008:
				Close ();
				return null;
			case 134695760:
			case 808471376:
				num = inputBuffer.ReadLeInt ();
				break;
			}
			if (num != 67324752) {
				throw new ZipException ("Wrong Local header signature: 0x" + $"{num:X}");
			}
			short versionRequiredToExtract = (short)inputBuffer.ReadLeShort ();
			flags = inputBuffer.ReadLeShort ();
			method = inputBuffer.ReadLeShort ();
			uint num2 = (uint)inputBuffer.ReadLeInt ();
			int num3 = inputBuffer.ReadLeInt ();
			csize = inputBuffer.ReadLeInt ();
			size = inputBuffer.ReadLeInt ();
			int num4 = inputBuffer.ReadLeShort ();
			int num5 = inputBuffer.ReadLeShort ();
			bool flag = (flags & 1) == 1;
			byte[] array = new byte[num4];
			inputBuffer.ReadRawBuffer (array);
			string name = ZipConstants.ConvertToStringExt (flags, array);
			entry = new ZipEntry (name, versionRequiredToExtract);
			entry.Flags = flags;
			entry.CompressionMethod = (CompressionMethod)method;
			if ((flags & 8) == 0) {
				entry.Crc = num3 & 0xFFFFFFFFu;
				entry.Size = size & 0xFFFFFFFFu;
				entry.CompressedSize = csize & 0xFFFFFFFFu;
				entry.CryptoCheckValue = (byte)((uint)(num3 >> 24) & 0xFFu);
			} else {
				if (num3 != 0) {
					entry.Crc = num3 & 0xFFFFFFFFu;
				}
				if (size != 0) {
					entry.Size = size & 0xFFFFFFFFu;
				}
				if (csize != 0) {
					entry.CompressedSize = csize & 0xFFFFFFFFu;
				}
				entry.CryptoCheckValue = (byte)((num2 >> 8) & 0xFFu);
			}
			entry.DosTime = num2;
			if (num5 > 0) {
				byte[] array2 = new byte[num5];
				inputBuffer.ReadRawBuffer (array2);
				entry.ExtraData = array2;
			}
			entry.ProcessExtraData (localHeader: true);
			if (entry.CompressedSize >= 0) {
				csize = entry.CompressedSize;
			}
			if (entry.Size >= 0) {
				size = entry.Size;
			}
			if (method == 0 && ((!flag && csize != size) || (flag && csize - 12 != size))) {
				throw new ZipException ("Stored, but compressed != uncompressed");
			}
			if (entry.IsCompressionMethodSupported ()) {
				internalReader = InitialRead;
			} else {
				internalReader = ReadingNotSupported;
			}
			return entry;
		}

		private void ReadDataDescriptor ()
		{
			if (inputBuffer.ReadLeInt () != 134695760) {
				throw new ZipException ("Data descriptor signature not found");
			}
			entry.Crc = inputBuffer.ReadLeInt () & 0xFFFFFFFFu;
			if (entry.LocalHeaderRequiresZip64) {
				csize = inputBuffer.ReadLeLong ();
				size = inputBuffer.ReadLeLong ();
			} else {
				csize = inputBuffer.ReadLeInt ();
				size = inputBuffer.ReadLeInt ();
			}
			entry.CompressedSize = csize;
			entry.Size = size;
		}

		private void CompleteCloseEntry (bool testCrc)
		{
			StopDecrypting ();
			if (((uint)flags & 8u) != 0) {
				ReadDataDescriptor ();
			}
			size = 0L;
			if (testCrc && (crc.Value & 0xFFFFFFFFu) != entry.Crc && entry.Crc != -1) {
				throw new ZipException ("CRC mismatch");
			}
			crc.Reset ();
			if (method == 8) {
				inf.Reset ();
			}
			entry = null;
		}

		public void CloseEntry ()
		{
			if (crc == null) {
				throw new InvalidOperationException ("Closed");
			}
			if (entry == null) {
				return;
			}
			if (method == 8) {
				if (((uint)flags & 8u) != 0) {
					byte[] array = new byte[4096];
					while (Read (array, 0, array.Length) > 0) {
					}
					return;
				}
				csize -= inf.TotalIn;
				inputBuffer.Available += inf.RemainingInput;
			}
			if (inputBuffer.Available > csize && csize >= 0) {
				inputBuffer.Available = (int)(inputBuffer.Available - csize);
			} else {
				csize -= inputBuffer.Available;
				inputBuffer.Available = 0;
				while (csize != 0) {
					long num = Skip (csize);
					if (num <= 0) {
						throw new ZipException ("Zip archive ends early.");
					}
					csize -= num;
				}
			}
			CompleteCloseEntry (testCrc: false);
		}

		public override int ReadByte ()
		{
			byte[] array = new byte[1];
			if (Read (array, 0, 1) <= 0) {
				return -1;
			}
			return array [0] & 0xFF;
		}

		private int ReadingNotAvailable (byte[] destination, int offset, int count)
		{
			throw new InvalidOperationException ("Unable to read from this stream");
		}

		private int ReadingNotSupported (byte[] destination, int offset, int count)
		{
			throw new ZipException ("The compression method for this entry is not supported");
		}

		private int InitialRead (byte[] destination, int offset, int count)
		{
			if (!CanDecompressEntry) {
				throw new ZipException ("Library cannot extract this entry. Version required is (" + entry.Version + ")");
			}
			if (entry.IsCrypted) {
				if (password == null) {
					throw new ZipException ("No password set.");
				}
				PkzipClassicManaged pkzipClassicManaged = new PkzipClassicManaged ();
				byte[] rgbKey = PkzipClassic.GenerateKeys (ZipConstants.ConvertToArray (password));
				inputBuffer.CryptoTransform = pkzipClassicManaged.CreateDecryptor (rgbKey, null);
				byte[] array = new byte[12];
				inputBuffer.ReadClearTextBuffer (array, 0, 12);
				if (array [11] != entry.CryptoCheckValue) {
					throw new ZipException ("Invalid password");
				}
				if (csize >= 12) {
					csize -= 12L;
				} else if ((entry.Flags & 8) == 0) {
					throw new ZipException ($"Entry compressed size {csize} too small for encryption");
				}
			} else {
				inputBuffer.CryptoTransform = null;
			}
			if (csize > 0 || ((uint)flags & 8u) != 0) {
				if (method == 8 && inputBuffer.Available > 0) {
					inputBuffer.SetInflaterInput (inf);
				}
				internalReader = BodyRead;
				return BodyRead (destination, offset, count);
			}
			internalReader = ReadingNotAvailable;
			return 0;
		}

		public override int Read (byte[] buffer, int offset, int count)
		{
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (offset < 0) {
				throw new ArgumentOutOfRangeException ("offset", "Cannot be negative");
			}
			if (count < 0) {
				throw new ArgumentOutOfRangeException ("count", "Cannot be negative");
			}
			if (buffer.Length - offset < count) {
				throw new ArgumentException ("Invalid offset/count combination");
			}
			return internalReader (buffer, offset, count);
		}

		private int BodyRead (byte[] buffer, int offset, int count)
		{
			if (crc == null) {
				throw new InvalidOperationException ("Closed");
			}
			if (entry == null || count <= 0) {
				return 0;
			}
			if (offset + count > buffer.Length) {
				throw new ArgumentException ("Offset + count exceeds buffer size");
			}
			bool flag = false;
			switch (method) {
			case 8:
				count = base.Read (buffer, offset, count);
				if (count <= 0) {
					if (!inf.IsFinished) {
						throw new ZipException ("Inflater not finished!");
					}
					inputBuffer.Available = inf.RemainingInput;
					if ((flags & 8) == 0 && ((inf.TotalIn != csize && csize != uint.MaxValue && csize != -1) || inf.TotalOut != size)) {
						throw new ZipException ("Size mismatch: " + csize + ";" + size + " <-> " + inf.TotalIn + ";" + inf.TotalOut);
					}
					inf.Reset ();
					flag = true;
				}
				break;
			case 0:
				if (count > csize && csize >= 0) {
					count = (int)csize;
				}
				if (count > 0) {
					count = inputBuffer.ReadClearTextBuffer (buffer, offset, count);
					if (count > 0) {
						csize -= count;
						size -= count;
					}
				}
				if (csize == 0) {
					flag = true;
				} else if (count < 0) {
					throw new ZipException ("EOF in stored block");
				}
				break;
			}
			if (count > 0) {
				crc.Update (buffer, offset, count);
			}
			if (flag) {
				CompleteCloseEntry (testCrc: true);
			}
			return count;
		}

		public override void Close ()
		{
			internalReader = ReadingNotAvailable;
			crc = null;
			entry = null;
			base.Close ();
		}
	}
	public class ZipNameTransform : INameTransform
	{
		private string trimPrefix_;

		private static readonly char[] InvalidEntryChars;

		private static readonly char[] InvalidEntryCharsRelaxed;

		public string TrimPrefix {
			get {
				return trimPrefix_;
			}
			set {
				trimPrefix_ = value;
				if (trimPrefix_ != null) {
					trimPrefix_ = trimPrefix_.ToLower ();
				}
			}
		}

		public ZipNameTransform ()
		{
		}

		public ZipNameTransform (string trimPrefix)
		{
			TrimPrefix = trimPrefix;
		}

		static ZipNameTransform ()
		{
			char[] invalidPathChars = Path.GetInvalidPathChars ();
			int num = invalidPathChars.Length + 2;
			InvalidEntryCharsRelaxed = new char[num];
			Array.Copy (invalidPathChars, 0, InvalidEntryCharsRelaxed, 0, invalidPathChars.Length);
			InvalidEntryCharsRelaxed [num - 1] = '*';
			InvalidEntryCharsRelaxed [num - 2] = '?';
			num = invalidPathChars.Length + 4;
			InvalidEntryChars = new char[num];
			Array.Copy (invalidPathChars, 0, InvalidEntryChars, 0, invalidPathChars.Length);
			InvalidEntryChars [num - 1] = ':';
			InvalidEntryChars [num - 2] = '\\';
			InvalidEntryChars [num - 3] = '*';
			InvalidEntryChars [num - 4] = '?';
		}

		public string TransformDirectory (string name)
		{
			name = TransformFile (name);
			if (name.Length > 0) {
				if (!name.EndsWith ("/")) {
					name += "/";
				}
				return name;
			}
			throw new ZipException ("Cannot have an empty directory name");
		}

		public string TransformFile (string name)
		{
			if (name != null) {
				string text = name.ToLower ();
				if (trimPrefix_ != null && text.IndexOf (trimPrefix_) == 0) {
					name = name.Substring (trimPrefix_.Length);
				}
				name = name.Replace ("\\", "/");
				name = WindowsPathUtils.DropPathRoot (name);
				while (name.Length > 0 && name [0] == '/') {
					name = name.Remove (0, 1);
				}
				while (name.Length > 0 && name [name.Length - 1] == '/') {
					name = name.Remove (name.Length - 1, 1);
				}
				for (int num = name.IndexOf ("//"); num >= 0; num = name.IndexOf ("//")) {
					name = name.Remove (num, 1);
				}
				name = MakeValidName (name, '_');
			} else {
				name = string.Empty;
			}
			return name;
		}

		private static string MakeValidName (string name, char replacement)
		{
			int num = name.IndexOfAny (InvalidEntryChars);
			if (num >= 0) {
				StringBuilder stringBuilder = new StringBuilder (name);
				while (num >= 0) {
					stringBuilder [num] = replacement;
					num = ((num < name.Length) ? name.IndexOfAny (InvalidEntryChars, num + 1) : (-1));
				}
				name = stringBuilder.ToString ();
			}
			if (name.Length > 65535) {
				throw new PathTooLongException ();
			}
			return name;
		}

		public static bool IsValidName (string name, bool relaxed)
		{
			bool flag = name != null;
			if (flag) {
				flag = ((!relaxed) ? (name.IndexOfAny (InvalidEntryChars) < 0 && name.IndexOf ('/') != 0) : (name.IndexOfAny (InvalidEntryCharsRelaxed) < 0));
			}
			return flag;
		}

		public static bool IsValidName (string name)
		{
			return name != null && name.IndexOfAny (InvalidEntryChars) < 0 && name.IndexOf ('/') != 0;
		}
	}
	public class ZipOutputStream : DeflaterOutputStream
	{
		private ArrayList entries = new ArrayList ();

		private Crc32 crc = new Crc32 ();

		private ZipEntry curEntry;

		private int defaultCompressionLevel = -1;

		private CompressionMethod curMethod = CompressionMethod.Deflated;

		private long size;

		private long offset;

		private byte[] zipComment = new byte[0];

		private bool patchEntryHeader;

		private long crcPatchPos = -1L;

		private long sizePatchPos = -1L;

		private UseZip64 useZip64_ = UseZip64.Dynamic;

		public bool IsFinished => entries == null;

		public UseZip64 UseZip64 {
			get {
				return useZip64_;
			}
			set {
				useZip64_ = value;
			}
		}

		public ZipOutputStream (Stream baseOutputStream)
			: base (baseOutputStream, new Deflater (-1, noZlibHeaderOrFooter: true))
		{
		}

		public ZipOutputStream (Stream baseOutputStream, int bufferSize)
			: base (baseOutputStream, new Deflater (-1, noZlibHeaderOrFooter: true), bufferSize)
		{
		}

		public void SetComment (string comment)
		{
			byte[] array = ZipConstants.ConvertToArray (comment);
			if (array.Length > 65535) {
				throw new ArgumentOutOfRangeException ("comment");
			}
			zipComment = array;
		}

		public void SetLevel (int level)
		{
			deflater_.SetLevel (level);
			defaultCompressionLevel = level;
		}

		public int GetLevel ()
		{
			return deflater_.GetLevel ();
		}

		private void WriteLeShort (int value)
		{
			baseOutputStream_.WriteByte ((byte)((uint)value & 0xFFu));
			baseOutputStream_.WriteByte ((byte)((uint)(value >> 8) & 0xFFu));
		}

		private void WriteLeInt (int value)
		{
			WriteLeShort (value);
			WriteLeShort (value >> 16);
		}

		private void WriteLeLong (long value)
		{
			WriteLeInt ((int)value);
			WriteLeInt ((int)(value >> 32));
		}

		public void PutNextEntry (ZipEntry entry)
		{
			if (entry == null) {
				throw new ArgumentNullException ("entry");
			}
			if (entries == null) {
				throw new InvalidOperationException ("ZipOutputStream was finished");
			}
			if (curEntry != null) {
				CloseEntry ();
			}
			if (entries.Count == int.MaxValue) {
				throw new ZipException ("Too many entries for Zip file");
			}
			CompressionMethod compressionMethod = entry.CompressionMethod;
			int level = defaultCompressionLevel;
			entry.Flags &= 2048;
			patchEntryHeader = false;
			bool flag;
			if (entry.Size == 0) {
				entry.CompressedSize = entry.Size;
				entry.Crc = 0L;
				compressionMethod = CompressionMethod.Stored;
				flag = true;
			} else {
				flag = entry.Size >= 0 && entry.HasCrc;
				if (compressionMethod == CompressionMethod.Stored) {
					if (!flag) {
						if (!base.CanPatchEntries) {
							compressionMethod = CompressionMethod.Deflated;
							level = 0;
						}
					} else {
						entry.CompressedSize = entry.Size;
						flag = entry.HasCrc;
					}
				}
			}
			if (!flag) {
				if (!base.CanPatchEntries) {
					entry.Flags |= 8;
				} else {
					patchEntryHeader = true;
				}
			}
			if (base.Password != null) {
				entry.IsCrypted = true;
				if (entry.Crc < 0) {
					entry.Flags |= 8;
				}
			}
			entry.Offset = offset;
			entry.CompressionMethod = compressionMethod;
			curMethod = compressionMethod;
			sizePatchPos = -1L;
			if (useZip64_ == UseZip64.On || (entry.Size < 0 && useZip64_ == UseZip64.Dynamic)) {
				entry.ForceZip64 ();
			}
			WriteLeInt (67324752);
			WriteLeShort (entry.Version);
			WriteLeShort (entry.Flags);
			WriteLeShort ((byte)entry.CompressionMethodForHeader);
			WriteLeInt ((int)entry.DosTime);
			if (flag) {
				WriteLeInt ((int)entry.Crc);
				if (entry.LocalHeaderRequiresZip64) {
					WriteLeInt (-1);
					WriteLeInt (-1);
				} else {
					WriteLeInt ((int)((!entry.IsCrypted) ? entry.CompressedSize : ((int)entry.CompressedSize + 12)));
					WriteLeInt ((int)entry.Size);
				}
			} else {
				if (patchEntryHeader) {
					crcPatchPos = baseOutputStream_.Position;
				}
				WriteLeInt (0);
				if (patchEntryHeader) {
					sizePatchPos = baseOutputStream_.Position;
				}
				if (entry.LocalHeaderRequiresZip64 || patchEntryHeader) {
					WriteLeInt (-1);
					WriteLeInt (-1);
				} else {
					WriteLeInt (0);
					WriteLeInt (0);
				}
			}
			byte[] array = ZipConstants.ConvertToArray (entry.Flags, entry.Name);
			if (array.Length > 65535) {
				throw new ZipException ("Entry name too long.");
			}
			ZipExtraData zipExtraData = new ZipExtraData (entry.ExtraData);
			if (entry.LocalHeaderRequiresZip64) {
				zipExtraData.StartNewEntry ();
				if (flag) {
					zipExtraData.AddLeLong (entry.Size);
					zipExtraData.AddLeLong (entry.CompressedSize);
				} else {
					zipExtraData.AddLeLong (-1L);
					zipExtraData.AddLeLong (-1L);
				}
				zipExtraData.AddNewEntry (1);
				if (!zipExtraData.Find (1)) {
					throw new ZipException ("Internal error cant find extra data");
				}
				if (patchEntryHeader) {
					sizePatchPos = zipExtraData.CurrentReadIndex;
				}
			} else {
				zipExtraData.Delete (1);
			}
			if (entry.AESKeySize > 0) {
				AddExtraDataAES (entry, zipExtraData);
			}
			byte[] entryData = zipExtraData.GetEntryData ();
			WriteLeShort (array.Length);
			WriteLeShort (entryData.Length);
			if (array.Length > 0) {
				baseOutputStream_.Write (array, 0, array.Length);
			}
			if (entry.LocalHeaderRequiresZip64 && patchEntryHeader) {
				sizePatchPos += baseOutputStream_.Position;
			}
			if (entryData.Length > 0) {
				baseOutputStream_.Write (entryData, 0, entryData.Length);
			}
			offset += 30 + array.Length + entryData.Length;
			if (entry.AESKeySize > 0) {
				offset += entry.AESOverheadSize;
			}
			curEntry = entry;
			crc.Reset ();
			if (compressionMethod == CompressionMethod.Deflated) {
				deflater_.Reset ();
				deflater_.SetLevel (level);
			}
			size = 0L;
			if (entry.IsCrypted) {
				if (entry.AESKeySize > 0) {
					WriteAESHeader (entry);
				} else if (entry.Crc < 0) {
					WriteEncryptionHeader (entry.DosTime << 16);
				} else {
					WriteEncryptionHeader (entry.Crc);
				}
			}
		}

		public void CloseEntry ()
		{
			if (curEntry == null) {
				throw new InvalidOperationException ("No open entry");
			}
			long totalOut = size;
			if (curMethod == CompressionMethod.Deflated) {
				if (size >= 0) {
					base.Finish ();
					totalOut = deflater_.TotalOut;
				} else {
					deflater_.Reset ();
				}
			}
			if (curEntry.AESKeySize > 0) {
				baseOutputStream_.Write (AESAuthCode, 0, 10);
			}
			if (curEntry.Size < 0) {
				curEntry.Size = size;
			} else if (curEntry.Size != size) {
				throw new ZipException ("size was " + size + ", but I expected " + curEntry.Size);
			}
			if (curEntry.CompressedSize < 0) {
				curEntry.CompressedSize = totalOut;
			} else if (curEntry.CompressedSize != totalOut) {
				throw new ZipException ("compressed size was " + totalOut + ", but I expected " + curEntry.CompressedSize);
			}
			if (curEntry.Crc < 0) {
				curEntry.Crc = crc.Value;
			} else if (curEntry.Crc != crc.Value) {
				throw new ZipException ("crc was " + crc.Value + ", but I expected " + curEntry.Crc);
			}
			offset += totalOut;
			if (curEntry.IsCrypted) {
				if (curEntry.AESKeySize > 0) {
					curEntry.CompressedSize += curEntry.AESOverheadSize;
				} else {
					curEntry.CompressedSize += 12L;
				}
			}
			if (patchEntryHeader) {
				patchEntryHeader = false;
				long position = baseOutputStream_.Position;
				baseOutputStream_.Seek (crcPatchPos, SeekOrigin.Begin);
				WriteLeInt ((int)curEntry.Crc);
				if (curEntry.LocalHeaderRequiresZip64) {
					if (sizePatchPos == -1) {
						throw new ZipException ("Entry requires zip64 but this has been turned off");
					}
					baseOutputStream_.Seek (sizePatchPos, SeekOrigin.Begin);
					WriteLeLong (curEntry.Size);
					WriteLeLong (curEntry.CompressedSize);
				} else {
					WriteLeInt ((int)curEntry.CompressedSize);
					WriteLeInt ((int)curEntry.Size);
				}
				baseOutputStream_.Seek (position, SeekOrigin.Begin);
			}
			if (((uint)curEntry.Flags & 8u) != 0) {
				WriteLeInt (134695760);
				WriteLeInt ((int)curEntry.Crc);
				if (curEntry.LocalHeaderRequiresZip64) {
					WriteLeLong (curEntry.CompressedSize);
					WriteLeLong (curEntry.Size);
					offset += 24L;
				} else {
					WriteLeInt ((int)curEntry.CompressedSize);
					WriteLeInt ((int)curEntry.Size);
					offset += 16L;
				}
			}
			entries.Add (curEntry);
			curEntry = null;
		}

		private void WriteEncryptionHeader (long crcValue)
		{
			offset += 12L;
			InitializePassword (base.Password);
			byte[] array = new byte[12];
			System.Random random = new System.Random ();
			random.NextBytes (array);
			array [11] = (byte)(crcValue >> 24);
			EncryptBlock (array, 0, array.Length);
			baseOutputStream_.Write (array, 0, array.Length);
		}

		private static void AddExtraDataAES (ZipEntry entry, ZipExtraData extraData)
		{
			extraData.StartNewEntry ();
			extraData.AddLeShort (2);
			extraData.AddLeShort (17729);
			extraData.AddData (entry.AESEncryptionStrength);
			extraData.AddLeShort ((int)entry.CompressionMethod);
			extraData.AddNewEntry (39169);
		}

		private void WriteAESHeader (ZipEntry entry)
		{
			InitializeAESPassword (entry, base.Password, out var salt, out var pwdVerifier);
			baseOutputStream_.Write (salt, 0, salt.Length);
			baseOutputStream_.Write (pwdVerifier, 0, pwdVerifier.Length);
		}

		public override void Write (byte[] buffer, int offset, int count)
		{
			if (curEntry == null) {
				throw new InvalidOperationException ("No open entry.");
			}
			if (buffer == null) {
				throw new ArgumentNullException ("buffer");
			}
			if (offset < 0) {
				throw new ArgumentOutOfRangeException ("offset", "Cannot be negative");
			}
			if (count < 0) {
				throw new ArgumentOutOfRangeException ("count", "Cannot be negative");
			}
			if (buffer.Length - offset < count) {
				throw new ArgumentException ("Invalid offset/count combination");
			}
			crc.Update (buffer, offset, count);
			size += count;
			switch (curMethod) {
			case CompressionMethod.Deflated:
				base.Write (buffer, offset, count);
				break;
			case CompressionMethod.Stored:
				if (base.Password != null) {
					CopyAndEncrypt (buffer, offset, count);
				} else {
					baseOutputStream_.Write (buffer, offset, count);
				}
				break;
			}
		}

		private void CopyAndEncrypt (byte[] buffer, int offset, int count)
		{
			byte[] array = new byte[4096];
			while (count > 0) {
				int num = ((count >= 4096) ? 4096 : count);
				Array.Copy (buffer, offset, array, 0, num);
				EncryptBlock (array, 0, num);
				baseOutputStream_.Write (array, 0, num);
				count -= num;
				offset += num;
			}
		}

		public override void Finish ()
		{
			if (entries == null) {
				return;
			}
			if (curEntry != null) {
				CloseEntry ();
			}
			long noOfEntries = entries.Count;
			long num = 0L;
			foreach (ZipEntry entry in entries) {
				WriteLeInt (33639248);
				WriteLeShort (51);
				WriteLeShort (entry.Version);
				WriteLeShort (entry.Flags);
				WriteLeShort ((short)entry.CompressionMethodForHeader);
				WriteLeInt ((int)entry.DosTime);
				WriteLeInt ((int)entry.Crc);
				if (entry.IsZip64Forced () || entry.CompressedSize >= uint.MaxValue) {
					WriteLeInt (-1);
				} else {
					WriteLeInt ((int)entry.CompressedSize);
				}
				if (entry.IsZip64Forced () || entry.Size >= uint.MaxValue) {
					WriteLeInt (-1);
				} else {
					WriteLeInt ((int)entry.Size);
				}
				byte[] array = ZipConstants.ConvertToArray (entry.Flags, entry.Name);
				if (array.Length > 65535) {
					throw new ZipException ("Name too long.");
				}
				ZipExtraData zipExtraData = new ZipExtraData (entry.ExtraData);
				if (entry.CentralHeaderRequiresZip64) {
					zipExtraData.StartNewEntry ();
					if (entry.IsZip64Forced () || entry.Size >= uint.MaxValue) {
						zipExtraData.AddLeLong (entry.Size);
					}
					if (entry.IsZip64Forced () || entry.CompressedSize >= uint.MaxValue) {
						zipExtraData.AddLeLong (entry.CompressedSize);
					}
					if (entry.Offset >= uint.MaxValue) {
						zipExtraData.AddLeLong (entry.Offset);
					}
					zipExtraData.AddNewEntry (1);
				} else {
					zipExtraData.Delete (1);
				}
				if (entry.AESKeySize > 0) {
					AddExtraDataAES (entry, zipExtraData);
				}
				byte[] entryData = zipExtraData.GetEntryData ();
				byte[] array2 = ((entry.Comment == null) ? new byte[0] : ZipConstants.ConvertToArray (entry.Flags, entry.Comment));
				if (array2.Length > 65535) {
					throw new ZipException ("Comment too long.");
				}
				WriteLeShort (array.Length);
				WriteLeShort (entryData.Length);
				WriteLeShort (array2.Length);
				WriteLeShort (0);
				WriteLeShort (0);
				if (entry.ExternalFileAttributes != -1) {
					WriteLeInt (entry.ExternalFileAttributes);
				} else if (entry.IsDirectory) {
					WriteLeInt (16);
				} else {
					WriteLeInt (0);
				}
				if (entry.Offset >= uint.MaxValue) {
					WriteLeInt (-1);
				} else {
					WriteLeInt ((int)entry.Offset);
				}
				if (array.Length > 0) {
					baseOutputStream_.Write (array, 0, array.Length);
				}
				if (entryData.Length > 0) {
					baseOutputStream_.Write (entryData, 0, entryData.Length);
				}
				if (array2.Length > 0) {
					baseOutputStream_.Write (array2, 0, array2.Length);
				}
				num += 46 + array.Length + entryData.Length + array2.Length;
			}
			using (ZipHelperStream zipHelperStream = new ZipHelperStream (baseOutputStream_)) {
				zipHelperStream.WriteEndOfCentralDirectory (noOfEntries, num, offset, zipComment);
			}
			entries = null;
		}
	}
}
public class EffectTimeDelay : MonoBehaviour
{
	public DelayTransform[] DelayTransforms;

	private void Start ()
	{
		if (DelayTransforms == null || DelayTransforms.Length == 0) {
			return;
		}
		DelayTransform[] delayTransforms = DelayTransforms;
		foreach (DelayTransform delayTransform in delayTransforms) {
			if (!(delayTransform.Trans == null) && delayTransform.ModeSet != 0) {
				StartCoroutine ("OnEffectEventFire", delayTransform);
			}
		}
	}

	private IEnumerator OnEffectEventFire (DelayTransform delayTransform)
	{
		yield return new WaitForSeconds (delayTransform.TimeDelay);
		EffectTimeDelayMode modeSet = delayTransform.ModeSet;
		Transform trans = delayTransform.Trans;
		switch (modeSet) {
		case EffectTimeDelayMode.GameObjectOn:
			trans.gameObject.SetActive (value: true);
			break;
		case EffectTimeDelayMode.GameObjectOff:
			trans.gameObject.SetActive (value: false);
			break;
		case EffectTimeDelayMode.EmitterOn: {
			ParticleEmitter[] componentsInChildren = trans.GetComponentsInChildren<ParticleEmitter> ();
			ParticleEmitter[] array = componentsInChildren;
			foreach (ParticleEmitter particleEmitter in array) {
				particleEmitter.emit = true;
			}
			break;
		}
		case EffectTimeDelayMode.EmitterOff: {
			ParticleEmitter[] componentsInChildren2 = trans.GetComponentsInChildren<ParticleEmitter> ();
			ParticleEmitter[] array2 = componentsInChildren2;
			foreach (ParticleEmitter particleEmitter2 in array2) {
				particleEmitter2.emit = false;
			}
			break;
		}
		case EffectTimeDelayMode.AnimationStart:
			if (trans.GetComponent<Animation> () != null) {
				trans.GetComponent<Animation> ().Play ();
			}
			break;
		case EffectTimeDelayMode.AnimationStop:
			if (trans.GetComponent<Animation> () != null) {
				trans.GetComponent<Animation> ().Stop ();
			}
			break;
		}
	}
}
[Serializable]
public class DelayTransform
{
	public EffectTimeDelayMode ModeSet;

	public float TimeDelay;

	public Transform Trans;
}
public enum EffectTimeDelayMode
{
	None,
	GameObjectOn,
	GameObjectOff,
	EmitterOn,
	EmitterOff,
	AnimationStart,
	AnimationStop
}
public class FlashLight : MonoBehaviour
{
	private const float FlashIntervalCfg = 10f;

	private const float FlashIntervalRand = 0.2f;

	public AudioSource AudioSrc;

	private float _flashEllapse;

	private float _flashInterfalThisTm = 10f;

	private void Start ()
	{
		_flashInterfalThisTm = 10f * (1f + UnityEngine.Random.Range (-0.2f, 0.2f));
	}

	private void Update ()
	{
		_flashEllapse += Time.deltaTime;
		if (_flashEllapse > _flashInterfalThisTm) {
			_flashEllapse = 0f;
			_flashInterfalThisTm = 10f * (1f + UnityEngine.Random.Range (-0.2f, 0.2f));
			Flash ();
			int min = 154350;
			int max = 198450;
			AudioSrc.Play (Convert.ToUInt64 (UnityEngine.Random.Range (min, max)));
		}
	}

	private void Flash ()
	{
		GetComponent<Animation> ().Play ("dengshan");
	}
}
public class GenerateParticle : MonoBehaviour
{
	public GameObject P;

	private void Update ()
	{
		if (Input.GetKeyDown (KeyCode.E)) {
			UnityEngine.Object.Instantiate (P);
		}
	}
}
public class MedalEffectHelp : MonoBehaviour
{
	public GameObject[] xunzhang;

	public GameObject liuguang;

	public Texture TestMedalTexture;

	public Texture TestMaskTexture;

	public bool TestModel;

	private void Awake ()
	{
		if (TestModel) {
			UpdateMedalMaterTexture (TestMedalTexture);
			UpdateMaterialMask (TestMaskTexture);
		}
	}

	public void UpdateMedalMaterTexture (Texture MedalTexture)
	{
		GameObject[] array = xunzhang;
		foreach (GameObject go in array) {
			ChangeMaterialTexture (go, MedalTexture);
		}
	}

	public void ChangeMaterialTexture (GameObject go, Texture MedalTexture)
	{
		if (!(MedalTexture == null) && (go.GetComponent<Renderer> () != null || go.GetComponent<Renderer> ().material != null)) {
			go.GetComponent<Renderer> ().material.mainTexture = MedalTexture;
		}
	}

	public void UpdateMaterialMask (Texture MaskTexture)
	{
		if (!(MaskTexture == null)) {
			liuguang.GetComponent<Renderer> ().material.SetTexture ("_Mask", MaskTexture);
		}
	}
}
namespace Mono.Xml
{
	internal class MiniParser
	{
		public interface IReader
		{
			int Read ();
		}

		public interface IAttrList
		{
			int Length { get; }

			bool IsEmpty { get; }

			string[] Names { get; }

			string[] Values { get; }

			string GetName (int i);

			string GetValue (int i);

			string GetValue (string name);

			void ChangeValue (string name, string newValue);
		}

		public interface IMutableAttrList : IAttrList
		{
			void Clear ();

			void Add (string name, string value);

			void CopyFrom (IAttrList attrs);

			void Remove (int i);

			void Remove (string name);
		}

		public interface IHandler
		{
			void OnStartParsing (MiniParser parser);

			void OnStartElement (string name, IAttrList attrs);

			void OnEndElement (string name);

			void OnChars (string ch);

			void OnEndParsing (MiniParser parser);
		}

		public class HandlerAdapter : IHandler
		{
			public void OnStartParsing (MiniParser parser)
			{
			}

			public void OnStartElement (string name, IAttrList attrs)
			{
			}

			public void OnEndElement (string name)
			{
			}

			public void OnChars (string ch)
			{
			}

			public void OnEndParsing (MiniParser parser)
			{
			}
		}

		private enum CharKind : byte
		{
			LEFT_BR = 0,
			RIGHT_BR = 1,
			SLASH = 2,
			PI_MARK = 3,
			EQ = 4,
			AMP = 5,
			SQUOTE = 6,
			DQUOTE = 7,
			BANG = 8,
			LEFT_SQBR = 9,
			SPACE = 10,
			RIGHT_SQBR = 11,
			TAB = 12,
			CR = 13,
			EOL = 14,
			CHARS = 15,
			UNKNOWN = 31
		}

		private enum ActionCode : byte
		{
			START_ELEM = 0,
			END_ELEM = 1,
			END_NAME = 2,
			SET_ATTR_NAME = 3,
			SET_ATTR_VAL = 4,
			SEND_CHARS = 5,
			START_CDATA = 6,
			END_CDATA = 7,
			ERROR = 8,
			STATE_CHANGE = 9,
			FLUSH_CHARS_STATE_CHANGE = 10,
			ACC_CHARS_STATE_CHANGE = 11,
			ACC_CDATA = 12,
			PROC_CHAR_REF = 13,
			UNKNOWN = 15
		}

		public class AttrListImpl : IMutableAttrList, IAttrList
		{
			protected ArrayList names;

			protected ArrayList values;

			public int Length => names.Count;

			public bool IsEmpty => Length != 0;

			public string[] Names => names.ToArray (typeof(string)) as string[];

			public string[] Values => values.ToArray (typeof(string)) as string[];

			public AttrListImpl ()
				: this (0)
			{
			}

			public AttrListImpl (int initialCapacity)
			{
				if (initialCapacity <= 0) {
					names = new ArrayList ();
					values = new ArrayList ();
				} else {
					names = new ArrayList (initialCapacity);
					values = new ArrayList (initialCapacity);
				}
			}

			public AttrListImpl (IAttrList attrs)
				: this (attrs?.Length ?? 0)
			{
				if (attrs != null) {
					CopyFrom (attrs);
				}
			}

			public string GetName (int i)
			{
				string result = null;
				if (i >= 0 && i < Length) {
					result = names [i] as string;
				}
				return result;
			}

			public string GetValue (int i)
			{
				string result = null;
				if (i >= 0 && i < Length) {
					result = values [i] as string;
				}
				return result;
			}

			public string GetValue (string name)
			{
				return GetValue (names.IndexOf (name));
			}

			public void ChangeValue (string name, string newValue)
			{
				int num = names.IndexOf (name);
				if (num >= 0 && num < Length) {
					values [num] = newValue;
				}
			}

			public void Clear ()
			{
				names.Clear ();
				values.Clear ();
			}

			public void Add (string name, string value)
			{
				names.Add (name);
				values.Add (value);
			}

			public void Remove (int i)
			{
				if (i >= 0) {
					names.RemoveAt (i);
					values.RemoveAt (i);
				}
			}

			public void Remove (string name)
			{
				Remove (names.IndexOf (name));
			}

			public void CopyFrom (IAttrList attrs)
			{
				if (attrs != null && this == attrs) {
					Clear ();
					int length = attrs.Length;
					for (int i = 0; i < length; i++) {
						Add (attrs.GetName (i), attrs.GetValue (i));
					}
				}
			}
		}

		public class XMLError : Exception
		{
			protected string descr;

			protected int line;

			protected int column;

			public int Line => line;

			public int Column => column;

			public XMLError ()
				: this ("Unknown")
			{
			}

			public XMLError (string descr)
				: this (descr, -1, -1)
			{
			}

			public XMLError (string descr, int line, int column)
				: base (descr)
			{
				this.descr = descr;
				this.line = line;
				this.column = column;
			}

			public override string ToString ()
			{
				return $"{descr} @ (line = {line}, col = {column})";
			}
		}

		private static readonly int INPUT_RANGE = 13;

		private static readonly ushort[] tbl = new ushort[262] {
			2305, 43264, 63616, 10368, 6272, 14464, 18560, 22656, 26752, 34944,
			39040, 47232, 30848, 2177, 10498, 6277, 14595, 18561, 22657, 26753,
			35088, 39041, 43137, 47233, 30849, 64004, 4352, 43266, 64258, 2177,
			10369, 14465, 18561, 22657, 26753, 34945, 39041, 47233, 30849, 14597,
			2307, 10499, 6403, 18691, 22787, 26883, 35075, 39171, 43267, 47363,
			30979, 63747, 64260, 8710, 4615, 41480, 2177, 14465, 18561, 22657,
			26753, 34945, 39041, 47233, 30849, 6400, 2307, 10499, 14595, 18691,
			22787, 26883, 35075, 39171, 43267, 47363, 30979, 63747, 6400, 2177,
			10369, 14465, 18561, 22657, 26753, 34945, 39041, 43137, 47233, 30849,
			63617, 2561, 23818, 11274, 7178, 15370, 19466, 27658, 35850, 39946,
			43783, 48138, 31754, 64522, 64265, 8198, 4103, 43272, 2177, 14465,
			18561, 22657, 26753, 34945, 39041, 47233, 30849, 64265, 17163, 43276,
			2178, 10370, 6274, 14466, 22658, 26754, 34946, 39042, 47234, 30850,
			2317, 23818, 11274, 7178, 15370, 19466, 27658, 35850, 39946, 44042,
			48138, 31754, 64522, 26894, 30991, 43275, 2180, 10372, 6276, 14468,
			18564, 22660, 34948, 39044, 47236, 63620, 17163, 43276, 2178, 10370,
			6274, 14466, 22658, 26754, 34946, 39042, 47234, 30850, 63618, 9474,
			35088, 2182, 6278, 14470, 18566, 22662, 26758, 39046, 43142, 47238,
			30854, 63622, 25617, 23822, 2830, 11022, 6926, 15118, 19214, 35598,
			39694, 43790, 47886, 31502, 64270, 29713, 23823, 2831, 11023, 6927,
			15119, 19215, 27407, 35599, 39695, 43791, 47887, 64271, 38418, 6400,
			1555, 9747, 13843, 17939, 22035, 26131, 34323, 42515, 46611, 30227,
			62995, 8198, 4103, 43281, 64265, 2177, 14465, 18561, 22657, 26753,
			34945, 39041, 47233, 30849, 46858, 3090, 11282, 7186, 15378, 19474,
			23570, 27666, 35858, 39954, 44050, 31762, 64530, 3091, 11283, 7187,
			15379, 19475, 23571, 27667, 35859, 39955, 44051, 48147, 31763, 64531,
			65535, 65535
		};

		protected static string[] errors = new string[8] { "Expected element", "Invalid character in tag", "No '='", "Invalid character entity", "Invalid attr value", "Empty tag", "No end tag", "Bad entity ref" };

		protected int line;

		protected int col;

		protected int[] twoCharBuff;

		protected bool splitCData;

		public MiniParser ()
		{
			twoCharBuff = new int[2];
			splitCData = false;
			Reset ();
		}

		public void Reset ()
		{
			line = 0;
			col = 0;
		}

		protected static bool StrEquals (string str, StringBuilder sb, int sbStart, int len)
		{
			if (len != str.Length) {
				return false;
			}
			for (int i = 0; i < len; i++) {
				if (str [i] != sb [sbStart + i]) {
					return false;
				}
			}
			return true;
		}

		protected void FatalErr (string descr)
		{
			throw new XMLError (descr, line, col);
		}

		protected static int Xlat (int charCode, int state)
		{
			int num = state * INPUT_RANGE;
			int num2 = System.Math.Min (tbl.Length - num, INPUT_RANGE);
			while (--num2 >= 0) {
				ushort num3 = tbl [num];
				if (charCode == num3 >> 12) {
					return num3 & 0xFFF;
				}
				num++;
			}
			return 4095;
		}

		public void Parse (IReader reader, IHandler handler)
		{
			if (reader == null) {
				throw new ArgumentNullException ("reader");
			}
			if (handler == null) {
				handler = new HandlerAdapter ();
			}
			AttrListImpl attrListImpl = new AttrListImpl ();
			string text = null;
			Stack stack = new Stack ();
			string text2 = null;
			line = 1;
			col = 0;
			int num = 0;
			int num2 = 0;
			StringBuilder stringBuilder = new StringBuilder ();
			bool flag = false;
			bool flag2 = false;
			bool flag3 = false;
			int num3 = 0;
			handler.OnStartParsing (this);
			while (true) {
				col++;
				num = reader.Read ();
				if (num == -1) {
					break;
				}
				int num4 = "<>/?=&'\"![ ]\t\r\n".IndexOf ((char)num) & 0xF;
				switch (num4) {
				case 13:
					continue;
				case 12:
					num4 = 10;
					break;
				}
				if (num4 == 14) {
					col = 0;
					line++;
					num4 = 10;
				}
				int num5 = Xlat (num4, num2);
				num2 = num5 & 0xFF;
				if (num == 10 && (num2 == 14 || num2 == 15)) {
					continue;
				}
				num5 >>= 8;
				if (num2 >= 128) {
					if (num2 == 255) {
						FatalErr ("State dispatch error.");
					} else {
						FatalErr (errors [num2 ^ 0x80]);
					}
				}
				switch (num5) {
				case 9:
					break;
				case 0:
					handler.OnStartElement (text2, attrListImpl);
					if (num != 47) {
						stack.Push (text2);
					} else {
						handler.OnEndElement (text2);
					}
					attrListImpl.Clear ();
					break;
				case 1: {
					text2 = stringBuilder.ToString ();
					stringBuilder = new StringBuilder ();
					string text6 = null;
					if (stack.Count == 0 || text2 != (text6 = stack.Pop () as string)) {
						if (text6 == null) {
							FatalErr ("Tag stack underflow");
						} else {
							FatalErr ($"Expected end tag '{text2}' but found '{text6}'");
						}
					}
					handler.OnEndElement (text2);
					break;
				}
				case 2:
					text2 = stringBuilder.ToString ();
					stringBuilder = new StringBuilder ();
					if (num != 47 && num != 62) {
						break;
					}
					goto case 0;
				case 3:
					text = stringBuilder.ToString ();
					stringBuilder = new StringBuilder ();
					break;
				case 4:
					if (text == null) {
						FatalErr ("Internal error.");
					}
					attrListImpl.Add (text, stringBuilder.ToString ());
					stringBuilder = new StringBuilder ();
					text = null;
					break;
				case 5:
					handler.OnChars (stringBuilder.ToString ());
					stringBuilder = new StringBuilder ();
					break;
				case 6: {
					string text5 = "CDATA[";
					flag2 = false;
					flag3 = false;
					switch (num) {
					case 45:
						num = reader.Read ();
						if (num != 45) {
							FatalErr ("Invalid comment");
						}
						col++;
						flag2 = true;
						twoCharBuff [0] = -1;
						twoCharBuff [1] = -1;
						break;
					default:
						flag3 = true;
						num3 = 0;
						break;
					case 91: {
						for (int k = 0; k < text5.Length; k++) {
							if (reader.Read () != text5 [k]) {
								col += k + 1;
								break;
							}
						}
						col += text5.Length;
						flag = true;
						break;
					}
					}
					break;
				}
				case 7: {
					int num20 = 0;
					num = 93;
					while (true) {
						switch (num) {
						case 93:
							goto IL_0397;
						default: {
							for (int j = 0; j < num20; j++) {
								stringBuilder.Append (']');
							}
							stringBuilder.Append ((char)num);
							num2 = 18;
							break;
						}
						case 62: {
							for (int i = 0; i < num20 - 2; i++) {
								stringBuilder.Append (']');
							}
							flag = false;
							break;
						}
						}
						break;
						IL_0397:
						num = reader.Read ();
						num20++;
					}
					col += num20;
					break;
				}
				case 8:
					FatalErr ($"Error {num2}");
					break;
				case 10:
					stringBuilder = new StringBuilder ();
					if (num != 60) {
						goto case 11;
					}
					break;
				case 11:
					stringBuilder.Append ((char)num);
					break;
				case 12:
					if (flag2) {
						if (num == 62 && twoCharBuff [0] == 45 && twoCharBuff [1] == 45) {
							flag2 = false;
							num2 = 0;
						} else {
							twoCharBuff [0] = twoCharBuff [1];
							twoCharBuff [1] = num;
						}
					} else if (flag3) {
						if (num == 60 || num == 62) {
							num3 ^= 1;
						}
						if (num == 62 && num3 != 0) {
							flag3 = false;
							num2 = 0;
						}
					} else {
						if (splitCData && stringBuilder.Length > 0 && flag) {
							handler.OnChars (stringBuilder.ToString ());
							stringBuilder = new StringBuilder ();
						}
						flag = false;
						stringBuilder.Append ((char)num);
					}
					break;
				case 13: {
					num = reader.Read ();
					int num6 = col + 1;
					if (num == 35) {
						int num7 = 10;
						int num8 = 0;
						int num9 = 0;
						num = reader.Read ();
						num6++;
						if (num == 120) {
							num = reader.Read ();
							num6++;
							num7 = 16;
						}
						NumberStyles style = ((num7 != 16) ? NumberStyles.Integer : NumberStyles.HexNumber);
						while (true) {
							int num10 = -1;
							if (char.IsNumber ((char)num) || "abcdef".IndexOf (char.ToLower ((char)num)) != -1) {
								try {
									num10 = int.Parse (new string ((char)num, 1), style);
								} catch (FormatException) {
									num10 = -1;
								}
							}
							if (num10 == -1) {
								break;
							}
							num8 *= num7;
							num8 += num10;
							num9++;
							num = reader.Read ();
							num6++;
						}
						if (num == 59 && num9 > 0) {
							stringBuilder.Append ((char)num8);
						} else {
							FatalErr ("Bad char ref");
						}
					} else {
						string text3 = "aglmopqstu";
						string text4 = "&'\"><";
						int num11 = 0;
						int num12 = 15;
						int num13 = 0;
						int length = stringBuilder.Length;
						while (true) {
							if (num11 != 15) {
								num11 = text3.IndexOf ((char)num) & 0xF;
							}
							if (num11 == 15) {
								FatalErr (errors [7]);
							}
							stringBuilder.Append ((char)num);
							int num14 = "Ｕ㾏侏ཟｸ\ue1f4⊙\ueeff\ueeffｏ" [num11];
							int num15 = (num14 >> 4) & 0xF;
							int num16 = num14 & 0xF;
							int num17 = num14 >> 12;
							int num18 = (num14 >> 8) & 0xF;
							num = reader.Read ();
							num6++;
							num11 = 15;
							if (num15 != 15 && num == text3 [num15]) {
								if (num17 < 14) {
									num12 = num17;
								}
								num13 = 12;
							} else if (num16 != 15 && num == text3 [num16]) {
								if (num18 < 14) {
									num12 = num18;
								}
								num13 = 8;
							} else if (num == 59) {
								if (num12 != 15 && num13 != 0 && ((num14 >> num13) & 0xF) == 14) {
									break;
								}
								continue;
							}
							num11 = 0;
						}
						int num19 = num6 - col - 1;
						if (num19 > 0 && num19 < 5 && (StrEquals ("amp", stringBuilder, length, num19) || StrEquals ("apos", stringBuilder, length, num19) || StrEquals ("quot", stringBuilder, length, num19) || StrEquals ("lt", stringBuilder, length, num19) || StrEquals ("gt", stringBuilder, length, num19))) {
							stringBuilder.Length = length;
							stringBuilder.Append (text4 [num12]);
						} else {
							FatalErr (errors [7]);
						}
					}
					col = num6;
					break;
				}
				default:
					FatalErr ($"Unexpected action code - {num5}.");
					break;
				}
			}
			if (num2 != 0) {
				FatalErr ("Unexpected EOF");
			}
			handler.OnEndParsing (this);
		}
	}
	public class SecurityParser : SmallXmlParser, SmallXmlParser.IContentHandler
	{
		private SecurityElement root;

		private SecurityElement current;

		private Stack stack;

		public SecurityParser ()
		{
			stack = new Stack ();
		}

		public void LoadXml (string xml)
		{
			root = null;
			stack.Clear ();
			Parse (new StringReader (xml), this);
		}

		public SecurityElement ToXml ()
		{
			return root;
		}

		public void OnStartParsing (SmallXmlParser parser)
		{
		}

		public void OnProcessingInstruction (string name, string text)
		{
		}

		public void OnIgnorableWhitespace (string s)
		{
		}

		public void OnStartElement (string name, IAttrList attrs)
		{
			SecurityElement securityElement = new SecurityElement (name);
			if (root == null) {
				root = securityElement;
				current = securityElement;
			} else {
				SecurityElement securityElement2 = (SecurityElement)stack.Peek ();
				securityElement2.AddChild (securityElement);
			}
			stack.Push (securityElement);
			current = securityElement;
			int length = attrs.Length;
			for (int i = 0; i < length; i++) {
				current.AddAttribute (attrs.GetName (i), attrs.GetValue (i));
			}
		}

		public void OnEndElement (string name)
		{
			current = (SecurityElement)stack.Pop ();
		}

		public void OnChars (string ch)
		{
			current.Text = ch;
		}

		public void OnEndParsing (SmallXmlParser parser)
		{
		}
	}
	internal class DefaultHandler : SmallXmlParser.IContentHandler
	{
		public void OnStartParsing (SmallXmlParser parser)
		{
		}

		public void OnEndParsing (SmallXmlParser parser)
		{
		}

		public void OnStartElement (string name, SmallXmlParser.IAttrList attrs)
		{
		}

		public void OnEndElement (string name)
		{
		}

		public void OnChars (string s)
		{
		}

		public void OnIgnorableWhitespace (string s)
		{
		}

		public void OnProcessingInstruction (string name, string text)
		{
		}
	}
	public class SmallXmlParser
	{
		public interface IContentHandler
		{
			void OnStartParsing (SmallXmlParser parser);

			void OnEndParsing (SmallXmlParser parser);

			void OnStartElement (string name, IAttrList attrs);

			void OnEndElement (string name);

			void OnProcessingInstruction (string name, string text);

			void OnChars (string text);

			void OnIgnorableWhitespace (string text);
		}

		public interface IAttrList
		{
			int Length { get; }

			bool IsEmpty { get; }

			string[] Names { get; }

			string[] Values { get; }

			string GetName (int i);

			string GetValue (int i);

			string GetValue (string name);
		}

		private class AttrListImpl : IAttrList
		{
			private ArrayList attrNames = new ArrayList ();

			private ArrayList attrValues = new ArrayList ();

			public int Length => attrNames.Count;

			public bool IsEmpty => attrNames.Count == 0;

			public string[] Names => (string[])attrNames.ToArray (typeof(string));

			public string[] Values => (string[])attrValues.ToArray (typeof(string));

			public string GetName (int i)
			{
				return (string)attrNames [i];
			}

			public string GetValue (int i)
			{
				return (string)attrValues [i];
			}

			public string GetValue (string name)
			{
				for (int i = 0; i < attrNames.Count; i++) {
					if ((string)attrNames [i] == name) {
						return (string)attrValues [i];
					}
				}
				return null;
			}

			internal void Clear ()
			{
				attrNames.Clear ();
				attrValues.Clear ();
			}

			internal void Add (string name, string value)
			{
				attrNames.Add (name);
				attrValues.Add (value);
			}
		}

		private IContentHandler handler;

		private TextReader reader;

		private Stack elementNames = new Stack ();

		private Stack xmlSpaces = new Stack ();

		private string xmlSpace;

		private StringBuilder buffer = new StringBuilder (200);

		private char[] nameBuffer = new char[30];

		private bool isWhitespace;

		private AttrListImpl attributes = new AttrListImpl ();

		private int line = 1;

		private int column;

		private bool resetColumn;

		private Exception Error (string msg)
		{
			return new Mono.Xml.SmallXmlParserException (msg, line, column);
		}

		private Exception UnexpectedEndError ()
		{
			string[] array = new string[elementNames.Count];
			((ICollection)elementNames).CopyTo ((Array)array, 0);
			return Error (string.Format ("Unexpected end of stream. Element stack content is {0}", string.Join (",", array)));
		}

		private bool IsNameChar (char c, bool start)
		{
			if (c != '-' && c != '.') {
				if (c == ':' || c == '_') {
					return true;
				}
				if (c > 'Ā') {
					if (c == 'ՙ' || c == 'ۥ' || c == 'ۦ') {
						return true;
					}
					if ('ʻ' <= c && c <= 'ˁ') {
						return true;
					}
				}
				switch (char.GetUnicodeCategory (c)) {
				case UnicodeCategory.UppercaseLetter:
				case UnicodeCategory.LowercaseLetter:
				case UnicodeCategory.TitlecaseLetter:
				case UnicodeCategory.OtherLetter:
				case UnicodeCategory.LetterNumber:
					return true;
				case UnicodeCategory.ModifierLetter:
				case UnicodeCategory.NonSpacingMark:
				case UnicodeCategory.SpacingCombiningMark:
				case UnicodeCategory.EnclosingMark:
				case UnicodeCategory.DecimalDigitNumber:
					return !start;
				default:
					return false;
				}
			}
			return !start;
		}

		private bool IsWhitespace (int c)
		{
			switch (c) {
			case 9:
			case 10:
			case 13:
			case 32:
				return true;
			default:
				return false;
			}
		}

		public void SkipWhitespaces ()
		{
			SkipWhitespaces (expected: false);
		}

		private void HandleWhitespaces ()
		{
			while (IsWhitespace (Peek ())) {
				buffer.Append ((char)Read ());
			}
			if (Peek () != 60 && Peek () >= 0) {
				isWhitespace = false;
			}
		}

		public void SkipWhitespaces (bool expected)
		{
			while (true) {
				switch (Peek ()) {
				case 9:
				case 10:
				case 13:
				case 32:
					Read ();
					if (expected) {
						expected = false;
					}
					break;
				default:
					if (expected) {
						throw Error ("Whitespace is expected.");
					}
					return;
				}
			}
		}

		private int Peek ()
		{
			return reader.Peek ();
		}

		private int Read ()
		{
			int num = reader.Read ();
			if (num == 10) {
				resetColumn = true;
			}
			if (resetColumn) {
				line++;
				resetColumn = false;
				column = 1;
			} else {
				column++;
			}
			return num;
		}

		public void Expect (int c)
		{
			int num = Read ();
			if (num < 0) {
				throw UnexpectedEndError ();
			}
			if (num != c) {
				throw Error ($"Expected '{(char)c}' but got {(char)num}");
			}
		}

		private string ReadUntil (char until, bool handleReferences)
		{
			while (true) {
				if (Peek () < 0) {
					throw UnexpectedEndError ();
				}
				char c = (char)Read ();
				if (c == until) {
					break;
				}
				if (handleReferences && c == '&') {
					ReadReference ();
				} else {
					buffer.Append (c);
				}
			}
			string result = buffer.ToString ();
			buffer.Length = 0;
			return result;
		}

		public string ReadName ()
		{
			int num = 0;
			if (Peek () < 0 || !IsNameChar ((char)Peek (), start: true)) {
				throw Error ("XML name start character is expected.");
			}
			for (int num2 = Peek (); num2 >= 0; num2 = Peek ()) {
				char c = (char)num2;
				if (!IsNameChar (c, start: false)) {
					break;
				}
				if (num == nameBuffer.Length) {
					char[] destinationArray = new char[num * 2];
					Array.Copy (nameBuffer, 0, destinationArray, 0, num);
					nameBuffer = destinationArray;
				}
				nameBuffer [num++] = c;
				Read ();
			}
			if (num == 0) {
				throw Error ("Valid XML name is expected.");
			}
			return new string (nameBuffer, 0, num);
		}

		public void Parse (TextReader input, IContentHandler handler)
		{
			reader = input;
			this.handler = handler;
			handler.OnStartParsing (this);
			while (Peek () >= 0) {
				ReadContent ();
			}
			HandleBufferedContent ();
			if (elementNames.Count > 0) {
				throw Error ($"Insufficient close tag: {elementNames.Peek ()}");
			}
			handler.OnEndParsing (this);
			Cleanup ();
		}

		private void Cleanup ()
		{
			line = 1;
			column = 0;
			handler = null;
			reader = null;
			elementNames.Clear ();
			xmlSpaces.Clear ();
			attributes.Clear ();
			buffer.Length = 0;
			xmlSpace = null;
			isWhitespace = false;
		}

		public void ReadContent ()
		{
			if (IsWhitespace (Peek ())) {
				if (buffer.Length == 0) {
					isWhitespace = true;
				}
				HandleWhitespaces ();
			}
			if (Peek () == 60) {
				Read ();
				switch (Peek ()) {
				case 33:
					Read ();
					if (Peek () == 91) {
						Read ();
						if (ReadName () != "CDATA") {
							throw Error ("Invalid declaration markup");
						}
						Expect (91);
						ReadCDATASection ();
						break;
					}
					if (Peek () == 45) {
						ReadComment ();
						break;
					}
					if (ReadName () != "DOCTYPE") {
						throw Error ("Invalid declaration markup.");
					}
					throw Error ("This parser does not support document type.");
				case 63: {
					HandleBufferedContent ();
					Read ();
					string text = ReadName ();
					SkipWhitespaces ();
					string text3 = string.Empty;
					if (Peek () != 63) {
						while (true) {
							text3 += ReadUntil ('?', handleReferences: false);
							if (Peek () == 62) {
								break;
							}
							text3 += "?";
						}
					}
					handler.OnProcessingInstruction (text, text3);
					Expect (62);
					break;
				}
				case 47: {
					HandleBufferedContent ();
					if (elementNames.Count == 0) {
						throw UnexpectedEndError ();
					}
					Read ();
					string text = ReadName ();
					SkipWhitespaces ();
					string text2 = (string)elementNames.Pop ();
					xmlSpaces.Pop ();
					if (xmlSpaces.Count > 0) {
						xmlSpace = (string)xmlSpaces.Peek ();
					} else {
						xmlSpace = null;
					}
					if (text != text2) {
						throw Error ($"End tag mismatch: expected {text2} but found {text}");
					}
					handler.OnEndElement (text);
					Expect (62);
					break;
				}
				default: {
					HandleBufferedContent ();
					string text = ReadName ();
					while (Peek () != 62 && Peek () != 47) {
						ReadAttribute (attributes);
					}
					handler.OnStartElement (text, attributes);
					attributes.Clear ();
					SkipWhitespaces ();
					if (Peek () == 47) {
						Read ();
						handler.OnEndElement (text);
					} else {
						elementNames.Push (text);
						xmlSpaces.Push (xmlSpace);
					}
					Expect (62);
					break;
				}
				}
			} else {
				ReadCharacters ();
			}
		}

		private void HandleBufferedContent ()
		{
			if (buffer.Length != 0) {
				if (isWhitespace) {
					handler.OnIgnorableWhitespace (buffer.ToString ());
				} else {
					handler.OnChars (buffer.ToString ());
				}
				buffer.Length = 0;
				isWhitespace = false;
			}
		}

		private void ReadCharacters ()
		{
			isWhitespace = false;
			while (true) {
				switch (Peek ()) {
				case -1:
				case 60:
					return;
				case 38:
					Read ();
					ReadReference ();
					break;
				default:
					buffer.Append ((char)Read ());
					break;
				}
			}
		}

		private void ReadReference ()
		{
			if (Peek () == 35) {
				Read ();
				ReadCharacterReference ();
				return;
			}
			string text = ReadName ();
			Expect (59);
			switch (text) {
			case "amp":
				buffer.Append ('&');
				break;
			case "quot":
				buffer.Append ('"');
				break;
			case "apos":
				buffer.Append ('\'');
				break;
			case "lt":
				buffer.Append ('<');
				break;
			case "gt":
				buffer.Append ('>');
				break;
			default:
				throw Error ("General non-predefined entity reference is not supported in this parser.");
			}
		}

		private int ReadCharacterReference ()
		{
			int num = 0;
			if (Peek () == 120) {
				Read ();
				for (int num2 = Peek (); num2 >= 0; num2 = Peek ()) {
					if (48 <= num2 && num2 <= 57) {
						num <<= 4 + num2 - 48;
					} else if (65 <= num2 && num2 <= 70) {
						num <<= 4 + num2 - 65 + 10;
					} else {
						if (97 > num2 || num2 > 102) {
							break;
						}
						num <<= 4 + num2 - 97 + 10;
					}
					Read ();
				}
			} else {
				int num3 = Peek ();
				while (num3 >= 0 && 48 <= num3 && num3 <= 57) {
					num <<= 4 + num3 - 48;
					Read ();
					num3 = Peek ();
				}
			}
			return num;
		}

		private void ReadAttribute (AttrListImpl a)
		{
			SkipWhitespaces (expected: true);
			if (Peek () != 47 && Peek () != 62) {
				string text = ReadName ();
				SkipWhitespaces ();
				Expect (61);
				SkipWhitespaces ();
				string value = Read () switch {
					39 => ReadUntil ('\'', handleReferences: true), 
					34 => ReadUntil ('"', handleReferences: true), 
					_ => throw Error ("Invalid attribute value markup."), 
				};
				if (text == "xml:space") {
					xmlSpace = value;
				}
				a.Add (text, value);
			}
		}

		private void ReadCDATASection ()
		{
			int num = 0;
			while (Peek () >= 0) {
				char c = (char)Read ();
				switch (c) {
				case ']':
					num++;
					continue;
				case '>':
					if (num > 1) {
						for (int num2 = num; num2 > 2; num2--) {
							buffer.Append (']');
						}
						return;
					}
					break;
				}
				for (int i = 0; i < num; i++) {
					buffer.Append (']');
				}
				num = 0;
				buffer.Append (c);
			}
			throw UnexpectedEndError ();
		}

		private void ReadComment ()
		{
			Expect (45);
			Expect (45);
			while (Read () != 45 || Read () != 45) {
			}
			if (Read () != 62) {
				throw Error ("'--' is not allowed inside comment markup.");
			}
		}
	}
	internal class SmallXmlParserException : SystemException
	{
		private int line;

		private int column;

		public int Line => line;

		public int Column => column;

		public SmallXmlParserException (string msg, int line, int column)
			: base ($"{msg}. At ({line},{column})")
		{
			this.line = line;
			this.column = column;
		}
	}
}
[ExecuteInEditMode]
public class SetRenderQueue : MonoBehaviour
{
	public RenderQueue[] RenderQueues;

	private void Start ()
	{
		if (RenderQueues == null) {
			return;
		}
		for (int i = 0; i < RenderQueues.Length; i++) {
			RenderQueue renderQueue = RenderQueues [i];
			if (renderQueue == null || !(renderQueue.Renderer != null)) {
				continue;
			}
			Material[] sharedMaterials = renderQueue.Renderer.sharedMaterials;
			if (sharedMaterials == null || sharedMaterials.Length <= 0) {
				continue;
			}
			foreach (Material material in sharedMaterials) {
				if (material != null && material.shader != null) {
					material.renderQueue = material.shader.renderQueue + renderQueue.RendererDepth;
				}
			}
		}
	}
}
[Serializable]
public class RenderQueue
{
	public Renderer Renderer;

	public int RendererDepth;
}
public class TimedObjectDestructor : MonoBehaviour
{
	public float Time;

	public bool DetchChildren;

	private void Start ()
	{
		Invoke ("DestroyNow", Time);
	}

	private void DestroyNow ()
	{
		if (DetchChildren) {
			base.transform.DetachChildren ();
		}
		UnityEngine.Object.DestroyObject (base.gameObject);
	}
}
[ExecuteInEditMode]
public class Water : MonoBehaviour
{
	public enum WaterMode
	{
		Simple,
		Reflective,
		Refractive
	}

	public WaterMode m_WaterMode = WaterMode.Refractive;

	public bool m_DisablePixelLights = true;

	public int m_TextureSize = 256;

	public float m_ClipPlaneOffset = 0.07f;

	public LayerMask m_ReflectLayers = -1;

	public LayerMask m_RefractLayers = -1;

	private Hashtable m_ReflectionCameras = new Hashtable ();

	private Hashtable m_RefractionCameras = new Hashtable ();

	private RenderTexture m_ReflectionTexture;

	private RenderTexture m_RefractionTexture;

	private WaterMode m_HardwareWaterSupport = WaterMode.Refractive;

	private int m_OldReflectionTextureSize;

	private int m_OldRefractionTextureSize;

	private static bool s_InsideWater;

	public void OnWillRenderObject ()
	{
		if (!base.enabled || !GetComponent<Renderer> () || !GetComponent<Renderer> ().sharedMaterial || !GetComponent<Renderer> ().enabled) {
			return;
		}
		Camera current = Camera.current;
		if ((bool)current && !s_InsideWater) {
			s_InsideWater = true;
			m_HardwareWaterSupport = FindHardwareWaterSupport ();
			WaterMode waterMode = GetWaterMode ();
			CreateWaterObjects (current, out var reflectionCamera, out var refractionCamera);
			Vector3 position = base.transform.position;
			Vector3 up = base.transform.up;
			int pixelLightCount = QualitySettings.pixelLightCount;
			if (m_DisablePixelLights) {
				QualitySettings.pixelLightCount = 0;
			}
			UpdateCameraModes (current, reflectionCamera);
			UpdateCameraModes (current, refractionCamera);
			if (waterMode >= WaterMode.Reflective) {
				float w = 0f - Vector3.Dot (up, position) - m_ClipPlaneOffset;
				Vector4 plane = new Vector4 (up.x, up.y, up.z, w);
				Matrix4x4 reflectionMat = Matrix4x4.zero;
				CalculateReflectionMatrix (ref reflectionMat, plane);
				Vector3 position2 = current.transform.position;
				Vector3 position3 = reflectionMat.MultiplyPoint (position2);
				reflectionCamera.worldToCameraMatrix = current.worldToCameraMatrix * reflectionMat;
				Vector4 clipPlane = CameraSpacePlane (reflectionCamera, position, up, 1f);
				Matrix4x4 projection = current.projectionMatrix;
				CalculateObliqueMatrix (ref projection, clipPlane);
				reflectionCamera.projectionMatrix = projection;
				reflectionCamera.cullingMask = -17 & m_ReflectLayers.value;
				reflectionCamera.targetTexture = m_ReflectionTexture;
				GL.SetRevertBackfacing (revertBackFaces: true);
				reflectionCamera.transform.position = position3;
				Vector3 eulerAngles = current.transform.eulerAngles;
				reflectionCamera.transform.eulerAngles = new Vector3 (0f - eulerAngles.x, eulerAngles.y, eulerAngles.z);
				reflectionCamera.Render ();
				reflectionCamera.transform.position = position2;
				GL.SetRevertBackfacing (revertBackFaces: false);
				GetComponent<Renderer> ().sharedMaterial.SetTexture ("_ReflectionTex", m_ReflectionTexture);
			}
			if (waterMode >= WaterMode.Refractive) {
				refractionCamera.worldToCameraMatrix = current.worldToCameraMatrix;
				Vector4 clipPlane2 = CameraSpacePlane (refractionCamera, position, up, -1f);
				Matrix4x4 projection2 = current.projectionMatrix;
				CalculateObliqueMatrix (ref projection2, clipPlane2);
				refractionCamera.projectionMatrix = projection2;
				refractionCamera.cullingMask = -17 & m_RefractLayers.value;
				refractionCamera.targetTexture = m_RefractionTexture;
				refractionCamera.transform.position = current.transform.position;
				refractionCamera.transform.rotation = current.transform.rotation;
				refractionCamera.Render ();
				GetComponent<Renderer> ().sharedMaterial.SetTexture ("_RefractionTex", m_RefractionTexture);
			}
			if (m_DisablePixelLights) {
				QualitySettings.pixelLightCount = pixelLightCount;
			}
			switch (waterMode) {
			case WaterMode.Simple:
				Shader.EnableKeyword ("WATER_SIMPLE");
				Shader.DisableKeyword ("WATER_REFLECTIVE");
				Shader.DisableKeyword ("WATER_REFRACTIVE");
				break;
			case WaterMode.Reflective:
				Shader.DisableKeyword ("WATER_SIMPLE");
				Shader.EnableKeyword ("WATER_REFLECTIVE");
				Shader.DisableKeyword ("WATER_REFRACTIVE");
				break;
			case WaterMode.Refractive:
				Shader.DisableKeyword ("WATER_SIMPLE");
				Shader.DisableKeyword ("WATER_REFLECTIVE");
				Shader.EnableKeyword ("WATER_REFRACTIVE");
				break;
			}
			s_InsideWater = false;
		}
	}

	private void OnDisable ()
	{
		if ((bool)m_ReflectionTexture) {
			UnityEngine.Object.DestroyImmediate (m_ReflectionTexture);
			m_ReflectionTexture = null;
		}
		if ((bool)m_RefractionTexture) {
			UnityEngine.Object.DestroyImmediate (m_RefractionTexture);
			m_RefractionTexture = null;
		}
		foreach (DictionaryEntry reflectionCamera in m_ReflectionCameras) {
			UnityEngine.Object.DestroyImmediate (((Camera)reflectionCamera.Value).gameObject);
		}
		m_ReflectionCameras.Clear ();
		foreach (DictionaryEntry refractionCamera in m_RefractionCameras) {
			UnityEngine.Object.DestroyImmediate (((Camera)refractionCamera.Value).gameObject);
		}
		m_RefractionCameras.Clear ();
	}

	private void Update ()
	{
		if ((bool)GetComponent<Renderer> ()) {
			Material sharedMaterial = GetComponent<Renderer> ().sharedMaterial;
			if ((bool)sharedMaterial) {
				Vector4 vector = sharedMaterial.GetVector ("WaveSpeed");
				float @float = sharedMaterial.GetFloat ("_WaveScale");
				Vector4 value = new Vector4 (@float, @float, @float * 0.4f, @float * 0.45f);
				double num = (double)Time.timeSinceLevelLoad / 20.0;
				Vector4 value2 = new Vector4 ((float)Math.IEEERemainder ((double)(vector.x * value.x) * num, 1.0), (float)Math.IEEERemainder ((double)(vector.y * value.y) * num, 1.0), (float)Math.IEEERemainder ((double)(vector.z * value.z) * num, 1.0), (float)Math.IEEERemainder ((double)(vector.w * value.w) * num, 1.0));
				sharedMaterial.SetVector ("_WaveOffset", value2);
				sharedMaterial.SetVector ("_WaveScale4", value);
				Vector3 size = GetComponent<Renderer> ().bounds.size;
				Matrix4x4 value3 = Matrix4x4.TRS (s: new Vector3 (size.x * value.x, size.z * value.y, 1f), pos: new Vector3 (value2.x, value2.y, 0f), q: Quaternion.identity);
				sharedMaterial.SetMatrix ("_WaveMatrix", value3);
				value3 = Matrix4x4.TRS (s: new Vector3 (size.x * value.z, size.z * value.w, 1f), pos: new Vector3 (value2.z, value2.w, 0f), q: Quaternion.identity);
				sharedMaterial.SetMatrix ("_WaveMatrix2", value3);
			}
		}
	}

	private void UpdateCameraModes (Camera src, Camera dest)
	{
		if (dest == null) {
			return;
		}
		dest.clearFlags = src.clearFlags;
		dest.backgroundColor = src.backgroundColor;
		if (src.clearFlags == CameraClearFlags.Skybox) {
			Skybox skybox = src.GetComponent (typeof(Skybox)) as Skybox;
			Skybox skybox2 = dest.GetComponent (typeof(Skybox)) as Skybox;
			if (!skybox || !skybox.material) {
				skybox2.enabled = false;
			} else {
				skybox2.enabled = true;
				skybox2.material = skybox.material;
			}
		}
		dest.farClipPlane = src.farClipPlane;
		dest.nearClipPlane = src.nearClipPlane;
		dest.orthographic = src.orthographic;
		dest.fieldOfView = src.fieldOfView;
		dest.aspect = src.aspect;
		dest.orthographicSize = src.orthographicSize;
	}

	private void CreateWaterObjects (Camera currentCamera, out Camera reflectionCamera, out Camera refractionCamera)
	{
		WaterMode waterMode = GetWaterMode ();
		reflectionCamera = null;
		refractionCamera = null;
		if (waterMode >= WaterMode.Reflective) {
			if (!m_ReflectionTexture || m_OldReflectionTextureSize != m_TextureSize) {
				if ((bool)m_ReflectionTexture) {
					UnityEngine.Object.DestroyImmediate (m_ReflectionTexture);
				}
				m_ReflectionTexture = new RenderTexture (m_TextureSize, m_TextureSize, 16);
				m_ReflectionTexture.name = "__WaterReflection" + GetInstanceID ();
				m_ReflectionTexture.isPowerOfTwo = true;
				m_ReflectionTexture.hideFlags = HideFlags.DontSave;
				m_OldReflectionTextureSize = m_TextureSize;
			}
			reflectionCamera = m_ReflectionCameras [currentCamera] as Camera;
			if (!reflectionCamera) {
				GameObject gameObject = new GameObject ("Water Refl Camera id" + GetInstanceID () + " for " + currentCamera.GetInstanceID (), typeof(Camera), typeof(Skybox));
				reflectionCamera = gameObject.GetComponent<Camera> ();
				reflectionCamera.enabled = false;
				reflectionCamera.transform.position = base.transform.position;
				reflectionCamera.transform.rotation = base.transform.rotation;
				reflectionCamera.gameObject.AddComponent<FlareLayer> ();
				gameObject.hideFlags = HideFlags.HideAndDontSave;
				m_ReflectionCameras [currentCamera] = reflectionCamera;
			}
		}
		if (waterMode < WaterMode.Refractive) {
			return;
		}
		if (!m_RefractionTexture || m_OldRefractionTextureSize != m_TextureSize) {
			if ((bool)m_RefractionTexture) {
				UnityEngine.Object.DestroyImmediate (m_RefractionTexture);
			}
			m_RefractionTexture = new RenderTexture (m_TextureSize, m_TextureSize, 16);
			m_RefractionTexture.name = "__WaterRefraction" + GetInstanceID ();
			m_RefractionTexture.isPowerOfTwo = true;
			m_RefractionTexture.hideFlags = HideFlags.DontSave;
			m_OldRefractionTextureSize = m_TextureSize;
		}
		refractionCamera = m_RefractionCameras [currentCamera] as Camera;
		if (!refractionCamera) {
			GameObject gameObject2 = new GameObject ("Water Refr Camera id" + GetInstanceID () + " for " + currentCamera.GetInstanceID (), typeof(Camera), typeof(Skybox));
			refractionCamera = gameObject2.GetComponent<Camera> ();
			refractionCamera.enabled = false;
			refractionCamera.transform.position = base.transform.position;
			refractionCamera.transform.rotation = base.transform.rotation;
			refractionCamera.gameObject.AddComponent<FlareLayer> ();
			gameObject2.hideFlags = HideFlags.HideAndDontSave;
			m_RefractionCameras [currentCamera] = refractionCamera;
		}
	}

	private WaterMode GetWaterMode ()
	{
		if (m_HardwareWaterSupport < m_WaterMode) {
			return m_HardwareWaterSupport;
		}
		return m_WaterMode;
	}

	private WaterMode FindHardwareWaterSupport ()
	{
		if (!SystemInfo.supportsRenderTextures || !GetComponent<Renderer> ()) {
			return WaterMode.Simple;
		}
		Material sharedMaterial = GetComponent<Renderer> ().sharedMaterial;
		if (!sharedMaterial) {
			return WaterMode.Simple;
		}
		string text = sharedMaterial.GetTag ("WATERMODE", searchFallbacks: false);
		if (text == "Refractive") {
			return WaterMode.Refractive;
		}
		if (text == "Reflective") {
			return WaterMode.Reflective;
		}
		return WaterMode.Simple;
	}

	private static float sgn (float a)
	{
		if (a > 0f) {
			return 1f;
		}
		if (a < 0f) {
			return -1f;
		}
		return 0f;
	}

	private Vector4 CameraSpacePlane (Camera cam, Vector3 pos, Vector3 normal, float sideSign)
	{
		Vector3 v = pos + normal * m_ClipPlaneOffset;
		Matrix4x4 worldToCameraMatrix = cam.worldToCameraMatrix;
		Vector3 lhs = worldToCameraMatrix.MultiplyPoint (v);
		Vector3 rhs = worldToCameraMatrix.MultiplyVector (normal).normalized * sideSign;
		return new Vector4 (rhs.x, rhs.y, rhs.z, 0f - Vector3.Dot (lhs, rhs));
	}

	private static void CalculateObliqueMatrix (ref Matrix4x4 projection, Vector4 clipPlane)
	{
		Vector4 b = projection.inverse * new Vector4 (sgn (clipPlane.x), sgn (clipPlane.y), 1f, 1f);
		Vector4 vector = clipPlane * (2f / Vector4.Dot (clipPlane, b));
		projection [2] = vector.x - projection [3];
		projection [6] = vector.y - projection [7];
		projection [10] = vector.z - projection [11];
		projection [14] = vector.w - projection [15];
	}

	private static void CalculateReflectionMatrix (ref Matrix4x4 reflectionMat, Vector4 plane)
	{
		reflectionMat.m00 = 1f - 2f * plane [0] * plane [0];
		reflectionMat.m01 = -2f * plane [0] * plane [1];
		reflectionMat.m02 = -2f * plane [0] * plane [2];
		reflectionMat.m03 = -2f * plane [3] * plane [0];
		reflectionMat.m10 = -2f * plane [1] * plane [0];
		reflectionMat.m11 = 1f - 2f * plane [1] * plane [1];
		reflectionMat.m12 = -2f * plane [1] * plane [2];
		reflectionMat.m13 = -2f * plane [3] * plane [1];
		reflectionMat.m20 = -2f * plane [2] * plane [0];
		reflectionMat.m21 = -2f * plane [2] * plane [1];
		reflectionMat.m22 = 1f - 2f * plane [2] * plane [2];
		reflectionMat.m23 = -2f * plane [3] * plane [2];
		reflectionMat.m30 = 0f;
		reflectionMat.m31 = 0f;
		reflectionMat.m32 = 0f;
		reflectionMat.m33 = 1f;
	}
}
public class WebSocket
{
	private Uri mUrl;

	private WebSocketSharp.WebSocket m_Socket;

	private Queue<byte[]> m_Messages = new Queue<byte[]> ();

	private bool m_IsConnected;

	private string m_Error;

	public int ReadyState => (int)m_Socket.ReadyState;

	public bool isConnected => m_IsConnected;

	public string error => m_Error;

	public WebSocket (Uri url)
	{
		mUrl = url;
		string scheme = mUrl.Scheme;
		if (!scheme.Equals ("ws") && !scheme.Equals ("wss")) {
			throw new ArgumentException ("Unsupported protocol: " + scheme);
		}
	}

	public void SendString (string str)
	{
		Send (Encoding.UTF8.GetBytes (str));
	}

	public string RecvString ()
	{
		byte[] array = Recv ();
		if (array == null) {
			return null;
		}
		return Encoding.UTF8.GetString (array);
	}

	public IEnumerator Connect ()
	{
		m_Socket = new WebSocketSharp.WebSocket (mUrl.ToString ());
		m_Socket.OnMessage += delegate(object sender, MessageEventArgs e) {
			m_Messages.Enqueue (e.RawData);
		};
		m_Socket.OnOpen += delegate {
			m_IsConnected = true;
		};
		m_Socket.OnClose += delegate {
			m_IsConnected = false;
		};
		m_Socket.OnError += delegate(object sender, WebSocketSharp.ErrorEventArgs e) {
			m_Error = e.Message;
		};
		m_Socket.ConnectAsync ();
		while (!m_IsConnected && m_Error == null) {
			yield return null;
		}
	}

	public void Send (byte[] buffer)
	{
		m_Socket.Send (buffer);
	}

	public byte[] Recv ()
	{
		if (m_Messages.Count == 0) {
			return null;
		}
		return m_Messages.Dequeue ();
	}

	public void Close ()
	{
		m_Socket.Close ();
	}
}
[ExecuteInEditMode]
[RequireComponent (typeof(Camera))]
[AddComponentMenu ("Image Efects/Bloom (4.0f, HDR, Lens Flares) New In Csharp")]
public class BloomInCsharp : PostEffectsBaseInCsharp
{
	public enum LensFlareStyle
	{
		Ghosting,
		Anamorphic,
		Combined
	}

	public enum TweakMode
	{
		Basic,
		Complex
	}

	public enum HDRBloomMode
	{
		Auto,
		On,
		Of
	}

	public enum BloomScreenBlendMode
	{
		Screen,
		Add
	}

	public enum BloomQuality
	{
		Cheap,
		High
	}

	public TweakMode tweakMode;

	public BloomScreenBlendMode screenBlendMode = BloomScreenBlendMode.Add;

	public HDRBloomMode hdr;

	public bool doHdr;

	public float sepBlurSpread = 2.5f;

	public BloomQuality quality = BloomQuality.High;

	public float bloomIntensity = 0.5f;

	public float bloomThreshhold = 0.5f;

	public Color bloomThreshholdColor = Color.white;

	public int bloomBlurIterations = 2;

	public int hollywoodFlareBlurIterations = 2;

	public float flareRotation;

	public LensFlareStyle lensflareMode = LensFlareStyle.Anamorphic;

	public float hollyStretchWidth = 2.5f;

	public float lensflareIntensity;

	public float lensflareThreshhold = 0.3f;

	public float lensFlareSaturation = 0.75f;

	public Color flareColorA = new Color (0.4f, 0.4f, 0.8f, 0.75f);

	public Color flareColorB = new Color (0.4f, 0.8f, 0.8f, 0.75f);

	public Color flareColorC = new Color (0.8f, 0.4f, 0.8f, 0.75f);

	public Color flareColorD = new Color (0.8f, 0.4f, 0f, 0.75f);

	public float blurWidth = 1f;

	public Texture2D lensFlareVignetteMask;

	public Shader lensFlareShader;

	private Material lensFlareMaterial;

	public Shader screenBlendShader;

	private Material screenBlend;

	public Shader blurAndFlaresShader;

	private Material blurAndFlaresMaterial;

	public Shader brightPassFilterShader;

	private Material brightPassFilterMaterial;

	private void Start ()
	{
		CheckResources ();
	}

	public new bool CheckResources ()
	{
		CheckSupport (needDepth: false);
		screenBlend = CheckShaderAndCreateMaterial (screenBlendShader, screenBlend);
		lensFlareMaterial = CheckShaderAndCreateMaterial (lensFlareShader, lensFlareMaterial);
		blurAndFlaresMaterial = CheckShaderAndCreateMaterial (blurAndFlaresShader, blurAndFlaresMaterial);
		brightPassFilterMaterial = CheckShaderAndCreateMaterial (brightPassFilterShader, brightPassFilterMaterial);
		if (!isSupported) {
			ReportAutoDisable ();
		}
		return isSupported;
	}

	public void OnRenderImageFun (RenderTexture source, RenderTexture destination)
	{
		if (!CheckResources ()) {
			Graphics.Blit (source, destination);
			return;
		}
		doHdr = false;
		if (hdr == HDRBloomMode.Auto) {
			doHdr = source.format == RenderTextureFormat.ARGBHalf && GetComponent<Camera> ().hdr;
		} else {
			doHdr = hdr == HDRBloomMode.On;
		}
		doHdr = doHdr && supportHDRTextures;
		BloomScreenBlendMode bloomScreenBlendMode = screenBlendMode;
		if (doHdr) {
			bloomScreenBlendMode = BloomScreenBlendMode.Add;
		}
		RenderTextureFormat format = ((!doHdr) ? RenderTextureFormat.Default : RenderTextureFormat.ARGBHalf);
		RenderTexture temporary = RenderTexture.GetTemporary (source.width / 2, source.height / 2, 0, format);
		RenderTexture temporary2 = RenderTexture.GetTemporary (source.width / 4, source.height / 4, 0, format);
		RenderTexture temporary3 = RenderTexture.GetTemporary (source.width / 4, source.height / 4, 0, format);
		RenderTexture temporary4 = RenderTexture.GetTemporary (source.width / 4, source.height / 4, 0, format);
		float num = 1f * (float)source.width / (1f * (float)source.height);
		float num2 = 0.001953125f;
		if (quality > BloomQuality.Cheap) {
			Graphics.Blit (source, temporary, screenBlend, 2);
			Graphics.Blit (temporary, temporary3, screenBlend, 2);
			Graphics.Blit (temporary3, temporary2, screenBlend, 6);
		} else {
			Graphics.Blit (source, temporary);
			Graphics.Blit (temporary, temporary2, screenBlend, 6);
		}
		BrightFilter (bloomThreshhold * bloomThreshholdColor, temporary2, temporary3);
		if (bloomBlurIterations < 1) {
			bloomBlurIterations = 1;
		} else if (bloomBlurIterations > 10) {
			bloomBlurIterations = 10;
		}
		for (int i = 0; i < bloomBlurIterations; i++) {
			float num3 = (1f + (float)i * 0.25f) * sepBlurSpread;
			blurAndFlaresMaterial.SetVector ("_Offsets", new Vector4 (0f, num3 * num2, 0f, 0f));
			Graphics.Blit (temporary3, temporary4, blurAndFlaresMaterial, 4);
			if (quality > BloomQuality.Cheap) {
				blurAndFlaresMaterial.SetVector ("_Offsets", new Vector4 (num3 / num * num2, 0f, 0f, 0f));
				Graphics.Blit (temporary4, temporary3, blurAndFlaresMaterial, 4);
				if (i == 0) {
					Graphics.Blit (temporary3, temporary2);
				} else {
					Graphics.Blit (temporary3, temporary2, screenBlend, 10);
				}
			} else {
				blurAndFlaresMaterial.SetVector ("_Offsets", new Vector4 (num3 / num * num2, 0f, 0f, 0f));
				Graphics.Blit (temporary4, temporary3, blurAndFlaresMaterial, 4);
			}
		}
		if (quality > BloomQuality.Cheap) {
			Graphics.Blit (temporary2, temporary3, screenBlend, 6);
		}
		if (lensflareIntensity > Mathf.Epsilon) {
			if (lensflareMode == LensFlareStyle.Ghosting) {
				BrightFilter (lensflareThreshhold, temporary3, temporary4);
				if (quality > BloomQuality.Cheap) {
					blurAndFlaresMaterial.SetVector ("_Offsets", new Vector4 (0f, 1.5f / (1f * (float)temporary2.height), 0f, 0f));
					Graphics.Blit (temporary4, temporary2, blurAndFlaresMaterial, 4);
					blurAndFlaresMaterial.SetVector ("_Offsets", new Vector4 (1.5f / (1f * (float)temporary2.width), 0f, 0f, 0f));
					Graphics.Blit (temporary2, temporary4, blurAndFlaresMaterial, 4);
				}
				Vignette (0.975f, temporary4, temporary4);
				BlendFlares (temporary4, temporary3);
			} else {
				float num4 = 1f * Mathf.Cos (flareRotation);
				float num5 = 1f * Mathf.Sin (flareRotation);
				float num6 = hollyStretchWidth * 1f / num * num2;
				blurAndFlaresMaterial.SetVector ("_Offsets", new Vector4 (num4, num5, 0f, 0f));
				blurAndFlaresMaterial.SetVector ("_Threshhold", new Vector4 (lensflareThreshhold, 1f, 0f, 0f));
				blurAndFlaresMaterial.SetVector ("_TintColor", new Vector4 (flareColorA.r, flareColorA.g, flareColorA.b, flareColorA.a) * flareColorA.a * lensflareIntensity);
				blurAndFlaresMaterial.SetFloat ("_Saturation", lensFlareSaturation);
				Graphics.Blit (temporary4, temporary2, blurAndFlaresMaterial, 2);
				Graphics.Blit (temporary2, temporary4, blurAndFlaresMaterial, 3);
				blurAndFlaresMaterial.SetVector ("_Offsets", new Vector4 (num4 * num6, num5 * num6, 0f, 0f));
				blurAndFlaresMaterial.SetFloat ("_StretchWidth", hollyStretchWidth);
				Graphics.Blit (temporary4, temporary2, blurAndFlaresMaterial, 1);
				blurAndFlaresMaterial.SetFloat ("_StretchWidth", hollyStretchWidth * 2f);
				Graphics.Blit (temporary2, temporary4, blurAndFlaresMaterial, 1);
				blurAndFlaresMaterial.SetFloat ("_StretchWidth", hollyStretchWidth * 4f);
				Graphics.Blit (temporary4, temporary2, blurAndFlaresMaterial, 1);
				for (int j = 0; j < hollywoodFlareBlurIterations; j++) {
					num6 = hollyStretchWidth * 2f / num * num2;
					blurAndFlaresMaterial.SetVector ("_Offsets", new Vector4 (num6 * num4, num6 * num5, 0f, 0f));
					Graphics.Blit (temporary2, temporary4, blurAndFlaresMaterial, 4);
					blurAndFlaresMaterial.SetVector ("_Offsets", new Vector4 (num6 * num4, num6 * num5, 0f, 0f));
					Graphics.Blit (temporary4, temporary2, blurAndFlaresMaterial, 4);
				}
				if (lensflareMode == LensFlareStyle.Anamorphic) {
					AddTo (1f, temporary2, temporary3);
				} else {
					Vignette (1f, temporary2, temporary4);
					BlendFlares (temporary4, temporary2);
					AddTo (1f, temporary2, temporary3);
				}
			}
		}
		int pass = (int)bloomScreenBlendMode;
		screenBlend.SetFloat ("_Intensity", bloomIntensity);
		screenBlend.SetTexture ("_ColorBuffer", source);
		if (quality > BloomQuality.Cheap) {
			Graphics.Blit (temporary3, temporary);
			Graphics.Blit (temporary, destination, screenBlend, pass);
		} else {
			Graphics.Blit (temporary3, destination, screenBlend, pass);
		}
		RenderTexture.ReleaseTemporary (temporary);
		RenderTexture.ReleaseTemporary (temporary2);
		RenderTexture.ReleaseTemporary (temporary3);
		RenderTexture.ReleaseTemporary (temporary4);
	}

	private void AddTo (float intensity_, RenderTexture from, RenderTexture to)
	{
		screenBlend.SetFloat ("_Intensity", intensity_);
		Graphics.Blit (from, to, screenBlend, 9);
	}

	private void BlendFlares (RenderTexture from, RenderTexture to)
	{
		lensFlareMaterial.SetVector ("colorA", new Vector4 (flareColorA.r, flareColorA.g, flareColorA.b, flareColorA.a) * lensflareIntensity);
		lensFlareMaterial.SetVector ("colorB", new Vector4 (flareColorB.r, flareColorB.g, flareColorB.b, flareColorB.a) * lensflareIntensity);
		lensFlareMaterial.SetVector ("colorC", new Vector4 (flareColorC.r, flareColorC.g, flareColorC.b, flareColorC.a) * lensflareIntensity);
		lensFlareMaterial.SetVector ("colorD", new Vector4 (flareColorD.r, flareColorD.g, flareColorD.b, flareColorD.a) * lensflareIntensity);
		Graphics.Blit (from, to, lensFlareMaterial);
	}

	private void BrightFilter (float thresh, RenderTexture from, RenderTexture to)
	{
		brightPassFilterMaterial.SetVector ("_Threshhold", new Vector4 (thresh, thresh, thresh, thresh));
		Graphics.Blit (from, to, brightPassFilterMaterial, 0);
	}

	private void BrightFilter (Color threshColor, RenderTexture from, RenderTexture to)
	{
		brightPassFilterMaterial.SetVector ("_Threshhold", threshColor);
		Graphics.Blit (from, to, brightPassFilterMaterial, 1);
	}

	private void Vignette (float amount, RenderTexture from, RenderTexture to)
	{
		if ((bool)lensFlareVignetteMask) {
			screenBlend.SetTexture ("_ColorBuffer", lensFlareVignetteMask);
			Graphics.Blit ((!(from == to)) ? from : null, to, screenBlend, (!(from == to)) ? 3 : 7);
		} else if (from != to) {
			Graphics.Blit (from, to);
		}
	}
}
[ExecuteInEditMode]
[AddComponentMenu ("Image Effects/Blur")]
public class BlurEffect : MonoBehaviour
{
	public int iterations = 3;

	public float blurSpread = 0.6f;

	public Shader blurShader;

	private static Material m_Material;

	protected Material material {
		get {
			if (m_Material == null) {
				m_Material = new Material (blurShader);
				m_Material.hideFlags = HideFlags.DontSave;
			}
			return m_Material;
		}
	}

	protected void OnDisable ()
	{
		if ((bool)m_Material) {
			UnityEngine.Object.DestroyImmediate (m_Material);
		}
	}

	protected void Start ()
	{
		if (!SystemInfo.supportsImageEffects) {
			base.enabled = false;
		} else if (!blurShader || !material.shader.isSupported) {
			base.enabled = false;
		}
	}

	public void FourTapCone (RenderTexture source, RenderTexture dest, int iteration)
	{
		float num = 0.5f + (float)iteration * blurSpread;
		Graphics.BlitMultiTap (source, dest, material, new Vector2 (0f - num, 0f - num), new Vector2 (0f - num, num), new Vector2 (num, num), new Vector2 (num, 0f - num));
	}

	private void DownSample4x (RenderTexture source, RenderTexture dest)
	{
		float num = 1f;
		Graphics.BlitMultiTap (source, dest, material, new Vector2 (0f - num, 0f - num), new Vector2 (0f - num, num), new Vector2 (num, num), new Vector2 (num, 0f - num));
	}

	private void OnRenderImage (RenderTexture source, RenderTexture destination)
	{
		RenderTexture temporary = RenderTexture.GetTemporary (source.width / 4, source.height / 4, 0);
		RenderTexture temporary2 = RenderTexture.GetTemporary (source.width / 4, source.height / 4, 0);
		DownSample4x (source, temporary);
		bool flag = true;
		for (int i = 0; i < iterations; i++) {
			if (flag) {
				FourTapCone (temporary, temporary2, i);
			} else {
				FourTapCone (temporary2, temporary, i);
			}
			flag = !flag;
		}
		if (flag) {
			Graphics.Blit (temporary, destination);
		} else {
			Graphics.Blit (temporary2, destination);
		}
		RenderTexture.ReleaseTemporary (temporary);
		RenderTexture.ReleaseTemporary (temporary2);
	}
}
[ExecuteInEditMode]
[AddComponentMenu ("Image Effects/Color Correction (Ramp)")]
public class ColorCorrectionEffect : ImageEffectBase
{
	public Texture textureRamp;

	private void OnRenderImage (RenderTexture source, RenderTexture destination)
	{
		base.material.SetTexture ("_RampTex", textureRamp);
		Graphics.Blit (source, destination, base.material);
	}
}
[ExecuteInEditMode]
[AddComponentMenu ("Image Effects/Contrast Stretch")]
public class ContrastStretchEffect : MonoBehaviour
{
	public float adaptationSpeed = 0.02f;

	public float limitMinimum = 0.2f;

	public float limitMaximum = 0.6f;

	private RenderTexture[] adaptRenderTex = new RenderTexture[2];

	private int curAdaptIndex;

	public Shader shaderLum;

	private Material m_materialLum;

	public Shader shaderReduce;

	private Material m_materialReduce;

	public Shader shaderAdapt;

	private Material m_materialAdapt;

	public Shader shaderApply;

	private Material m_materialApply;

	protected Material materialLum {
		get {
			if (m_materialLum == null) {
				m_materialLum = new Material (shaderLum);
				m_materialLum.hideFlags = HideFlags.HideAndDontSave;
			}
			return m_materialLum;
		}
	}

	protected Material materialReduce {
		get {
			if (m_materialReduce == null) {
				m_materialReduce = new Material (shaderReduce);
				m_materialReduce.hideFlags = HideFlags.HideAndDontSave;
			}
			return m_materialReduce;
		}
	}

	protected Material materialAdapt {
		get {
			if (m_materialAdapt == null) {
				m_materialAdapt = new Material (shaderAdapt);
				m_materialAdapt.hideFlags = HideFlags.HideAndDontSave;
			}
			return m_materialAdapt;
		}
	}

	protected Material materialApply {
		get {
			if (m_materialApply == null) {
				m_materialApply = new Material (shaderApply);
				m_materialApply.hideFlags = HideFlags.HideAndDontSave;
			}
			return m_materialApply;
		}
	}

	private void Start ()
	{
		if (!SystemInfo.supportsImageEffects) {
			base.enabled = false;
		} else if (!shaderAdapt.isSupported || !shaderApply.isSupported || !shaderLum.isSupported || !shaderReduce.isSupported) {
			base.enabled = false;
		}
	}

	private void OnEnable ()
	{
		for (int i = 0; i < 2; i++) {
			if (!adaptRenderTex [i]) {
				adaptRenderTex [i] = new RenderTexture (1, 1, 32);
				adaptRenderTex [i].hideFlags = HideFlags.HideAndDontSave;
			}
		}
	}

	private void OnDisable ()
	{
		for (int i = 0; i < 2; i++) {
			UnityEngine.Object.DestroyImmediate (adaptRenderTex [i]);
			adaptRenderTex [i] = null;
		}
		if ((bool)m_materialLum) {
			UnityEngine.Object.DestroyImmediate (m_materialLum);
		}
		if ((bool)m_materialReduce) {
			UnityEngine.Object.DestroyImmediate (m_materialReduce);
		}
		if ((bool)m_materialAdapt) {
			UnityEngine.Object.DestroyImmediate (m_materialAdapt);
		}
		if ((bool)m_materialApply) {
			UnityEngine.Object.DestroyImmediate (m_materialApply);
		}
	}

	private void OnRenderImage (RenderTexture source, RenderTexture destination)
	{
		RenderTexture renderTexture = RenderTexture.GetTemporary (source.width, source.height);
		Graphics.Blit (source, renderTexture, materialLum);
		while (renderTexture.width > 1 || renderTexture.height > 1) {
			int num = renderTexture.width / 2;
			if (num < 1) {
				num = 1;
			}
			int num2 = renderTexture.height / 2;
			if (num2 < 1) {
				num2 = 1;
			}
			RenderTexture temporary = RenderTexture.GetTemporary (num, num2);
			Graphics.Blit (renderTexture, temporary, materialReduce);
			RenderTexture.ReleaseTemporary (renderTexture);
			renderTexture = temporary;
		}
		CalculateAdaptation (renderTexture);
		materialApply.SetTexture ("_AdaptTex", adaptRenderTex [curAdaptIndex]);
		Graphics.Blit (source, destination, materialApply);
		RenderTexture.ReleaseTemporary (renderTexture);
	}

	private void CalculateAdaptation (Texture curTexture)
	{
		int num = curAdaptIndex;
		curAdaptIndex = (curAdaptIndex + 1) % 2;
		float value = 1f - Mathf.Pow (1f - adaptationSpeed, 30f * Time.deltaTime);
		value = Mathf.Clamp (value, 0.01f, 1f);
		materialAdapt.SetTexture ("_CurTex", curTexture);
		materialAdapt.SetVector ("_AdaptParams", new Vector4 (value, limitMinimum, limitMaximum, 0f));
		Graphics.Blit (adaptRenderTex [num], adaptRenderTex [curAdaptIndex], materialAdapt);
	}
}
[ExecuteInEditMode]
[AddComponentMenu ("Image Effects/Edge Detection (Color)")]
public class EdgeDetectEffect : ImageEffectBase
{
	public float threshold = 0.2f;

	private void OnRenderImage (RenderTexture source, RenderTexture destination)
	{
		base.material.SetFloat ("_Treshold", threshold * threshold);
		Graphics.Blit (source, destination, base.material);
	}
}
[ExecuteInEditMode]
[RequireComponent (typeof(Camera))]
[AddComponentMenu ("Image Effects/Glow")]
public class GlowEffect : MonoBehaviour
{
	public float glowIntensity = 1.5f;

	public int blurIterations = 3;

	public float blurSpread = 0.7f;

	public Color glowTint = new Color (1f, 1f, 1f, 0f);

	public Shader compositeShader;

	private Material m_CompositeMaterial;

	public Shader blurShader;

	private Material m_BlurMaterial;

	public Shader downsampleShader;

	private Material m_DownsampleMaterial;

	protected Material compositeMaterial {
		get {
			if (m_CompositeMaterial == null) {
				m_CompositeMaterial = new Material (compositeShader);
				m_CompositeMaterial.hideFlags = HideFlags.HideAndDontSave;
			}
			return m_CompositeMaterial;
		}
	}

	protected Material blurMaterial {
		get {
			if (m_BlurMaterial == null) {
				m_BlurMaterial = new Material (blurShader);
				m_BlurMaterial.hideFlags = HideFlags.HideAndDontSave;
			}
			return m_BlurMaterial;
		}
	}

	protected Material downsampleMaterial {
		get {
			if (m_DownsampleMaterial == null) {
				m_DownsampleMaterial = new Material (downsampleShader);
				m_DownsampleMaterial.hideFlags = HideFlags.HideAndDontSave;
			}
			return m_DownsampleMaterial;
		}
	}

	protected void OnDisable ()
	{
		if ((bool)m_CompositeMaterial) {
			UnityEngine.Object.DestroyImmediate (m_CompositeMaterial);
		}
		if ((bool)m_BlurMaterial) {
			UnityEngine.Object.DestroyImmediate (m_BlurMaterial);
		}
		if ((bool)m_DownsampleMaterial) {
			UnityEngine.Object.DestroyImmediate (m_DownsampleMaterial);
		}
	}

	protected void Start ()
	{
		if (!SystemInfo.supportsImageEffects) {
			base.enabled = false;
			return;
		}
		if (downsampleShader == null) {
			UnityEngine.Debug.Log ("No downsample shader assigned! Disabling glow.");
			base.enabled = false;
			return;
		}
		if (!blurMaterial.shader.isSupported) {
			base.enabled = false;
		}
		if (!compositeMaterial.shader.isSupported) {
			base.enabled = false;
		}
		if (!downsampleMaterial.shader.isSupported) {
			base.enabled = false;
		}
	}

	public void FourTapCone (RenderTexture source, RenderTexture dest, int iteration)
	{
		float num = 0.5f + (float)iteration * blurSpread;
		Graphics.BlitMultiTap (source, dest, blurMaterial, new Vector2 (num, num), new Vector2 (0f - num, num), new Vector2 (num, 0f - num), new Vector2 (0f - num, 0f - num));
	}

	private void DownSample4x (RenderTexture source, RenderTexture dest)
	{
		downsampleMaterial.color = new Color (glowTint.r, glowTint.g, glowTint.b, glowTint.a / 4f);
		Graphics.Blit (source, dest, downsampleMaterial);
	}

	private void OnRenderImage (RenderTexture source, RenderTexture destination)
	{
		glowIntensity = Mathf.Clamp (glowIntensity, 0f, 10f);
		blurIterations = Mathf.Clamp (blurIterations, 0, 30);
		blurSpread = Mathf.Clamp (blurSpread, 0.5f, 1f);
		RenderTexture temporary = RenderTexture.GetTemporary (source.width / 4, source.height / 4, 0);
		RenderTexture temporary2 = RenderTexture.GetTemporary (source.width / 4, source.height / 4, 0);
		DownSample4x (source, temporary);
		float num = Mathf.Clamp01 ((glowIntensity - 1f) / 4f);
		blurMaterial.color = new Color (1f, 1f, 1f, 0.25f + num);
		bool flag = true;
		for (int i = 0; i < blurIterations; i++) {
			if (flag) {
				FourTapCone (temporary, temporary2, i);
			} else {
				FourTapCone (temporary2, temporary, i);
			}
			flag = !flag;
		}
		Graphics.Blit (source, destination);
		if (flag) {
			BlitGlow (temporary, destination);
		} else {
			BlitGlow (temporary2, destination);
		}
		RenderTexture.ReleaseTemporary (temporary);
		RenderTexture.ReleaseTemporary (temporary2);
	}

	public void BlitGlow (RenderTexture source, RenderTexture dest)
	{
		compositeMaterial.color = new Color (1f, 1f, 1f, Mathf.Clamp01 (glowIntensity));
		Graphics.Blit (source, dest, compositeMaterial);
	}
}
[ExecuteInEditMode]
[AddComponentMenu ("Image Effects/Grayscale")]
public class GrayscaleEffect : ImageEffectBase
{
	public float RampOffset;

	public Texture TextureRamp;

	public void OnRenderImageFun (RenderTexture source, RenderTexture destination)
	{
		base.material.SetTexture ("_RampTex", TextureRamp);
		base.material.SetFloat ("_RampOffset", RampOffset);
		Graphics.Blit (source, destination, base.material);
	}
}
[RequireComponent (typeof(Camera))]
[AddComponentMenu ("")]
public class ImageEffectBase : MonoBehaviour
{
	private Material m_Material;

	public Shader shader;

	protected Material material {
		get {
			if (m_Material == null) {
				m_Material = new Material (shader);
				m_Material.hideFlags = HideFlags.HideAndDontSave;
			}
			return m_Material;
		}
	}

	protected virtual void Start ()
	{
		if (!SystemInfo.supportsImageEffects) {
			base.enabled = false;
		} else if (!shader || !shader.isSupported) {
			base.enabled = false;
		}
	}

	protected virtual void OnDisable ()
	{
		if ((bool)m_Material) {
			UnityEngine.Object.DestroyImmediate (m_Material);
		}
	}
}
[AddComponentMenu ("")]
public class ImageEffects
{
	public static void RenderDistortion (Material material, RenderTexture source, RenderTexture destination, float angle, Vector2 center, Vector2 radius)
	{
		if (source.texelSize.y < 0f) {
			center.y = 1f - center.y;
			angle = 0f - angle;
		}
		Matrix4x4 value = Matrix4x4.TRS (Vector3.zero, Quaternion.Euler (0f, 0f, angle), Vector3.one);
		material.SetMatrix ("_RotationMatrix", value);
		material.SetVector ("_CenterRadius", new Vector4 (center.x, center.y, radius.x, radius.y));
		material.SetFloat ("_Angle", angle * ((float)Math.PI / 180f));
		Graphics.Blit (source, destination, material);
	}

	[Obsolete ("Use Graphics.Blit(source,dest) instead")]
	public static void Blit (RenderTexture source, RenderTexture dest)
	{
		Graphics.Blit (source, dest);
	}

	[Obsolete ("Use Graphics.Blit(source, destination, material) instead")]
	public static void BlitWithMaterial (Material material, RenderTexture source, RenderTexture dest)
	{
		Graphics.Blit (source, dest, material);
	}
}
[ExecuteInEditMode]
[AddComponentMenu ("Image Effects/Motion Blur (Color Accumulation)")]
[RequireComponent (typeof(Camera))]
public class MotionBlur : ImageEffectBase
{
	public float blurAmount = 0.8f;

	public bool extraBlur;

	private RenderTexture accumTexture;

	protected override void Start ()
	{
		if (!SystemInfo.supportsRenderTextures) {
			base.enabled = false;
		} else {
			base.Start ();
		}
	}

	protected override void OnDisable ()
	{
		base.OnDisable ();
		UnityEngine.Object.DestroyImmediate (accumTexture);
	}

	private void OnRenderImage (RenderTexture source, RenderTexture destination)
	{
		if (accumTexture == null || accumTexture.width != source.width || accumTexture.height != source.height) {
			UnityEngine.Object.DestroyImmediate (accumTexture);
			accumTexture = new RenderTexture (source.width, source.height, 0);
			accumTexture.hideFlags = HideFlags.HideAndDontSave;
			Graphics.Blit (source, accumTexture);
		}
		if (extraBlur) {
			RenderTexture temporary = RenderTexture.GetTemporary (source.width / 4, source.height / 4, 0);
			Graphics.Blit (accumTexture, temporary);
			Graphics.Blit (temporary, accumTexture);
			RenderTexture.ReleaseTemporary (temporary);
		}
		blurAmount = Mathf.Clamp (blurAmount, 0f, 0.92f);
		base.material.SetTexture ("_MainTex", accumTexture);
		base.material.SetFloat ("_AccumOrig", 1f - blurAmount);
		Graphics.Blit (source, accumTexture, base.material);
		Graphics.Blit (accumTexture, destination);
	}
}
[ExecuteInEditMode]
[RequireComponent (typeof(Camera))]
[AddComponentMenu ("Image Effects/Noise")]
public class NoiseEffect : MonoBehaviour
{
	public bool monochrome = true;

	private bool rgbFallback;

	public float grainIntensityMin = 0.1f;

	public float grainIntensityMax = 0.2f;

	public float grainSize = 2f;

	public float scratchIntensityMin = 0.05f;

	public float scratchIntensityMax = 0.25f;

	public float scratchFPS = 10f;

	public float scratchJitter = 0.01f;

	public Texture grainTexture;

	public Texture scratchTexture;

	public Shader shaderRGB;

	public Shader shaderYUV;

	private Material m_MaterialRGB;

	private Material m_MaterialYUV;

	private float scratchTimeLeft;

	private float scratchX;

	private float scratchY;

	protected Material material {
		get {
			if (m_MaterialRGB == null) {
				m_MaterialRGB = new Material (shaderRGB);
				m_MaterialRGB.hideFlags = HideFlags.HideAndDontSave;
			}
			if (m_MaterialYUV == null && !rgbFallback) {
				m_MaterialYUV = new Material (shaderYUV);
				m_MaterialYUV.hideFlags = HideFlags.HideAndDontSave;
			}
			return (rgbFallback || monochrome) ? m_MaterialRGB : m_MaterialYUV;
		}
	}

	protected void Start ()
	{
		if (!SystemInfo.supportsImageEffects) {
			base.enabled = false;
		} else if (shaderRGB == null || shaderYUV == null) {
			UnityEngine.Debug.Log ("Noise shaders are not set up! Disabling noise effect.");
			base.enabled = false;
		} else if (!shaderRGB.isSupported) {
			base.enabled = false;
		} else if (!shaderYUV.isSupported) {
			rgbFallback = true;
		}
	}

	protected void OnDisable ()
	{
		if ((bool)m_MaterialRGB) {
			UnityEngine.Object.DestroyImmediate (m_MaterialRGB);
		}
		if ((bool)m_MaterialYUV) {
			UnityEngine.Object.DestroyImmediate (m_MaterialYUV);
		}
	}

	private void SanitizeParameters ()
	{
		grainIntensityMin = Mathf.Clamp (grainIntensityMin, 0f, 5f);
		grainIntensityMax = Mathf.Clamp (grainIntensityMax, 0f, 5f);
		scratchIntensityMin = Mathf.Clamp (scratchIntensityMin, 0f, 5f);
		scratchIntensityMax = Mathf.Clamp (scratchIntensityMax, 0f, 5f);
		scratchFPS = Mathf.Clamp (scratchFPS, 1f, 30f);
		scratchJitter = Mathf.Clamp (scratchJitter, 0f, 1f);
		grainSize = Mathf.Clamp (grainSize, 0.1f, 50f);
	}

	private void OnRenderImage (RenderTexture source, RenderTexture destination)
	{
		SanitizeParameters ();
		if (scratchTimeLeft <= 0f) {
			scratchTimeLeft = UnityEngine.Random.value * 2f / scratchFPS;
			scratchX = UnityEngine.Random.value;
			scratchY = UnityEngine.Random.value;
		}
		scratchTimeLeft -= Time.deltaTime;
		Material material = this.material;
		material.SetTexture ("_GrainTex", grainTexture);
		material.SetTexture ("_ScratchTex", scratchTexture);
		float num = 1f / grainSize;
		material.SetVector ("_GrainOffsetScale", new Vector4 (UnityEngine.Random.value, UnityEngine.Random.value, (float)Screen.width / (float)grainTexture.width * num, (float)Screen.height / (float)grainTexture.height * num));
		material.SetVector ("_ScratchOffsetScale", new Vector4 (scratchX + UnityEngine.Random.value * scratchJitter, scratchY + UnityEngine.Random.value * scratchJitter, (float)Screen.width / (float)scratchTexture.width, (float)Screen.height / (float)scratchTexture.height));
		material.SetVector ("_Intensity", new Vector4 (UnityEngine.Random.Range (grainIntensityMin, grainIntensityMax), UnityEngine.Random.Range (scratchIntensityMin, scratchIntensityMax), 0f, 0f));
		Graphics.Blit (source, destination, material);
	}
}
[ExecuteInEditMode]
[RequireComponent (typeof(Camera))]
public class PostEffectsBaseInCsharp : MonoBehaviour
{
	protected bool supportHDRTextures = true;

	protected bool supportDX11;

	protected bool isSupported = true;

	public Material CheckShaderAndCreateMaterial (Shader s, Material m2Create)
	{
		if (!s) {
			UnityEngine.Debug.Log ("Missing shader in " + ToString ());
			base.enabled = false;
			return null;
		}
		if (s.isSupported && (bool)m2Create && m2Create.shader == s) {
			return m2Create;
		}
		if (!s.isSupported) {
			NotSupported ();
			UnityEngine.Debug.Log ("The shader " + s.ToString () + " on effect " + ToString () + " is not supported on this platform!");
			return null;
		}
		m2Create = new Material (s);
		m2Create.hideFlags = HideFlags.DontSave;
		if ((bool)m2Create) {
			return m2Create;
		}
		return null;
	}

	private Material CreateMaterial (Shader s, Material m2Create)
	{
		if (!s) {
			UnityEngine.Debug.Log ("Missing shader in " + ToString ());
			return null;
		}
		if ((bool)m2Create && m2Create.shader == s && s.isSupported) {
			return m2Create;
		}
		if (!s.isSupported) {
			return null;
		}
		m2Create = new Material (s);
		m2Create.hideFlags = HideFlags.DontSave;
		if ((bool)m2Create) {
			return m2Create;
		}
		return null;
	}

	private void OnEnable ()
	{
		isSupported = true;
	}

	public bool CheckSupport ()
	{
		return CheckSupport (needDepth: false);
	}

	protected bool CheckResources ()
	{
		UnityEngine.Debug.LogWarning ("CheckResources () for " + ToString () + " should be overwritten.");
		return isSupported;
	}

	public bool CheckSupport (bool needDepth)
	{
		isSupported = true;
		supportHDRTextures = SystemInfo.SupportsRenderTextureFormat (RenderTextureFormat.ARGBHalf);
		supportDX11 = SystemInfo.graphicsShaderLevel >= 50 && SystemInfo.supportsComputeShaders;
		if (!SystemInfo.supportsImageEffects || !SystemInfo.supportsRenderTextures) {
			NotSupported ();
			return false;
		}
		if (needDepth && !SystemInfo.SupportsRenderTextureFormat (RenderTextureFormat.Depth)) {
			NotSupported ();
			return false;
		}
		if (needDepth) {
			GetComponent<Camera> ().depthTextureMode |= DepthTextureMode.Depth;
		}
		return true;
	}

	private bool CheckSupport (bool needDepth, bool needHdr)
	{
		if (!CheckSupport (needDepth)) {
			return false;
		}
		if (needHdr && !supportHDRTextures) {
			NotSupported ();
			return false;
		}
		return true;
	}

	private bool Dx11Support ()
	{
		return supportDX11;
	}

	public void ReportAutoDisable ()
	{
		UnityEngine.Debug.LogWarning ("The image effect " + ToString () + " has been disabled as it's not supported on the current platform.");
	}

	private bool CheckShader (Shader s)
	{
		UnityEngine.Debug.Log ("The shader " + s.ToString () + " on effect " + ToString () + " is not part of the Unity 3.2f+ effects suite anymore. For best performance and quality, please ensure you are using the latest Standard Assets Image Effects (Pro only) package.");
		if (!s.isSupported) {
			NotSupported ();
			return false;
		}
		return false;
	}

	private void NotSupported ()
	{
		base.enabled = false;
		isSupported = false;
	}

	private void DrawBorder (RenderTexture dest, Material material)
	{
		RenderTexture.active = dest;
		bool flag = true;
		GL.PushMatrix ();
		GL.LoadOrtho ();
		for (int i = 0; i < material.passCount; i++) {
			material.SetPass (i);
			float y;
			float y2;
			if (flag) {
				y = 1f;
				y2 = 0f;
			} else {
				y = 0f;
				y2 = 1f;
			}
			float x = 0f;
			float x2 = 1f / ((float)dest.width * 1f);
			float y3 = 0f;
			float y4 = 1f;
			GL.Begin (7);
			GL.TexCoord2 (0f, y);
			GL.Vertex3 (x, y3, 0.1f);
			GL.TexCoord2 (1f, y);
			GL.Vertex3 (x2, y3, 0.1f);
			GL.TexCoord2 (1f, y2);
			GL.Vertex3 (x2, y4, 0.1f);
			GL.TexCoord2 (0f, y2);
			GL.Vertex3 (x, y4, 0.1f);
			x = 1f - 1f / ((float)dest.width * 1f);
			x2 = 1f;
			y3 = 0f;
			y4 = 1f;
			GL.TexCoord2 (0f, y);
			GL.Vertex3 (x, y3, 0.1f);
			GL.TexCoord2 (1f, y);
			GL.Vertex3 (x2, y3, 0.1f);
			GL.TexCoord2 (1f, y2);
			GL.Vertex3 (x2, y4, 0.1f);
			GL.TexCoord2 (0f, y2);
			GL.Vertex3 (x, y4, 0.1f);
			x = 0f;
			x2 = 1f;
			y3 = 0f;
			y4 = 1f / ((float)dest.height * 1f);
			GL.TexCoord2 (0f, y);
			GL.Vertex3 (x, y3, 0.1f);
			GL.TexCoord2 (1f, y);
			GL.Vertex3 (x2, y3, 0.1f);
			GL.TexCoord2 (1f, y2);
			GL.Vertex3 (x2, y4, 0.1f);
			GL.TexCoord2 (0f, y2);
			GL.Vertex3 (x, y4, 0.1f);
			x = 0f;
			x2 = 1f;
			y3 = 1f - 1f / ((float)dest.height * 1f);
			y4 = 1f;
			GL.TexCoord2 (0f, y);
			GL.Vertex3 (x, y3, 0.1f);
			GL.TexCoord2 (1f, y);
			GL.Vertex3 (x2, y3, 0.1f);
			GL.TexCoord2 (1f, y2);
			GL.Vertex3 (x2, y4, 0.1f);
			GL.TexCoord2 (0f, y2);
			GL.Vertex3 (x, y4, 0.1f);
			GL.End ();
		}
		GL.PopMatrix ();
	}
}
[ExecuteInEditMode]
[RequireComponent (typeof(Camera))]
[AddComponentMenu ("Image Effects/Screen Space Ambient Occlusion")]
public class SSAOEffect : MonoBehaviour
{
	public enum SSAOSamples
	{
		Low,
		Medium,
		High
	}

	public float m_Radius = 0.4f;

	public SSAOSamples m_SampleCount = SSAOSamples.Medium;

	public float m_OcclusionIntensity = 1.5f;

	public int m_Blur = 2;

	public int m_Downsampling = 2;

	public float m_OcclusionAttenuation = 1f;

	public float m_MinZ = 0.01f;

	public Shader m_SSAOShader;

	private Material m_SSAOMaterial;

	public Texture2D m_RandomTexture;

	private bool m_Supported;

	private static Material CreateMaterial (Shader shader)
	{
		if (!shader) {
			return null;
		}
		Material material = new Material (shader);
		material.hideFlags = HideFlags.HideAndDontSave;
		return material;
	}

	private static void DestroyMaterial (Material mat)
	{
		if ((bool)mat) {
			UnityEngine.Object.DestroyImmediate (mat);
			mat = null;
		}
	}

	private void OnDisable ()
	{
		DestroyMaterial (m_SSAOMaterial);
	}

	private void Start ()
	{
		if (!SystemInfo.supportsImageEffects || !SystemInfo.SupportsRenderTextureFormat (RenderTextureFormat.Depth)) {
			m_Supported = false;
			base.enabled = false;
			return;
		}
		CreateMaterials ();
		if (!m_SSAOMaterial || m_SSAOMaterial.passCount != 5) {
			m_Supported = false;
			base.enabled = false;
		} else {
			m_Supported = true;
		}
	}

	private void OnEnable ()
	{
		GetComponent<Camera> ().depthTextureMode |= DepthTextureMode.DepthNormals;
	}

	private void CreateMaterials ()
	{
		if (!m_SSAOMaterial && m_SSAOShader.isSupported) {
			m_SSAOMaterial = CreateMaterial (m_SSAOShader);
			m_SSAOMaterial.SetTexture ("_RandomTexture", m_RandomTexture);
		}
	}

	[ImageEffectOpaque]
	private void OnRenderImage (RenderTexture source, RenderTexture destination)
	{
		if (!m_Supported || !m_SSAOShader.isSupported) {
			base.enabled = false;
			return;
		}
		CreateMaterials ();
		m_Downsampling = Mathf.Clamp (m_Downsampling, 1, 6);
		m_Radius = Mathf.Clamp (m_Radius, 0.05f, 1f);
		m_MinZ = Mathf.Clamp (m_MinZ, 1E-05f, 0.5f);
		m_OcclusionIntensity = Mathf.Clamp (m_OcclusionIntensity, 0.5f, 4f);
		m_OcclusionAttenuation = Mathf.Clamp (m_OcclusionAttenuation, 0.2f, 2f);
		m_Blur = Mathf.Clamp (m_Blur, 0, 4);
		RenderTexture renderTexture = RenderTexture.GetTemporary (source.width / m_Downsampling, source.height / m_Downsampling, 0);
		float fieldOfView = GetComponent<Camera> ().fieldOfView;
		float farClipPlane = GetComponent<Camera> ().farClipPlane;
		float num = Mathf.Tan (fieldOfView * ((float)Math.PI / 180f) * 0.5f) * farClipPlane;
		float x = num * GetComponent<Camera> ().aspect;
		m_SSAOMaterial.SetVector ("_FarCorner", new Vector3 (x, num, farClipPlane));
		int num2;
		int num3;
		if ((bool)m_RandomTexture) {
			num2 = m_RandomTexture.width;
			num3 = m_RandomTexture.height;
		} else {
			num2 = 1;
			num3 = 1;
		}
		m_SSAOMaterial.SetVector ("_NoiseScale", new Vector3 ((float)renderTexture.width / (float)num2, (float)renderTexture.height / (float)num3, 0f));
		m_SSAOMaterial.SetVector ("_Params", new Vector4 (m_Radius, m_MinZ, 1f / m_OcclusionAttenuation, m_OcclusionIntensity));
		bool flag = m_Blur > 0;
		Graphics.Blit ((!flag) ? source : null, renderTexture, m_SSAOMaterial, (int)m_SampleCount);
		if (flag) {
			RenderTexture temporary = RenderTexture.GetTemporary (source.width, source.height, 0);
			m_SSAOMaterial.SetVector ("_TexelOffsetScale", new Vector4 ((float)m_Blur / (float)source.width, 0f, 0f, 0f));
			m_SSAOMaterial.SetTexture ("_SSAO", renderTexture);
			Graphics.Blit (null, temporary, m_SSAOMaterial, 3);
			RenderTexture.ReleaseTemporary (renderTexture);
			RenderTexture temporary2 = RenderTexture.GetTemporary (source.width, source.height, 0);
			m_SSAOMaterial.SetVector ("_TexelOffsetScale", new Vector4 (0f, (float)m_Blur / (float)source.height, 0f, 0f));
			m_SSAOMaterial.SetTexture ("_SSAO", temporary);
			Graphics.Blit (source, temporary2, m_SSAOMaterial, 3);
			RenderTexture.ReleaseTemporary (temporary);
			renderTexture = temporary2;
		}
		m_SSAOMaterial.SetTexture ("_SSAO", renderTexture);
		Graphics.Blit (source, destination, m_SSAOMaterial, 4);
		RenderTexture.ReleaseTemporary (renderTexture);
	}
}
[ExecuteInEditMode]
[AddComponentMenu ("Image Effects/Sepia Tone")]
public class SepiaToneEffect : ImageEffectBase
{
	private void OnRenderImage (RenderTexture source, RenderTexture destination)
	{
		Graphics.Blit (source, destination, base.material);
	}
}
[ExecuteInEditMode]
[AddComponentMenu ("Image Effects/Twirl")]
public class TwirlEffect : ImageEffectBase
{
	public Vector2 radius = new Vector2 (0.3f, 0.3f);

	public float angle = 50f;

	public Vector2 center = new Vector2 (0.5f, 0.5f);

	private void OnRenderImage (RenderTexture source, RenderTexture destination)
	{
		ImageEffects.RenderDistortion (base.material, source, destination, angle, center, radius);
	}
}
[ExecuteInEditMode]
[RequireComponent (typeof(Camera))]
[AddComponentMenu ("Image Efects/Vignette and Chromatic Aberration New In Csharp")]
public class VignettingInCsharp : PostEffectsBaseInCsharp
{
	public enum AberrationMode
	{
		Simple,
		Advanced
	}

	public AberrationMode mode;

	public float intensity = 0.375f;

	public float chromaticAberration = 0.2f;

	public float axialAberration = 0.5f;

	public float blur;

	public float blurSpread = 0.75f;

	public float luminanceDependency = 0.25f;

	public Shader vignetteShader;

	private Material vignetteMaterial;

	public Shader separableBlurShader;

	private Material separableBlurMaterial;

	public Shader chromAberrationShader;

	private Material chromAberrationMaterial;

	private void Start ()
	{
		CheckResources ();
	}

	public new bool CheckResources ()
	{
		CheckSupport (needDepth: false);
		vignetteMaterial = CheckShaderAndCreateMaterial (vignetteShader, vignetteMaterial);
		separableBlurMaterial = CheckShaderAndCreateMaterial (separableBlurShader, separableBlurMaterial);
		chromAberrationMaterial = CheckShaderAndCreateMaterial (chromAberrationShader, chromAberrationMaterial);
		if (!isSupported) {
			ReportAutoDisable ();
		}
		return isSupported;
	}

	public void OnRenderImageFun (RenderTexture source, RenderTexture destination)
	{
		if (!CheckResources ()) {
			Graphics.Blit (source, destination);
			return;
		}
		bool flag = Mathf.Abs (blur) > 0f || Mathf.Abs (intensity) > 0f;
		float num = 1f * (float)source.width / (1f * (float)source.height);
		float num2 = 0.001953125f;
		RenderTexture renderTexture = null;
		RenderTexture renderTexture2 = null;
		RenderTexture renderTexture3 = null;
		if (flag) {
			renderTexture = RenderTexture.GetTemporary (source.width, source.height, 0, source.format);
			if (Mathf.Abs (blur) > 0f) {
				renderTexture2 = RenderTexture.GetTemporary (source.width / 2, source.height / 2, 0, source.format);
				renderTexture3 = RenderTexture.GetTemporary (source.width / 2, source.height / 2, 0, source.format);
				Graphics.Blit (source, renderTexture2, chromAberrationMaterial, 0);
				for (int i = 0; i < 2; i++) {
					separableBlurMaterial.SetVector ("offsets", new Vector4 (0f, blurSpread * num2, 0f, 0f));
					Graphics.Blit (renderTexture2, renderTexture3, separableBlurMaterial);
					separableBlurMaterial.SetVector ("offsets", new Vector4 (blurSpread * num2 / num, 0f, 0f, 0f));
					Graphics.Blit (renderTexture3, renderTexture2, separableBlurMaterial);
				}
			}
			vignetteMaterial.SetFloat ("_Intensity", intensity);
			vignetteMaterial.SetFloat ("_Blur", blur);
			vignetteMaterial.SetTexture ("_VignetteTex", renderTexture2);
			Graphics.Blit (source, renderTexture, vignetteMaterial, 0);
		}
		chromAberrationMaterial.SetFloat ("_ChromaticAberration", chromaticAberration);
		chromAberrationMaterial.SetFloat ("_AxialAberration", axialAberration);
		chromAberrationMaterial.SetFloat ("_Luminance", 1f / (Mathf.Epsilon + luminanceDependency));
		if (flag) {
			renderTexture.wrapMode = TextureWrapMode.Clamp;
		} else {
			source.wrapMode = TextureWrapMode.Clamp;
		}
		Graphics.Blit ((!flag) ? source : renderTexture, destination, chromAberrationMaterial, (mode != AberrationMode.Advanced) ? 1 : 2);
		if ((bool)renderTexture) {
			RenderTexture.ReleaseTemporary (renderTexture);
		}
		if ((bool)renderTexture2) {
			RenderTexture.ReleaseTemporary (renderTexture2);
		}
		if ((bool)renderTexture3) {
			RenderTexture.ReleaseTemporary (renderTexture3);
		}
	}
}
[ExecuteInEditMode]
[AddComponentMenu ("Image Effects/Vortex")]
public class VortexEffect : ImageEffectBase
{
	public Vector2 radius = new Vector2 (0.4f, 0.4f);

	public float angle = 50f;

	public Vector2 center = new Vector2 (0.5f, 0.5f);

	private void OnRenderImage (RenderTexture source, RenderTexture destination)
	{
		ImageEffects.RenderDistortion (base.material, source, destination, angle, center, radius);
	}
}
public class ActivateTrigger : MonoBehaviour
{
	public enum Mode
	{
		Trigger,
		Replace,
		Activate,
		Enable,
		Animate,
		Deactivate
	}

	public Mode action = Mode.Activate;

	public UnityEngine.Object target;

	public GameObject source;

	public int triggerCount = 1;

	public bool repeatTrigger;

	private void DoActivateTrigger ()
	{
		triggerCount--;
		if (triggerCount != 0 && !repeatTrigger) {
			return;
		}
		UnityEngine.Object @object = ((!(target != null)) ? base.gameObject : target);
		Behaviour behaviour = @object as Behaviour;
		GameObject gameObject = @object as GameObject;
		if (behaviour != null) {
			gameObject = behaviour.gameObject;
		}
		switch (action) {
		case Mode.Trigger:
			gameObject.BroadcastMessage ("DoActivateTrigger");
			break;
		case Mode.Replace:
			if (source != null) {
				UnityEngine.Object.Instantiate (source, gameObject.transform.position, gameObject.transform.rotation);
				UnityEngine.Object.DestroyObject (gameObject);
			}
			break;
		case Mode.Activate:
			gameObject.SetActive (value: true);
			break;
		case Mode.Enable:
			if (behaviour != null) {
				behaviour.enabled = true;
			}
			break;
		case Mode.Animate:
			gameObject.GetComponent<Animation> ().Play ();
			break;
		case Mode.Deactivate:
			gameObject.SetActive (value: false);
			break;
		}
	}

	private void OnTriggerEnter (Collider other)
	{
		DoActivateTrigger ();
	}
}
