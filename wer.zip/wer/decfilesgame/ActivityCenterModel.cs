public class ActivityCenterModel
{
	public EnumActivityCenter Type;

	public int PicID;

	public EnumActivityCenterTemplate TemplateType;

	public CommonActivityModel CommonActivityData;

	public ActivityCenterModel(EnumActivityCenter type, int picID, EnumActivityCenterTemplate templateType, CommonActivityModel commonActivityData = null)
	{
		Type = type;
		PicID = picID;
		TemplateType = templateType;
		CommonActivityData = commonActivityData;
	}
}
