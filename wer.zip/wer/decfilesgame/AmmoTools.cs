using System;
using ClientSocket;
using TK;
using UnityEngine;

public class AmmoTools
{
	public static AmmoInfo MainPlayerLastHitAmmo;

	public static FunctionAmmoPath GetAmmoPath(Vector3 startPos, Vector3 endPos, float speed, float g = 0f)
	{
		FunctionAmmoPath functionAmmoPath = new FunctionAmmoPath();
		functionAmmoPath.StartPoint = startPos;
		functionAmmoPath.G = g;
		Vector3 vector = endPos - startPos;
		if (Mathf.Abs(g) < float.Epsilon)
		{
			functionAmmoPath.HitNeedTime = vector.magnitude / speed;
			functionAmmoPath.StartVelocity = vector / functionAmmoPath.HitNeedTime;
		}
		else
		{
			float num = g * g;
			float num2 = speed * speed;
			double num3 = Math.Pow(vector.y * g - num2, 2.0) - (double)(num * vector.sqrMagnitude);
			if (num3 <= 0.0)
			{
				return GetAmmoPath(startPos, endPos, speed);
			}
			double d = ((double)(num2 - g * vector.y) - Math.Sqrt(num3)) * 2.0 / (double)num;
			float num4 = (functionAmmoPath.HitNeedTime = (float)Math.Sqrt(d));
			functionAmmoPath.StartVelocity.Set(vector.x / num4, vector.y / num4 + 0.5f * g * num4, vector.z / num4);
		}
		return functionAmmoPath;
	}

	public static FunctionAmmoPath GetAmmoPath(Vector3 startPos, Vector3 startVelocity, Vector3 endPos)
	{
		FunctionAmmoPath functionAmmoPath = new FunctionAmmoPath();
		functionAmmoPath.StartPoint = startPos;
		functionAmmoPath.G = 0f;
		functionAmmoPath.StartVelocity = startVelocity;
		Vector3 vector = endPos - startPos;
		if (Mathf.Abs(startVelocity.x) > float.Epsilon)
		{
			functionAmmoPath.HitNeedTime = vector.x / startVelocity.x;
		}
		else if (Mathf.Abs(startVelocity.z) > float.Epsilon)
		{
			functionAmmoPath.HitNeedTime = vector.z / startVelocity.z;
		}
		else
		{
			Debug.LogWarning("Speed is 0, can not be calculated");
			functionAmmoPath.HitNeedTime = 0f;
		}
		return functionAmmoPath;
	}

	public static bool CheckHit(Vector3 startPoint, Vector3 endPoint, out RaycastHit hitInfo)
	{
		Vector3 direction = endPoint - startPoint;
		return TankTools.CalDamageHit(startPoint, direction, direction.magnitude, out hitInfo);
	}

	public static void DoMainPlayerDamageAmmoAudio(EShootTip shootTip)
	{
		if (MainPlayerLastHitAmmo == null)
		{
			TKLog.LogError("MainPlayerDamageAmmoAudio Error LastHitAmmo is null");
			return;
		}
		Vector3 realHitWorldPosition = MainPlayerLastHitAmmo.GetRealHitWorldPosition();
		switch (shootTip)
		{
		case EShootTip.ESTipFailPierce:
			ResourcesManager.Audio.PlayAudioOnce(MainPlayerLastHitAmmo.TableShell.audio_notpenetrate, realHitWorldPosition);
			break;
		case EShootTip.ESTipJumpBullet:
			ResourcesManager.Audio.PlayAudioOnce(MainPlayerLastHitAmmo.TableShell.audio_ricochet, realHitWorldPosition);
			break;
		default:
			ResourcesManager.Audio.PlayAudioOnce(MainPlayerLastHitAmmo.TableShell.audio_penetrate, realHitWorldPosition);
			break;
		}
	}

	public static void DoAmmoAudioAndEffect(Table_Shell tableShell, int hitLayer, int hitModel, Vector3 pos, Vector3 normal, ShootResult shootResult)
	{
		int audioId = 0;
		int effectId = 0;
		if (GameManager.EnvManager.IsTank(hitLayer))
		{
			effectId = tableShell.effect_penetrate;
			switch (shootResult)
			{
			case ShootResult.Fail:
				audioId = tableShell.audio_notpenetrate;
				break;
			case ShootResult.JumpBullet:
				audioId = tableShell.audio_ricochet;
				break;
			default:
				audioId = tableShell.audio_penetrate;
				break;
			case ShootResult.Error:
				break;
			}
		}
		else if (hitLayer == 10)
		{
			GameManager.TableMgr.GetHitTerrainInfo(tableShell, ref effectId, ref audioId);
		}
		else
		{
			switch (hitModel)
			{
			case 1:
				effectId = tableShell.effect_stone;
				audioId = tableShell.audio_stone;
				break;
			case 2:
				effectId = tableShell.effect_tree;
				audioId = tableShell.audio_tree;
				break;
			case 3:
				effectId = tableShell.effect_ground;
				audioId = tableShell.audio_ground;
				break;
			case 4:
				effectId = tableShell.effect_water;
				audioId = tableShell.audio_water;
				break;
			case 5:
				effectId = tableShell.effect_stone;
				audioId = tableShell.audio_stone;
				break;
			case 6:
				effectId = tableShell.effect_stone;
				audioId = tableShell.audio_stone;
				break;
			case 7:
				effectId = tableShell.effect_building;
				audioId = tableShell.audio_stone;
				break;
			case 11:
				effectId = tableShell.effect_ice;
				audioId = tableShell.audio_ice;
				break;
			case 8:
				GameManager.TableMgr.GetHitTerrainInfo(tableShell, ref effectId, ref audioId);
				break;
			default:
				effectId = tableShell.effect_ground;
				audioId = tableShell.audio_ground;
				break;
			case 14:
				return;
			}
		}
		ResourcesManager.Audio.PlayAudioOnce(audioId, pos);
		if (!GameManager.SettingManager.ImageSet.FireHit)
		{
			return;
		}
		if (CommonTools.CheckParticleUseGameObjPool(effectId))
		{
			ResourcesManager.Particle.PlayEffectWithGameObjPool(effectId, pos, normal);
			return;
		}
		ResourcesManager.Instance.Retrieve(effectId, ResourceType.Particle, GameManager.IsRoomLevel, delegate(UnityEngine.Object asset)
		{
			GameObject p = CommonTools.InstantiateObject(asset);
			Emit(p, pos, normal);
		});
	}

	private static void Emit(GameObject p, Vector3 pos, Vector3 normal)
	{
		p.transform.position = pos;
		p.transform.rotation = Quaternion.FromToRotation(Vector3.up, normal);
	}

	public static void SyncSpecialObjectSceneInfo(ushort id, Vector3 pos)
	{
		SceneRoom.Instance.GetRoom().GetSpecialObject().OnSyncCrashUp(id, pos);
	}

	public static uint GetTimeStamp()
	{
		return (uint)(Time.time * 1000f);
	}

	public static PK_HitTankInfo GetHitTankInfo(long guid)
	{
		PK_HitTankInfo pK_HitTankInfo = new PK_HitTankInfo();
		PlayerProxy playerByID = SceneRoom.Instance.GetRoom().GetPlayerByID(guid);
		if (playerByID == null)
		{
			TKLog.LogError("HitPlayer is not exsit: " + guid);
			return null;
		}
		pK_HitTankInfo.PlayerGuid = guid;
		pK_HitTankInfo.TankStateNo = playerByID.TankStateSync.StateNumber;
		pK_HitTankInfo.TankPos = playerByID.Trans.position;
		pK_HitTankInfo.TankRotation = playerByID.Trans.eulerAngles;
		pK_HitTankInfo.TurretAngle = playerByID.TankStateSync.TurretSync.CurAngle;
		pK_HitTankInfo.GunAngle = playerByID.TankStateSync.GunSync.CurAngle;
		pK_HitTankInfo.HullAngle = playerByID.TankModel.Hull.localEulerAngles;
		pK_HitTankInfo.HullY = playerByID.TankModel.Hull.localPosition.y;
		return pK_HitTankInfo;
	}
}
