using System.Text;
using UnityEngine;

public class ApSendData
{
	public long PlayerGuid;

	public byte[] Type;

	public byte[] Ind;

	public float[] Dis;

	public Vector3 HitPoint;

	public byte Angle;

	public Vector3 Normal;

	public Vector3 OnTankHit;

	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("[ApSendData]");
		stringBuilder.AppendLine("Angle: " + Angle);
		stringBuilder.AppendLine("HitPoint: " + CommonTools.ToString(HitPoint));
		for (int i = 0; i < Type.Length; i++)
		{
			stringBuilder.AppendLine(Dis[i] + "," + Type[i] + "," + Ind[i]);
		}
		return stringBuilder.ToString();
	}
}
