using UnityEngine;

public class AmmoStateFlyRemoteUnReach : AmmoStateBase
{
	private bool _remoteHasFirstOverHitNeedTime;

	private AmmoStateType _tempNextStateType;

	public AmmoStateFlyRemoteUnReach()
	{
		_remoteHasFirstOverHitNeedTime = false;
		_tempNextStateType = AmmoStateType.Invaid;
	}

	public override void EnterState(CAmmoStateParam param)
	{
		param.CurState = AmmoStateType.FlyRemoteHitpacketUnreachedFly;
	}

	public override bool UpdateState(CAmmoStateParam param)
	{
		if (param.Ammo.HasTouchDown)
		{
			_tempNextStateType = AmmoStateType.FlyRemoteHitpacketReachedFly;
			return true;
		}
		param.LiveTime += Time.fixedDeltaTime * 0.5f;
		Vector3 positionByTime;
		if (!_remoteHasFirstOverHitNeedTime)
		{
			if (param.LiveTime < param.HitPath.HitNeedTime)
			{
				positionByTime = param.AmmoPath.GetPositionByTime(param.LiveTime);
			}
			else
			{
				param.LiveTime = param.HitPath.HitNeedTime;
				positionByTime = param.HitPath.GetPositionByTime(param.LiveTime);
				_remoteHasFirstOverHitNeedTime = true;
			}
		}
		else
		{
			positionByTime = param.HitPath.GetPositionByTime(param.LiveTime);
		}
		param.Trans.position = positionByTime;
		if (param.Ammo.OverMaxDistance(positionByTime))
		{
			param.HasReadyDestory = true;
			_tempNextStateType = AmmoStateType.Bomb;
			return true;
		}
		return false;
	}

	public override void LeaveState(CAmmoStateParam param, ref AmmoStateType nextstate)
	{
		nextstate = _tempNextStateType;
	}
}
