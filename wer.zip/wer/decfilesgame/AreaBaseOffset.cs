public class AreaBaseOffset : UIButtonOffset
{
	public override void OnPress(bool isPressed)
	{
	}

	public override void OnHover(bool isOver)
	{
	}

	public void SetOnPress(bool isPressed)
	{
		if (base.enabled)
		{
			if (!mInitDone)
			{
				Init();
			}
			TweenPosition.Begin(tweenTarget.gameObject, duration, (!isPressed) ? mPos : (mPos + pressed)).method = UITweener.Method.EaseInOut;
		}
	}

	public void SetOnHover(bool isOver)
	{
		if (base.enabled)
		{
			if (!mInitDone)
			{
				Init();
			}
			TweenPosition.Begin(tweenTarget.gameObject, duration, (!isOver) ? mPos : (mPos + hover)).method = UITweener.Method.EaseInOut;
			mHighlighted = isOver;
		}
	}
}
