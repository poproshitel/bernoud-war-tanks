using SceneCameraStruct;
using UnityEngine;

public class AmmoControl : MonoBehaviour
{
	private CAmmoStateParam _ammoParam;

	private CAmmoStateManager _ammoStateMgr;

	private ShellTrailRenderer _trailcomponent;

	private Vector3 _gunPos;

	private GunSyncData _gunSyncData;

	private bool isLaser;

	public bool IsDestory;

	public void Init(GunSyncData data, AmmoInfo ammo)
	{
		_gunSyncData = data;
		_preLoadResource();
		_initAmmoInfo(ammo);
		_isInTraining();
		_initTrailMeshRenderer();
		_initAmmoStateMachine();
	}

	private void _preLoadResource()
	{
		ResourcesManager.Instance.Retrieve(403, ResourceType.Particle);
		ResourcesManager.Instance.Retrieve(440, ResourceType.Particle);
		ResourcesManager.Instance.Retrieve(441, ResourceType.Particle);
		ResourcesManager.Instance.Retrieve(442, ResourceType.Particle);
	}

	private void FixedUpdate()
	{
		if (_ammoParam.LiveTime > 10f)
		{
			_ammoParam.Ammo.DisposeMe();
			_destroySelf();
		}
		if (!_ammoParam.HasReadyDestory)
		{
			if (_ammoStateMgr != null)
			{
				_ammoStateMgr.Update();
			}
		}
		else
		{
			_destoryAmmo();
		}
		UpdateLaserTransform();
	}

	private void _isInTraining()
	{
		if (_ammoParam != null)
		{
			_ammoParam.IsInTraining = GameManager.Instance.GameType == GameType.Train;
		}
	}

	private void _initAmmoInfo(AmmoInfo ammo)
	{
		_ammoParam = new CAmmoStateParam();
		if (_ammoParam != null)
		{
			_ammoParam.Ammo = ammo;
			_ammoParam.AmmoPath = AmmoTools.GetAmmoPath(_ammoParam.Ammo.GunFirePoint, _ammoParam.Ammo.IdealPosition, _ammoParam.Ammo.TableShell.ammo_speed, _ammoParam.Ammo.TableShell.ammo_gravity);
			_ammoParam.Trans = base.transform;
			_ammoParam.Trans.position = _ammoParam.AmmoPath.StartPoint;
			_ammoParam.Trans.forward = _ammoParam.AmmoPath.StartVelocity;
			_ammoParam.LiveTime = 0f;
		}
	}

	private void _initTrailMeshRenderer()
	{
		if (_ammoParam == null)
		{
			return;
		}
		float ammosize = _ammoParam.Ammo.TableShell.caliber;
		_ammoParam.AmmoEntity = base.transform.Find("AmmoEnt");
		if (_ammoParam.AmmoEntity != null)
		{
			_ammoParam.AmmoEntity.gameObject.SetActive(value: true);
			int childCount = base.gameObject.transform.GetChildCount();
			for (int i = 0; i < childCount; i++)
			{
				Transform child = base.gameObject.transform.GetChild(i);
				ShellTrailRenderer component = child.GetComponent<ShellTrailRenderer>();
				if (null != component)
				{
					_trailcomponent = component;
					break;
				}
			}
			isLaser = _isLaserTank();
			if ((bool)_trailcomponent)
			{
				_trailcomponent.Init(ammosize, CameraManager.Instance.CameraState == CameraState.First, _ammoParam.Ammo.ShootBy.IsMain, _ammoParam.Ammo, isLaser);
				_ammoParam.CurCaliber = _trailcomponent.CurAmmoCaliber;
				_ammoParam.SmokeEnt = _ammoParam.AmmoEntity.Find("439_paoxian_smoke");
				if (_ammoParam.SmokeEnt == null)
				{
					TKLog.Log("the SmokeSystem can not find ParticleSystem");
					return;
				}
				_ammoParam.SmokeSystem = _ammoParam.SmokeEnt.GetComponentInChildren<ParticleSystem>();
				if (_ammoParam.Ammo.ShootBy.IsMain)
				{
					_ammoParam.HitPath = AmmoTools.GetAmmoPath(_ammoParam.Ammo.ShootPosition, _ammoParam.Ammo.ShootDirection * _ammoParam.Ammo.TableShell.ammo_speed, _ammoParam.Ammo.IdealPosition);
				}
				else
				{
					_ammoParam.HitPath = AmmoTools.GetAmmoPath(_ammoParam.Ammo.ShootPosition, _ammoParam.Ammo.IdealPosition, _ammoParam.Ammo.TableShell.ammo_speed);
				}
				_ammoParam.CurHitCheckPosition = _ammoParam.HitPath.StartPoint;
				if (CameraManager.Instance.CameraState == CameraState.First)
				{
					_ammoParam.AmmoEntity.gameObject.SetActive(value: false);
				}
			}
			else
			{
				TKLog.Log("can not find trailcompoent");
			}
		}
		else
		{
			TKLog.Log("can not find AmmoEntity");
		}
	}

	private void _initAmmoStateMachine()
	{
		if (_ammoParam != null)
		{
			_ammoStateMgr = new CAmmoStateManager(_ammoParam);
			if (_ammoStateMgr != null)
			{
				_ammoStateMgr.CreateState(_ammoParam.Ammo.ShootBy.IsMain);
				_ammoStateMgr.SetInitState(_ammoParam.Ammo.HasTouchDown);
				_ammoStateMgr.Init();
			}
			else
			{
				TKLog.Log("can`t find the AmmoStateManager");
			}
		}
	}

	private void _destoryAmmo()
	{
		if (_ammoParam != null)
		{
			if (!_ammoParam.HasDestroy)
			{
				_alphaDisappearance();
			}
			_ammoParam.LiveTime += Time.fixedDeltaTime;
		}
	}

	private void _alphaDisappearance()
	{
		if (_ammoParam != null)
		{
			if (isLaser)
			{
				Invoke("_destroySelf", 0.5f);
			}
			else
			{
				_destroySelf();
			}
			_ammoParam.HasDestroy = true;
			IsDestory = true;
		}
	}

	private void _destroySelf()
	{
		Object.Destroy(base.gameObject);
	}

	private bool _isLaserTank()
	{
		if (_ammoParam == null)
		{
			return false;
		}
		if (_ammoParam.Ammo == null)
		{
			return false;
		}
		if (_ammoParam.Ammo.TableShell == null)
		{
			return false;
		}
		return _ammoParam.Ammo.TableShell.kind == 6;
	}

	public void UpdateLaserTransform()
	{
		if (_ammoParam != null && _ammoParam.Ammo != null && isLaser && (bool)_trailcomponent)
		{
			if (CameraManager.Instance.CameraState == CameraState.First)
			{
				_trailcomponent.UpdateLaserStartPos(_gunSyncData.FirePointTrans.position + new Vector3(0f, -2f, 0f));
			}
			else
			{
				_trailcomponent.UpdateLaserStartPos(_gunSyncData.FirePointTrans.position);
			}
		}
	}

	public void DestoryAmmo()
	{
		_destroySelf();
	}
}
