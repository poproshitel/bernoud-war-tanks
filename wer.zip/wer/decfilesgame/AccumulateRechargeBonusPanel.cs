using System;
using System.Collections.Generic;
using UnityEngine;

public class AccumulateRechargeBonusPanel : ActivityRightSubBasePanel
{
	public UILabel TitleLabel;

	public UILabel TimeLabel;

	public UILabel DescriptionLabel;

	public UILabel ChargeLabel;

	public UILabel ChargeNumLabel;

	public UILabel UnitLabel;

	public Transform RewardsListPivot;

	public GameObject RewardListItemPrefab;

	private List<InviteRewardListItem> _rewardsList;

	private int[] _rewardConditions;

	private int[] _rewardIds;

	private const int LIST_ITEM_GAP = 72;

	private const int REWARD_LEVEL_COUNT = 5;

	private void Awake()
	{
		ShowPageLocalPositon = new Vector3(-389f, -263f, -1f);
		Singleton<AccumulateRechargeBonusManager>.Instance.InitRewardDatas();
		AccumulateRechargeBonusManager instance = Singleton<AccumulateRechargeBonusManager>.Instance;
		instance.BroadCastUpdateBtnStatus = (Action)Delegate.Combine(instance.BroadCastUpdateBtnStatus, new Action(UpdateRewardBtnStatus));
	}

	private void InitBaseUI()
	{
		TitleLabel.text = CommonTools.GetDictString("activity_chongzhi_04");
		TimeLabel.text = string.Format(CommonTools.GetDictString("Hot_Christmas_ts_01"), Singleton<AccumulateRechargeBonusManager>.Instance.startTime + "-" + Singleton<AccumulateRechargeBonusManager>.Instance.endTime);
		DescriptionLabel.text = CommonTools.GetDictString("activity_chongzhi_05");
		ChargeLabel.text = CommonTools.GetDictString("activity_chongzhi_06");
		ChargeNumLabel.text = string.Format("activity_chongzhi_07", Singleton<AccumulateRechargeBonusManager>.Instance.RechargeNum);
		UnitLabel.text = CommonTools.GetDictString("activity_chongzhi_08");
		CommonTools.SetObjectOffsetLabel(ChargeLabel, ChargeNumLabel.transform, 5f, rightOffset: true);
		CommonTools.SetObjectOffsetLabel(ChargeNumLabel, UnitLabel.transform, 5f, rightOffset: true);
		InitRewardsInfo();
		UpdateRewardBtnStatus();
	}

	private void InitRewardsList()
	{
		if (_rewardsList != null)
		{
			return;
		}
		_rewardsList = new List<InviteRewardListItem>();
		for (int i = 0; i < _rewardConditions.Length; i++)
		{
			GameObject gameObject = UnityEngine.Object.Instantiate(RewardListItemPrefab);
			InviteRewardListItem component = gameObject.GetComponent<InviteRewardListItem>();
			if (component == null)
			{
				TKLog.LogError("Can't find InviteRewardListItem from RewardListItemPrefab!");
				break;
			}
			CommonTools.SetParent(component.transform, RewardsListPivot);
			component.transform.localScale = Vector3.one;
			component.transform.localPosition = new Vector3(0f, -i * 72, -1f);
			component.InitUI(_rewardConditions[i], _rewardIds[i], i, ActivityTypeForRewardListItem.AccumulateRechargeBonus);
			_rewardsList.Add(component);
		}
	}

	private void InitRewardsInfo()
	{
		ReadConfig.TryGetValue("accumulative_recharge", "accumulative_recharge_gold_cnt", out string v);
		_rewardConditions = CommonTools.GetIntsFromString(v, '_');
		ReadConfig.TryGetValue("accumulative_recharge", "reward_id", out v);
		_rewardIds = CommonTools.GetIntsFromString(v, '_');
		InitRewardsList();
	}

	private void UpdateChargeNum()
	{
		ChargeNumLabel.text = string.Format(CommonTools.GetDictString("activity_chongzhi_07"), Singleton<AccumulateRechargeBonusManager>.Instance.RechargeNum);
		CommonTools.SetObjectOffsetLabel(ChargeNumLabel, UnitLabel.transform, 5f, rightOffset: true);
	}

	private void UpdateRewardBtnStatus()
	{
		UpdateChargeNum();
		for (int i = 0; i < 5; i++)
		{
			_rewardsList[i].UpdateRewardStatus(Singleton<AccumulateRechargeBonusManager>.Instance.RewardsBtnStatus[i].rewardStatus);
		}
	}

	public override void Load()
	{
		base.Load();
		LoadOverCallback();
	}

	public override void Open()
	{
		base.Open();
		base.transform.localPosition = ShowPageLocalPositon;
		InitBaseUI();
	}

	public override void Close()
	{
		base.Close();
		base.transform.localPosition = HidePageLocalPositon;
	}

	public void OnDestroy()
	{
		AccumulateRechargeBonusManager instance = Singleton<AccumulateRechargeBonusManager>.Instance;
		instance.BroadCastUpdateBtnStatus = (Action)Delegate.Remove(instance.BroadCastUpdateBtnStatus, new Action(UpdateRewardBtnStatus));
	}
}
