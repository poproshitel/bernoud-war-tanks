using ClientSocket;

public class AccProItemForNmlRvv : AccProItem
{
	public int LoseCount;

	public int SurviveCount;

	public int TotalKillCount;

	public int MaxKillCount;

	public int TotalDamage;

	public int TotalExp;

	public int ShootCount;

	public int HitCount;

	public int MaxExp;

	public byte MedalLevel;

	public float LoseRate;

	public float SurviveRate;

	public float HitRate;

	public int AverageExp;

	public void ReadByte(ByteArray ba)
	{
		VehicleId = ba.ReadInt();
		BattleCount = ba.ReadInt();
		WinCount = ba.ReadInt();
		LoseCount = ba.ReadInt();
		SurviveCount = ba.ReadInt();
		TotalKillCount = ba.ReadInt();
		MaxKillCount = ba.ReadInt();
		TotalDamage = ba.ReadInt();
		TotalExp = ba.ReadInt();
		ShootCount = ba.ReadInt();
		HitCount = ba.ReadInt();
		MaxExp = ba.ReadInt();
		MedalLevel = ba.ReadByte();
	}

	public override AccProItem Calculate()
	{
		base.Calculate();
		LoseRate = ((BattleCount != 0) ? ((float)LoseCount / (float)BattleCount) : 0f);
		SurviveRate = ((BattleCount != 0) ? ((float)SurviveCount / (float)BattleCount) : 0f);
		HitRate = ((ShootCount != 0) ? ((float)HitCount / (float)ShootCount) : 0f);
		AverageExp = ((BattleCount != 0) ? (TotalExp / BattleCount) : 0);
		return this;
	}
}
