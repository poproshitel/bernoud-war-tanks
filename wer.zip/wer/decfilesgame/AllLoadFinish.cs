public delegate void AllLoadFinish(bool result);
