using System;
using System.Collections.Generic;
using ClientSocket;

public class AccumulateRechargeBonusManager : Singleton<AccumulateRechargeBonusManager>
{
	public Dictionary<int, List<InviteAwardItem>> RewardDatas;

	public int RechargeNum;

	public string startTime = string.Empty;

	public string endTime = string.Empty;

	public List<RewardStatusVO> RewardsBtnStatus;

	public bool AnyRewardCanGet;

	public bool IsOpen;

	public bool HasReward;

	public Action BroadCastUpdateBtnStatus;

	public void InitRewardDatas()
	{
		RewardDatas = new Dictionary<int, List<InviteAwardItem>>();
		ReadConfig.TryGetValue("accumulative_recharge", "reward_id", out string v);
		int[] intsFromString = CommonTools.GetIntsFromString(v, '_');
		for (int i = 0; i < intsFromString.Length; i++)
		{
			LoadRewards(intsFromString[i], out var rewardItems);
			RewardDatas[intsFromString[i]] = rewardItems;
		}
	}

	private void LoadRewards(int id, out List<InviteAwardItem> rewardItems)
	{
		Table_Reward reward = GameManager.TableMgr.GetReward(id);
		rewardItems = new List<InviteAwardItem>();
		if (reward == null)
		{
			TKLog.LogError("can't find the Table_Reward where id =" + reward);
			return;
		}
		if (reward.reward1_type != 0)
		{
			rewardItems.Add(new InviteAwardItem
			{
				rewardType = reward.reward1_type,
				rewardID = reward.reward1_ID,
				rewardCount = reward.reward1_count,
				IconID = reward.reward1_icon
			});
		}
		if (reward.reward2_type != 0)
		{
			rewardItems.Add(new InviteAwardItem
			{
				rewardType = reward.reward2_type,
				rewardID = reward.reward2_ID,
				rewardCount = reward.reward2_count,
				IconID = reward.reward2_icon
			});
		}
		if (reward.reward3_type != 0)
		{
			rewardItems.Add(new InviteAwardItem
			{
				rewardType = reward.reward3_type,
				rewardID = reward.reward3_ID,
				rewardCount = reward.reward3_count,
				IconID = reward.reward3_icon
			});
		}
		if (reward.reward4_type != 0)
		{
			rewardItems.Add(new InviteAwardItem
			{
				rewardType = reward.reward4_type,
				rewardID = reward.reward4_ID,
				rewardCount = reward.reward4_count,
				IconID = reward.reward4_icon
			});
		}
		if (reward.reward5_type != 0)
		{
			rewardItems.Add(new InviteAwardItem
			{
				rewardType = reward.reward5_type,
				rewardID = reward.reward5_ID,
				rewardCount = reward.reward5_count,
				IconID = reward.reward5_icon
			});
		}
	}

	public void RequestGetAccumulateRechargeReward(int rewardID)
	{
		GameManager.Hall.RequestGetAccumulateRechargeReward(rewardID);
	}

	public void ReceiveAccumulateRechargeActivityInfo(ref PK_NM_HC_AccumulateRechargeActivityInfo msg)
	{
		IsOpen = msg.nOpenSwitch == 1;
		startTime = GetLocalTimeFromTicks(msg.nBeginTime);
		endTime = GetLocalTimeFromTicks(msg.nEndTime);
	}

	public void ReceiveAccumulateRechargeRewardStatus(ref PK_NM_HC_AccumulateRechargeRewardStatus msg)
	{
		RechargeNum = msg.totalCharge;
		RewardsBtnStatus = msg.lstrewardStatusList;
		HasReward = false;
		foreach (RewardStatusVO item in RewardsBtnStatus)
		{
			if (item.rewardStatus == 1)
			{
				HasReward = true;
				break;
			}
		}
		JudgeWhetherAnyReward(RewardsBtnStatus);
		if (BroadCastUpdateBtnStatus != null)
		{
			BroadCastUpdateBtnStatus();
		}
		if (HallGuiManager.Instance != null && HallGuiManager.Instance.IsExistUI<TankPortUIManager>())
		{
			HallGuiManager.Instance.Get<TankPortUIManager>().GetBottomButtonByType(ToggleFaceType.NewActivity).UpdateBtnState();
		}
	}

	private void JudgeWhetherAnyReward(List<RewardStatusVO> status)
	{
		AnyRewardCanGet = false;
		for (int i = 0; i < status.Count; i++)
		{
			if (status[i].rewardStatus == 1)
			{
				AnyRewardCanGet = true;
			}
		}
	}

	private string GetLocalTimeFromTicks(long ticksTime)
	{
		return new DateTime(ticksTime * 10000000 + new DateTime(1970, 1, 1).Ticks).ToLocalTime().ToShortDateString();
	}
}
