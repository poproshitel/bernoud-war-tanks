public class AmmoStateInvalid : AmmoStateBase
{
	public override void EnterState(CAmmoStateParam param)
	{
		param.CurState = AmmoStateType.Invaid;
		param.AccmulateDisplacement = 0f;
	}

	public override bool UpdateState(CAmmoStateParam param)
	{
		return false;
	}

	public override void LeaveState(CAmmoStateParam param, ref AmmoStateType nextstate)
	{
	}
}
