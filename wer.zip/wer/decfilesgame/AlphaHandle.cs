using System.Collections.Generic;
using SceneCameraStruct;
using TK;
using UnityEngine;

public class AlphaHandle : MonoBehaviour
{
	private Shader _translateShader;

	private List<Transform> _back;

	private List<Transform> _alphaGo;

	private List<TransformShader> _transformShaders;

	private float _thirdCheckTreeHitTm;

	private Transform _transform;

	private Camera _camera;

	private List<Transform> _hitgos;

	private float _firstCheckTreeHitTm;

	public float _alphaDistance;

	public float _halfOfHorizontalAlphaLength;

	private Vector3[] _boundingBoxVertices;

	private GameObject _camAlphaObj;

	private Transform _camAlphaObjTrans;

	private BoxCollider _boxCollider;

	private Vector3 _CamPosAlphaObj;

	private Bounds _bound;

	private Vector3 _size;

	private Vector3 _min;

	private Vector3 _posCam;

	private bool _inAlphaFOV;

	private bool _alphaFOVTest;

	private Vector3 _tankPosition;

	private Vector3 _tankPosCam;

	private Vector3 _cam2TankDirection;

	private Vector3 left;

	private Vector3 right;

	public bool AlphaFOVTest
	{
		set
		{
			_alphaFOVTest = value;
		}
	}

	public CameraManager CameraManagerNew => CameraManager.Instance;

	public void Init()
	{
		_transform = base.transform;
		_camera = Camera.main;
		_translateShader = Shader.Find("Tank/CollisionCamera");
		_hitgos = new List<Transform>();
		_back = new List<Transform>();
		_alphaGo = new List<Transform>();
		_transformShaders = new List<TransformShader>();
		_alphaDistance = 400f;
		_halfOfHorizontalAlphaLength = _alphaDistance * Mathf.Tan(0.17453292f);
		_boundingBoxVertices = new Vector3[8];
		_camAlphaObj = null;
		_camAlphaObjTrans = null;
		_boxCollider = null;
		_CamPosAlphaObj = Vector3.zero;
		_bound = new Bounds(Vector3.zero, new Vector3(0f, 0f, 0f));
		_size = (_min = (_posCam = Vector3.zero));
		_inAlphaFOV = (_alphaFOVTest = false);
		_tankPosition = (_tankPosCam = (_cam2TankDirection = Vector3.zero));
		left = new Vector3(0f - _halfOfHorizontalAlphaLength, 0f, _alphaDistance);
		right = new Vector3(_halfOfHorizontalAlphaLength, 0f, _alphaDistance);
	}

	private void AlphaEffect()
	{
		if (_alphaGo.Count <= 0)
		{
			return;
		}
		Transform transform = null;
		for (int i = 0; i < _alphaGo.Count; i++)
		{
			transform = _alphaGo[i];
			if (transform == null)
			{
				continue;
			}
			bool flag = false;
			if ((bool)transform.transform.parent)
			{
				BbltRuntime component = transform.transform.parent.GetComponent<BbltRuntime>();
				if ((bool)component)
				{
					flag = true;
					component.BeTransparent(transparent: true);
				}
			}
			if (flag || transform.parent == null)
			{
				continue;
			}
			MeshRenderer component2 = transform.parent.GetComponent<MeshRenderer>();
			if (component2 != null)
			{
				Material material = component2.material;
				if (material == null)
				{
					TKLog.Log(transform.name + " material null");
				}
				else if (!(material.color.a < 1f))
				{
					SetShader(transform, material.shader);
					material.shader = _translateShader;
					Color color = material.color;
					color.a = 0.2f;
					material.color = color;
				}
			}
		}
	}

	private void ResetAlaph()
	{
		if (_back.Count <= 0)
		{
			return;
		}
		foreach (Transform item in _back)
		{
			if (item == null)
			{
				continue;
			}
			bool flag = false;
			if ((bool)item.parent)
			{
				BbltRuntime component = item.parent.GetComponent<BbltRuntime>();
				if ((bool)component)
				{
					flag = true;
					component.BeTransparent(transparent: false);
				}
			}
			if (flag || item.parent == null)
			{
				continue;
			}
			MeshRenderer component2 = item.parent.GetComponent<MeshRenderer>();
			if (!(component2 == null))
			{
				Material material = component2.material;
				Shader shaderName = GetShaderName(item);
				if (shaderName != null)
				{
					material.shader = shaderName;
				}
				Color color = material.color;
				color.a = 1f;
				material.color = color;
			}
		}
		_back.Clear();
	}

	public void AlaphResetHandle(CameraState state)
	{
		if (state == CameraState.First)
		{
			FirstCheckRayHit();
		}
		else
		{
			ThirdCheckTreeHit();
		}
		AlphaEffect();
		ResetAlaph();
	}

	public void SetShader(Transform trans, Shader shader)
	{
		int i;
		for (i = 0; i < _transformShaders.Count; i++)
		{
			TransformShader transformShader = _transformShaders[i];
			if (transformShader.Trans == trans)
			{
				break;
			}
		}
		if (i >= _transformShaders.Count)
		{
			TransformShader transformShader2 = new TransformShader();
			transformShader2.Trans = trans;
			transformShader2.Shader = shader;
			TransformShader transformShader = transformShader2;
			_transformShaders.Add(transformShader);
		}
	}

	private Shader GetShaderName(Transform trans)
	{
		foreach (TransformShader transformShader in _transformShaders)
		{
			if (transformShader.Trans == trans)
			{
				return transformShader.Shader;
			}
		}
		return null;
	}

	public void AddAlaphTrans(Transform Trans)
	{
		_alphaGo.Add(Trans);
	}

	private void ThirdCheckTreeHit()
	{
		if (Time.time - _thirdCheckTreeHitTm < 0.25f)
		{
			return;
		}
		_thirdCheckTreeHitTm = Time.time;
		for (int i = 0; i < MapEntity.CamAlphaObjectList.Count; i++)
		{
			BoxCollider boxCollider = MapEntity.CamAlphaObjectList[i];
			if (boxCollider == null)
			{
				MapEntity.CamAlphaObjectList.RemoveAt(i);
				i--;
				continue;
			}
			_camAlphaObj = boxCollider.gameObject;
			if (!_camAlphaObj)
			{
				continue;
			}
			_camAlphaObjTrans = _camAlphaObj.transform;
			_boxCollider = boxCollider;
			if ((bool)_boxCollider)
			{
				_CamPosAlphaObj = _camAlphaObjTrans.InverseTransformPoint(_transform.position);
				_bound.center = _boxCollider.center;
				_bound.size = _boxCollider.size;
				if (_bound.Contains(_CamPosAlphaObj))
				{
					_hitgos.Add(_camAlphaObjTrans);
				}
			}
		}
		if (SceneRoom.Instance.GetMainPlayer() == null)
		{
			TKLog.LogWarning("dosn't have tankmodel,AlaphHandle");
			return;
		}
		_tankPosition = SceneRoom.Instance.GetMainPlayer().transform.position;
		_tankPosCam = _transform.InverseTransformPoint(_tankPosition);
		_cam2TankDirection = _tankPosition - _transform.position;
		float num = _cam2TankDirection.magnitude;
		Vector3 vector3_ZERO = CommonTools.Vector3_ZERO;
		Vector3 position = _transform.position;
		RaycastHit hitInfo;
		while (Physics.Raycast(position, _cam2TankDirection, out hitInfo, num))
		{
			num -= hitInfo.distance;
			position -= hitInfo.point;
			Transform transform = hitInfo.transform;
			if (MapEntity.CamAlphaTable.Contains(transform) && !(_transform.InverseTransformPoint(transform.position).z >= _tankPosCam.z) && !_hitgos.Contains(transform))
			{
				_hitgos.Add(transform);
			}
		}
		if (_alphaGo.Count > 0)
		{
			foreach (Transform item in _alphaGo)
			{
				if (!_hitgos.Contains(item))
				{
					_back.Add(item);
				}
			}
			_alphaGo.Clear();
		}
		if (_hitgos.Count > 0)
		{
			foreach (Transform hitgo in _hitgos)
			{
				_alphaGo.Add(hitgo);
			}
		}
		_hitgos.Clear();
	}

	private void FirstCheckRayHit()
	{
		if (Time.time - _firstCheckTreeHitTm < 0.25f)
		{
			return;
		}
		_firstCheckTreeHitTm = Time.time;
		left.x = 0f - _halfOfHorizontalAlphaLength;
		right.x = _halfOfHorizontalAlphaLength;
		left.z = (right.z = _alphaDistance);
		Debug.DrawLine(_transform.position, _transform.TransformPoint(left), Color.red, 0.25f);
		Debug.DrawLine(_transform.position, _transform.TransformPoint(right), Color.red, 0.25f);
		for (int i = 0; i < MapEntity.CamAlphaObjectList.Count; i++)
		{
			BoxCollider boxCollider = MapEntity.CamAlphaObjectList[i];
			if (boxCollider == null)
			{
				MapEntity.CamAlphaObjectList.RemoveAt(i);
				i--;
				continue;
			}
			_camAlphaObj = boxCollider.gameObject;
			if (!_camAlphaObj)
			{
				continue;
			}
			_camAlphaObjTrans = _camAlphaObj.transform;
			_boxCollider = boxCollider;
			if (!_boxCollider)
			{
				continue;
			}
			_CamPosAlphaObj = _camAlphaObjTrans.InverseTransformPoint(_transform.position);
			_bound.center = _boxCollider.center;
			_bound.size = _boxCollider.size;
			if (_bound.Contains(_CamPosAlphaObj))
			{
				_hitgos.Add(_camAlphaObjTrans);
			}
			else
			{
				if (!_alphaFOVTest)
				{
					continue;
				}
				_inAlphaFOV = false;
				_size = _boxCollider.size;
				_min = _boxCollider.center - _size / 2f;
				for (int j = 0; j < 7; j++)
				{
					ref Vector3 reference = ref _boundingBoxVertices[j];
					reference = _min;
				}
				_boundingBoxVertices[1].x = _min.x + _size.x;
				_boundingBoxVertices[2].z = _min.z + _size.z;
				_boundingBoxVertices[3].x = _boundingBoxVertices[1].x;
				_boundingBoxVertices[3].z = _boundingBoxVertices[2].z;
				_boundingBoxVertices[4].y = _min.y + _size.y;
				_boundingBoxVertices[5].x = _boundingBoxVertices[1].x;
				_boundingBoxVertices[5].y = _boundingBoxVertices[4].y;
				_boundingBoxVertices[6].y = _boundingBoxVertices[4].y;
				_boundingBoxVertices[6].z = _boundingBoxVertices[2].z;
				ref Vector3 reference2 = ref _boundingBoxVertices[7];
				reference2 = _min + _size;
				for (int k = 0; k < 8; k++)
				{
					_posCam = _boundingBoxVertices[k];
					_posCam = _camAlphaObjTrans.TransformPoint(_posCam);
					_posCam = _transform.InverseTransformPoint(_posCam);
					if (Mathf.Abs(_alphaDistance * _posCam.x / _posCam.z) < _halfOfHorizontalAlphaLength && _posCam.z > 0f && _posCam.z < _alphaDistance)
					{
						_inAlphaFOV = true;
						_hitgos.Add(_camAlphaObjTrans);
						break;
					}
				}
				if (!_inAlphaFOV)
				{
				}
			}
		}
		RaycastHit[] array = Physics.RaycastAll(_transform.position, _transform.TransformDirection(Vector3.forward), _alphaDistance);
		for (int l = 0; l < array.Length; l++)
		{
			_camAlphaObjTrans = array[l].transform;
			if (_camAlphaObjTrans.CompareTag("CamAlpha") && !_hitgos.Contains(_camAlphaObjTrans))
			{
				_hitgos.Add(_camAlphaObjTrans);
			}
		}
		if (_alphaGo.Count > 0)
		{
			foreach (Transform item in _alphaGo)
			{
				if (!_hitgos.Contains(item))
				{
					_back.Add(item);
				}
			}
			_alphaGo.Clear();
		}
		foreach (Transform hitgo in _hitgos)
		{
			_alphaGo.Add(hitgo);
		}
		_hitgos.Clear();
	}
}
