public class ActivityWindowDataManager : Singleton<ActivityWindowDataManager>
{
	public static bool IsActiveOpen = true;

	public static void EnterHallShow()
	{
		if (HallGuideManager.Instance.IsInGarage && IsActiveOpen && GameManager.Player.RoomGUID == -1 && !GameManager.Player.IsFirstLogin)
		{
			ActivityMainPanelUi activityMainPanelUi = HallGuiManager.Instance.Get<ActivityMainPanelUi>();
			activityMainPanelUi.Toggle();
			activityMainPanelUi.OpenDefaultPanel();
			activityMainPanelUi.ActivityMainPanelUiDoCloseEvent += ShowOffer;
		}
		IsActiveOpen = false;
	}

	private static void ShowOffer(bool isShow)
	{
		ActivityMainPanelUi activityMainPanelUi = HallGuiManager.Instance.Get<ActivityMainPanelUi>();
		activityMainPanelUi.ActivityMainPanelUiDoCloseEvent -= ShowOffer;
		Singleton<OfferController>.Instance.ShowOfferWindow();
	}
}
