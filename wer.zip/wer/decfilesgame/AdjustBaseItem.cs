using System.Collections.Generic;
using UnityEngine;

public class AdjustBaseItem : MonoBehaviour
{
	public class Data
	{
		public string Text;

		public Vector3 Position;
	}

	public enum TextStyle
	{
		Title,
		Content
	}

	private List<Data> _itemList = new List<Data>();

	private float _localPosY;

	private float _localPosX;

	private const float LocalPosZ = 0f;

	private TextStyle _textStyle;

	private const int TextLength = 500;

	public void SetData(List<Data> itemList, float localPosY, TextStyle textStyle)
	{
		_itemList = itemList;
		_localPosY = localPosY;
		_textStyle = textStyle;
	}

	public void SetData(List<Data> itemList, float localPosX, float localPosY, TextStyle textStyle)
	{
		_itemList = itemList;
		_localPosX = localPosX;
		_localPosY = localPosY;
		_textStyle = textStyle;
	}

	private string GetTextStyle(TextStyle style)
	{
		return style switch
		{
			TextStyle.Title => CommonTools.GetDictString("huodong_type"), 
			TextStyle.Content => CommonTools.GetDictString("tvs_itemlist_des"), 
			_ => CommonTools.GetDictString("tvs_itemlist_des"), 
		};
	}

	private void Start()
	{
		DestroyChildren();
		CreateUiLabelList();
		base.transform.localPosition = new Vector3(_localPosX, _localPosY, 0f);
	}

	private void CreateUiLabelList()
	{
		foreach (Data item in _itemList)
		{
			string text = string.Format(GetTextStyle(_textStyle), item.Text);
			UILabel uILabel = NGUITools.AddUIlabel(base.gameObject, UIWidget.Pivot.TopLeft, text, item.Position, 500);
			uILabel.font = GUITools.GetFontByString(CommonTools.GetDictString("huodong_type"));
			uILabel.MakePixelPerfect();
		}
	}

	private void DestroyChildren()
	{
		UILabel[] componentsInChildren = base.transform.GetComponentsInChildren<UILabel>();
		for (int num = componentsInChildren.Length - 1; num >= 0; num--)
		{
			Object.DestroyObject(componentsInChildren[num].gameObject);
		}
	}
}
