using System;
using System.Collections.Generic;
using ClientSocket;
using TK;

public class AdvancedAccountManager
{
	public Action RefreshAccountPanel;

	private static AdvancedAccountManager _ins;

	public bool IsAdvanced;

	public bool IsLevel2Advanced;

	public bool MoneyTypeChanged;

	public int AdvanceLevel;

	private int _currentCharge = 500;

	public int GarageSelected;

	private List<int> _realGarageImgIndex;

	public bool AttributeComparisionSwitch;

	public static AdvancedAccountManager Instance
	{
		get
		{
			if (_ins == null)
			{
				_ins = new AdvancedAccountManager();
			}
			_ins._realGarageImgIndex = new List<int>();
			_ins._realGarageImgIndex.Add(10001);
			_ins._realGarageImgIndex.Add(10002);
			_ins._realGarageImgIndex.Add(10003);
			_ins._realGarageImgIndex.Add(10004);
			_ins._realGarageImgIndex.Add(10005);
			return _ins;
		}
	}

	public int CurrentCharge
	{
		get
		{
			return _currentCharge;
		}
		set
		{
			float v = 0f;
			float v2 = 0f;
			ReadConfig.TryGetValue("advanced_user", "advanced_user_new_money", out v);
			ReadConfig.TryGetValue("advanced_user", "advanced_user_money", out v2);
			_currentCharge = value;
			if (_currentCharge >= (int)v)
			{
				AdvanceLevel = 1;
				if (_currentCharge >= (int)v2)
				{
					AdvanceLevel = 2;
					IsLevel2Advanced = true;
				}
				IsAdvanced = true;
			}
			if (RefreshAccountPanel != null)
			{
				RefreshAccountPanel();
			}
		}
	}

	public int GetGarageID(int index)
	{
		if (index >= _realGarageImgIndex.Count || index < 0)
		{
			TKLog.LogError("The GarageIndex is Wrong Out Of Range");
			return 0;
		}
		return _realGarageImgIndex[index];
	}

	public int GetIndexOfGarage(int realIndex)
	{
		for (int i = 0; i < _realGarageImgIndex.Count; i++)
		{
			if (_realGarageImgIndex[i] == realIndex)
			{
				return i;
			}
		}
		return -1;
	}

	public bool IsActiveOpen()
	{
		return CurrentCharge < 2500;
	}

	public void OnGetCurrentBackGround(PK_HC_Garage_Background msg)
	{
		GarageSelected = GetIndexOfGarage(msg.IndexID);
		GameManager.Player.GarageID = msg.IndexID;
	}

	public void OnSetGarageBackgroundResult(PK_HC_Set_Garage_Background msg)
	{
		if (msg.Result == 1)
		{
			GarageSelected = GetIndexOfGarage(msg.TargetIndex);
			GameManager.Player.GarageID = msg.TargetIndex;
			if (RefreshAccountPanel != null)
			{
				RefreshAccountPanel();
			}
			if (TankSelectList.Instance.ChangeGarageState == 1)
			{
				TankSelectList.Instance.ClickChangeGarageBtn();
			}
			SceneHall.Instance.ChangeGarage(GameManager.Player.GarageID);
		}
	}

	public void ChangeGarageBackground(int index)
	{
		GameManager.Hall.SendChangeGarageBackground(index);
	}
}
