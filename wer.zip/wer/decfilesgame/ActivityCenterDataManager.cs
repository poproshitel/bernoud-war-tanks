using System;
using System.Collections.Generic;
using ClientSocket;

public class ActivityCenterDataManager : Singleton<ActivityCenterDataManager>
{
	private class ActivityComparer : IComparer<ActivityCenterModel>
	{
		public int Compare(ActivityCenterModel a, ActivityCenterModel b)
		{
			return b.Type - a.Type;
		}
	}

	public PK_HC_GoldToSilverDiscountActivityInfor GoldToSilverDiscountActivityInfor;

	public PK_HC_GoldTransExpDiscountActivityInfor GoldTransExpDiscountActivityInfor;

	public PK_HC_GoldDepositActivityInfor GoldDepositActivityInfor;

	public PK_HC_VIPBuyActivityInfor VipBuyActivityInfor;

	public PK_HC_DiscountTankActivityInfor DiscountTankActivityInfor;

	public CommonActivityModel BattleActivityInfo = new CommonActivityModel();

	public CommonActivityModel KillActivityInfo = new CommonActivityModel();

	public CommonActivityModel VictoryActivityInfo = new CommonActivityModel();

	public Action<object> GoldToSilverDiscountAction;

	public Action<object> GoldTransExpDiscountAction;

	public Action<object> GoldDepositAction;

	public Action<object> VIPBuyAction;

	public Action<object> DiscountTankAction;

	public Action CommonActivityAction;

	public int MaxDiscountTank = 8;

	public Dictionary<EnumActivityCenter, HotActivityState> ActivityStateDic = new Dictionary<EnumActivityCenter, HotActivityState>();

	public Dictionary<EnumActivityCenter, ActivityCenterModel> ActivityModelDic = new Dictionary<EnumActivityCenter, ActivityCenterModel>();

	private List<ActivityCenterModel> _activityIngList;

	public int MaxActivityNum = 8;

	public bool StateChanged;

	public List<ActivityCenterModel> ActivityIngList
	{
		get
		{
			if (_activityIngList == null)
			{
				InitData();
			}
			return _activityIngList;
		}
		set
		{
			_activityIngList = value;
		}
	}

	public ActivityCenterDataManager()
	{
		AddModelDic(EnumActivityCenter.Battle, 583, EnumActivityCenterTemplate.Common, BattleActivityInfo);
		AddModelDic(EnumActivityCenter.Kill, 583, EnumActivityCenterTemplate.Common, KillActivityInfo);
		AddModelDic(EnumActivityCenter.Victory, 583, EnumActivityCenterTemplate.Common, VictoryActivityInfo);
		AddModelDic(EnumActivityCenter.DiscountTankActivity, 895, EnumActivityCenterTemplate.DiscountTankActivity);
		AddModelDic(EnumActivityCenter.GoldDepositActivity, 895, EnumActivityCenterTemplate.GoldDepositActivity);
		AddModelDic(EnumActivityCenter.GoldToSilverDiscountActivity, 895, EnumActivityCenterTemplate.GoldToSilverDiscountActivity);
		AddModelDic(EnumActivityCenter.GoldTransExpDiscountActivity, 895, EnumActivityCenterTemplate.GoldTransExpDiscountActivity);
		AddModelDic(EnumActivityCenter.VipBuyActivity, 895, EnumActivityCenterTemplate.VipBuyActivity);
		foreach (EnumActivityCenter value in Enum.GetValues(typeof(EnumActivityCenter)))
		{
			ActivityStateDic.Add(value, new HotActivityState());
		}
		TestData();
	}

	private void TestData()
	{
		PK_HC_CommonActivityInfo pK_HC_CommonActivityInfo = new PK_HC_CommonActivityInfo();
		CommonActivityModel commonActivityModel = new CommonActivityModel();
		commonActivityModel.IsOpen = true;
		commonActivityModel.RewardRate = 3f;
		commonActivityModel.RewardType = 1;
		commonActivityModel.Times = 5;
		pK_HC_CommonActivityInfo.BattleActivityInfo = commonActivityModel;
		CommonActivityModel commonActivityModel2 = new CommonActivityModel();
		commonActivityModel2.IsOpen = true;
		commonActivityModel2.RewardRate = 3f;
		commonActivityModel2.RewardType = 2;
		commonActivityModel2.Times = 5;
		pK_HC_CommonActivityInfo.KillActivityInfo = commonActivityModel2;
		CommonActivityModel commonActivityModel3 = new CommonActivityModel();
		commonActivityModel3.IsOpen = true;
		commonActivityModel3.RewardRate = 3f;
		commonActivityModel3.RewardType = 3;
		commonActivityModel3.Times = 5;
		pK_HC_CommonActivityInfo.VictoryActivityInfo = commonActivityModel3;
		OnCommonActivityInfo(pK_HC_CommonActivityInfo);
	}

	public void InitData()
	{
		ActivityIngList = new List<ActivityCenterModel>();
		foreach (EnumActivityCenter value2 in Enum.GetValues(typeof(EnumActivityCenter)))
		{
			if (ActivityStateDic.TryGetValue(value2, out var value) && value.IsOpen)
			{
				ActivityIngList.Add(ActivityModelDic[value2]);
			}
		}
		ActivityIngList.Sort(new ActivityComparer());
	}

	private void AddModelDic(EnumActivityCenter type, int picID, EnumActivityCenterTemplate templateType, CommonActivityModel commonActivityData = null)
	{
		ActivityCenterModel value = new ActivityCenterModel(type, picID, templateType, commonActivityData);
		ActivityModelDic.Add(type, value);
	}

	public void OnActivityConfig(PK_HC_ActivityConfig msg)
	{
		GoldToSilverDiscountActivityInfor = msg.GoldToSilverDiscountActivityInfor;
		GoldTransExpDiscountActivityInfor = msg.GoldTransExpDiscountActivityInfor;
		GoldDepositActivityInfor = msg.GoldDepositActivityInfor;
		DiscountTankActivityInfor = msg.DiscountTankActivityInfor;
		VipBuyActivityInfor = msg.VipBuyActivityInfor;
	}

	public void OnGoldToSilverDiscountActivityInfor(PK_HC_GoldToSilverDiscountActivityInfor msg)
	{
		GoldToSilverDiscountActivityInfor = msg;
		if (GoldToSilverDiscountAction != null)
		{
			GoldToSilverDiscountAction(null);
		}
	}

	public void OnGoldTransExpDiscountActivityInfor(PK_HC_GoldTransExpDiscountActivityInfor msg)
	{
		GoldTransExpDiscountActivityInfor = msg;
		if (GoldTransExpDiscountAction != null)
		{
			GoldTransExpDiscountAction(null);
		}
	}

	public void OnGoldDepositActivityInfor(PK_HC_GoldDepositActivityInfor msg)
	{
		GoldDepositActivityInfor = msg;
		if (GoldTransExpDiscountAction != null)
		{
			GoldTransExpDiscountAction(null);
		}
	}

	public void OnDiscountTankActivityInfor(PK_HC_DiscountTankActivityInfor msg)
	{
		DiscountTankActivityInfor = msg;
		if (DiscountTankAction != null)
		{
			DiscountTankAction(null);
		}
	}

	public void OnVIPBuyActivityInfor(PK_HC_VIPBuyActivityInfor msg)
	{
		VipBuyActivityInfor = msg;
		if (VIPBuyAction != null)
		{
			VIPBuyAction(null);
		}
	}

	public void OnActivityOpenState(PK_HC_ActivityOpenState msg)
	{
		ChangeActivityState(EnumActivityCenter.VipBuyActivity, msg.BuyVIP == 1);
		ChangeActivityState(EnumActivityCenter.DiscountTankActivity, msg.DiscountTank == 1);
		ChangeActivityState(EnumActivityCenter.GoldDepositActivity, msg.GoldDeposit == 1);
		ChangeActivityState(EnumActivityCenter.GoldTransExpDiscountActivity, msg.GoldToExp == 1);
		ChangeActivityState(EnumActivityCenter.GoldToSilverDiscountActivity, msg.GoldToSliver == 1);
	}

	public void OnCommonActivityInfo(PK_HC_CommonActivityInfo msg)
	{
		BattleActivityInfo.CopyInstance(msg.BattleActivityInfo);
		KillActivityInfo.CopyInstance(msg.KillActivityInfo);
		VictoryActivityInfo.CopyInstance(msg.VictoryActivityInfo);
		if (CommonActivityAction != null)
		{
			CommonActivityAction();
		}
		ChangeActivityState(EnumActivityCenter.Battle, BattleActivityInfo.IsOpen);
		ChangeActivityState(EnumActivityCenter.Kill, KillActivityInfo.IsOpen);
		ChangeActivityState(EnumActivityCenter.Victory, VictoryActivityInfo.IsOpen);
	}

	private void ChangeActivityState(EnumActivityCenter type, bool isOpen)
	{
		if (ActivityStateDic.TryGetValue(type, out var value) && value.IsOpen != isOpen)
		{
			value.IsOpen = isOpen;
			StateChanged = true;
			InitData();
		}
	}

	public void LoadAssets()
	{
		if (ActivityIngList.Count > 0)
		{
			ResourcesManager.Instance.LoadFromCacheOrDownload(ActivityIngList[0].PicID, ResourceType.Texture);
		}
		if (!ActivityStateDic[EnumActivityCenter.DiscountTankActivity].IsOpen)
		{
			return;
		}
		for (int i = 0; i < DiscountTankActivityInfor.TankDiscountInfo.Length; i++)
		{
			TankDiscount tankDiscount = DiscountTankActivityInfor.TankDiscountInfo[i];
			Table_Vehicle vehicle = GameManager.TableMgr.GetVehicle(tankDiscount.TankID);
			if (vehicle == null)
			{
				TKLog.Log("dosn't have Vehice table by tanID " + tankDiscount.TankID);
				break;
			}
			ResourcesManager.Instance.LoadFromCacheOrDownload(TextureAsset.GetNationTextureId(vehicle.nation, isCarport: true, isGold: true), ResourceType.Texture);
			ResourcesManager.Instance.LoadFromCacheOrDownload(CommonTools.GetIdFormString(vehicle.bigicon), ResourceType.Texture);
			ResourcesManager.Instance.LoadFromCacheOrDownload(TextureAsset.GetTankTypeTextureId(vehicle.type, isGoldTank: true), ResourceType.Texture);
			ResourcesManager.Instance.LoadFromCacheOrDownload(TextureAsset.GetLevelTextureId(vehicle.level, isGoldTank: true), ResourceType.Texture);
		}
	}
}
