public class AreaBaseScale : UIButtonScale
{
	public override void OnPress(bool isPressed)
	{
	}

	public override void OnHover(bool isOver)
	{
	}

	public void SetOnPress(bool isPressed)
	{
		base.OnPress(isPressed);
	}

	public void SetOnHover(bool isOver)
	{
		base.OnHover(isOver);
	}
}
