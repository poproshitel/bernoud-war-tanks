using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class AdvancedAccountPopupList : MonoBehaviour
{
	public enum Position
	{
		Auto,
		Above,
		Below
	}

	private bool _openFlag;

	private Transform _cachedParentPanelTransform;

	private const float animSpeed = 0.15f;

	public UIAtlas atlas;

	public UIAtlas ImgAtlas;

	public UIFont font;

	public UILabel textLabel;

	public UISprite MoneyTypeSprite;

	public string backgroundSprite;

	public string highlightSprite;

	public Position position;

	public List<string> items = new List<string>();

	public List<string> sprites = new List<string>();

	public Vector2 padding = new Vector3(4f, 4f);

	public float textScale = 1f;

	public Color textColor = Color.white;

	public Color backgroundColor = Color.white;

	public Color highlightColor = new Color(0.59607846f, 1f, 0.2f, 1f);

	public bool isAnimated = true;

	public bool isLocalized;

	public GameObject eventReceiver;

	public string functionName = "OnSelectionChange";

	[SerializeField]
	private string mSelectedItem;

	private UIPanel mPanel;

	private GameObject mChild;

	private UISprite mBackground;

	private UISprite mHighlight;

	private UILabel mHighlightedLabel;

	private List<UILabel> mLabelList = new List<UILabel>();

	private float mBgBorder;

	public bool NeedToMovelabelForward;

	public bool NeedToAddUipanel;

	private int _index = -1;

	public bool isOpen => mChild != null;

	public string selection
	{
		get
		{
			return mSelectedItem;
		}
		set
		{
			if (mSelectedItem != value)
			{
				mSelectedItem = value;
				if (textLabel != null)
				{
					textLabel.text = ((!isLocalized || !(Localization.instance != null)) ? value : Localization.instance.Get(value));
					MoneyTypeSprite.spriteName = GetApproSpriteName(textLabel.text);
				}
				if (eventReceiver != null && !string.IsNullOrEmpty(functionName) && Application.isPlaying)
				{
					eventReceiver.SendMessage(functionName, mSelectedItem, SendMessageOptions.DontRequireReceiver);
				}
			}
		}
	}

	private bool handleEvents
	{
		get
		{
			UIButtonKeys component = GetComponent<UIButtonKeys>();
			return component == null || !component.enabled;
		}
		set
		{
			UIButtonKeys component = GetComponent<UIButtonKeys>();
			if (component != null)
			{
				component.enabled = !value;
			}
		}
	}

	private string GetApproSpriteName(string lblname)
	{
		int num = -1;
		for (int i = 0; i < items.Count; i++)
		{
			if (FilterFontFlagString(items[i]) == lblname)
			{
				num = i;
				break;
			}
		}
		if (num == -1)
		{
			TKLog.LogError("Can't find the appropriate img index!");
		}
		return sprites[num];
	}

	private string FilterFontFlagString(string str)
	{
		int num = -1;
		for (int i = 0; i < str.Length; i++)
		{
			if (str[i] == '>')
			{
				num = i;
				break;
			}
		}
		if (num == -1)
		{
			return str;
		}
		if (num == str.Length - 1)
		{
			return string.Empty;
		}
		return str.Substring(num + 1);
	}

	private void Start()
	{
		if (string.IsNullOrEmpty(mSelectedItem))
		{
			if (items.Count > 0)
			{
				selection = items[0];
			}
			return;
		}
		string text = mSelectedItem;
		mSelectedItem = null;
		mSelectedItem = text;
		if (textLabel != null)
		{
			textLabel.text = ((!isLocalized || !(Localization.instance != null)) ? text : Localization.instance.Get(text));
			MoneyTypeSprite.spriteName = GetApproSpriteName(textLabel.text);
		}
	}

	private void OnLocalize(Localization loc)
	{
		if (isLocalized && textLabel != null)
		{
			textLabel.text = loc.Get(mSelectedItem);
		}
	}

	private void Highlight(UILabel lbl, bool instant)
	{
		if (!(mHighlight != null))
		{
			return;
		}
		TweenPosition component = lbl.GetComponent<TweenPosition>();
		if (!(component != null) || !component.enabled)
		{
			mHighlightedLabel = lbl;
			UIAtlas.Sprite sprite = mHighlight.sprite;
			float num = sprite.inner.xMin - sprite.outer.xMin;
			float y = sprite.inner.yMin - sprite.outer.yMin;
			Vector3 vector = new Vector3(98f, lbl.cachedTransform.localPosition.y, lbl.cachedTransform.localPosition.z) + new Vector3(0f, y, 0f);
			if (instant || !isAnimated)
			{
				mHighlight.cachedTransform.localPosition = vector;
			}
			else
			{
				TweenPosition.Begin(mHighlight.gameObject, 0.1f, vector).method = UITweener.Method.EaseOut;
			}
		}
	}

	private void OnItemHover(GameObject go, bool isOver)
	{
		if (isOver)
		{
			UILabel component = go.GetComponent<UILabel>();
			Highlight(component, instant: false);
		}
	}

	private void Select(UILabel lbl, bool instant)
	{
		Highlight(lbl, instant);
		UIEventListener component = lbl.gameObject.GetComponent<UIEventListener>();
		selection = component.parameter as string;
		UIButtonSound[] components = GetComponents<UIButtonSound>();
		int i = 0;
		for (int num = components.Length; i < num; i++)
		{
			UIButtonSound uIButtonSound = components[i];
			if (uIButtonSound.trigger == UIButtonSound.Trigger.OnClick)
			{
				NGUITools.PlaySound(uIButtonSound.audioClip, uIButtonSound.volume);
			}
		}
	}

	private void OnItemPress(GameObject go, bool isPressed)
	{
		if (isPressed)
		{
			Select(go.GetComponent<UILabel>(), instant: true);
		}
	}

	private void OnKey(KeyCode key)
	{
	}

	private void OnSelect(bool isSelected)
	{
		if (isSelected || !(mChild != null))
		{
			return;
		}
		mLabelList.Clear();
		handleEvents = false;
		if (isAnimated)
		{
			UIWidget[] componentsInChildren = mChild.GetComponentsInChildren<UIWidget>();
			int i = 0;
			for (int num = componentsInChildren.Length; i < num; i++)
			{
				UIWidget uIWidget = componentsInChildren[i];
				Color color = uIWidget.color;
				color.a = 0f;
				TweenColor.Begin(uIWidget.gameObject, 0.15f, color).method = UITweener.Method.EaseOut;
			}
			Collider[] componentsInChildren2 = mChild.GetComponentsInChildren<Collider>();
			int j = 0;
			for (int num2 = componentsInChildren2.Length; j < num2; j++)
			{
				componentsInChildren2[j].enabled = false;
			}
			UpdateManager.AddDestroy(mChild, 0.15f);
		}
		else
		{
			Object.Destroy(mChild);
		}
		mBackground = null;
		mHighlight = null;
		mChild = null;
		OnClose();
	}

	private void AnimateColor(UIWidget widget)
	{
		Color color = widget.color;
		widget.color = new Color(color.r, color.g, color.b, 0f);
		TweenColor.Begin(widget.gameObject, 0.15f, color).method = UITweener.Method.EaseOut;
	}

	private void AnimatePosition(UIWidget widget, bool placeAbove, float bottom)
	{
		Vector3 localPosition = widget.cachedTransform.localPosition;
		Vector3 localPosition2 = ((!placeAbove) ? new Vector3(localPosition.x, 0f, localPosition.z) : new Vector3(localPosition.x, bottom, localPosition.z));
		widget.cachedTransform.localPosition = localPosition2;
		GameObject go = widget.gameObject;
		TweenPosition.Begin(go, 0.15f, localPosition).method = UITweener.Method.EaseOut;
	}

	private void AnimateScale(UIWidget widget, bool placeAbove, float bottom)
	{
		GameObject go = widget.gameObject;
		Transform cachedTransform = widget.cachedTransform;
		float num = (float)font.size * textScale + mBgBorder * 2f;
		Vector3 localScale = cachedTransform.localScale;
		cachedTransform.localScale = new Vector3(localScale.x, num, localScale.z);
		TweenScale.Begin(go, 0.15f, localScale).method = UITweener.Method.EaseOut;
		if (placeAbove)
		{
			Vector3 localPosition = cachedTransform.localPosition;
			cachedTransform.localPosition = new Vector3(localPosition.x, localPosition.y - localScale.y + num, localPosition.z);
			TweenPosition.Begin(go, 0.15f, localPosition).method = UITweener.Method.EaseOut;
		}
	}

	private void Animate(UIWidget widget, bool placeAbove, float bottom)
	{
		AnimateColor(widget);
		AnimatePosition(widget, placeAbove, bottom);
	}

	private void OnClick()
	{
		if (mChild == null && atlas != null && font != null && items.Count > 1)
		{
			OnOpen();
			mLabelList.Clear();
			handleEvents = true;
			if (mPanel == null)
			{
				mPanel = UIPanel.Find(base.transform, createIfMissing: true);
			}
			Transform transform = base.transform;
			Bounds bounds = NGUIMath.CalculateRelativeWidgetBounds(transform.parent, transform);
			mChild = new GameObject("Drop-down List");
			mChild.layer = base.gameObject.layer;
			if (NeedToAddUipanel)
			{
				mChild.AddComponent<UIPanel>();
			}
			Transform transform2 = mChild.transform;
			transform2.parent = transform.parent;
			transform2.localPosition = new Vector3(-7f, 22f, -1f);
			transform2.localRotation = Quaternion.identity;
			transform2.localScale = Vector3.one;
			mBackground = NGUITools.AddSprite(mChild, atlas, backgroundSprite);
			mBackground.pivot = UIWidget.Pivot.TopRight;
			mBackground.depth = NGUITools.CalculateNextDepth(mPanel.gameObject);
			mBackground.color = backgroundColor;
			Vector4 border = mBackground.border;
			mBgBorder = border.y;
			mBackground.cachedTransform.localPosition = new Vector3(99f, border.y, 0f);
			mHighlight = NGUITools.AddSprite(mChild, atlas, highlightSprite);
			mHighlight.pivot = UIWidget.Pivot.TopRight;
			mHighlight.color = highlightColor;
			UIAtlas.Sprite sprite = mHighlight.sprite;
			float num = sprite.inner.yMin - sprite.outer.yMin;
			float num2 = (float)font.size * textScale;
			float a = 0f;
			float num3 = 0f - padding.y;
			List<UILabel> list = new List<UILabel>();
			int i = 0;
			for (int count = items.Count; i < count; i++)
			{
				string text = items[i];
				string spriteName = sprites[i];
				UILabel uILabel = NGUITools.AddWidget<UILabel>(mChild);
				uILabel.pivot = UIWidget.Pivot.TopRight;
				uILabel.font = font;
				uILabel.color = textColor;
				uILabel.text = ((!isLocalized || !(Localization.instance != null)) ? text : Localization.instance.Get(text));
				uILabel.cachedTransform.localPosition = new Vector3(92f, num3, -1f);
				uILabel.MakePixelPerfect();
				UISprite uISprite = NGUITools.AddWidget<UISprite>(mChild);
				uISprite.atlas = ImgAtlas;
				uISprite.pivot = UIWidget.Pivot.TopLeft;
				uISprite.spriteName = spriteName;
				uISprite.cachedTransform.localPosition = new Vector3(border.x + 6f, num3, -1f);
				uISprite.MakePixelPerfect();
				if (textScale != 1f)
				{
					Vector3 localScale = uILabel.cachedTransform.localScale;
					uILabel.cachedTransform.localScale = localScale * textScale;
				}
				list.Add(uILabel);
				num3 -= num2;
				num3 -= padding.y;
				a = Mathf.Max(a, uILabel.relativeSize.x * num2);
				UIEventListener uIEventListener = UIEventListener.Get(uILabel.gameObject);
				uIEventListener.onHover = OnItemHover;
				uIEventListener.onPress = OnItemPress;
				uIEventListener.parameter = text;
				if (mSelectedItem == text)
				{
					Highlight(uILabel, instant: true);
				}
				mLabelList.Add(uILabel);
			}
			a = Mathf.Max(a, bounds.size.x - border.x * 2f);
			Vector3 center = new Vector3(-2f, -0.5f, 0f);
			Vector3 size = new Vector3(a / num2, (num2 + padding.y) / num2, 1f);
			int j = 0;
			for (int count2 = list.Count; j < count2; j++)
			{
				UILabel uILabel2 = list[j];
				BoxCollider boxCollider = NGUITools.AddWidgetCollider(uILabel2.gameObject);
				center.z = boxCollider.center.z;
				boxCollider.center = center;
				boxCollider.size = size;
			}
			a += border.x * 2f;
			num3 -= border.y;
			mBackground.cachedTransform.localScale = new Vector3(92f, 0f - num3 + border.y, 1f);
			mHighlight.cachedTransform.localScale = new Vector3(90f, num2 + num * 2f, 1f);
			bool flag = position == Position.Above;
			if (position == Position.Auto)
			{
				UICamera uICamera = UICamera.FindCameraForLayer(base.gameObject.layer);
				if (uICamera != null)
				{
					flag = uICamera.cachedCamera.WorldToViewportPoint(transform.position).y < 0.5f;
				}
			}
			if (isAnimated)
			{
				float bottom = num3 + num2;
				Animate(mHighlight, flag, bottom);
				int k = 0;
				for (int count3 = list.Count; k < count3; k++)
				{
					Animate(list[k], flag, bottom);
				}
				AnimateColor(mBackground);
				AnimateScale(mBackground, flag, bottom);
			}
			if (flag)
			{
				transform2.localPosition = new Vector3(-7f, bounds.max.y - num3 - border.y, bounds.min.z);
			}
		}
		else
		{
			OnSelect(isSelected: false);
		}
	}

	private void OnOpen()
	{
		_openFlag = true;
		if (_cachedParentPanelTransform == null)
		{
			_cachedParentPanelTransform = NGUITools.FindInParents<UIPanel>(base.gameObject).transform;
		}
		_cachedParentPanelTransform.localPosition -= Vector3.forward;
	}

	private void OnClose()
	{
		if (_openFlag)
		{
			_openFlag = false;
			_cachedParentPanelTransform.localPosition += Vector3.forward;
		}
	}

	public void InitSetSelection(int index)
	{
		if (index < 0 || index > items.Count - 1)
		{
			TKLog.LogError("Set select items index is invalid::" + index + " the list just have " + items.Count + " items!!!!");
		}
		else
		{
			mSelectedItem = items[index];
			if (textLabel != null)
			{
				textLabel.text = items[index];
				MoneyTypeSprite.spriteName = GetApproSpriteName(textLabel.text);
			}
			_index = index;
		}
	}

	public void SetSelection(int index)
	{
		if (index < 0 || index > items.Count - 1)
		{
			TKLog.LogError("Set select items index is invalid::" + index + " the list just have " + items.Count + " items!!!!");
		}
		else
		{
			mSelectedItem = items[index];
			if (textLabel != null)
			{
				textLabel.text = items[index];
			}
			_index = index;
		}
	}

	public int GetIndex()
	{
		if (items == null)
		{
			TKLog.Log("list is null, can't get the index!!!!!");
			return -1;
		}
		int count = items.Count;
		for (int i = 0; count > i; i++)
		{
			if (string.CompareOrdinal(items[i], selection) == 0)
			{
				_index = i;
				return _index;
			}
		}
		return -1;
	}

	public bool Set(int index)
	{
		if (items == null)
		{
			TKLog.Log("list is null, can't get the index!!!!!");
			return false;
		}
		if (index > items.Count - 1 || index < 0)
		{
			TKLog.Log("Paramer index is invalid ::" + index);
			return false;
		}
		selection = items[index];
		return true;
	}

	public void Forbidden(bool forbidden = true)
	{
		UIImageButton component = GetComponent<UIImageButton>();
		if (forbidden)
		{
			GetComponent<Collider>().enabled = false;
			if (component != null)
			{
				component.target.spriteName = "Config_drag_down_4";
			}
		}
		else
		{
			GetComponent<Collider>().enabled = true;
			if (component != null)
			{
				component.target.spriteName = "Config_drag_down_1";
			}
		}
	}
}
