using System;

public class ActivityItemData
{
	public int Level1Id;

	public string Level1BtnName;

	public int Level2Id;

	public string Level2BtnName;

	public Action<ActivitySelect> Callback;

	public BetterList<ActivityItemData> SubItemList;
}
