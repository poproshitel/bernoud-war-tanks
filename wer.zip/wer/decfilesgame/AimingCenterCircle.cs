using System;
using UnityEngine;

public class AimingCenterCircle : MonoBehaviour
{
	public static AimingCenterCircle Instance;

	public MeshFilter OutlineMeshFilter;

	public MeshFilter CenterMeshFilter;

	private Mesh _outlineMesh;

	private Mesh _centerMesh;

	private Material _outlineMaterial;

	private Material _centerMaterial;

	public float OutlineWidth = 1f;

	public float ScaleModule;

	private int _triCount = 60;

	public float FillAcount;

	private Vector3[] _outlineMeshVera;

	private Vector3[] _centerMeshVera;

	private Color _colorRed = new Color(1f, 0.11764706f, 0.11764706f);

	private Color _colorRedAlpha = new Color(1f, 10f / 51f, 10f / 51f, 4f / 51f);

	private Color _colorGreen = new Color(0f, 1f, 0f);

	private Color _colorGreenAlpha = new Color(0f, 1f, 0f, 4f / 51f);

	private float[] _arrayCos;

	private float[] _arraySin;

	private bool _complete;

	private void Awake()
	{
		Instance = this;
		_centerMaterial = CenterMeshFilter.GetComponent<MeshRenderer>().sharedMaterial;
		_outlineMaterial = OutlineMeshFilter.GetComponent<MeshRenderer>().sharedMaterial;
		_centerMaterial.color = _colorRedAlpha;
		_outlineMaterial.color = _colorRed;
	}

	private void Start()
	{
		CenterMeshFilter.mesh = (_centerMesh = new Mesh());
		OutlineMeshFilter.mesh = (_outlineMesh = new Mesh());
		float num = (float)Math.PI * 2f / (float)_triCount;
		float num2 = num / 2f;
		_centerMeshVera = new Vector3[_triCount];
		_outlineMeshVera = new Vector3[_triCount * 2];
		int[] array = new int[(_triCount - 2) * 3];
		int[] array2 = new int[_triCount * 2 * 3];
		_arrayCos = new float[_triCount];
		_arraySin = new float[_triCount];
		for (int i = 0; i < _triCount; i++)
		{
			_arrayCos[i] = Mathf.Cos(num2);
			_arraySin[i] = Mathf.Sin(num2);
			num2 += num;
		}
		if (FillAcount > 1f)
		{
			FillAcount = 1f;
		}
		SetReloadCompleteColor(FillAcount >= 1f);
		float num3 = ScaleModule + OutlineWidth;
		int j = 0;
		int num4 = 0;
		int num5 = 0;
		for (; j < _triCount; j++)
		{
			if (j < _triCount - 2)
			{
				array[num4++] = 0;
				array[num4++] = j + 1;
				array[num4++] = j + 2;
			}
			int num6 = (j + 1) % _triCount;
			array2[num5++] = j;
			array2[num5++] = j + _triCount;
			array2[num5++] = num6;
			array2[num5++] = num6;
			array2[num5++] = j + _triCount;
			array2[num5++] = num6 + _triCount;
			ref Vector3 reference = ref _centerMeshVera[j];
			reference = new Vector3(ScaleModule * _arraySin[j], ScaleModule * _arrayCos[j], 0f);
			ref Vector3 reference2 = ref _outlineMeshVera[j];
			reference2 = _centerMeshVera[j];
			ref Vector3 reference3 = ref _outlineMeshVera[_triCount + j];
			reference3 = new Vector3(num3 * _arraySin[j], num3 * _arrayCos[j], 0f);
		}
		_centerMesh.vertices = _centerMeshVera;
		_centerMesh.triangles = array;
		_outlineMesh.vertices = _outlineMeshVera;
		_outlineMesh.triangles = array2;
	}

	private void Update()
	{
		if (FillAcount > 1f)
		{
			FillAcount = 1f;
		}
		SetReloadCompleteColor(FillAcount >= 1f);
		float num = ScaleModule + OutlineWidth;
		for (int i = 0; i < _triCount; i++)
		{
			_centerMeshVera[i].Set(ScaleModule * _arraySin[i], ScaleModule * _arrayCos[i], 0f);
			_outlineMeshVera[i].Set(_centerMeshVera[i].x, _centerMeshVera[i].y, 0f);
			_outlineMeshVera[_triCount + i].Set(num * _arraySin[i], num * _arrayCos[i], 0f);
		}
		_centerMesh.vertices = _centerMeshVera;
		_outlineMesh.vertices = _outlineMeshVera;
	}

	private void SetReloadCompleteColor(bool complete)
	{
		if (_complete != complete)
		{
			_complete = complete;
			if (complete)
			{
				_centerMaterial.color = _colorGreenAlpha;
				_outlineMaterial.color = _colorGreen;
			}
			else
			{
				_centerMaterial.color = _colorRedAlpha;
				_outlineMaterial.color = _colorRed;
			}
		}
	}

	public void ShowOrHide(bool show)
	{
		CenterMeshFilter.gameObject.SetActive(show);
		OutlineMeshFilter.gameObject.SetActive(show);
	}

	private void OnDestroy()
	{
		Instance = null;
	}
}
