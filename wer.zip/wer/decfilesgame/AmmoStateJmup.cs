using UnityEngine;

public class AmmoStateJmup : AmmoStateBase
{
	private float _dirX;

	private float _dirY;

	private float _timecount;

	public AmmoStateJmup()
	{
		_timecount = 0f;
	}

	public override void EnterState(CAmmoStateParam param)
	{
		_dirX = Random.Range(300, 340);
		_dirY = param.Trans.eulerAngles.y + (float)Random.Range(-90, 90);
		param.Trans.eulerAngles = new Vector3(_dirX, _dirY, param.Trans.transform.eulerAngles.z);
		param.CurState = AmmoStateType.Jump;
		ResourcesManager.Particle.Emit(_getParticleId(param.CurCaliber), param.Ammo.GetRealHitWorldPosition(), param.Ammo.GetRealNormalWorldDirection());
		AmmoTools.DoAmmoAudioAndEffect(param.Ammo.TableShell, param.Ammo.HitLayerId, param.Ammo.HitModelId, param.Ammo.GetRealHitWorldPosition(), param.Ammo.GetRealNormalWorldDirection(), param.Ammo.ShootRes);
	}

	public override bool UpdateState(CAmmoStateParam param)
	{
		_timecount += Time.fixedDeltaTime * 20f;
		param.Trans.position += param.Trans.transform.forward * 5f;
		if (_timecount > 10f)
		{
			return true;
		}
		return false;
	}

	public override void LeaveState(CAmmoStateParam param, ref AmmoStateType nextstate)
	{
		nextstate = AmmoStateType.Bomb;
	}

	private int _getParticleId(ESAmmoCaliber caliber)
	{
		int result = 0;
		switch (caliber)
		{
		case ESAmmoCaliber.Min:
			result = 440;
			break;
		case ESAmmoCaliber.Mid:
			result = 441;
			break;
		case ESAmmoCaliber.Max:
			result = 442;
			break;
		}
		return result;
	}
}
