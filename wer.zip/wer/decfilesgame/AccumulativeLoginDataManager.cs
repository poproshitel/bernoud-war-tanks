using System;
using ClientSocket;

public class AccumulativeLoginDataManager : Singleton<AccumulativeLoginDataManager>
{
	public PK_HC_NewGuideLoginReward data;

	private PK_HC_NewGuideLoginReward _lastData;

	public bool CanGetToday
	{
		get
		{
			if (data == null)
			{
				return false;
			}
			for (int i = 0; i < data.LoginDays; i++)
			{
				if (data.Rewards[i] == 0)
				{
					return true;
				}
			}
			return false;
		}
	}

	public bool IsOver
	{
		get
		{
			if (data == null)
			{
				return true;
			}
			return data.LoginDays >= 3 && data.Rewards[0] == 1 && data.Rewards[1] == 1 && data.Rewards[2] == 1;
		}
	}

	public event Action OnRecvLoginRewardData;

	public event Action OnSevenLoginRewardFinish;

	public void GetData(PK_HC_NewGuideLoginReward response)
	{
		_lastData = data;
		data = response;
		if (this.OnRecvLoginRewardData != null)
		{
			this.OnRecvLoginRewardData();
		}
		if (response.IsLoginRewardFinish && this.OnSevenLoginRewardFinish != null)
		{
			this.OnSevenLoginRewardFinish();
		}
		if (HallGuiManager.Instance != null && HallGuiManager.Instance.IsExistUI<TankPortUIManager>())
		{
			HallGuiManager.Instance.Get<TankPortUIManager>().GetBottomButtonByType(ToggleFaceType.NewActivity).UpdateBtnState();
		}
	}

	public bool IsAlreadyGotReward(int day)
	{
		if (day < 1 || day > data.Rewards.Length)
		{
			return false;
		}
		return data.Rewards[day - 1] == 1;
	}

	public bool LastestGetedItem(out byte itemID)
	{
		if (_lastData != null)
		{
			for (int i = 0; i < _lastData.Rewards.Length; i++)
			{
				if (_lastData.Rewards[i] != data.Rewards[i])
				{
					itemID = (byte)i;
					_lastData = null;
					return true;
				}
			}
		}
		itemID = byte.MaxValue;
		return false;
	}
}
