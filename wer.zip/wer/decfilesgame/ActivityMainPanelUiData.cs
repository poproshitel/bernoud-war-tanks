public class ActivityMainPanelUiData : Singleton<ActivityMainPanelUiData>
{
	public bool IsNeedRefresh = true;
}
