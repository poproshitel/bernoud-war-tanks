using System.Collections.Generic;
using UnityEngine;

public class ArearBase : UIImageButton
{
	public GameObject Taget;

	public UISprite TroopsIcon;

	public UILabel TroopsName;

	public AreaBaseInfo ArearBaseInfo;

	protected DomainHSData DomainHsData;

	protected Vector2 MapWidthHight;

	protected float LocalPositionZ;

	protected UIDragPanelContents UiDragPanelContents;

	protected bool CanBeOperate;

	protected bool IsInSpriteRealPixelArea;

	protected bool CurIsIn;

	protected Tips CurTips;

	protected AreaButtonTipListener AreaButtonTipListener;

	private BoxCollider _boxCollider;

	private const float TarteLocalPositionZ = 0f;

	private ArearBaseColor _arearBaseColor;

	private AreaBaseScale _areaBaseScale;

	private GameObject _hoverGameObject;

	private int _defaultDepth;

	private const int HoverDepth = 50;

	private readonly Color _hoverColor = new Color(1f, 71f / 75f, 8f / 15f, 1f);

	private readonly Color _landAreaDefaultColor = new Color(0.5511111f, 1.1333333f, 14f / 75f, 1f);

	private readonly Color _territoryDefaultColor = new Color(1.1333333f, 1.1333333f, 1.1333333f, 1f);

	private readonly Color _selfOwnColor = new Color(22f / 75f, 44f / 75f, 1.0044445f, 1f);

	private readonly Color _otherOwnColor = new Color(1.1155555f, 0.60444444f, 37f / 75f, 1f);

	private Color _orgColor;

	protected virtual void Awake()
	{
		base.gameObject.tag = "MapArea";
		UiDragPanelContents = base.gameObject.GetComponent<UIDragPanelContents>();
		_boxCollider = GetComponent<BoxCollider>();
		if (Label == null)
		{
			Label = GetComponentInChildren<UILabel>();
		}
		_arearBaseColor = base.gameObject.GetComponent<ArearBaseColor>();
		_arearBaseColor.tweenTarget = target.gameObject;
		_areaBaseScale = base.gameObject.GetComponent<AreaBaseScale>();
		_areaBaseScale.hover = Vector3.one * 1.04f;
		TroopsName.transform.localPosition += new Vector3(0f, 0f, -2f);
		Singleton<TerritoryWarDataManager>.Instance.UpdateDomainHsDataEvent += UpdateData;
		Singleton<TerritoryWarDataManager>.Instance.InSpriteRealPixelAreaOnClickEvent += InSpriteRealPixelAreaOnClick;
	}

	private void OnDestroy()
	{
		Singleton<TerritoryWarDataManager>.Instance.UpdateDomainHsDataEvent -= UpdateData;
		Singleton<TerritoryWarDataManager>.Instance.InSpriteRealPixelAreaEvent -= InSpriteRealPixelArea;
		Singleton<TerritoryWarDataManager>.Instance.InSpriteRealPixelAreaOnClickEvent -= InSpriteRealPixelAreaOnClick;
	}

	public void SetAreaSpriteDefaultColor()
	{
		DomainHSData domainHsData = Singleton<TerritoryWarDataManager>.Instance.GetDomainHsData(ArearBaseInfo.Id);
		if (domainHsData == null)
		{
			return;
		}
		if (domainHsData.OwnCorpsId != 0)
		{
			if (Singleton<TerritoryWarDataManager>.Instance.IsLandArea(ArearBaseInfo.Id))
			{
				target.color = ((!Singleton<TerritoryWarDataManager>.Instance.MyLandAreaIdList.Contains(ArearBaseInfo.Id)) ? _otherOwnColor : _selfOwnColor);
			}
			else
			{
				target.color = ((!Singleton<TerritoryWarDataManager>.Instance.MyTerritoryIdList.Contains(ArearBaseInfo.Id)) ? _otherOwnColor : _selfOwnColor);
			}
		}
		else if (Singleton<TerritoryWarDataManager>.Instance.IsLandArea(ArearBaseInfo.Id))
		{
			target.color = _landAreaDefaultColor;
		}
		else
		{
			target.color = _territoryDefaultColor;
		}
	}

	protected virtual void InSpriteRealPixelArea(GameObject hoverGameObject)
	{
		_hoverGameObject = hoverGameObject;
		SetIsInSpriteRealPixelArea(hoverGameObject);
	}

	protected virtual void SetOnHover()
	{
		_arearBaseColor.hover = _hoverColor;
		_arearBaseColor.SetOnHover(IsInSpriteRealPixelArea);
		_areaBaseScale.SetOnHover(IsInSpriteRealPixelArea);
		target.depth = ((!IsInSpriteRealPixelArea) ? _defaultDepth : 50);
	}

	private void SetIsInSpriteRealPixelArea(GameObject hoverGameObject)
	{
		if (hoverGameObject != null)
		{
			int id = hoverGameObject.GetComponent<ArearBase>().ArearBaseInfo.Id;
			IsInSpriteRealPixelArea = id == ArearBaseInfo.Id;
		}
		else
		{
			IsInSpriteRealPixelArea = false;
		}
	}

	protected void AddTip()
	{
		AreaButtonTipListener = base.gameObject.AddComponent<AreaButtonTipListener>();
		AreaButtonTipListener.FunctionName = "TooolTips";
	}

	private void InSpriteRealPixelAreaOnClick(GameObject hoverGameObject)
	{
		_hoverGameObject = hoverGameObject;
		SetIsInSpriteRealPixelArea(hoverGameObject);
		if (IsInSpriteRealPixelArea && _hoverGameObject != null && CanBeOperate)
		{
			_hoverGameObject.gameObject.GetComponent<AreaUIButtonMessage>().SetOnClick();
		}
	}

	public void UpdateData(List<DomainHSData> domainhsdatalist)
	{
		DomainHSData domainHsData = Singleton<TerritoryWarDataManager>.Instance.GetDomainHsData(ArearBaseInfo.Id);
		SetBtnSprite(ArearBaseInfo.Id.ToString());
		SetAreaSpriteDefaultColor();
		_arearBaseColor.defaultColor = target.color;
		SetTroopsName(domainHsData);
	}

	public void SetBtnSprite(string spriteName)
	{
		normalSprite = spriteName;
		hoverSprite = spriteName;
		pressedSprite = spriteName;
		target.spriteName = spriteName;
		Rect outer = target.sprite.outer;
		SetBtnSpriteLocalScale(outer);
		SetBoxCollider(outer);
	}

	private void SetBtnSpriteLocalScale(Rect outer)
	{
		target.transform.localScale = new Vector3(outer.width, outer.height, 0f);
	}

	private void SetBoxCollider(Rect outer)
	{
		_boxCollider.center = new Vector3(0f, 0f, 0f);
		_boxCollider.size = new Vector3(outer.width, outer.height, 0f);
	}

	protected void SetTroopsName(DomainHSData domainHsData)
	{
		TroopsName.text = GetTroopsName(domainHsData);
	}

	protected string GetTroopsName(DomainHSData domainHsData)
	{
		if (domainHsData != null && domainHsData.OwnCorpsId != 0)
		{
			DomainCorpsData corpsData = Singleton<TerritoryWarDataManager>.Instance.GetCorpsData(domainHsData.OwnCorpsId);
			return (corpsData != null) ? string.Format(CommonTools.GetDictString("territory_auction_hegemony_territory_troops_tip_name"), corpsData.TipName) : string.Empty;
		}
		return string.Empty;
	}

	protected void SetUiPosition()
	{
		Vector2 mapSubAreaLocalPsition = Singleton<TerritoryWarDataManager>.Instance.GetMapSubAreaLocalPsition(MapWidthHight, ArearBaseInfo.LocalPostion, target.sprite.outer);
		base.transform.localPosition = new Vector3(mapSubAreaLocalPsition.x, mapSubAreaLocalPsition.y, LocalPositionZ);
		Vector2 mapSubAreaTatgetLocalPsition = Singleton<TerritoryWarDataManager>.Instance.GetMapSubAreaTatgetLocalPsition(MapWidthHight, ArearBaseInfo.TagetPostion, mapSubAreaLocalPsition);
		Taget.transform.localPosition = new Vector3(mapSubAreaTatgetLocalPsition.x, mapSubAreaTatgetLocalPsition.y, 0f);
	}

	protected void SetBtnSpriteDepth(int depth)
	{
		_defaultDepth = depth;
		target.depth = depth;
	}

	public void AddUiButtonControl()
	{
		if (CanBeOperate)
		{
		}
	}
}
