using UnityEngine;

[RequireComponent(typeof(ActivityMainPanelUi))]
public class ActivityMainPanelMediator : MonoBehaviour
{
	private UiActivityLeftPanel _uiActivityLeftPanel;

	private ActivityMainPanelUi _activityMainPanelUi;

	private void Awake()
	{
		_activityMainPanelUi = GetComponent<ActivityMainPanelUi>();
		_uiActivityLeftPanel = GetComponentInChildren<UiActivityLeftPanel>();
		_uiActivityLeftPanel.SetData(_activityMainPanelUi);
	}

	public void OpenDefaultPanel()
	{
		_uiActivityLeftPanel.OpenDefault();
	}

	public void OpenPanel(ActivityWindowType activityWindowType)
	{
		_uiActivityLeftPanel.OpenPanel(activityWindowType);
	}

	public void RefreshActivity(ActivityWindowType activityWindowType)
	{
		_uiActivityLeftPanel.RefreshActivity(activityWindowType);
	}
}
