using UnityEngine;

public class AgreementWindow : UIBase, IGuideHelpTarget
{
	public GameObject PrefabCheckbox;

	public UIImageButton ButtonAccepted;

	public UIPanel TextContainer;

	public UILabel TitleLabel;

	public UILabel ButtonRejectLabel;

	public UILabel ButtonAcceptLabel;

	public int LineWidth = 380;

	public int LineHeight = 20;

	public int StartXLocation = 16;

	private int _TitleAndContentOffsetY = 6;

	private float _totalHeight;

	private string _queryString;

	private int _state = 3;

	private void Awake()
	{
	}

	public void Init(string queryString)
	{
		_queryString = queryString;
		TitleLabel.text = CommonTools.GetDictString("agreement_window_title");
		ButtonRejectLabel.text = CommonTools.GetDictString("agreement_reject_label");
		ButtonAcceptLabel.text = CommonTools.GetDictString("agreement_accept_label");
		UILabel uILabel = NGUITools.AddWidget<UILabel>(TextContainer.gameObject);
		uILabel.text = CommonTools.GetDictString("agreement_text_1");
		ConfigUILabel(uILabel);
		AddUILabelToScrollPanel(uILabel, _TitleAndContentOffsetY);
		_totalHeight -= LineHeight;
		GameObject linkObj = GUITools.CreateTextButton(TextContainer.transform, new Vector3(0f, 0f, 0f), CommonTools.GetDictString("agreement_eula_link"), base.transform, "PressLinkEULA", UIWidget.Pivot.TopLeft, Color.red);
		AddUILinkLabelToScrollPanel(linkObj);
		linkObj = GUITools.CreateTextButton(TextContainer.transform, new Vector3(0f, 0f, 0f), CommonTools.GetDictString("agreement_game_rules_link"), base.transform, "PressLinkGameRules", UIWidget.Pivot.TopLeft, Color.red);
		AddUILinkLabelToScrollPanel(linkObj);
		linkObj = GUITools.CreateTextButton(TextContainer.transform, new Vector3(0f, 0f, 0f), CommonTools.GetDictString("agreement_conf_policy_link"), base.transform, "PressLinkConfidentialityPolicy", UIWidget.Pivot.TopLeft, Color.red);
		AddUILinkLabelToScrollPanel(linkObj);
		_totalHeight -= LineHeight;
		uILabel = NGUITools.AddWidget<UILabel>(TextContainer.gameObject);
		uILabel.text = CommonTools.GetDictString("agreement_text_2");
		ConfigUILabel(uILabel);
		AddUILabelToScrollPanel(uILabel, _TitleAndContentOffsetY);
		_totalHeight -= LineHeight;
		uILabel = NGUITools.AddWidget<UILabel>(TextContainer.gameObject);
		uILabel.text = CommonTools.GetDictString("agreement_text_3");
		ConfigUILabel(uILabel);
		AddUILabelToScrollPanel(uILabel, _TitleAndContentOffsetY);
		_totalHeight -= LineHeight;
		UICheckboxWithLabel component = Object.Instantiate(PrefabCheckbox).GetComponent<UICheckboxWithLabel>();
		component.transform.parent = TextContainer.transform;
		component.transform.localScale = Vector3.one;
		component.Label.lineWidth = 500;
		component.Text = CommonTools.GetDictString("agreement_checkbox_eula");
		component.isChecked = false;
		component.eventReceiver = base.gameObject;
		component.functionName = "OnCheckBox";
		AddCheckBoxToScrollPanel(component, _TitleAndContentOffsetY);
		component = Object.Instantiate(PrefabCheckbox).GetComponent<UICheckboxWithLabel>();
		component.transform.parent = TextContainer.transform;
		component.transform.localScale = Vector3.one;
		component.Label.lineWidth = 500;
		component.Text = CommonTools.GetDictString("agreement_checkbox_game_rules");
		component.isChecked = false;
		component.eventReceiver = base.gameObject;
		component.functionName = "OnCheckBox";
		AddCheckBoxToScrollPanel(component, _TitleAndContentOffsetY);
		component = Object.Instantiate(PrefabCheckbox).GetComponent<UICheckboxWithLabel>();
		component.transform.parent = TextContainer.transform;
		component.transform.localScale = Vector3.one;
		component.Label.lineWidth = 500;
		component.Text = CommonTools.GetDictString("agreement_checkbox_conf_policy");
		component.isChecked = false;
		component.eventReceiver = base.gameObject;
		component.functionName = "OnCheckBox";
		AddCheckBoxToScrollPanel(component, _TitleAndContentOffsetY);
		ButtonAccepted.UnableSprite = "MissionBtn_Unable";
		ButtonAccepted.SetUnable();
	}

	private void OnCheckBox(bool state)
	{
		if (state)
		{
			_state++;
		}
		else
		{
			_state--;
		}
		if (_state >= 3)
		{
			ButtonAccepted.Flag = true;
			ButtonAccepted.SetNormal();
		}
		else
		{
			ButtonAccepted.Flag = false;
			ButtonAccepted.SetUnable();
		}
	}

	private void ConfigUILabel(UILabel label)
	{
		label.pivot = UIWidget.Pivot.TopLeft;
		label.lineWidth = LineWidth;
		label.multiLine = true;
	}

	private void AddUILabelToScrollPanel(UILabel label, int offsetY)
	{
		Vector2 uILabelSize = CommonTools.GetUILabelSize(label);
		label.transform.localPosition = new Vector3(StartXLocation, _totalHeight, 0f);
		_totalHeight -= uILabelSize.y + (float)offsetY;
	}

	private void AddCheckBoxToScrollPanel(UICheckboxWithLabel obj, int offsetY)
	{
		obj.transform.localPosition = new Vector3(StartXLocation, _totalHeight, 0f);
		_totalHeight -= LineHeight;
	}

	private void AddUILinkLabelToScrollPanel(GameObject linkObj)
	{
		UILabel componentInChildren = linkObj.GetComponentInChildren<UILabel>();
		Vector2 uILabelSize = CommonTools.GetUILabelSize(componentInChildren);
		linkObj.transform.localPosition = new Vector3(StartXLocation, _totalHeight, 0f);
		UISlicedSprite componentInChildren2 = linkObj.GetComponentInChildren<UISlicedSprite>();
		_totalHeight -= uILabelSize.y + componentInChildren2.transform.localScale.y + (float)_TitleAndContentOffsetY;
	}

	private void PressLinkEULA()
	{
		string url = "https://documentation.my.games/gameterms/tanks_agreement";
		openWebLink(url);
	}

	private void PressLinkGameRules()
	{
		string url = "https://documentation.my.games/gameterms/tanks_game_rules";
		openWebLink(url);
	}

	private void PressLinkConfidentialityPolicy()
	{
		string url = "https://documentation.my.games/gameterms/tanks_privacy";
		openWebLink(url);
	}

	private void openWebLink(string url)
	{
		if (Screen.fullScreen)
		{
			CommonTools.FullScreen();
		}
		Application.OpenURL(url);
	}

	public Transform GetGuideHelpTarget(int index)
	{
		return base.transform;
	}

	private void OnActivate(bool state)
	{
	}

	private void OnChangeScreenHandle()
	{
		ChangePositon();
	}

	public void OnRejectClick()
	{
		CommonTools.Quit();
	}

	public void OnAcceptClick()
	{
		if (_state < 3)
		{
			return;
		}
		string[] array = _queryString.Split('&');
		string text = string.Empty;
		string[] array2 = array;
		foreach (string text2 in array2)
		{
			string[] array3 = text2.Split(' ');
			foreach (string text3 in array3)
			{
				string[] array4 = text3.Split('=');
				if (array4.Length == 2)
				{
					switch (array4[0].ToLower())
					{
					case "login":
						text = text + "login=" + array4[1] + "&";
						break;
					case "pers_id":
						text = text + "pers_id=" + array4[1] + "&";
						break;
					case "server_id":
						text = text + "server_id=" + array4[1] + "&";
						break;
					case "req_time":
						text = text + "req_time=" + array4[1] + "&";
						break;
					case "sign":
						text = text + "sign=" + array4[1] + "&";
						break;
					}
				}
			}
		}
		text += "callback=11111&agreed=true&subscribe=false";
		GameManager.ServerInfo.SendAgreementToServer(text);
	}
}
