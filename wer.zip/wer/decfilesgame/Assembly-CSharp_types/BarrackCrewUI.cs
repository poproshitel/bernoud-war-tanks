using System;
using UnityEngine;

public class BarrackCrewUI : MonoBehaviour
{
	public CrewExpBarControl expbar;

	public UILabel level_label;

	public UILabel status_label;

	public UILabel name_label;

	public GameObject infobtn;

	public GameObject operBtn;

	public UISlicedSprite nationimg;

	public UITexture icon;

	public CrewInfoForUi crewinfo;

	public UISlicedSprite highlight;

	public UISlicedSprite lvimg;

	public SkillListUI Skilllist;

	public bool isChoice;

	public int imgheight;

	public int imgwidth;

	private void OnClick()
	{
		base.transform.parent.parent.gameObject.SendMessage("ClickCrew", this, SendMessageOptions.DontRequireReceiver);
	}

	private void Start()
	{
		isChoice = false;
		SetFocusArea();
		CrewManager instance = CrewManager.Instance;
		instance.BroadCastLearnResult = (Action<long>)Delegate.Combine(instance.BroadCastLearnResult, new Action<long>(UpdateSkills));
		CrewManager instance2 = CrewManager.Instance;
		instance2.BroadResetResult = (Action<long>)Delegate.Combine(instance2.BroadResetResult, new Action<long>(UpdateSkills));
	}

	private void SetFocusArea()
	{
		Bounds bounds = NGUIMath.CalculateRelativeWidgetBounds(base.transform);
		BoxCollider component = GetComponent<BoxCollider>();
		if (component != null)
		{
			component.center = bounds.center + new Vector3(0f, 0f, 10f);
			component.size = bounds.size;
		}
	}

	private void OnHover(bool onhover)
	{
		HallGuiManager.Instance.Get<UIBarrack>().UpdateItemsHover();
	}

	public void UpdateItemsHover()
	{
		highlight.enabled = NGUITools.IsChild(base.transform, UICamera.lastHit.transform);
	}

	private void OnDestroy()
	{
		CrewManager instance = CrewManager.Instance;
		instance.BroadCastLearnResult = (Action<long>)Delegate.Remove(instance.BroadCastLearnResult, new Action<long>(UpdateSkills));
		CrewManager instance2 = CrewManager.Instance;
		instance2.BroadResetResult = (Action<long>)Delegate.Remove(instance2.BroadResetResult, new Action<long>(UpdateSkills));
	}

	private void UpdateSkills(long crewguid)
	{
		if (crewguid == crewinfo.Guid)
		{
			Skilllist.crewguid = crewguid;
			Skilllist.RefreshSkills();
		}
	}
}
