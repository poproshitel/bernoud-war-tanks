using System;
using System.Collections.Generic;
using UnityEngine;

public class BbltRuntime : MonoBehaviour
{
	private enum TransparentState
	{
		Fading,
		Normal
	}

	public bool IsTreeOrShrub;

	private bool _isDown;

	private const float MaxAlpha = 1f;

	private const float MinAlpha = 0.2f;

	private float _tgtAlpha;

	private List<Material> _lod0MatList;

	private Material _trunkMat;

	private TransparentState _curState;

	private void Awake()
	{
		_lod0MatList = new List<Material>();
		foreach (Transform item in base.transform)
		{
			if (item.name.Contains("lod0"))
			{
				_lod0MatList.Add(item.GetComponent<Renderer>().material);
			}
			else if (item.name == "Trunk")
			{
				_trunkMat = item.GetComponent<Renderer>().material;
			}
		}
		string text = ((!_isDown) ? string.Empty : "Idleing");
		Shader shader = Shader.Find("TK/BBLTLeafGroup" + text);
		Shader shader2 = Shader.Find("TK/BBLTTrunk" + text);
		foreach (Material lod0Mat in _lod0MatList)
		{
			lod0Mat.shader = shader;
		}
		_trunkMat.shader = shader2;
		_tgtAlpha = 1f;
	}

	private void Update()
	{
		switch (_curState)
		{
		case TransparentState.Fading:
			Fading();
			break;
		case TransparentState.Normal:
			Normal();
			break;
		}
	}

	private void Fading()
	{
		Color color;
		foreach (Material lod0Mat in _lod0MatList)
		{
			color = lod0Mat.color;
			color.a = Mathf.MoveTowards(color.a, _tgtAlpha, 4f * Time.deltaTime);
			lod0Mat.color = color;
		}
		color = _trunkMat.color;
		color.a = Mathf.MoveTowards(color.a, _tgtAlpha, 4f * Time.deltaTime);
		_trunkMat.color = color;
		if (!(Math.Abs(color.a - _tgtAlpha) < 0.01f))
		{
			return;
		}
		if (Math.Abs(_tgtAlpha - 1f) < 0.01f)
		{
			string text = ((!_isDown) ? string.Empty : "Idleing");
			Shader shader = Shader.Find("TK/BBLTLeafGroup" + text);
			Shader shader2 = Shader.Find("TK/BBLTTrunk" + text);
			foreach (Material lod0Mat2 in _lod0MatList)
			{
				lod0Mat2.shader = shader;
				color = lod0Mat2.color;
				color.a = _tgtAlpha;
				lod0Mat2.color = color;
			}
			_trunkMat.shader = shader2;
			color = _trunkMat.color;
			color.a = _tgtAlpha;
			_trunkMat.color = color;
			base.enabled = false;
		}
		_curState = TransparentState.Normal;
	}

	private void Normal()
	{
	}

	public void BeTransparent(bool transparent)
	{
		if (transparent)
		{
			string text = ((!_isDown) ? string.Empty : "Idleing");
			Shader shader = Shader.Find("TK/BBLTLeafGroupTransparent" + text);
			Shader shader2 = Shader.Find("TK/BBLTTrunkTransparent" + text);
			foreach (Material lod0Mat in _lod0MatList)
			{
				lod0Mat.shader = shader;
			}
			_trunkMat.shader = shader2;
			_tgtAlpha = 0.2f;
		}
		else
		{
			_tgtAlpha = 1f;
		}
		_curState = TransparentState.Fading;
		base.enabled = true;
	}

	public void BeHitDown()
	{
		_isDown = true;
		Shader shader = Shader.Find("TK/BBLTLeafGroupIdleing");
		Shader shader2 = Shader.Find("TK/BBLTTrunkIdleing");
		foreach (Material lod0Mat in _lod0MatList)
		{
			lod0Mat.shader = shader;
		}
		_trunkMat.shader = shader2;
	}

	public static void ScaleMesh(Mesh mesh, float scale)
	{
		Vector3[] vertices = mesh.vertices;
		Color[] colors = mesh.colors;
		Vector3[] normals = mesh.normals;
		for (int i = 0; i < mesh.vertexCount; i++)
		{
			vertices[i] *= scale;
			Vector2 vec = DecodeColorToVec2(colors[i]);
			vec *= scale;
			ref Color reference = ref colors[i];
			reference = EncodeVec2ToColor(vec);
			ref Vector3 reference2 = ref normals[i];
			reference2 = new Vector3(vertices[i].x, 1f, vertices[i].z).normalized;
		}
		mesh.vertices = vertices;
		mesh.colors = colors;
		mesh.normals = normals;
		mesh.RecalculateBounds();
	}

	private static Vector2 DecodeColorToVec2(Color c)
	{
		float x = (c.r + c.g * 0.00392f) * 10f - 5f;
		float y = (c.b + c.a * 0.00392f) * 10f - 5f;
		return new Vector2(x, y);
	}

	private static Color EncodeVec2ToColor(Vector2 vec2)
	{
		if (Mathf.Min(vec2.x, vec2.y) < -5f || Mathf.Max(vec2.x, vec2.y) > 5f)
		{
			Debug.Log("The position of tree leaf billboard vertex out of limit");
		}
		vec2 /= 5f;
		vec2 = vec2 * 0.5f + Vector2.one * 0.5f;
		vec2 *= 255f;
		return new Color32((byte)vec2.x, (byte)(vec2.x % 1f * 255f), (byte)vec2.y, (byte)(vec2.y % 1f * 255f));
	}

	public static Mesh calculateLeafGroupActualMesh(Mesh mesh)
	{
		if (mesh == null)
		{
			return null;
		}
		Mesh mesh2 = UnityEngine.Object.Instantiate(mesh);
		Vector3[] vertices = mesh2.vertices;
		Color[] colors = mesh2.colors;
		for (int i = 0; i < vertices.Length; i++)
		{
			Vector2 vector = DecodeColorToVec2(colors[i]);
			vertices[i] += vector.y * Vector3.up + vector.x * new Vector3(vertices[i].x, 0f, vertices[i].z).normalized;
		}
		mesh2.vertices = vertices;
		return mesh2;
	}
}
