using System;
using System.IO;
using TK;
using UnityEngine;

public class AssetResourceLoader : AssetLoader
{
	public enum LoadingState
	{
		Null,
		Waiting,
		LoadingFromCache,
		TryLoadingAgain,
		Decrypt,
		Loaded,
		LoadedFailed,
		UnLoading,
		UnLoaded
	}

	private LoadingState _loadingState;

	private string _path;

	private bool _logLoader;

	public AssetResourceLoader(string url, ResourceType type, int version, bool isEncrypted, bool log = false)
	{
		_retryTimes = 5;
		_url = url;
		_logLoader = log;
		_startTime = Time.realtimeSinceStartup;
		_isEncrypted = isEncrypted;
		_version = version;
		_loadingState = LoadingState.Waiting;
		_type = type;
		_stageLevel = ((SceneEntity.Instance.GetFSM().GetCurrentState() == SceneHall.Instance) ? Level.Hall : Level.Room);
		int length = GameManager.ServerInfo.AssetbundleBaseURL.Length;
		_path = Directory.GetParent(Application.dataPath).FullName + "/AssetBundles" + _url.Substring(length - 1, _url.Length - length + 1);
		_path = _path.Replace('\\', '/');
		if (_logLoader)
		{
			TKLog.Log("init {0}", this);
		}
	}

	public override void Start()
	{
		if (_logLoader)
		{
			TKLog.Log("start {0}", this);
		}
		_startTime = Time.realtimeSinceStartup;
		try
		{
			if (File.Exists(_path))
			{
				_www = new WWW("file://" + _path);
				_loadingState = LoadingState.LoadingFromCache;
				return;
			}
			_loadingState = LoadingState.LoadedFailed;
			string url = _url;
			_url = _path;
			FireLoadingFailed();
			_url = url;
		}
		catch (Exception ex)
		{
			TKLog.Log(_url + ex);
			throw;
		}
	}

	public override float GetLoadingProgress()
	{
		if (_loadingState == LoadingState.Waiting || _loadingState == LoadingState.LoadingFromCache || _loadingState == LoadingState.TryLoadingAgain)
		{
			return 0f;
		}
		if (!IsIgnoredResource() && _loadingState == LoadingState.LoadedFailed)
		{
			return 0f;
		}
		return 1f;
	}

	public override bool IsWaiting()
	{
		return _loadingState == LoadingState.Waiting;
	}

	public override bool IsLoading()
	{
		return _loadingState == LoadingState.LoadingFromCache || _loadingState == LoadingState.Decrypt || _loadingState == LoadingState.TryLoadingAgain;
	}

	public override bool IsLoadFailed()
	{
		return _loadingState == LoadingState.LoadedFailed;
	}

	public override bool IsLoaded()
	{
		return _loadingState == LoadingState.Loaded;
	}

	public override void Unload(bool unloadAllLoadedObjects)
	{
		if (_loadingState == LoadingState.Loaded)
		{
			_loadingState = LoadingState.UnLoading;
			_assetBundle.Unload(unloadAllLoadedObjects);
			if (_assetBundleCreateRequest != null)
			{
				_assetBundleCreateRequest.assetBundle.Unload(unloadAllLoadedObjects);
			}
		}
		if (_www != null)
		{
			_www.Dispose();
		}
		_www = null;
		_assetBundle = null;
		_loadingState = LoadingState.UnLoaded;
		if (_logLoader)
		{
			TKLog.Log("unload {0}", this);
		}
	}

	public override void Update(float deltaTime)
	{
		if (_loadingState == LoadingState.LoadingFromCache)
		{
			if (_www == null)
			{
				_loadingState = LoadingState.LoadedFailed;
				if (_logLoader)
				{
					TKLog.Log("www=null {0}", this);
				}
			}
			else if (_www.isDone)
			{
				if (_www.error != null || _www.assetBundle == null || _www.bytes == null)
				{
					_loadingState = LoadingState.LoadedFailed;
					if (_www.error != null)
					{
						if (_logLoader)
						{
							TKLog.Log("www.error={0} {1}", _www.error, this);
						}
						else if (_www.assetBundle == null)
						{
							if (_logLoader)
							{
								TKLog.Log("www.ab=null {0}", this);
							}
							else if (_logLoader)
							{
								TKLog.Log("www.bytes=null {0}", this);
							}
						}
					}
				}
				else if (_isEncrypted)
				{
					if (_assetBundleCreateRequest == null)
					{
						if (!TankTools.DecryptAsset(_www, out var bytes))
						{
							_loadingState = LoadingState.LoadedFailed;
							if (_logLoader)
							{
								TKLog.Log("failed decrypt {0}", this);
							}
						}
						else
						{
							_assetBundleCreateRequest = AssetBundle.LoadFromMemoryAsync(bytes);
							_www.assetBundle.Unload(unloadAllLoadedObjects: false);
							_loadingState = LoadingState.Decrypt;
							if (_logLoader)
							{
								TKLog.Log("decrypt {0}", this);
							}
						}
					}
				}
				else
				{
					if (_assetBundle == null)
					{
						_assetBundle = _www.assetBundle;
					}
					if (_assetBundle == null)
					{
						_loadingState = LoadingState.LoadedFailed;
						if (_logLoader)
						{
							TKLog.Log("assetBundle=null {0}", this);
						}
					}
					else
					{
						_loadingState = LoadingState.Loaded;
						if (_logLoader)
						{
							TKLog.Log("loaded {0}", this);
						}
						_www.Dispose();
						_www = null;
					}
				}
			}
		}
		else if (_loadingState == LoadingState.Decrypt)
		{
			if (_assetBundleCreateRequest == null)
			{
				_loadingState = LoadingState.LoadedFailed;
			}
			else if (_assetBundleCreateRequest.isDone)
			{
				if (_assetBundleCreateRequest.assetBundle == null)
				{
					_loadingState = LoadingState.LoadedFailed;
				}
				else
				{
					_assetBundle = _assetBundleCreateRequest.assetBundle;
					_assetBundleCreateRequest = null;
					_www.Dispose();
					_www = null;
					_loadingState = LoadingState.Loaded;
				}
			}
		}
		if (_loadingState == LoadingState.Loaded)
		{
			if (_logLoader)
			{
				TKLog.Log("loaded_1 {0}", this);
			}
			FireLoadingComplete();
		}
		else if (_loadingState == LoadingState.LoadedFailed || Time.realtimeSinceStartup - _startTime > 20f)
		{
			if (_retryTimes == 0)
			{
				FireLoadingFailed();
			}
			else if (_retryTimes <= 2)
			{
				_loadingState = LoadingState.TryLoadingAgain;
				if (_logLoader)
				{
					TKLog.Log("retry {0} {1}", _retryTimes, this);
				}
			}
			else
			{
				Retry();
			}
		}
		else if (_loadingState == LoadingState.TryLoadingAgain && Time.realtimeSinceStartup - _startTime > 10f)
		{
			Retry();
		}
	}

	public override string ToString()
	{
		return string.Concat("[AssetResourceLoader ", _path, " ", _loadingState, " hasContent:", _assetBundle != null, "]");
	}
}
