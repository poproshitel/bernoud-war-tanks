using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace boxTank;

public class GeoCompute
{
	public enum RelativePosType
	{
		RPT_END0,
		RPT_END1,
		RPT_ON_LINESEG
	}

	public enum ElementType
	{
		ET_POINT,
		ET_EDGE
	}

	public enum PolyPunctureDisType
	{
		PPDT_P2P,
		PPDT_P2E
	}

	public struct PntLineSegDisCalResult
	{
		public double dis;

		public Vector3 pt;

		public Vector3 lineEnd0;

		public Vector3 lineEnd1;

		public Vector3 touchPnt;

		public int pntIndex;

		public int lineSegIndex;

		public RelativePosType relPosType;
	}

	public struct EleRelationship
	{
		public PolyPunctureDisType ppdt;

		public Vector3 pt;

		public int ptIndex;

		public Vector3 otherPt;

		public int otherPtIndex;

		public Vector3 lineSegEnd0;

		public Vector3 lineSegEnd1;

		public int lineInd;

		public Vector3 touchPntOnEdge;

		public int exLineInd0;

		public int exLineInd1;

		public float dis;

		public Vector3 nor;

		public EleRelationship(int ptInd)
		{
			ppdt = PolyPunctureDisType.PPDT_P2E;
			pt = default(Vector3);
			ptIndex = ptInd;
			otherPt = default(Vector3);
			otherPtIndex = 0;
			lineSegEnd0 = default(Vector3);
			lineSegEnd1 = default(Vector3);
			lineInd = 0;
			touchPntOnEdge = default(Vector3);
			exLineInd0 = -1;
			exLineInd1 = -1;
			dis = 0f;
			nor = default(Vector3);
		}
	}

	public struct SimpleData_0
	{
		public float flt;

		public int intgr;
	}

	private static Vector3 tv0 = Vector3.zero;

	private static Vector3 tv1 = Vector3.zero;

	private static Vector3 tv2 = Vector3.zero;

	private static Vector3 tv3 = Vector3.zero;

	private static Vector3 tv4 = Vector3.zero;

	private static Vector3 tv5 = Vector3.zero;

	private static Vector3 tv6 = Vector3.zero;

	private static double pointRadius = 0.10000000149011612;

	private static Quaternion turnRightQ = Quaternion.AngleAxis(90f, Vector3.up);

	private static Quaternion turnLeftQ = Quaternion.AngleAxis(-90f, Vector3.up);

	private static Vector3 p2ls_v0 = default(Vector3);

	private static Vector3 p2ls_v1 = default(Vector3);

	private static Vector3 p2ls_v2 = default(Vector3);

	private static Vector3 center0 = default(Vector3);

	private static Vector3 center1 = default(Vector3);

	private static List<SimpleData_0> someTmpList = new List<SimpleData_0>();

	public static bool GetMinMax(Vector3[] convex, ref float minX, ref float maxX, ref float minZ, ref float maxZ)
	{
		int num = convex.Length;
		if (num < 1)
		{
			return false;
		}
		for (int i = 0; i < num; i++)
		{
			Vector3 vector = convex[i];
			if (i == 0)
			{
				minX = (maxX = vector.x);
				minZ = (maxZ = vector.z);
				continue;
			}
			if (minX > vector.x)
			{
				minX = vector.x;
			}
			if (maxX < vector.x)
			{
				maxX = vector.x;
			}
			if (minZ > vector.z)
			{
				minZ = vector.z;
			}
			if (maxZ < vector.z)
			{
				maxZ = vector.z;
			}
		}
		return true;
	}

	public static void TurnRight(ref Vector3 inV)
	{
		inV = turnRightQ * inV;
	}

	public static void TurnLeft(ref Vector3 inV)
	{
		inV = turnLeftQ * inV;
	}

	public static float CalDis_Pnt_LineSeg(Vector3 pt, Vector3 end0, Vector3 end1, ref Vector3 touchPnt, ref RelativePosType posType)
	{
		tv3 = end1 - end0;
		tv0 = end1 - end0;
		TurnRight(ref tv0);
		tv1 = pt - end0;
		tv2 = pt - end1;
		float num = Vector3.Dot(tv3, tv1);
		float num2 = Vector3.Dot(tv3, tv2);
		if (Math.Abs(num) < float.Epsilon && Math.Abs(num2) < float.Epsilon)
		{
			TKLog.LogError("CalDis_Pnt_LineSeg(),Math.Abs(dot0) < double.Epsilon && Math.Abs(dot1) < double.Epsilon");
			return 1E+12f;
		}
		if (num * num2 < 0f)
		{
			tv4 = end1 - end0;
			tv4 *= Math.Abs(num) / (Math.Abs(num) + Math.Abs(num2));
			touchPnt = end0 + tv4;
			posType = RelativePosType.RPT_ON_LINESEG;
			return (touchPnt - pt).magnitude;
		}
		if (Math.Abs(num) < Math.Abs(num2))
		{
			touchPnt = end0;
			posType = RelativePosType.RPT_END0;
			return (pt - end0).magnitude;
		}
		touchPnt = end1;
		posType = RelativePosType.RPT_END1;
		return (pt - end1).magnitude;
	}

	private static bool Pnt2LineSeg(Vector3 pt, Vector3 lineEnd0, Vector3 lineEnd1)
	{
		p2ls_v0 = lineEnd1 - lineEnd0;
		p2ls_v1 = p2ls_v0;
		TurnRight(ref p2ls_v1);
		p2ls_v2 = pt - lineEnd0;
		return Vector3.Dot(p2ls_v1, p2ls_v2) > 0f;
	}

	private static bool PntInConvex(Vector3 pt, Vector3[] convexPts)
	{
		float maxX = 0f;
		float minX = 0f;
		float maxZ = 0f;
		float minZ = 0f;
		int num = convexPts.Length;
		if (num < 3)
		{
			return false;
		}
		GetMinMax(convexPts, ref minX, ref maxX, ref minZ, ref maxZ);
		if (pt.x < minX)
		{
			return false;
		}
		if (pt.x > maxX)
		{
			return false;
		}
		if (pt.z < minZ)
		{
			return false;
		}
		if (pt.z > maxZ)
		{
			return false;
		}
		bool flag = true;
		for (int i = 0; i < num; i++)
		{
			Vector3 lineEnd = convexPts[i];
			Vector3 lineEnd2 = convexPts[(i + 1) % num];
			bool flag2 = Pnt2LineSeg(pt, lineEnd, lineEnd2);
			if (i == 0)
			{
				flag = flag2;
			}
			else if (flag2 != flag)
			{
				return false;
			}
		}
		return true;
	}

	public static bool LineSegIntersect(Vector3 l00, Vector3 l01, Vector3 l10, Vector3 l11)
	{
		bool flag = Pnt2LineSeg(l00, l10, l11);
		bool flag2 = Pnt2LineSeg(l01, l10, l11);
		bool flag3 = Pnt2LineSeg(l10, l00, l01);
		bool flag4 = Pnt2LineSeg(l11, l00, l01);
		if (flag == flag2)
		{
			return false;
		}
		if (flag3 == flag4)
		{
			return false;
		}
		return true;
	}

	public static bool ConvexBBoxOverlap(Vector3[] poly0, Vector3[] poly1)
	{
		float minX = 0f;
		float maxX = 0f;
		float minZ = 0f;
		float maxZ = 0f;
		float minX2 = 0f;
		float maxX2 = 0f;
		float minZ2 = 0f;
		float maxZ2 = 0f;
		if (!GetMinMax(poly0, ref minX, ref maxX, ref minZ, ref maxZ))
		{
			return false;
		}
		if (!GetMinMax(poly1, ref minX2, ref maxX2, ref minZ2, ref maxZ2))
		{
			return false;
		}
		if (minX > maxX2 || maxX < minX2)
		{
			return false;
		}
		if (minZ > maxZ2 || maxZ < minZ2)
		{
			return false;
		}
		return true;
	}

	public static int ConvexOverlap(Vector3[] poly0, Vector3[] poly1)
	{
		if (!ConvexBBoxOverlap(poly0, poly1))
		{
			return -5;
		}
		int num = poly0.Length;
		int num2 = poly1.Length;
		for (int i = 0; i < num; i++)
		{
			Vector3 pt = poly0[i];
			if (PntInConvex(pt, poly1))
			{
				return 1;
			}
		}
		for (int j = 0; j < num2; j++)
		{
			Vector3 pt2 = poly1[j];
			if (PntInConvex(pt2, poly0))
			{
				return 2;
			}
		}
		for (int k = 0; k < num; k++)
		{
			Vector3 l = poly0[k];
			Vector3 l2 = poly0[(k + 1) % num];
			for (int m = 0; m < num2; m++)
			{
				Vector3 l3 = poly1[m];
				Vector3 l4 = poly1[(m + 1) % num2];
				if (LineSegIntersect(l, l2, l3, l4))
				{
					return 3;
				}
			}
		}
		return -4;
	}

	public static void CalAngleSplitVec(Vector3[] pnts, int ind, ref Vector3 ret)
	{
		int num = pnts.Length;
		Vector3[] array = new Vector3[3];
		for (int i = 0; i < 3; i++)
		{
			array[i] = default(Vector3);
		}
		ref Vector3 reference = ref array[0];
		reference = pnts[(ind - 1 + num) % num];
		ref Vector3 reference2 = ref array[1];
		reference2 = pnts[ind];
		ref Vector3 reference3 = ref array[2];
		reference3 = pnts[(ind + 1) % num];
		ref Vector3 reference4 = ref array[0];
		reference4 = array[0] - array[1];
		array[0].Normalize();
		ref Vector3 reference5 = ref array[2];
		reference5 = array[2] - array[1];
		array[2].Normalize();
		ref Vector3 reference6 = ref array[1];
		reference6 = array[0] + array[2];
		array[1].Normalize();
		ret = array[1];
		ref Vector3 reference7 = ref array[0];
		reference7 = pnts[(ind - 1 + num) % num];
		ref Vector3 reference8 = ref array[1];
		reference8 = pnts[ind];
		ref Vector3 reference9 = ref array[2];
		reference9 = pnts[(ind + 1) % num];
		ref Vector3 reference10 = ref array[0];
		reference10 = array[1] - array[0];
		ref Vector3 reference11 = ref array[2];
		reference11 = array[2] - array[1];
		ref Vector3 reference12 = ref array[1];
		reference12 = array[0];
		TurnRight(ref array[1]);
		float num2 = Vector3.Dot(array[1], array[2]);
		if (num2 < 0f)
		{
			ret = new Vector3(ret.x * -1f, 0f, ret.z * -1f);
		}
	}

	public static int CalConvexDis(Vector3[] poly0, Vector3[] poly1, ref Vector3 pt0, ref Vector3 pt1, ref ElementType et0, ref ElementType et1, ref Vector3 nor0, ref Vector3 nor1)
	{
		center0 = Vector3.zero;
		center1 = Vector3.zero;
		int num = poly0.Length;
		int num2 = poly1.Length;
		if (num < 3 || num2 < 3)
		{
			return -5;
		}
		for (int i = 0; i < num; i++)
		{
			center0.x += poly0[i].x;
			center0.z += poly0[i].z;
		}
		center0.x /= num;
		center0.z /= num;
		for (int j = 0; j < num2; j++)
		{
			center1.x += poly1[j].x;
			center1.z += poly1[j].z;
		}
		center1.x /= num2;
		center1.z /= num2;
		bool flag = true;
		double num3 = 0.0;
		int ind = 0;
		int ind2 = 0;
		for (int k = 0; k < num; k++)
		{
			Vector3 vector = poly0[k];
			for (int l = 0; l < num2; l++)
			{
				Vector3 vector2 = poly1[l];
				if (flag)
				{
					num3 = (vector - vector2).magnitude;
					flag = false;
					pt0 = vector;
					pt1 = vector2;
					ind = k;
					ind2 = l;
					continue;
				}
				double num4 = (vector - vector2).magnitude;
				if (num4 < num3)
				{
					num3 = num4;
					pt0 = vector;
					pt1 = vector2;
					ind = k;
					ind2 = l;
				}
			}
		}
		List<PntLineSegDisCalResult> list = new List<PntLineSegDisCalResult>();
		List<PntLineSegDisCalResult> list2 = new List<PntLineSegDisCalResult>();
		PntLineSegDisCalResult item = default(PntLineSegDisCalResult);
		for (int m = 0; m < num; m++)
		{
			Vector3 pt2 = poly0[m];
			for (int n = 0; n < num2; n++)
			{
				Vector3 vector3 = poly1[n];
				Vector3 vector4 = poly1[(n + 1) % num2];
				RelativePosType posType = RelativePosType.RPT_ON_LINESEG;
				double dis = CalDis_Pnt_LineSeg(pt2, vector3, vector4, ref tv0, ref posType);
				item.dis = dis;
				item.pntIndex = m;
				item.lineSegIndex = n;
				item.pt = pt2;
				item.lineEnd0 = vector3;
				item.lineEnd1 = vector4;
				item.relPosType = posType;
				item.touchPnt = tv0;
				list.Add(item);
			}
		}
		for (int num5 = 0; num5 < num2; num5++)
		{
			Vector3 pt3 = poly1[num5];
			for (int num6 = 0; num6 < num; num6++)
			{
				Vector3 vector5 = poly0[num6];
				Vector3 vector6 = poly0[(num6 + 1) % num];
				RelativePosType posType2 = RelativePosType.RPT_ON_LINESEG;
				double dis2 = CalDis_Pnt_LineSeg(pt3, vector5, vector6, ref tv0, ref posType2);
				item.dis = dis2;
				item.pntIndex = num5;
				item.lineSegIndex = num6;
				item.pt = pt3;
				item.lineEnd0 = vector5;
				item.lineEnd1 = vector6;
				item.relPosType = posType2;
				item.touchPnt = tv0;
				list2.Add(item);
			}
		}
		PntLineSegDisCalResult pntLineSegDisCalResult = default(PntLineSegDisCalResult);
		bool flag2 = true;
		int count = list.Count;
		for (int num7 = 0; num7 < count; num7++)
		{
			if (flag2)
			{
				pntLineSegDisCalResult = list[num7];
				flag2 = false;
			}
			else if (list[num7].dis < pntLineSegDisCalResult.dis)
			{
				pntLineSegDisCalResult = list[num7];
			}
		}
		if (flag2)
		{
			TKLog.LogError("Impossible!!!");
			return 0;
		}
		int num8 = 0;
		int count2 = list2.Count;
		for (int num9 = 0; num9 < count2; num9++)
		{
			if (list2[num9].dis < pntLineSegDisCalResult.dis)
			{
				pntLineSegDisCalResult = list2[num9];
				num8 = 1;
			}
		}
		double num10 = 0.0;
		Vector3 vector7 = default(Vector3);
		Vector3 vector8 = default(Vector3);
		int num11 = 0;
		if (num3 < pntLineSegDisCalResult.dis)
		{
			num10 = num3;
			vector7 = pt0;
			vector8 = pt1;
			num11 = 1;
			et0 = ElementType.ET_POINT;
			et1 = ElementType.ET_POINT;
			CalAngleSplitVec(poly0, ind, ref nor0);
			CalAngleSplitVec(poly1, ind2, ref nor1);
		}
		else
		{
			num10 = pntLineSegDisCalResult.dis;
			vector7 = pntLineSegDisCalResult.pt;
			vector8 = pntLineSegDisCalResult.touchPnt;
			num11 = 2;
			if (num8 == 0)
			{
				et0 = ElementType.ET_POINT;
				et1 = ElementType.ET_EDGE;
				CalAngleSplitVec(poly0, pntLineSegDisCalResult.pntIndex, ref nor0);
				tv0 = vector7 - vector8;
				tv0.Normalize();
				nor1 = tv0;
				tv6 = vector8 - center1;
				if (Vector3.Dot(tv6, nor1) < 0f)
				{
					nor1 *= -1f;
				}
			}
			else
			{
				et0 = ElementType.ET_EDGE;
				et1 = ElementType.ET_POINT;
				tv0 = vector7 - vector8;
				tv0.Normalize();
				nor0 = tv0;
				tv6 = vector8 - center0;
				if (Vector3.Dot(tv6, nor0) < 0f)
				{
					nor0 *= -1f;
				}
				CalAngleSplitVec(poly1, pntLineSegDisCalResult.pntIndex, ref nor1);
			}
		}
		pt0 = vector7;
		pt1 = vector8;
		return num11;
	}

	public static int CalConvexPuncture(Vector3[] poly0, Vector3[] poly1, ref Vector3 pt0, ref Vector3 pt1, ref ElementType et0, ref ElementType et1, ref Vector3 nor0, ref Vector3 nor1, ref float punchDepth)
	{
		if (ConvexOverlap(poly0, poly1) < 0)
		{
			return -1;
		}
		List<EleRelationship> infos = new List<EleRelationship>();
		List<EleRelationship> infos2 = new List<EleRelationship>();
		FindConvexPunctureInfo(poly0, poly1, ref infos);
		FindConvexPunctureInfo(poly1, poly0, ref infos2);
		if (infos.Count < 1 && infos2.Count < 1)
		{
			return 0;
		}
		int count = infos.Count;
		int count2 = infos2.Count;
		PolyPunctureDisType ppdt = PolyPunctureDisType.PPDT_P2P;
		for (int i = 0; i < count; i++)
		{
			EleRelationship info = infos[i];
			double num = CalAccuratePunctureDepth(poly0, poly1, ref info, ref ppdt);
			infos[i] = info;
		}
		for (int j = 0; j < count2; j++)
		{
			EleRelationship info2 = infos2[j];
			double num2 = CalAccuratePunctureDepth(poly1, poly0, ref info2, ref ppdt);
			infos2[j] = info2;
		}
		double num3 = 0.0;
		int num4 = -1;
		int index = 0;
		for (int k = 0; k < count; k++)
		{
			EleRelationship eleRelationship = infos[k];
			if (num4 < 0)
			{
				num4 = 0;
				num3 = eleRelationship.dis;
				index = k;
			}
			else if (num3 < (double)eleRelationship.dis)
			{
				num4 = 0;
				num3 = eleRelationship.dis;
				index = k;
			}
		}
		for (int l = 0; l < count2; l++)
		{
			EleRelationship eleRelationship2 = infos2[l];
			if (num4 < 0)
			{
				num4 = 1;
				num3 = eleRelationship2.dis;
				index = l;
			}
			else if (num3 < (double)eleRelationship2.dis)
			{
				num4 = 1;
				num3 = eleRelationship2.dis;
				index = l;
			}
		}
		if (num4 < 0)
		{
			TKLog.LogError("No puncture point found.");
			return -3;
		}
		switch (num4)
		{
		case 0:
		{
			EleRelationship eleRelationship4 = infos[index];
			if (eleRelationship4.ppdt == PolyPunctureDisType.PPDT_P2E)
			{
				pt0 = eleRelationship4.pt;
				tv4 = eleRelationship4.nor;
				tv4 *= eleRelationship4.dis;
				pt1 = eleRelationship4.pt - tv4;
				et0 = ElementType.ET_POINT;
				et1 = ElementType.ET_EDGE;
				nor0 = eleRelationship4.nor;
				nor1 = eleRelationship4.nor;
				nor1 *= -1f;
				punchDepth = eleRelationship4.dis;
			}
			else
			{
				pt0 = eleRelationship4.pt;
				pt1 = eleRelationship4.otherPt;
				et0 = ElementType.ET_POINT;
				et1 = ElementType.ET_POINT;
				nor0 = eleRelationship4.nor;
				nor1 = eleRelationship4.nor;
				nor1 *= -1f;
				punchDepth = eleRelationship4.dis;
			}
			break;
		}
		case 1:
		{
			EleRelationship eleRelationship3 = infos2[index];
			if (eleRelationship3.ppdt == PolyPunctureDisType.PPDT_P2E)
			{
				tv4 = eleRelationship3.nor;
				tv4 *= eleRelationship3.dis;
				pt0 = eleRelationship3.pt - tv4;
				pt1 = eleRelationship3.pt;
				et0 = ElementType.ET_EDGE;
				et1 = ElementType.ET_POINT;
				nor0 = eleRelationship3.nor;
				nor0 *= -1f;
				nor1 = eleRelationship3.nor;
				punchDepth = eleRelationship3.dis;
			}
			else
			{
				pt0 = eleRelationship3.pt;
				pt1 = eleRelationship3.otherPt;
				et0 = ElementType.ET_POINT;
				et1 = ElementType.ET_POINT;
				nor0 = eleRelationship3.nor;
				nor0 *= -1f;
				nor1 = eleRelationship3.nor;
				punchDepth = eleRelationship3.dis;
			}
			break;
		}
		}
		return 1;
	}

	public static int FindConvexPunctureInfo(Vector3[] pnts, Vector3[] poly, ref List<EleRelationship> infos)
	{
		int num = pnts.Length;
		int num2 = poly.Length;
		center0 = Vector3.zero;
		center1 = Vector3.zero;
		for (int i = 0; i < num; i++)
		{
			center0 += pnts[i];
		}
		center0 *= 1f / (float)num;
		for (int j = 0; j < num2; j++)
		{
			center1 += poly[j];
		}
		center1 *= 1f / (float)num2;
		RelativePosType posType = RelativePosType.RPT_ON_LINESEG;
		for (int k = 0; k < num; k++)
		{
			if (!PntInConvex(pnts[k], poly))
			{
				continue;
			}
			someTmpList.Clear();
			float num3 = 0f;
			int num4 = 0;
			tv4 = Vector3.zero;
			for (int l = 0; l < num2; l++)
			{
				float num5 = CalDis_Pnt_LineSeg(pnts[k], poly[l], poly[(l + 1) % num2], ref tv0, ref posType);
				if (l == 0)
				{
					num3 = num5;
					num4 = 0;
					tv4 = tv0;
				}
				else if (num3 > num5)
				{
					num3 = num5;
					num4 = l;
					tv4 = tv0;
				}
				if (num5 < 0.5f)
				{
					SimpleData_0 item = default(SimpleData_0);
					item.flt = num5;
					item.intgr = l;
					someTmpList.Add(item);
				}
			}
			bool flag = false;
			if (someTmpList.Count == 2)
			{
				int num6 = 0;
				int num7 = someTmpList[0].intgr;
				int num8 = someTmpList[1].intgr;
				if (num7 > num8)
				{
					int num9 = num7;
					num7 = num8;
					num8 = num9;
				}
				num6 = ((num7 != 0 || num8 != num2 - 1) ? num8 : 0);
				float flt = someTmpList[0].flt;
				if (flt > someTmpList[1].flt)
				{
					flt = someTmpList[1].flt;
				}
				EleRelationship item2 = new EleRelationship(0);
				item2.ppdt = PolyPunctureDisType.PPDT_P2P;
				item2.ptIndex = k;
				item2.pt = pnts[k];
				item2.otherPt = poly[num6];
				item2.otherPtIndex = num6;
				item2.dis = flt;
				tv4 = center1 - center0;
				tv4.Normalize();
				item2.nor = tv4;
				infos.Add(item2);
				flag = true;
			}
			else
			{
				if (someTmpList.Count == 3)
				{
					TKLog.LogError("someTmpList.Count == 3");
					return 0;
				}
				if (someTmpList.Count == 4)
				{
					TKLog.LogError("someTmpList.Count == 4");
					return 0;
				}
			}
			if (flag)
			{
				continue;
			}
			float num10 = 0f;
			int num11 = 0;
			for (int m = 0; m < num2; m++)
			{
				float magnitude = (pnts[k] - poly[m]).magnitude;
				if (m == 0)
				{
					num10 = magnitude;
					num11 = m;
				}
				else if (num10 > magnitude)
				{
					num10 = magnitude;
					num11 = m;
				}
			}
			if ((double)num10 < pointRadius)
			{
				EleRelationship item3 = new EleRelationship(0);
				item3.ppdt = PolyPunctureDisType.PPDT_P2P;
				item3.ptIndex = k;
				item3.pt = pnts[k];
				item3.otherPt = poly[num11];
				item3.otherPtIndex = num11;
				item3.dis = num10;
				tv4 = center1 - center0;
				tv4.Normalize();
				item3.nor = tv4;
				infos.Add(item3);
			}
			else
			{
				EleRelationship item4 = new EleRelationship(0);
				item4.ppdt = PolyPunctureDisType.PPDT_P2E;
				item4.lineInd = num4;
				item4.lineSegEnd0 = poly[num4];
				item4.lineSegEnd1 = poly[(num4 + 1) % num2];
				item4.touchPntOnEdge = tv4;
				item4.ptIndex = k;
				item4.pt = pnts[k];
				tv5 = item4.lineSegEnd1 - item4.lineSegEnd0;
				tv5.Normalize();
				item4.nor = tv5;
				TurnLeft(ref item4.nor);
				item4.dis = num3;
				infos.Add(item4);
			}
		}
		return infos.Count;
	}

	public static double CalAccuratePunctureDepth(Vector3[] pnts, Vector3[] poly, ref EleRelationship info, ref PolyPunctureDisType ppdt)
	{
		if (info.ppdt == PolyPunctureDisType.PPDT_P2P)
		{
			return info.dis;
		}
		int num = pnts.Count();
		int num2 = poly.Count();
		int num3 = -1;
		int num4 = -1;
		tv0 = pnts[(info.ptIndex - 1 + num) % num];
		for (int i = 0; i < num2; i++)
		{
			tv2 = poly[i];
			tv3 = poly[(i + 1) % num2];
			if (LineSegIntersect(tv0, info.pt, tv2, tv3))
			{
				num3 = i;
				break;
			}
		}
		tv1 = pnts[(info.ptIndex + 1) % num];
		for (int j = 0; j < num2; j++)
		{
			tv2 = poly[j];
			tv3 = poly[(j + 1) % num2];
			if (LineSegIntersect(tv1, info.pt, tv2, tv3))
			{
				num4 = j;
				break;
			}
		}
		if (num3 < 0 || num4 < 0)
		{
			return 0.0;
		}
		RelativePosType posType = RelativePosType.RPT_ON_LINESEG;
		if (num3 == num4)
		{
			ppdt = PolyPunctureDisType.PPDT_P2E;
			info.exLineInd0 = num3;
			info.exLineInd1 = num3;
			info.dis = CalDis_Pnt_LineSeg(info.pt, poly[num3], poly[(num3 + 1) % num2], ref tv6, ref posType);
			if (Math.Abs(info.dis) > 40f)
			{
				TKLog.LogError("Math.Abs(info.dis) > 40.0f");
			}
			return info.dis;
		}
		float num5 = 0f;
		int num6 = 0;
		for (int k = 0; k < num2; k++)
		{
			float num7 = CalDis_Pnt_LineSeg(info.pt, poly[k], poly[(k + 1) % num2], ref tv6, ref posType);
			if (k == 0)
			{
				num5 = num7;
				num6 = 0;
			}
			else if (num5 > num7)
			{
				num5 = num7;
				num6 = k;
			}
		}
		info.dis = num5;
		info.exLineInd0 = num6;
		info.exLineInd1 = num6;
		info.lineInd = num6;
		info.lineSegEnd0 = poly[num6];
		info.lineSegEnd1 = poly[(num6 + 1) % num2];
		info.nor = info.lineSegEnd1 - info.lineSegEnd0;
		info.nor.Normalize();
		TurnLeft(ref info.nor);
		return num5;
	}

	public static double CalPunctureDepth(Vector3 pnt, Vector3[] poly)
	{
		return 0.0;
	}
}
