using System.Collections.Generic;

public class BulletPriceAdjustPanel : AdjustBasePanel
{
	private void InitItemUiLablePosxArray()
	{
		LocalPositionX = new float[5] { 1f, 104f, 268f, 454f, 590f };
	}

	private void InitTitleDataConfig()
	{
		TitleDataList.Clear();
		string dictString = CommonTools.GetDictString("tank_name_01");
		string dictString2 = CommonTools.GetDictString("gun_name_01");
		string dictString3 = CommonTools.GetDictString("shell_name_01");
		string dictString4 = CommonTools.GetDictString("shop_home_time_old_price");
		string dictString5 = CommonTools.GetDictString("shop_home_time_now_price");
		TitleDataList.Add(CreateAdjustBaseItemData(dictString, 0));
		TitleDataList.Add(CreateAdjustBaseItemData(dictString2, 1));
		TitleDataList.Add(CreateAdjustBaseItemData(dictString3, 2));
		TitleDataList.Add(CreateAdjustBaseItemData(dictString4, 3));
		TitleDataList.Add(CreateAdjustBaseItemData(dictString5, 4));
	}

	private void InitItemDataConfig()
	{
		ItemDataList.Clear();
		foreach (KeyValuePair<int, Table_BulletPriceAdjust> item in GameManager.TableMgr.BulletPriceAdjustDic)
		{
			List<AdjustBaseItem.Data> list = new List<AdjustBaseItem.Data>();
			string tank_name = item.Value.tank_name;
			string gun_name = item.Value.gun_name;
			string shell_name = item.Value.shell_name;
			string original_price = item.Value.original_price;
			string now_price = item.Value.now_price;
			list.Add(CreateAdjustBaseItemData(tank_name, 0));
			list.Add(CreateAdjustBaseItemData(gun_name, 1));
			list.Add(CreateAdjustBaseItemData(shell_name, 2));
			list.Add(CreateAdjustBaseItemData(original_price, 3));
			list.Add(CreateAdjustBaseItemData(now_price, 4));
			ItemDataList.Add(list);
		}
	}

	protected override void Awake()
	{
		base.Awake();
		InitItemUiLablePosxArray();
		InitTitleDataConfig();
		InitItemDataConfig();
	}

	public override void Open()
	{
		base.Open();
		CreateScrollList();
		SetUiScrollBarForeAlpha();
	}

	public override void Close()
	{
		base.Close();
		DestroyChildren();
	}

	protected override void Start()
	{
		PanelAndScollBarVertical.CurWholeHeight = GameManager.TableMgr.BulletPriceAdjustDic.Count * 18;
		base.Start();
	}
}
