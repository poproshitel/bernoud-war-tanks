using System;

[Serializable]
public class BehaveStruct : ICloneAbleData<BehaveStruct>
{
	public byte BehaveType;

	public byte PrizeType;

	public float Multiple;

	public BehaveStruct()
	{
	}

	public BehaveStruct(BehaveStruct data)
	{
		BehaveType = data.BehaveType;
		PrizeType = data.PrizeType;
		Multiple = data.Multiple;
	}

	public void Set(BehaveStruct data)
	{
		BehaveType = data.BehaveType;
		PrizeType = data.PrizeType;
		Multiple = data.Multiple;
	}

	public BehaveStruct CloneX()
	{
		return new BehaveStruct(this);
	}
}
