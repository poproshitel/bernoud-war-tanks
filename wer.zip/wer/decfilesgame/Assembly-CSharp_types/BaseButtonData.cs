public class BaseButtonData
{
	public string ButtonContex;

	public ButtonStyle Style;

	public CallBackFunctionType FunctionType;

	public bool DestroyPanel = true;
}
