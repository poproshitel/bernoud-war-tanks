using System.Collections.Generic;
using UnityEngine;

public class BulletMarkManager : MonoBehaviour
{
	public GameObject[] BulletMarks;

	public List<GameObject> Marks;

	public int MaxMarks;

	public List<float> PushDistances;

	public static BulletMarkManager Instance;

	private void Awake()
	{
		Instance = this;
	}

	private void Start()
	{
		Marks = new List<GameObject>();
		PushDistances = new List<float>();
		MaxMarks = 60;
	}

	public static float Add(GameObject go)
	{
		Transform transform = go.transform;
		Vector3 position = transform.position;
		float f = transform.localScale.x * transform.localScale.x * 0.25f + transform.localScale.y * transform.localScale.y * 0.25f + transform.localScale.z * transform.localScale.z * 0.25f;
		f = Mathf.Sqrt(f);
		float num = f * 2f;
		f *= 0.2f;
		if (Instance.Marks.Count == Instance.MaxMarks)
		{
			GameObject obj = Instance.Marks[0];
			Object.Destroy(obj);
			Instance.Marks.RemoveAt(0);
			Instance.PushDistances.RemoveAt(0);
		}
		float num2 = 0.0001f;
		int num3 = Instance.Marks.Count;
		for (int i = 0; i < num3; i++)
		{
			GameObject obj = Instance.Marks[i];
			if (obj != null)
			{
				Transform transform2 = obj.transform;
				float magnitude = (transform2.position - position).magnitude;
				if (magnitude < f)
				{
					Object.Destroy(obj);
					Instance.Marks.RemoveAt(i);
					Instance.PushDistances.RemoveAt(i);
					i--;
					num3--;
				}
				else if (magnitude < num)
				{
					float b = Instance.PushDistances[i];
					num2 = Mathf.Max(num2, b);
				}
			}
			else
			{
				Instance.Marks.RemoveAt(i);
				Instance.PushDistances.RemoveAt(i);
				i--;
				num3--;
			}
		}
		num2 += 0.0005f;
		Instance.Marks.Add(go);
		Instance.PushDistances.Add(num2);
		return num2;
	}

	public static void ClearMarks()
	{
		if (Instance.Marks.Count > 0)
		{
			for (int i = 0; i < Instance.Marks.Count; i++)
			{
				GameObject obj = Instance.Marks[i];
				Object.Destroy(obj);
			}
			Instance.Marks.Clear();
		}
	}
}
