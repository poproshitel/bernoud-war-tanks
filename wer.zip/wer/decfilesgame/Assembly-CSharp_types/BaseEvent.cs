public class BaseEvent
{
}
