using System;
using UnityEngine;

public class BottomNavigation : MonoBehaviour
{
	private Transform _transform;

	public float _height;

	private bool _isMoveDown;

	private BottomPanelManager _bottomPanelManager;

	public BottomPanelManager BottomPanelManager => _bottomPanelManager;

	public event Action OnScreenChangeEvent;

	private void Awake()
	{
		_bottomPanelManager = GetComponentInChildren<BottomPanelManager>();
	}

	public void Init()
	{
		_transform = base.transform;
		if (_bottomPanelManager == null)
		{
			TKLog.LogWarning("bottomPanleManager is null");
		}
		else
		{
			_bottomPanelManager.Init();
		}
		OnChangeScreenHandle();
	}

	private void OnChangeScreenHandle()
	{
		if (_isMoveDown)
		{
			_transform.localPosition = new Vector3(_transform.localPosition.x, (0f - ((float)Screen.height + _height + 20f)) / 2f, _transform.localPosition.z);
			_transform.localPosition = CommonTools.MakePixelPerfect(_transform.localPosition);
		}
		else
		{
			_transform.localPosition = new Vector3(_transform.localPosition.x, (0f - ((float)Screen.height - _height)) / 2f, _transform.localPosition.z);
			_transform.localPosition = CommonTools.MakePixelPerfect(_transform.localPosition);
		}
		if (TankSelectList.Instance != null)
		{
			TankSelectList.Instance.OnScreenChange();
		}
		if (this.OnScreenChangeEvent != null)
		{
			this.OnScreenChangeEvent();
		}
	}

	public void MakeBottomDown()
	{
		_isMoveDown = true;
		_transform.localPosition = new Vector3(_transform.localPosition.x, (0f - ((float)Screen.height + _height + 20f)) / 2f, _transform.localPosition.z);
		_transform.localPosition = CommonTools.MakePixelPerfect(_transform.localPosition);
	}

	public void MakeBottomUp()
	{
		_isMoveDown = false;
		_transform.localPosition = new Vector3(_transform.localPosition.x, (0f - ((float)Screen.height - _height)) / 2f, _transform.localPosition.z);
		_transform.localPosition = CommonTools.MakePixelPerfect(_transform.localPosition);
	}
}
