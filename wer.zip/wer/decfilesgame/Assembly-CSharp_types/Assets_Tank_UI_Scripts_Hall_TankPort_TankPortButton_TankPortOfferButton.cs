using System;

namespace Assets.Tank.UI.Scripts.Hall.TankPort.TankPortButton;

public class TankPortOfferButton : ToggleFAceButton
{
	public UILabel TimeLeftLabel;

	private string _styleString;

	public override void HonverState()
	{
		Sprite.spriteName = "garage_gift2";
	}

	public override void NomalState()
	{
		Sprite.spriteName = "garage_gift1";
	}

	public override void PressState()
	{
		Sprite.spriteName = "garage_gift3";
	}

	public override Type GetPanelType()
	{
		return typeof(OfferWindowController);
	}

	protected override void OnClickHandler()
	{
		Singleton<OfferController>.Instance.OnClickButtonHandler(this);
	}

	public override void Init()
	{
		base.Init();
		base.TipLabel = CommonTools.GetDictString("tips_offer");
		base.gameObject.SetActive(Singleton<OfferController>.Instance.ActiveOfferId > -1);
		BeginFlicker();
	}

	private void Update()
	{
		if ((bool)TimeLeftLabel)
		{
			if (_styleString == null)
			{
				_styleString = CommonTools.GetDictString("offer_button_time_style");
			}
			TimeLeftLabel.text = _styleString + Singleton<OfferController>.Instance.GetLeftTimeString();
		}
	}
}
