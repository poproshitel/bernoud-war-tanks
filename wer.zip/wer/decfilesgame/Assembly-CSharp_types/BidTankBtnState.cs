public enum BidTankBtnState
{
	NotBegin,
	BidTank,
	GetTank,
	GetTankWaitResponse,
	CanNotGet,
	AlreadyGet
}
