using UnityEngine;

public class CAmmoStateParam
{
	[SerializeField]
	public AmmoInfo Ammo;

	public FunctionAmmoPath AmmoPath;

	public Vector3 CurHitCheckPosition;

	public bool HasDestroy;

	public bool HasReadyDestory;

	public RaycastHit HitInfo;

	public FunctionAmmoPath HitPath;

	[SerializeField]
	public float LiveTime;

	public Vector3 NextHitCheckPositon;

	public Vector3 NextPostion;

	public Transform Trans;

	public GameObject Shell;

	public Transform Light;

	public Transform AmmoEntity;

	public Transform SmokeEnt;

	public ParticleSystem SmokeSystem;

	public bool IsInTraining;

	public AmmoStateType CurState;

	public ESAmmoCaliber CurCaliber;

	public float AccmulateDisplacement;
}
