using System;
using UnityEngine;

[Serializable]
public class BigAmmoTrailMeshRenderer : TrailMeshRenderer
{
	private Vector3 _lastPosition;

	public ParticleEmitter TrailEmiter;

	public Transform AmmoModel;

	public Transform BigAmmoModel;

	public Transform SmallAmmoModel;

	public Light PointLight;

	private Transform _emiterCachedTransform;

	public override bool Visiable
	{
		get
		{
			return AmmoModel.gameObject.activeSelf;
		}
		set
		{
			PointLight.enabled = value;
			AmmoModel.gameObject.SetActive(value);
			TrailVisiable = value;
		}
	}

	public override bool TrailVisiable
	{
		set
		{
			base.TrailVisiable = value;
			TrailEmiter.enabled = value;
		}
	}

	public override float AmmoSize
	{
		get
		{
			return base.AmmoSize;
		}
		set
		{
			base.AmmoSize = value;
			float num = 0f;
			if ((double)_ammoSize > 0.209)
			{
				num = value;
				BigAmmoModel.gameObject.SetActive(AmmoModel.gameObject.activeSelf);
				SmallAmmoModel.gameObject.SetActive(value: false);
				AmmoModel = BigAmmoModel;
			}
			else
			{
				num = value * 9f;
				SmallAmmoModel.gameObject.SetActive(AmmoModel.gameObject.activeSelf);
				BigAmmoModel.gameObject.SetActive(value: false);
				AmmoModel = SmallAmmoModel;
			}
			AmmoModel.localScale = new Vector3(num, num, num);
		}
	}

	public override void OnFirstSight()
	{
		TrailEmiter.maxEnergy = 0.3f;
		TrailEmiter.minEnergy = 0.3f;
		TrailVisiable = false;
	}

	public override void HideAmmo()
	{
		AmmoModel.gameObject.SetActive(value: false);
		TrailEmiter.maxEnergy = 0f;
		TrailEmiter.minEnergy = 0f;
		TrailEmiter.emit = false;
		PointLight.enabled = false;
	}

	private void Awake()
	{
		_emiterCachedTransform = TrailEmiter.transform;
	}

	private void FixedUpdate()
	{
		Vector3 position = _emiterCachedTransform.position;
		if (TrailVisiable && TrailEmiter.emit)
		{
			Vector3 vector = UnityEngine.Random.insideUnitSphere * 0.5f;
			for (float num = 0f; num <= 1f; num += 0.1f)
			{
				_emiterCachedTransform.position = Vector3.Lerp(_lastPosition, position, num) + (0.5f - Mathf.Abs(num - 0.5f)) * vector;
				TrailEmiter.Emit(1);
			}
			_emiterCachedTransform.localPosition = Vector3.zero;
		}
		_lastPosition = position;
	}

	public override void ResetAmmo()
	{
		base.enabled = false;
		Visiable = false;
		TrailVisiable = false;
		AmmoSize = 0f;
		Alpha = 0f;
		SmallAmmoModel.gameObject.SetActive(value: false);
		BigAmmoModel.gameObject.SetActive(value: false);
		TrailEmiter.maxEnergy = 1f;
		TrailEmiter.minEnergy = 1f;
		PointLight.enabled = true;
		TrailEmiter.emit = true;
	}

	public override void Init()
	{
		_lastPosition = _emiterCachedTransform.position;
		TrailEmiter.enabled = Visiable;
	}
}
