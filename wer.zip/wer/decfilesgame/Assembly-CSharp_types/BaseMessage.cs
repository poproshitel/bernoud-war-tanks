public class BaseMessage
{
	public MessageType Type;

	public int Id;
}
