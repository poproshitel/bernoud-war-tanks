public enum ButtonType
{
	None,
	Apply,
	Default,
	Cancle,
	ChangeButton,
	Ensure
}
