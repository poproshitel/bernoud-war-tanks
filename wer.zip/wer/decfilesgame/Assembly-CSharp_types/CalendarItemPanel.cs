using UnityEngine;

public class CalendarItemPanel : MonoBehaviour
{
	public UILabel DateLabel;

	public GameObject SignInIcon;

	public GameObject TodayIcon;

	private Transform _cacheTrans;

	private bool _isSignIn;

	private bool _isToday;

	private int _date;

	public Transform CacheTrans
	{
		get
		{
			if (_cacheTrans == null)
			{
				_cacheTrans = base.transform;
			}
			return _cacheTrans;
		}
	}

	public bool IsSignIn
	{
		get
		{
			return _isSignIn;
		}
		set
		{
			if (_isSignIn != value)
			{
				_isSignIn = value;
				UpdateSignIn();
			}
		}
	}

	public bool IsToday
	{
		get
		{
			return _isToday;
		}
		set
		{
			if (_isToday != value)
			{
				_isToday = value;
				UpdateTodayIcon();
			}
		}
	}

	public int Date => _date;

	public void SetDate(int date, bool isWeekend = false)
	{
		_date = date;
		if (isWeekend)
		{
			DateLabel.text = string.Format(CommonTools.GetDictString("activity_month_weekend"), _date);
		}
		else
		{
			DateLabel.text = string.Format(CommonTools.GetDictString("activity_month_01"), _date);
		}
	}

	public void UpdateSignIn()
	{
		SignInIcon.SetActive(_isSignIn);
	}

	public void UpdateTodayIcon()
	{
		TodayIcon.SetActive(_isToday);
	}
}
