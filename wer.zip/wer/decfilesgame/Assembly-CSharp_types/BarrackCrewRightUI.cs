using UnityEngine;

public class BarrackCrewRightUI : MonoBehaviour
{
	public UILabel name_label;

	public UILabel status_label;

	public UISlicedSprite nationimg;

	public UITexture icon;

	public int imgheight;

	public int imgwidth;
}
