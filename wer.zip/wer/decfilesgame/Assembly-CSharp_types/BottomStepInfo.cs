using UnityEngine;

public class BottomStepInfo : UIBase
{
	private const int MaxWidth = 600;

	private const int DeltaWidth = 5;

	private const int SpriteY = -22;

	public UISprite Background;

	public UISprite ImageTip;

	public UILabel TextTip;

	public UILabel TextTitle;

	public override void Init()
	{
		Width = 0f;
		Height = 100f;
		PositionType = UIPositionType.Bottom;
		OffsetHeight = 10f;
		Depth = 350f;
		SetPosition();
	}

	public void ShowOrHide(bool show)
	{
		base.gameObject.SetActive(show);
		if (!show)
		{
			ImageTip.alpha = 0f;
			TextTip.alpha = 0f;
		}
	}

	public void SetImageTextTip(string spriteName, string msgKey, string titleKey = null)
	{
		TextTip.lineWidth = 0;
		TextTip.text = CommonTools.GetDictString(msgKey);
		if (string.IsNullOrEmpty(spriteName))
		{
			ImageTip.alpha = 0f;
			TextTip.cachedTransform.localPosition = Vector3.zero;
			TextTip.pivot = UIWidget.Pivot.Center;
			TextTip.lineWidth = 600;
		}
		else
		{
			ImageTip.spriteName = spriteName;
			ImageTip.MakePixelPerfect();
			TextTip.pivot = UIWidget.Pivot.Left;
			float x = ImageTip.cachedTransform.localScale.x;
			float x2 = NGUIMath.CalculateRelativeWidgetBounds(TextTip.cachedTransform.parent, TextTip.cachedTransform).size.x;
			float value = x + 5f + x2;
			value = Mathf.Clamp(value, 0f, 600f);
			TextTip.lineWidth = (int)(value - x);
			float y = CommonTools.GetUILabelSize(TextTip).y;
			Vector3 localScale = Background.cachedTransform.localScale;
			ImageTip.cachedTransform.localPosition = CommonTools.MakePixelPerfect(new Vector3((0f - value) / 2f + x, -22f, 0f));
			ImageTip.alpha = 1f;
			if (string.IsNullOrEmpty(titleKey))
			{
				localScale.y = y + 20f;
				TextTip.cachedTransform.localPosition = CommonTools.MakePixelPerfect(new Vector3((0f - value) / 2f + x + 5f, 0f, 0f));
			}
			else
			{
				TextTip.pivot = UIWidget.Pivot.Left;
				TextTitle.pivot = UIWidget.Pivot.Left;
				TextTitle.text = CommonTools.GetDictString(titleKey);
				localScale.y = y + 30f;
				TextTitle.cachedTransform.localPosition = CommonTools.MakePixelPerfect(new Vector3((0f - value) / 2f + x + 5f, localScale.y * 0.5f - 18f, 0f));
				TextTip.cachedTransform.localPosition = CommonTools.MakePixelPerfect(new Vector3((0f - value) / 2f + x + 5f, (localScale.y - 30f) * -0.5f, 0f));
			}
			Background.cachedTransform.localScale = localScale;
		}
		TextTip.alpha = 1f;
	}

	private void OnChangeScreenHandle()
	{
		ChangePositon();
	}
}
