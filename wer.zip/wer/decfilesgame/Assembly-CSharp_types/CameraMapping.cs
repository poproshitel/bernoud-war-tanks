using UnityEngine;

public class CameraMapping : MonoBehaviour
{
	private Camera _mappingCamera;

	private RenderTexture _renderTexture;

	private GameObject _targetGameObject;

	public UITexture UiTexture;

	public Transform Parent
	{
		get
		{
			return base.transform.parent;
		}
		set
		{
			base.transform.parent = value;
		}
	}

	public Camera MappingCamera => _mappingCamera;

	public GameObject TargetGameObject
	{
		get
		{
			return _targetGameObject;
		}
		set
		{
			_targetGameObject = value;
			_targetGameObject.transform.parent = base.transform;
			_targetGameObject.transform.transform.localPosition = new Vector3(0f, 0f, 10f);
		}
	}

	public RenderTexture RenderTexture(int width, int height, int depth)
	{
		if (_renderTexture != null)
		{
			Object.Destroy(_renderTexture);
		}
		_renderTexture = new RenderTexture(width, height, depth);
		_renderTexture.name = "RenderTexture";
		_mappingCamera.targetTexture = _renderTexture;
		return _renderTexture;
	}

	private void Awake()
	{
		GameObject gameObject = new GameObject("Camera");
		gameObject.transform.parent = base.transform;
		_mappingCamera = gameObject.AddComponent<Camera>();
	}

	private void Update()
	{
		if (UiTexture != null)
		{
			UiTexture.material.mainTexture = _renderTexture;
		}
	}

	public static CameraMapping CreateCameraMapping()
	{
		GameObject gameObject = new GameObject("CameraMapping");
		return gameObject.AddComponent<CameraMapping>();
	}
}
