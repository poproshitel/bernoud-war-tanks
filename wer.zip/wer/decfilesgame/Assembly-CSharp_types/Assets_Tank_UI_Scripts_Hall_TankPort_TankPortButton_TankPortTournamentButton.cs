using System;

namespace Assets.Tank.UI.Scripts.Hall.TankPort.TankPortButton;

public class TankPortTournamentButton : ToggleFAceButton
{
	public UILabel TimeLeftLabel;

	public override void HonverState()
	{
		Sprite.spriteName = "garage_jinbiaosai2";
	}

	public override void NomalState()
	{
		Sprite.spriteName = "garage_jinbiaosai1";
	}

	public override void PressState()
	{
		Sprite.spriteName = "garage_jinbiaosai3";
	}

	public override Type GetPanelType()
	{
		return typeof(ActivityMainPanelUi);
	}

	protected override void OnClickHandler()
	{
		HallGuiManager.Instance.Get<ActivityMainPanelUi>().OpenPanel(ActivityWindowType.Tournament);
	}

	public override void Init()
	{
		base.Init();
		base.TipLabel = CommonTools.GetDictString("tournament_tip");
		UpdateVisibility();
	}

	public void UpdateVisibility()
	{
		base.gameObject.SetActive(TournamentManager.Instance.tournament_status != 0 && TournamentManager.Instance.tournament_status != TournamentStatus.TS_CLOSE);
	}

	public void OnDestroy()
	{
		TournamentManager.Instance.StatusChangedEvent -= UpdateVisibility;
	}

	protected override void Awake()
	{
		TournamentManager.Instance.StatusChangedEvent += UpdateVisibility;
	}
}
