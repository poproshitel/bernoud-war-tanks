using UnityEngine;

public class BaseConfig : MonoBehaviour
{
	public ConfigType TypeOfConfig;

	public UIFont DirectionFont;

	public virtual void Initial()
	{
	}

	public virtual void OnDefault()
	{
	}

	public virtual void OnApply()
	{
	}

	public virtual void OnCancle()
	{
	}

	public virtual void OnEnsure()
	{
	}

	public void TurnToGrey(ButtonType type, bool value)
	{
		base.transform.parent.gameObject.GetComponent<ConfigPanel>().SetEnable(type, value);
	}
}
