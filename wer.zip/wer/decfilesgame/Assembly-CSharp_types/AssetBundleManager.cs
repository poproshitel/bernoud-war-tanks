using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class AssetBundleManager
{
	public delegate void LoadingStartedHandler(AssetLoader loader);

	public delegate void LoadingHandler(float process, string assetUrl);

	public const int MaxLoadingCount = 6;

	[SerializeField]
	private List<AssetLoader> _loadings = new List<AssetLoader>();

	[SerializeField]
	private List<AssetLoader> _waitings = new List<AssetLoader>();

	private Dictionary<ResourceType, Dictionary<string, AssetLoader>> _caches = new Dictionary<ResourceType, Dictionary<string, AssetLoader>>();

	public event LoadingStartedHandler LoadingStarted;

	public event LoadingHandler LoadingEvent;

	protected void FireLoadingStarted(AssetLoader loader)
	{
		if (this.LoadingStarted != null)
		{
			this.LoadingStarted(loader);
		}
	}

	public AssetLoader LoadFromCacheOrDownload(ResourceType type, string url, bool isEncrypted = false, bool log = false)
	{
		if (string.IsNullOrEmpty(url))
		{
			return null;
		}
		if (!_caches.ContainsKey(type))
		{
			_caches.Add(type, new Dictionary<string, AssetLoader>());
		}
		Dictionary<string, AssetLoader> dictionary = _caches[type];
		AssetLoader value = null;
		if (!dictionary.TryGetValue(url, out value))
		{
			int version = 20221223;
			value = ((!Application.isEditor && !Application.isWebPlayer) ? ((AssetLoader)new AssetResourceLoader(url, type, version, isEncrypted, log)) : ((AssetLoader)new AssetBundleLoader(url, type, version, isEncrypted)));
			if (!_waitings.Contains(value))
			{
				_waitings.Add(value);
				FireLoadingStarted(value);
			}
			dictionary.Add(url, value);
		}
		return value;
	}

	public AssetLoader Retrieve(ResourceType type, string url)
	{
		return Retrieve(type, url, log: false);
	}

	public AssetLoader Retrieve(ResourceType type, string url, bool log)
	{
		if (string.IsNullOrEmpty(url))
		{
			TKLog.Log("string.IsNullOrEmpty(url)    " + url);
			return null;
		}
		AssetLoader value = null;
		if (_caches.TryGetValue(type, out var value2))
		{
			value2.TryGetValue(url, out value);
		}
		TKLog.Log(log, "ABM.R retrieve loader=" + value);
		return value;
	}

	public AsyncOperation UnloadRoomAssets()
	{
		ResourcesManager.Instance.ClearUITextureMaterials();
		Dictionary<ResourceType, List<string>> dictionary = new Dictionary<ResourceType, List<string>>();
		foreach (KeyValuePair<ResourceType, Dictionary<string, AssetLoader>> cache in _caches)
		{
			ResourceType key = cache.Key;
			Dictionary<string, AssetLoader> value = cache.Value;
			if (!dictionary.ContainsKey(key))
			{
				dictionary.Add(key, new List<string>());
			}
			List<string> list = dictionary[key];
			foreach (KeyValuePair<string, AssetLoader> item in value)
			{
				if (item.Value.GetStageLevel() == Level.Room)
				{
					list.Add(item.Key);
				}
			}
		}
		foreach (KeyValuePair<ResourceType, List<string>> item2 in dictionary)
		{
			ResourceType key2 = item2.Key;
			List<string> value2 = item2.Value;
			foreach (string item3 in value2)
			{
				Unload(key2, item3, unloadAllLoadedObjects: true);
			}
		}
		return Resources.UnloadUnusedAssets();
	}

	public AsyncOperation UnLoadHallAssets()
	{
		ResourcesManager.Instance.ClearUITextureMaterials();
		Dictionary<ResourceType, List<string>> dictionary = new Dictionary<ResourceType, List<string>>();
		foreach (KeyValuePair<ResourceType, Dictionary<string, AssetLoader>> cache in _caches)
		{
			ResourceType key = cache.Key;
			Dictionary<string, AssetLoader> value = cache.Value;
			switch (key)
			{
			case ResourceType.TankMain:
			case ResourceType.TankTurret:
			case ResourceType.TankGun:
			case ResourceType.Font:
				continue;
			}
			if (!dictionary.ContainsKey(key))
			{
				dictionary.Add(key, new List<string>());
			}
			List<string> list = dictionary[key];
			foreach (KeyValuePair<string, AssetLoader> item in value)
			{
				if (item.Value.GetStageLevel() == Level.Hall)
				{
					list.Add(item.Key);
				}
			}
		}
		foreach (KeyValuePair<ResourceType, List<string>> item2 in dictionary)
		{
			ResourceType key2 = item2.Key;
			List<string> value2 = item2.Value;
			foreach (string item3 in value2)
			{
				Unload(key2, item3, unloadAllLoadedObjects: true);
			}
		}
		return Resources.UnloadUnusedAssets();
	}

	public void Unload(ResourceType type, string url, bool unloadAllLoadedObjects)
	{
		for (int num = _waitings.Count - 1; num >= 0; num--)
		{
			AssetLoader assetLoader = _waitings[num];
			if (assetLoader.GetURL() == url)
			{
				_waitings.RemoveAt(num);
				break;
			}
		}
		for (int num2 = _loadings.Count - 1; num2 >= 0; num2--)
		{
			AssetLoader assetLoader2 = _loadings[num2];
			if (assetLoader2.GetURL() == url)
			{
				_loadings.RemoveAt(num2);
				break;
			}
		}
		AssetLoader value = null;
		if (_caches.TryGetValue(type, out var value2) && value2.TryGetValue(url, out value))
		{
			value.Unload(unloadAllLoadedObjects);
			value2.Remove(url);
		}
	}

	public void Update(float deltaTime)
	{
		if (_loadings.Count == 0 && _waitings.Count == 0)
		{
			return;
		}
		while (_loadings.Count < 6 && _waitings.Count > 0)
		{
			AssetLoader assetLoader = _waitings[0];
			_waitings.Remove(assetLoader);
			TKLog.Log(ReadConfig.LogResources, "ABM.U {0} loadings + {1} ", _loadings.Count, assetLoader);
			_loadings.Add(assetLoader);
			assetLoader.Start();
		}
		for (int i = 0; i < _loadings.Count; i++)
		{
			AssetLoader assetLoader2 = _loadings[i];
			if (assetLoader2.IsLoading())
			{
				if (this.LoadingEvent != null && assetLoader2.GetLoadingProgress() != 1f)
				{
					this.LoadingEvent(assetLoader2.GetLoadingProgress(), assetLoader2.GetURL());
				}
				assetLoader2.Update(deltaTime);
			}
			else
			{
				TKLog.Log(ReadConfig.LogResources, "ABM.U {0} loadings - {1} ", _loadings.Count, assetLoader2);
				_loadings.Remove(assetLoader2);
			}
		}
	}

	public void OnDestroy()
	{
		UnloadAllAssets();
		_waitings.Clear();
		_waitings = null;
		_loadings.Clear();
		_loadings = null;
		_caches.Clear();
		_caches = null;
		Resources.UnloadUnusedAssets();
	}

	public AsyncOperation UnloadAllAssets()
	{
		ResourcesManager.Instance.ClearUITextureMaterials();
		Dictionary<ResourceType, List<string>> dictionary = new Dictionary<ResourceType, List<string>>();
		foreach (KeyValuePair<ResourceType, Dictionary<string, AssetLoader>> cache in _caches)
		{
			ResourceType key = cache.Key;
			Dictionary<string, AssetLoader> value = cache.Value;
			if (!dictionary.ContainsKey(key))
			{
				dictionary.Add(key, new List<string>());
			}
			List<string> list = dictionary[key];
			foreach (KeyValuePair<string, AssetLoader> item in value)
			{
				list.Add(item.Key);
			}
		}
		foreach (KeyValuePair<ResourceType, List<string>> item2 in dictionary)
		{
			ResourceType key2 = item2.Key;
			List<string> value2 = item2.Value;
			foreach (string item3 in value2)
			{
				Unload(key2, item3, unloadAllLoadedObjects: true);
			}
		}
		return Resources.UnloadUnusedAssets();
	}
}
