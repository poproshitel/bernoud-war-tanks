using TK;
using UnityEngine;

public class BattleObserverMediator : MonoBehaviour
{
	public bool IsBattleObserver;

	public bool Test;

	public static string ThirdType = "ThirdType";

	public static string FirstType = "FirstType";

	public string CurrentType;

	public bool IsFristSetting;

	private void Start()
	{
		RoomGUIManager.Instance.Get<ChatLabelNode>().InputLabel.InputStage = false;
		NGUITools.SetActive(RoomGUIManager.Instance.Get<SightUI>().FirstUi.gameObject, state: false);
		NGUITools.SetActive(RoomGUIManager.Instance.Get<SightUI>().ThirdUi.gameObject, state: false);
		RoomGUIManager.Instance.Get<OperateControl>().HidenMainPlayer();
		RoomGUIManager.Instance.Get<LargeMapControl>().HidenMainPlayer();
		if (RoomGUIManager.Instance.Get<SightUI>().GunContinuousFireUi != null)
		{
			NGUITools.SetActive(RoomGUIManager.Instance.Get<SightUI>().GunContinuousFireUi.gameObject, state: false);
		}
		NGUITools.SetActive(RoomGUIManager.Instance.Get<ControlShellProvisionPosition>().gameObject, state: false);
	}

	private void BattleObserverCameraFirst()
	{
		if (CurrentType != FirstType)
		{
			UpdateRoomPanelOnObserve();
			ShowRoomTank(show: false);
			CurrentType = FirstType;
			GameManager.RoomNetwork.SendRequsetFreeView(1);
			CameraManager.Instance.UpdateChangeToObserveFirst();
		}
	}

	private void BattleObserverCameraThird()
	{
		if (CurrentType != ThirdType)
		{
			UpdateRoomPanelOnNormal();
			ShowRoomTank(show: true);
			CurrentType = ThirdType;
			GameManager.RoomNetwork.SendRequsetFreeView(2);
			CameraManager.Instance.UpdateChangeToObserveThird();
		}
	}

	public void UpdateRoomPanelOnObserve()
	{
		UpdateRoomPanel(show: false);
	}

	public void UpdateRoomPanelOnNormal()
	{
		UpdateRoomPanel(show: true);
	}

	public void ShowRoomTank(bool show)
	{
	}

	private void UpdateRoomPanel(bool show)
	{
		NGUITools.SetActive(RoomGUIManager.Instance.Get<TankUIState>().gameObject, show);
		NGUITools.SetActive(RoomGUIManager.Instance.Get<ControlShellProvisionPosition>().gameObject, state: false);
		if (show)
		{
			RoomGUIManager.Instance.Get<UIObserverHelpPanel>().ShowFirstObserverHelpPanelView();
			RoomGUIManager.Instance.Get<TankUIState>().OnChangeObserTypeHander();
			RoomGUIManager.Instance.Get<TankUIState>().ShowSpeedAndTankWardOffGrade();
		}
		else
		{
			RoomGUIManager.Instance.Get<UIObserverHelpPanel>().ShowThridObserverHelpPanelView();
		}
		NGUITools.SetActive(RoomGUIManager.Instance.Get<TankUIState>().PlayerNameLabel.gameObject, state: false);
		NGUITools.SetActive(RoomGUIManager.Instance.Get<AimAreaUI>().gameObject, state: false);
		NGUITools.SetActive(RoomGUIManager.Instance.Get<ControlShellProvisionPosition>().TankCannonballOperation.CannonballTwinklingEffectSprite.gameObject, state: false);
	}
}
