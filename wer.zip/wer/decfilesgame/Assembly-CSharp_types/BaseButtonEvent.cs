using System.Collections;
using UnityEngine;

[RequireComponent(typeof(BoxCollider))]
public class BaseButtonEvent : MonoBehaviour
{
	public ButtonType TypeOfButton;

	public GameObject target;

	public GameObject ClickTarget;

	public bool OnlyBearLeft = true;

	public string MouseOverFunction;

	public string MouseOutFunction;

	public string MousePressFunction;

	public string MouseReleaseFunction;

	public string MouseClickFunction;

	public string MouseRightClickFunction;

	protected bool mStarted;

	protected bool _showTips;

	public Transform CachedTransform;

	protected UILabel _tipsLabel;

	protected float _showTime;

	private void Start()
	{
		Init();
	}

	protected void Init()
	{
		mStarted = true;
		CachedTransform = base.transform;
	}

	protected void OnEnable()
	{
		if (mStarted)
		{
			OnHover(UICamera.IsHighlighted(base.gameObject));
		}
	}

	protected virtual void OnPress(bool isPressed)
	{
		if (!base.enabled)
		{
			return;
		}
		if (isPressed)
		{
			if (OnlyBearLeft)
			{
				if (Input.GetMouseButtonDown(0))
				{
					Send(TriggerStage.OnPress);
				}
			}
			else
			{
				Send(TriggerStage.OnPress);
			}
		}
		else if (OnlyBearLeft)
		{
			if (Input.GetMouseButtonDown(0))
			{
				Send(TriggerStage.OnRelease);
			}
		}
		else
		{
			Send(TriggerStage.OnRelease);
		}
	}

	protected virtual void OnClick()
	{
		if (base.enabled)
		{
			float realtimeSinceStartup = Time.realtimeSinceStartup;
			if (Input.GetMouseButtonUp(0))
			{
				Send(TriggerStage.OnClick);
			}
			else if (Input.GetMouseButtonUp(1))
			{
				Send(TriggerStage.OnRightClick);
			}
		}
	}

	protected virtual void OnHover(bool isOver)
	{
		if (!base.enabled)
		{
			return;
		}
		if (isOver)
		{
			Send(TriggerStage.OnMouseOver);
			if (_showTips)
			{
				StartCoroutine(WaitAndPrint(_showTime));
			}
			return;
		}
		Send(TriggerStage.OnMouseOut);
		if (_showTips)
		{
			StopCoroutine("WaitAndPrint");
			ShowTips(value: false);
		}
	}

	private IEnumerator WaitAndPrint(float waitTime)
	{
		yield return new WaitForSeconds(waitTime);
		ShowTips(value: true);
	}

	protected void ShowTips(bool value)
	{
		NGUITools.SetActive(_tipsLabel.gameObject, value);
	}

	protected void Send(TriggerStage stage)
	{
		if (target == null && ClickTarget == null)
		{
			return;
		}
		switch (stage)
		{
		case TriggerStage.OnMouseOver:
			if (!string.IsNullOrEmpty(MouseOverFunction))
			{
				target.SendMessage(MouseOverFunction, this, SendMessageOptions.DontRequireReceiver);
			}
			break;
		case TriggerStage.OnMouseOut:
			if (!string.IsNullOrEmpty(MouseOutFunction))
			{
				target.SendMessage(MouseOutFunction, this, SendMessageOptions.DontRequireReceiver);
			}
			break;
		case TriggerStage.OnPress:
			if (!string.IsNullOrEmpty(MousePressFunction))
			{
				target.SendMessage(MousePressFunction, this, SendMessageOptions.DontRequireReceiver);
			}
			break;
		case TriggerStage.OnRelease:
			if (!string.IsNullOrEmpty(MouseReleaseFunction))
			{
				target.SendMessage(MouseReleaseFunction, this, SendMessageOptions.DontRequireReceiver);
			}
			break;
		case TriggerStage.OnClick:
			if (!string.IsNullOrEmpty(MouseClickFunction))
			{
				if (ClickTarget == null)
				{
					target.SendMessage(MouseClickFunction, this, SendMessageOptions.DontRequireReceiver);
				}
				else
				{
					ClickTarget.SendMessage(MouseClickFunction, this, SendMessageOptions.DontRequireReceiver);
				}
			}
			break;
		case TriggerStage.OnRightClick:
			if (!string.IsNullOrEmpty(MouseRightClickFunction))
			{
				target.SendMessage(MouseRightClickFunction, this, SendMessageOptions.DontRequireReceiver);
			}
			break;
		case TriggerStage.OnDoubleClick:
			break;
		}
	}

	public void AddTips(string content, float value, GameObject parent, UIFont fontSource, float x = 0f, float y = 0f, float z = 0f)
	{
		if (value <= 1f)
		{
			_showTime = 1f;
		}
		else
		{
			_showTime = value;
		}
		_showTips = true;
		_tipsLabel = NGUITools.AddWidget<UILabel>(parent);
		_tipsLabel.font = fontSource;
		_tipsLabel.cachedTransform.parent = parent.transform;
		_tipsLabel.cachedTransform.localPosition = new Vector3(x, y, z);
		_tipsLabel.cachedTransform.localScale = new Vector3(16f, 16f, 1f);
		_tipsLabel.text = content;
		ShowTips(value: false);
	}
}
