using UnityEngine;

public class BaseActivityTemplate : MonoBehaviour
{
	public EnumActivityCenterTemplate Type;

	protected ActivityCenterDataManager data = Singleton<ActivityCenterDataManager>.Instance;

	private void Awake()
	{
		Init();
	}

	public virtual void Init()
	{
	}

	public virtual void UpdatePanel(object para)
	{
	}

	public virtual void ShowOrHide(bool flag)
	{
		base.gameObject.SetActive(flag);
	}
}
