using SceneCameraStruct;
using TK;
using UnityEngine;

public class CameraManagerNew : MonoBehaviour
{
	public GameObject FirstSight;

	public GameObject ThirdSight;

	private CamThirdModel thirdCamFuc;

	private AlphaHandle alphaHandle;

	private CamFirstModel firstCamFuc;

	private CameraState _cameraState = CameraState.Third;

	public static CameraManagerNew Instance;

	[SerializeField]
	private int _alaphMask;

	private Vector3 _firstUIPosition;

	private Vector3 _uiPosition;

	public bool IsFirstPerson;

	public Vector3 UIPosition
	{
		get
		{
			if (_cameraState == CameraState.First)
			{
				return _firstUIPosition;
			}
			return _uiPosition;
		}
	}

	public int AlaphMask => _alaphMask;

	public TankModel TankModel
	{
		get
		{
			if (SceneRoom.Instance.GetMainPlayer().TankModel != null)
			{
				return SceneRoom.Instance.GetMainPlayer().TankModel;
			}
			return null;
		}
	}

	public float MaxAmmoDistance
	{
		set
		{
			if (thirdCamFuc == null)
			{
				thirdCamFuc = GetComponent<CamThirdModel>();
			}
			thirdCamFuc.MaxAmmoDistance = value;
			if (firstCamFuc == null)
			{
				firstCamFuc = GetComponent<CamFirstModel>();
			}
			firstCamFuc.MaxAmmoDistance = value;
		}
	}

	public float FirstLimitUp
	{
		set
		{
			if (firstCamFuc == null)
			{
				firstCamFuc = GetComponent<CamFirstModel>();
			}
			firstCamFuc._limitUp = value;
		}
	}

	public Vector3 ShootPoint
	{
		get
		{
			Vector3 result = Vector3.zero;
			switch (_cameraState)
			{
			case CameraState.Third:
				result = thirdCamFuc.ShootPoint.point;
				break;
			case CameraState.First:
				result = firstCamFuc.ShootPoint.point;
				break;
			}
			return result;
		}
	}

	public CameraState CurrentCameraState => _cameraState;

	public Step CurCamStep
	{
		get
		{
			int result = 0;
			switch (_cameraState)
			{
			case CameraState.First:
				result = firstCamFuc.CurStep + 1;
				break;
			case CameraState.Third:
				result = thirdCamFuc.CurThirdStep + 4;
				break;
			case CameraState.Death:
				result = thirdCamFuc.CurThirdStep + 4;
				break;
			}
			return (Step)result;
		}
	}

	public int CurFirstStep => firstCamFuc.CurStep;

	public int CurThirdStep => thirdCamFuc.CurThirdStep;

	public void Init()
	{
		_alaphMask = 32768;
		if (thirdCamFuc == null)
		{
			thirdCamFuc = GetComponent<CamThirdModel>();
		}
		if (alphaHandle == null)
		{
			alphaHandle = GetComponent<AlphaHandle>();
		}
		if (firstCamFuc == null)
		{
			firstCamFuc = GetComponent<CamFirstModel>();
		}
		thirdCamFuc.Init();
		alphaHandle.Init();
		firstCamFuc.Init();
		base.enabled = true;
	}

	private void Awake()
	{
		Instance = this;
		base.enabled = false;
	}

	private void Update()
	{
		if (!base.enabled || alphaHandle == null || thirdCamFuc == null)
		{
			return;
		}
		UpdateUIParams();
		if (InputManager.ShootSurprisemodeDown && _cameraState != CameraState.Death)
		{
			if (!IsFirstPerson)
			{
				ChangeToFirst();
			}
			else
			{
				ChangeToThird();
			}
		}
		switch (_cameraState)
		{
		case CameraState.Third:
			thirdCamFuc.UpdateThird();
			break;
		case CameraState.First:
			firstCamFuc.UpdateFistModel();
			break;
		}
		alphaHandle.AlaphResetHandle(_cameraState);
	}

	private void UpdateUIParams()
	{
		float x = (float)Screen.width / 2f;
		float y = (float)Screen.height / 2f;
		if (_cameraState == CameraState.Third || _cameraState == CameraState.Death)
		{
			_uiPosition.x = x;
			_uiPosition.y = y;
			_uiPosition.z = 0f;
		}
		else
		{
			_firstUIPosition.x = x;
			_firstUIPosition.y = y;
			_firstUIPosition.z = 0f;
		}
	}

	private void ChangeToFirst()
	{
		firstCamFuc.ChangeToFirst();
		_cameraState = CameraState.First;
		ChangeFirstSight();
		IsFirstPerson = true;
	}

	private void ChangeToThird()
	{
		thirdCamFuc.ChangeToThird();
		_cameraState = CameraState.Third;
		ChangeThirdSight();
		IsFirstPerson = false;
	}

	public void ChangeToDeath()
	{
		_cameraState = CameraState.Death;
		ChangeThirdSight();
		IsFirstPerson = false;
	}

	public void ResetCam()
	{
		_cameraState = CameraState.Third;
		IsFirstPerson = false;
		SceneToGUI.UpdateSightUIBlood(1f);
		RoomGUIManager.Instance.Get<AimAreaUI>().ReSet(isDead: false);
		Init();
	}

	public void ChangeThirdSight()
	{
		FirstSight.SetActiveRecursively(state: false);
		ThirdSight.SetActiveRecursively(state: true);
	}

	public void ChangeFirstSight()
	{
		FirstSight.SetActiveRecursively(state: true);
		ThirdSight.SetActiveRecursively(state: false);
	}
}
