using System.Collections.Generic;

public class CAmmoStateManager
{
	private readonly CAmmoStateParam _ammoParam;

	private readonly Dictionary<AmmoStateType, AmmoStateBase> _stateDic;

	private AmmoStateType _curStateType;

	private bool _isMain;

	private AmmoStateType _nextStateType;

	private AmmoStateType _preStateType;

	public CAmmoStateManager(CAmmoStateParam param)
	{
		_ammoParam = param;
		_curStateType = AmmoStateType.Invaid;
		_preStateType = AmmoStateType.Invaid;
		_nextStateType = AmmoStateType.Invaid;
		_stateDic = new Dictionary<AmmoStateType, AmmoStateBase>();
		_stateDic.Clear();
	}

	public void CreateState(bool isMain)
	{
		_isMain = isMain;
		if (isMain)
		{
			_stateDic.Add(AmmoStateType.Invaid, new AmmoStateInvalid());
			_stateDic.Add(AmmoStateType.FlyMain, new AmmoStateFlyMain());
			_stateDic.Add(AmmoStateType.HitMain, new AmmoStateHitMain());
			_stateDic.Add(AmmoStateType.Jump, new AmmoStateJmup());
			_stateDic.Add(AmmoStateType.HitError, new AmmoStateHitError());
			_stateDic.Add(AmmoStateType.Bomb, new AmmoStateBomb());
			_stateDic.Add(AmmoStateType.Destroy, new AmmoStateDestroy());
		}
		else
		{
			_stateDic.Add(AmmoStateType.Invaid, new AmmoStateInvalid());
			_stateDic.Add(AmmoStateType.FlyRemoteHitpacketUnreachedFly, new AmmoStateFlyRemoteUnReach());
			_stateDic.Add(AmmoStateType.FlyRemoteHitpacketReachedFly, new AmmoStateFlyRemoteReach());
			_stateDic.Add(AmmoStateType.HitRemote, new AmmoStateHitRemote());
			_stateDic.Add(AmmoStateType.Jump, new AmmoStateJmup());
			_stateDic.Add(AmmoStateType.HitError, new AmmoStateHitError());
			_stateDic.Add(AmmoStateType.Bomb, new AmmoStateBomb());
			_stateDic.Add(AmmoStateType.Destroy, new AmmoStateDestroy());
		}
	}

	public void Init()
	{
		if (GetState(_curStateType) != null)
		{
			GetState(_curStateType).EnterState(_ammoParam);
		}
	}

	public void Update()
	{
		if (GetState(_curStateType) != null && GetState(_curStateType).UpdateState(_ammoParam))
		{
			_preStateType = _curStateType;
			GetState(_curStateType).LeaveState(_ammoParam, ref _nextStateType);
			_curStateType = _nextStateType;
			GetState(_curStateType).EnterState(_ammoParam);
		}
	}

	public void SetInitState(bool isReceive)
	{
		if (_isMain)
		{
			_curStateType = AmmoStateType.FlyMain;
			_preStateType = AmmoStateType.FlyMain;
		}
		else if (isReceive)
		{
			_curStateType = AmmoStateType.FlyRemoteHitpacketReachedFly;
			_preStateType = AmmoStateType.FlyRemoteHitpacketReachedFly;
		}
		else
		{
			_curStateType = AmmoStateType.FlyRemoteHitpacketUnreachedFly;
			_preStateType = AmmoStateType.FlyRemoteHitpacketUnreachedFly;
		}
	}

	private AmmoStateBase GetState(AmmoStateType stateType)
	{
		if (_stateDic.ContainsKey(stateType))
		{
			return _stateDic[stateType];
		}
		return null;
	}
}
