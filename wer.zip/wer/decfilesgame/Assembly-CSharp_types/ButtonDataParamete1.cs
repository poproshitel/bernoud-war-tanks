public class ButtonDataParamete1 : BaseButtonData
{
	public XXXCallBack1 Function;
}
