using System;

[Serializable]
public class AtlasAsset
{
	public int Id;

	public UIAtlas Target;
}
