using System;

[Serializable]
public abstract class BaseData
{
	public static int BaseDataItemCount;

	public static Action OnItemTypeCountChange;

	public string PartName;

	public NodePart Typeid;

	public int TableId;

	public bool IsResearched;

	public bool HasBought;

	public int Currency;

	public int Price;

	private ushort _count;

	public object TableData;

	public string Icon;

	public bool HasChecked;

	public float Discount = 1f;

	public ushort Count
	{
		get
		{
			return _count;
		}
		set
		{
			if (!(this is TankBaseData))
			{
				if (_count > 0 && value == 0)
				{
					BaseDataItemCount--;
				}
				else if (_count == 0 && value > 0)
				{
					BaseDataItemCount++;
				}
				if (OnItemTypeCountChange != null)
				{
					OnItemTypeCountChange();
				}
			}
			_count = value;
		}
	}

	public abstract bool Buy { get; }
}
