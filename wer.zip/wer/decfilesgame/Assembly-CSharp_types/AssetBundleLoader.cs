using System;
using TK;
using UnityEngine;

[Serializable]
public class AssetBundleLoader : AssetLoader
{
	public enum LoadingState
	{
		Null,
		Waiting,
		Loading,
		TryLoadingAgain,
		Decrypt,
		Loaded,
		LoadedFailed,
		UnLoading,
		UnLoaded
	}

	private LoadingState _loadingState;

	public AssetBundleLoader(string url, ResourceType type, int version, bool isEncrypted)
	{
		_retryTimes = 5;
		_url = url;
		_isEncrypted = isEncrypted;
		_version = version;
		_loadingState = LoadingState.Waiting;
		_type = type;
		_stageLevel = ((SceneEntity.Instance.GetFSM().GetCurrentState() == SceneHall.Instance) ? Level.Hall : Level.Room);
	}

	public override void Start()
	{
		try
		{
			_startTime = Time.realtimeSinceStartup;
			_lastContrastTime = Time.realtimeSinceStartup;
			string[] array = _url.Split(new char[1] { '?' }, StringSplitOptions.RemoveEmptyEntries);
			int num = 0;
			if (array.Length > 1)
			{
				num = int.Parse(array[1]);
			}
			_www = WWW.LoadFromCacheOrDownload(_url + "?t=" + _version, _version);
		}
		catch (Exception ex)
		{
			TKLog.Log(_url + ex);
			throw;
		}
		_loadingState = LoadingState.Loading;
	}

	protected override void FireLoadingFailed()
	{
		SaveLoadFailedResourceVersion();
		base.FireLoadingFailed();
	}

	private void SaveLoadFailedResourceVersion()
	{
		if (string.IsNullOrEmpty(_url))
		{
			return;
		}
		string[] array = _url.Split('/');
		if (array.Length > 0)
		{
			string key = array[array.Length - 1].Split('.')[0];
			if (PlayerPrefs.HasKey(key))
			{
				PlayerPrefs.DeleteKey(key);
			}
			_version++;
			PlayerPrefsStore.SetInt(key, _version);
			TKLog.Log("SaveLoadFailedResourceVersion: " + _url + " Version: " + _version);
		}
	}

	public override float GetLoadingProgress()
	{
		if (_loadingState == LoadingState.Waiting || _loadingState == LoadingState.TryLoadingAgain)
		{
			return 0f;
		}
		if (!IsIgnoredResource() && _loadingState == LoadingState.LoadedFailed)
		{
			return 0f;
		}
		if (_loadingState == LoadingState.Loading)
		{
			if (_www == null)
			{
				return 0f;
			}
			return _www.progress;
		}
		return 1f;
	}

	public override bool IsWaiting()
	{
		return _loadingState == LoadingState.Waiting;
	}

	public override bool IsLoading()
	{
		return _loadingState == LoadingState.Loading || _loadingState == LoadingState.Decrypt || _loadingState == LoadingState.TryLoadingAgain;
	}

	public override bool IsLoadFailed()
	{
		return _loadingState == LoadingState.LoadedFailed;
	}

	public override bool IsLoaded()
	{
		return _loadingState == LoadingState.Loaded;
	}

	public override void Unload(bool unloadAllLoadedObjects)
	{
		if (_loadingState == LoadingState.Loaded)
		{
			_loadingState = LoadingState.UnLoading;
			_assetBundle.Unload(unloadAllLoadedObjects);
			if (_assetBundleCreateRequest != null)
			{
				_assetBundleCreateRequest.assetBundle.Unload(unloadAllLoadedObjects);
			}
		}
		if (_www != null)
		{
			_www.Dispose();
		}
		_www = null;
		_assetBundle = null;
		_loadingState = LoadingState.UnLoaded;
	}

	public override void Update(float deltaTime)
	{
		if (_loadingState == LoadingState.Loading)
		{
			if (_www == null)
			{
				_loadingState = LoadingState.LoadedFailed;
			}
			else if (_www.isDone)
			{
				if (!string.IsNullOrEmpty(_www.error) || _www.assetBundle == null)
				{
					_loadingState = LoadingState.LoadedFailed;
				}
				else if (_isEncrypted)
				{
					if (_assetBundleCreateRequest == null)
					{
						if (!TankTools.DecryptAsset(_www, out var bytes))
						{
							_loadingState = LoadingState.LoadedFailed;
						}
						else
						{
							_assetBundleCreateRequest = AssetBundle.LoadFromMemoryAsync(bytes);
							_www.assetBundle.Unload(unloadAllLoadedObjects: false);
							_loadingState = LoadingState.Decrypt;
						}
					}
				}
				else
				{
					if (_assetBundle == null)
					{
						_assetBundle = _www.assetBundle;
					}
					if (_assetBundle == null)
					{
						_loadingState = LoadingState.LoadedFailed;
					}
					else
					{
						_loadingState = LoadingState.Loaded;
						_www.Dispose();
						_www = null;
					}
				}
			}
			else if (Time.realtimeSinceStartup - _lastContrastTime >= 15f)
			{
				_lastContrastTime = Time.realtimeSinceStartup;
				float num = (float)_size * _www.progress;
				if (num - _contrastSize <= 0f && num > 0f)
				{
					Debug.LogWarning(_url + " Time.realtimeSinceStartup - _startLoadTime >= 15 : " + _contrastSize + " " + num);
					num = 0f;
					if (!Retry())
					{
						_loadingState = LoadingState.LoadedFailed;
					}
				}
				_contrastSize = num;
			}
		}
		else if (_loadingState == LoadingState.Decrypt)
		{
			if (_assetBundleCreateRequest == null)
			{
				_loadingState = LoadingState.LoadedFailed;
			}
			else if (_assetBundleCreateRequest.isDone)
			{
				if (_assetBundleCreateRequest.assetBundle == null)
				{
					_loadingState = LoadingState.LoadedFailed;
				}
				else
				{
					_assetBundle = _assetBundleCreateRequest.assetBundle;
					_assetBundleCreateRequest = null;
					_www.Dispose();
					_www = null;
					_loadingState = LoadingState.Loaded;
				}
			}
		}
		if (_loadingState == LoadingState.Loaded)
		{
			FireLoadingComplete();
		}
		else if (_loadingState == LoadingState.LoadedFailed || Time.realtimeSinceStartup - _startTime > 5f)
		{
			if (_retryTimes <= 0)
			{
				FireLoadingFailed();
			}
			else if (_retryTimes <= 2)
			{
				_loadingState = LoadingState.TryLoadingAgain;
			}
			else
			{
				Retry();
			}
		}
		else if (_loadingState == LoadingState.TryLoadingAgain && Time.realtimeSinceStartup - _startTime > 10f)
		{
			Retry();
		}
	}

	public override string ToString()
	{
		return string.Concat("[AssetBundleLoader ", _url, " ", _loadingState, " hasContent:", _assetBundle != null, "]");
	}
}
