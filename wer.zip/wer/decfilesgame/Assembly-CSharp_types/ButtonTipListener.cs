using UnityEngine;

public class ButtonTipListener : ToolTipsListen
{
	private Tips _curTips;

	private TipsData _showData = new TipsData();

	private void Awake()
	{
	}

	private void TooolTipsXXX(bool value)
	{
		if (value)
		{
			_curTips = GUITools.AddTips(UITipStyle.Normal, _showData, getPos: false, moveByMouse: false);
		}
		else
		{
			DestroyTips();
		}
	}

	public static ButtonTipListener AddTipToButton(GameObject target, string showValue, int lineWidth = 0)
	{
		if (target == null)
		{
			return null;
		}
		ButtonTipListener component = target.GetComponent<ButtonTipListener>();
		if (component != null)
		{
			Object.DestroyImmediate(component);
		}
		ButtonTipListener buttonTipListener = target.AddComponent<ButtonTipListener>();
		buttonTipListener.Target = target;
		buttonTipListener._showData.LineWidth = lineWidth;
		buttonTipListener._showData.Contex = showValue;
		return buttonTipListener;
	}

	public static ButtonTipListener AddTipToButton(GameObject target, UILabel textureArea, int buttonWidth, string tip = null)
	{
		if (textureArea == null || target == null || buttonWidth < 0)
		{
			TKLog.LogWarning("ButtonTipListener Adding... Parameter is invalid!!!!!");
			return null;
		}
		textureArea.lineWidth = buttonWidth - UiConst.ButtonLineWidthDiffer;
		int lineWidth = textureArea.lineWidth;
		textureArea.lineWidth = 0;
		Vector2 uILabelSize = CommonTools.GetUILabelSize(textureArea);
		string arg = ((tip == null) ? textureArea.text : tip);
		if (uILabelSize.x <= (float)lineWidth)
		{
			textureArea.lineWidth = lineWidth;
		}
		else
		{
			textureArea.lineWidth = lineWidth;
			textureArea.text = CommonTools.FitUilabelShowWidth(textureArea);
		}
		ButtonTipListener buttonTipListener = target.GetComponent<ButtonTipListener>();
		if (buttonTipListener == null)
		{
			buttonTipListener = target.AddComponent<ButtonTipListener>();
		}
		buttonTipListener.Target = target;
		buttonTipListener._showData.Contex = string.Format(GameManager.TableMgr.GetDirString("tvs_itemlist_des").value, arg);
		return buttonTipListener;
	}

	public static ButtonTipListener AddTipToButton(GameObject target, UILabel textureArea, int buttonWidth, string tipContex, bool isDefaultStyle = true)
	{
		if (textureArea == null || target == null || buttonWidth < 0)
		{
			TKLog.LogWarning("ButtonTipListener Adding... Parameter is invalid!!!!!");
			return null;
		}
		textureArea.lineWidth = buttonWidth - UiConst.ButtonLineWidthDiffer;
		int lineWidth = textureArea.lineWidth;
		textureArea.lineWidth = 0;
		Vector2 uILabelSize = CommonTools.GetUILabelSize(textureArea);
		string text = textureArea.text;
		if (uILabelSize.x <= (float)lineWidth)
		{
			textureArea.lineWidth = lineWidth;
		}
		else
		{
			textureArea.lineWidth = lineWidth;
			textureArea.text = CommonTools.FitUilabelShowWidth(textureArea);
		}
		ButtonTipListener buttonTipListener = target.GetComponent<ButtonTipListener>();
		if (buttonTipListener == null)
		{
			buttonTipListener = target.AddComponent<ButtonTipListener>();
		}
		buttonTipListener.Target = target;
		buttonTipListener._showData.Contex = ((!isDefaultStyle) ? tipContex : string.Format(GameManager.TableMgr.GetDirString("tvs_itemlist_des").value, tipContex));
		return buttonTipListener;
	}

	public static ButtonTipListener AddTipToCheckBox(CheckBoxControl target, int buttonWidth)
	{
		if (target == null || target.Function == null || buttonWidth < 0)
		{
			TKLog.LogWarning("ButtonTipListener Adding... Parameter is invalid!!!!!");
			return null;
		}
		target.Function.lineWidth = buttonWidth - UiConst.ButtonLineWidthDiffer;
		int lineWidth = target.Function.lineWidth;
		target.Function.lineWidth = 0;
		Vector2 uILabelSize = CommonTools.GetUILabelSize(target.Function);
		string text = target.Function.text;
		if (uILabelSize.x <= (float)lineWidth)
		{
			target.Function.lineWidth = 0;
		}
		else
		{
			target.Function.lineWidth = lineWidth;
			target.Function.text = CommonTools.FitUilabelShowWidth(target.Function);
		}
		target.CalColliderSize();
		ButtonTipListener buttonTipListener = target.GetComponent<ButtonTipListener>();
		if (buttonTipListener == null)
		{
			buttonTipListener = target.gameObject.AddComponent<ButtonTipListener>();
		}
		buttonTipListener.Target = target.gameObject;
		buttonTipListener._showData.Contex = string.Format(GameManager.TableMgr.GetDirString("tvs_itemlist_des").value, text);
		return buttonTipListener;
	}

	public static ButtonTipListener AddTipToMainTanaceCheckBox(MainTanaceCheckBox target, int buttonWidth)
	{
		if (target == null || target.Context == null || buttonWidth < 0)
		{
			TKLog.LogWarning("ButtonTipListener Adding... Parameter is invalid!!!!!");
			return null;
		}
		target.Context.lineWidth = buttonWidth - UiConst.ButtonLineWidthDiffer;
		int lineWidth = target.Context.lineWidth;
		target.Context.lineWidth = 0;
		Vector2 uILabelSize = CommonTools.GetUILabelSize(target.Context);
		string text = target.Context.text;
		if (uILabelSize.x <= (float)lineWidth)
		{
			target.Context.lineWidth = 0;
		}
		else
		{
			target.Context.lineWidth = lineWidth;
			target.Context.text = CommonTools.FitUilabelShowWidth(target.Context);
		}
		target.CalColliderSize();
		ButtonTipListener buttonTipListener = target.GetComponent<ButtonTipListener>();
		if (buttonTipListener == null)
		{
			buttonTipListener = target.gameObject.AddComponent<ButtonTipListener>();
		}
		buttonTipListener.Target = target.gameObject;
		buttonTipListener._showData.Contex = string.Format(GameManager.TableMgr.GetDirString("tvs_itemlist_des").value, text);
		return buttonTipListener;
	}

	public static void SetCheckboxLabel(Transform checkBox, UILabel label, int labelWidth = 0, bool addTip = true, string tip = null)
	{
		if (checkBox == null || label == null || labelWidth < 0)
		{
			TKLog.LogWarning("ButtonTipListener SetCheckboxLabel ... Parameter is invalid!!!!!");
			return;
		}
		string arg = ((tip == null) ? label.text : tip);
		label.lineWidth = 0;
		Vector2 uILabelSize = CommonTools.GetUILabelSize(label);
		label.lineWidth = labelWidth;
		if (uILabelSize.x > (float)labelWidth)
		{
			label.text = CommonTools.FitUilabelShowWidth(label);
		}
		Bounds bounds = NGUIMath.CalculateRelativeWidgetBounds(checkBox, checkBox);
		bounds.Encapsulate(NGUIMath.CalculateRelativeWidgetBounds(checkBox, label.cachedTransform));
		BoxCollider component = checkBox.GetComponent<BoxCollider>();
		if (component != null)
		{
			Vector3 center = component.center;
			center.x = bounds.center.x;
			center.y = bounds.center.y;
			component.center = center;
			center = bounds.size;
			center.z = 0f;
			component.size = center;
		}
		if (addTip)
		{
			ButtonTipListener buttonTipListener = checkBox.GetComponent<ButtonTipListener>();
			if (buttonTipListener == null)
			{
				buttonTipListener = checkBox.gameObject.AddComponent<ButtonTipListener>();
			}
			buttonTipListener.Target = checkBox.gameObject;
			buttonTipListener._showData.Contex = string.Format(GameManager.TableMgr.GetDirString("tvs_itemlist_des").value, arg);
		}
	}

	public static void SetEsayCheckboxCollider(EasyCheckBox checkBox, UILabel label, Transform parent)
	{
		if (checkBox == null || label == null || parent == null)
		{
			TKLog.LogWarning("ButtonTipListener SetCheckboxLabel ... Parameter is invalid!!!!!");
			return;
		}
		if (label.relativeSize.y <= 1f)
		{
			label.lineWidth = 0;
		}
		Bounds bounds = NGUIMath.CalculateRelativeWidgetBounds(checkBox.CachedTransform, checkBox.CachedTransform);
		bounds.Encapsulate(NGUIMath.CalculateRelativeWidgetBounds(checkBox.CachedTransform, label.cachedTransform));
		BoxCollider component = checkBox.GetComponent<BoxCollider>();
		if (component != null)
		{
			Vector3 center = component.center;
			center.x = bounds.center.x;
			center.y = bounds.center.y;
			component.center = center;
			center = bounds.size;
			center.z = 0f;
			component.size = center;
		}
		checkBox.ColliderInit = true;
	}

	public static ButtonTipListener AddTipToImageButton(GameObject target, string tipContex)
	{
		if (target == null)
		{
			TKLog.LogWarning("ButtonTipListener Adding... Parameter is invalid!!!!!");
			return null;
		}
		ButtonTipListener buttonTipListener = target.GetComponent<ButtonTipListener>();
		if (buttonTipListener == null)
		{
			buttonTipListener = target.AddComponent<ButtonTipListener>();
		}
		buttonTipListener.Target = target;
		buttonTipListener._showData.Contex = string.Format(GameManager.TableMgr.GetDirString("tvs_itemlist_des").value, tipContex);
		return buttonTipListener;
	}

	public static AreaButtonTipListener AddTipToAreaImageButton(GameObject target, string tipContex)
	{
		if (target == null)
		{
			TKLog.LogWarning("ButtonTipListener Adding... Parameter is invalid!!!!!");
			return null;
		}
		AreaButtonTipListener areaButtonTipListener = target.GetComponent<AreaButtonTipListener>();
		if (areaButtonTipListener == null)
		{
			areaButtonTipListener = target.AddComponent<AreaButtonTipListener>();
		}
		areaButtonTipListener.Target = target;
		return areaButtonTipListener;
	}

	public static ButtonTipListener ChangeTipToButton(GameObject target, string showValue, int lineWidth = 0)
	{
		if (target == null)
		{
			return null;
		}
		ButtonTipListener buttonTipListener = target.GetComponent<ButtonTipListener>();
		if (buttonTipListener != null)
		{
			buttonTipListener._showData.LineWidth = lineWidth;
			buttonTipListener._showData.Contex = showValue;
		}
		else
		{
			buttonTipListener = AddTipToButton(target, showValue, lineWidth);
		}
		return buttonTipListener;
	}

	public void DestroyTips()
	{
		if (_curTips != null)
		{
			Object.Destroy(_curTips.gameObject);
			_curTips = null;
		}
	}
}
