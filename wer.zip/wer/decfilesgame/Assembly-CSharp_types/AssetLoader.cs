using System;
using TK;
using UnityEngine;

[Serializable]
public abstract class AssetLoader
{
	protected bool _isEncrypted;

	[SerializeField]
	protected AssetBundleCreateRequest _assetBundleCreateRequest;

	protected AssetBundle _assetBundle;

	protected Level _stageLevel;

	protected ResourceType _type;

	[SerializeField]
	protected string _url;

	protected WWW _www;

	protected short _retryTimes;

	protected float _startTime;

	protected int _version;

	protected const float DelayRetryTime = 10f;

	protected int _size;

	protected const float ContrastTime = 15f;

	protected float _contrastSize;

	protected float _lastContrastTime;

	public event LoadingCompleteDelegate EventLoadingComplete;

	public event LoadingFailedDelegate EventLoadingFailed;

	protected void FireLoadingComplete()
	{
		if (this.EventLoadingComplete != null)
		{
			Level level = ((SceneEntity.Instance.GetFSM().GetCurrentState() == SceneHall.Instance) ? Level.Hall : Level.Room);
			if ((_type != ResourceType.Audio && _type != ResourceType.Particle) || _stageLevel == level)
			{
				this.EventLoadingComplete(this);
			}
			this.EventLoadingComplete = null;
		}
	}

	protected virtual void FireLoadingFailed()
	{
		TKLog.LogError("LoadingFailed: " + _url);
		if (this.EventLoadingFailed != null)
		{
			this.EventLoadingFailed(this);
			this.EventLoadingFailed = null;
		}
		if (!IsIgnoredResource())
		{
			SceneEntity.Instance.Stop();
			GUITools.RefearshDialog(delegate
			{
				CommonTools.Quit();
			});
		}
	}

	public WWW GetWWW()
	{
		return _www;
	}

	public string GetURL()
	{
		return _url;
	}

	public Level GetStageLevel()
	{
		return _stageLevel;
	}

	public AssetBundle GetAssetBundle()
	{
		return _assetBundle;
	}

	public bool IsCompleted()
	{
		if (IsWaiting() || IsLoading())
		{
			return false;
		}
		if (!IsIgnoredResource() && IsLoadFailed())
		{
			return false;
		}
		return true;
	}

	public int GetAssetSize()
	{
		if (_size != 0)
		{
			return _size;
		}
		if (string.IsNullOrEmpty(_url))
		{
			Debug.LogError("GetAssetSize() but string.IsNullOrEmpty(_url)");
			return int.MaxValue;
		}
		int length = GameManager.ServerInfo.AssetbundleBaseURL.Length;
		string text = _url.Substring(length, _url.Length - length);
		int num = text.LastIndexOf('_');
		if (num > 0)
		{
			text = text.Substring(0, num) + ".tk";
		}
		_size = GameManager.ServerInfo.GetAssetSize(text);
		return _size;
	}

	public abstract void Start();

	public abstract float GetLoadingProgress();

	public abstract bool IsWaiting();

	public abstract bool IsLoading();

	public abstract bool IsLoadFailed();

	public abstract bool IsLoaded();

	public abstract void Unload(bool unloadAllLoadedObjects);

	public abstract void Update(float deltaTime);

	protected bool Retry()
	{
		if (_www != null)
		{
			_www.Dispose();
			_www = null;
		}
		if (_retryTimes > 0)
		{
			_retryTimes--;
			_version++;
			Start();
			TKLog.Log("RetryTimes : " + (5 - _retryTimes) + " " + this);
			return true;
		}
		return false;
	}

	protected bool IsIgnoredResource()
	{
		if (_type == ResourceType.Particle || _type == ResourceType.Audio || _type == ResourceType.Texture)
		{
			return true;
		}
		return false;
	}

	public override string ToString()
	{
		return "[AssetLoader " + _url + "]";
	}
}
