using UnityEngine;

public class BaseUiHandler<T> where T : MonoBehaviour
{
	public T CachedUiControl;

	public BaseUiHandler(T control)
	{
		CachedUiControl = control;
	}
}
