using System;
using UnityEngine;

public class Calculagraph : MonoBehaviour
{
	private float _Time;

	private const float TimeNum = 2.1474836E+09f;

	private Action _callback;

	public void SetData(int num, Action callback)
	{
		_callback = callback;
	}

	private void Update()
	{
		_Time += Time.deltaTime;
		if (_Time >= 2.1474836E+09f)
		{
			if (_callback != null)
			{
				_callback();
			}
			_Time = 0f;
		}
	}

	public static Calculagraph CreateCalculagraph(Transform parent)
	{
		GameObject gameObject = new GameObject("Calculagraph");
		gameObject.transform.parent = parent;
		return gameObject.AddComponent<Calculagraph>();
	}
}
