using UnityEngine;

public abstract class BaseUINewRecruitContentPanel : MonoBehaviour
{
	protected UINewRecruitCommonContent _commonContent;

	protected Vector3 OriginLocation;

	public ENewRecruitActivityType Type;

	protected NewRecruitActivityData _data = Singleton<NewRecruitActivityData>.Instance;

	public UINewRecruitCommonContent CommonContent
	{
		set
		{
			_commonContent = value;
		}
	}

	protected string ButtonTips
	{
		set
		{
			ButtonTipListener.AddTipToButton(_commonContent.BtnImage.gameObject, value);
		}
	}

	public void SetButtonType(NewRecruitBtnType btnType, string btnLabelName)
	{
		switch (btnType)
		{
		case NewRecruitBtnType.DOING:
			_commonContent.CanClick = true;
			_commonContent.SetBtnCanClick(can: true);
			_commonContent.SetBtnSpriteName("MissionBtn_Normal");
			break;
		case NewRecruitBtnType.DONE:
			_commonContent.CanClick = false;
			_commonContent.SetBtnCanClick(can: false);
			_commonContent.SetBtnSpriteName("MissionBtn_Unable");
			break;
		case NewRecruitBtnType.NONE:
			_commonContent.CanClick = false;
			_commonContent.SetBtnCanClick(can: false);
			_commonContent.SetBtnSpriteName("MissionBtn_Unable");
			break;
		}
		_commonContent.SetBtnLabelName(btnLabelName);
	}

	public void OnGetButtonClick()
	{
		if (_commonContent.CanClick)
		{
			SendGetMessage();
		}
	}

	protected virtual void Awake()
	{
		OriginLocation = base.transform.localPosition;
		ShowOrHide(flag: false);
		InitPanel();
	}

	public virtual void ShowOrHide(bool flag)
	{
		if (flag)
		{
			base.transform.localPosition = OriginLocation;
			UpdatePanel();
		}
		else
		{
			base.transform.localPosition = new Vector3(5000f, 5000f, 0f);
		}
	}

	protected abstract void InitPanel();

	public abstract void UpdatePanel();

	protected abstract void SendGetMessage();
}
