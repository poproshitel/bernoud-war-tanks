using UnityEngine;

public class AttackStruct
{
	public UILabel PlayerName;

	public UITexture TankIcon;

	public UILabel TankName;

	public UILabel LightDamage;

	public UISprite Icon1;

	public const int ShareDamageTextureID = 644;

	public const int DamageCountTextureID = 647;

	public const int KillModuleCountTextureID = 646;

	public const int KillOrDamageTextureID = 645;

	public UITexture LightTexture;

	public UITexture ShareDamageTexture;

	public UITexture DamageCountTexture;

	public UITexture KillModuleCountTexture;

	public UITexture KillOrDamageTexture;

	public UISprite Icon2;

	public UISprite Icon3;

	public UISprite LightIcon;

	public UILabel Count1;

	public UILabel Count2;

	public UILabel Count3;

	private UISprite _root;

	public LabelTipListener LabelTips;

	public LabelTipListener LabelTipsTank;

	public AttackStruct(UISprite root, HurtData data, GameObject parent)
	{
		Transform cachedTransform = root.cachedTransform;
		if (data.IsLight == 1)
		{
			root.spriteName = UiConst.PrizeLineBackGroundRed;
			root.cachedTransform.localScale = new Vector3(462f, 23f, 0f);
			root.cachedTransform.localPosition = new Vector3(0f, root.cachedTransform.localPosition.y - 0.5f, 0f);
			_root = root;
		}
		PlayerName = NGUITools.AddWidget<UILabel>(parent);
		PlayerName.pivot = UIWidget.Pivot.Left;
		PlayerName.font = ResourcesManager.Instance.GetFont();
		PlayerName.MakePixelPerfect();
		PlayerName.cachedTransform.localPosition = new Vector3(17f, cachedTransform.localPosition.y - 13f, -3f);
		PlayerName.text = string.Format(GameManager.TableMgr.GetDirString("battle_statistics_infostyle").value, data.PlayerName);
		PlayerName.depth = 1;
		LabelTips = LabelTipListener.AddToLabel(PlayerName, -1f, 100, 0, string.Empty);
		ShareDamageTexture = NGUITools.AddWidget<UITexture>(parent);
		ShareDamageTexture.cachedTransform.localScale = new Vector3(22f, 22f, 1f);
		ShareDamageTexture.pivot = UIWidget.Pivot.Left;
		ShareDamageTexture.depth = 1;
		ShareDamageTexture.cachedTransform.localPosition = new Vector3(300f, cachedTransform.localPosition.y - 13f, -3f);
		ResourcesManager.Instance.RetrieveUIMaterial(644, ShareDamageTexture);
		LightDamage = NGUITools.AddWidget<UILabel>(parent);
		LightDamage.pivot = UIWidget.Pivot.Right;
		LightDamage.font = ResourcesManager.Instance.GetFont();
		LightDamage.MakePixelPerfect();
		LightDamage.cachedTransform.localPosition = new Vector3(332f, cachedTransform.localPosition.y - 13f, -3f);
		LightDamage.text = string.Empty;
		LightDamage.depth = 1;
		PrizeToolTips.AddTipsToLeft(ShareDamageTexture.gameObject, -2f, string.Format(GameManager.TableMgr.GetDirString("UI_share_tips").value, data.LightDamage, data.ShareDamage), 200);
		TankIcon = NGUITools.AddWidget<UITexture>(parent);
		TankIcon.cachedTransform.localScale = new Vector3(54f, 20.5f, 1f);
		TankIcon.pivot = UIWidget.Pivot.Left;
		TankIcon.depth = 1;
		TankIcon.cachedTransform.localPosition = new Vector3(163f, cachedTransform.localPosition.y - 13f, -3f);
		Table_Vehicle vehicle = GameManager.TableMgr.GetVehicle(data.TankId);
		ResourcesManager.Instance.RetrieveUIMaterial(CommonTools.GetIdFormString(vehicle.icon), TankIcon);
		TankName = NGUITools.AddWidget<UILabel>(parent);
		TankName.pivot = UIWidget.Pivot.Left;
		TankName.font = ResourcesManager.Instance.GetFont();
		TankName.MakePixelPerfect();
		TankName.cachedTransform.localPosition = new Vector3(230f, cachedTransform.localPosition.y - 13f, -3f);
		TankName.text = string.Format(GameManager.TableMgr.GetDirString("battle_statistics_infostyle").value, GameManager.TableMgr.GetDirString(vehicle.name).value);
		TankName.depth = 1;
		LabelTipsTank = LabelTipListener.AddToLabel(TankName, -1f, 80, 0, string.Empty);
		KillOrDamageTexture = NGUITools.AddWidget<UITexture>(parent);
		KillOrDamageTexture.cachedTransform.localScale = new Vector3(22f, 22f, 1f);
		KillOrDamageTexture.pivot = UIWidget.Pivot.Left;
		KillOrDamageTexture.depth = 1;
		KillOrDamageTexture.cachedTransform.localPosition = new Vector3(423f, cachedTransform.localPosition.y - 13f, -3f);
		ResourcesManager.Instance.RetrieveUIMaterial(645, KillOrDamageTexture);
		Count1 = NGUITools.AddWidget<UILabel>(parent);
		Count1.pivot = UIWidget.Pivot.Left;
		Count1.font = ResourcesManager.Instance.GetFont();
		Count1.MakePixelPerfect();
		Count1.cachedTransform.localPosition = new Vector3(450f, cachedTransform.localPosition.y - 13f, -3f);
		Count1.text = data.KillOrDamage.ToString();
		Count1.depth = 1;
		if (data.KillOrDamage == 0)
		{
			Count1.text = string.Empty;
			KillOrDamageTexture.alpha = 0f;
		}
		else
		{
			PrizeToolTips.AddTipsToLeft(KillOrDamageTexture.gameObject, -2f, GameManager.TableMgr.GetDirString("battle_statistics_04").value, 200);
		}
		string showData = string.Format(GameManager.TableMgr.GetDirString("battle_statistics_07").value, data.Damage);
		DamageCountTexture = NGUITools.AddWidget<UITexture>(parent);
		DamageCountTexture.cachedTransform.localScale = new Vector3(22f, 22f, 1f);
		DamageCountTexture.pivot = UIWidget.Pivot.Left;
		DamageCountTexture.depth = 1;
		DamageCountTexture.cachedTransform.localPosition = new Vector3(342f, cachedTransform.localPosition.y - 13f, -3f);
		ResourcesManager.Instance.RetrieveUIMaterial(647, DamageCountTexture);
		PrizeToolTips.AddTipsToLeft(DamageCountTexture.gameObject, -2f, showData, 200);
		Count2 = NGUITools.AddWidget<UILabel>(parent);
		Count2.pivot = UIWidget.Pivot.Left;
		TankName.font = ResourcesManager.Instance.GetFont();
		Count2.MakePixelPerfect();
		Count2.cachedTransform.localPosition = new Vector3(368f, cachedTransform.localPosition.y - 13f, -3f);
		Count2.text = string.Format(GameManager.TableMgr.GetDirString("battle_statistics_infostyle").value, data.DamageCount);
		Count2.depth = 1;
		KillModuleCountTexture = NGUITools.AddWidget<UITexture>(parent);
		KillModuleCountTexture.cachedTransform.localScale = new Vector3(22f, 22f, 1f);
		KillModuleCountTexture.pivot = UIWidget.Pivot.Left;
		KillModuleCountTexture.depth = 1;
		KillModuleCountTexture.cachedTransform.localPosition = new Vector3(382f, cachedTransform.localPosition.y - 13f, -3f);
		ResourcesManager.Instance.RetrieveUIMaterial(646, KillModuleCountTexture);
		showData = string.Format(GameManager.TableMgr.GetDirString("battle_statistics_03").value, data.KillModuleCount);
		PrizeToolTips.AddTipsToLeft(KillModuleCountTexture.gameObject, -2f, showData, 200);
		Count3 = NGUITools.AddWidget<UILabel>(parent);
		Count3.pivot = UIWidget.Pivot.Left;
		TankName.font = ResourcesManager.Instance.GetFont();
		Count3.MakePixelPerfect();
		Count3.cachedTransform.localPosition = new Vector3(411f, cachedTransform.localPosition.y - 13f, -3f);
		Count3.text = string.Format(GameManager.TableMgr.GetDirString("battle_statistics_infostyle").value, data.KillModuleCount);
		Count3.depth = 1;
	}

	public void Destroy()
	{
		NGUITools.Destroy(ShareDamageTexture.gameObject);
		NGUITools.Destroy(DamageCountTexture.gameObject);
		NGUITools.Destroy(KillModuleCountTexture.gameObject);
		NGUITools.Destroy(KillOrDamageTexture.gameObject);
		NGUITools.Destroy(PlayerName.gameObject);
		NGUITools.Destroy(TankName.gameObject);
		NGUITools.Destroy(TankIcon.gameObject);
		NGUITools.Destroy(Count1.gameObject);
		NGUITools.Destroy(Count2.gameObject);
		NGUITools.Destroy(Count3.gameObject);
		NGUITools.Destroy(LightDamage);
		if (LabelTips != null)
		{
			LabelTips.DestroySelf();
		}
		if (LabelTipsTank != null)
		{
			LabelTipsTank.DestroySelf();
		}
	}
}
