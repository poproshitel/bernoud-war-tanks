public class ButtonDataParamete0 : BaseButtonData
{
	public XXXCallBack Function;
}
