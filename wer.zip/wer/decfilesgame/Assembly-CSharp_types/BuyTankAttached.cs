public struct BuyTankAttached
{
	public bool IsGoldTank;

	public bool IsBuyCarport;

	public bool IsAmmunitionResupply;

	public BuyTankAttached(bool d1 = false)
	{
		IsGoldTank = d1;
		IsBuyCarport = d1;
		IsAmmunitionResupply = d1;
	}

	public BuyTankAttached(bool v1, bool v2, bool v3)
	{
		IsGoldTank = v1;
		IsBuyCarport = v2;
		IsAmmunitionResupply = v3;
	}
}
