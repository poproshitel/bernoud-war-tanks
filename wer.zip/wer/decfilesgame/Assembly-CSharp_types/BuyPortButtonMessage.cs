public class BuyPortButtonMessage : UIBaseEvent
{
	public TankPortButtonType ButtonType;

	public int Index;

	public UISprite BkGround;

	public UISprite GoldIcon;

	public UILabel BuyPortLabel;

	public UILabel PriceLabel;

	private void Awake()
	{
		Messenger.AddListener("MessageChangeCarportPrice", OnCarportPriceChange);
	}

	private void Start()
	{
		ButtonType = TankPortButtonType.BuyPort;
	}

	public void Init(string price)
	{
		BuyPortLabel.text = GameManager.TableMgr.GetDirString("garage_list_buySpace").value;
		PriceLabel.text = string.Format(GameManager.TableMgr.GetDirString("tvstyle_gse").value, price);
	}

	private void OnDestroy()
	{
		Messenger.RemoveListener("MessageChangeCarportPrice", OnCarportPriceChange);
	}

	private void OnCarportPriceChange()
	{
		Init(ShopTools.GetStaticItemPrice(NodePart.Carport).ToString());
	}
}
