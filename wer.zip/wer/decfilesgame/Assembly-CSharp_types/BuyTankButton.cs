using UnityEngine;

public class BuyTankButton : MonoBehaviour
{
	public enum Trigger
	{
		OnClick,
		OnMouseOver,
		OnMouseOut,
		OnPress,
		OnRelease,
		OnDoubleClick
	}

	public GameObject target;

	public string functionName;

	public Trigger trigger;

	public bool includeChildren;

	private float mLastClick;

	private bool mStarted;

	private bool mHighlighted;

	public UISprite Bkg;

	public UISprite Background;

	public UISlicedSprite OverSprite;

	private Tips _curTips;

	private string _tipLabel;

	private ToolTipsListen tips;

	public string TipLabel
	{
		set
		{
			_tipLabel = value;
			AddTips();
		}
	}

	private void Start()
	{
		mStarted = true;
		if (OverSprite != null)
		{
			OverSprite.gameObject.SetActive(value: false);
			OverSprite.sprite.inner.x = OverSprite.sprite.outer.x + 10f;
			OverSprite.sprite.inner.y = OverSprite.sprite.outer.y + 10f;
			OverSprite.sprite.inner.width = OverSprite.sprite.outer.width - 20f;
			OverSprite.sprite.inner.height = OverSprite.sprite.outer.height - 20f;
			if (Background != null)
			{
				OverSprite.cachedTransform.localScale = CommonTools.MakePixelPerfect(new Vector3(220f, 40f, 0f));
			}
		}
		TipLabel = CommonTools.GetDictString("tmp_vehicle_purchase_hint");
	}

	private void OnEnable()
	{
		if (mStarted && mHighlighted)
		{
			OnHover(UICamera.IsHighlighted(base.gameObject));
		}
	}

	private void OnHover(bool isOver)
	{
		if (base.enabled)
		{
			if ((isOver && trigger == Trigger.OnMouseOver) || (!isOver && trigger == Trigger.OnMouseOut))
			{
				Send();
			}
			mHighlighted = isOver;
			if (OverSprite != null)
			{
				OverSprite.gameObject.SetActive(isOver);
			}
		}
	}

	private void OnPress(bool isPressed)
	{
		if (base.enabled && ((isPressed && trigger == Trigger.OnPress) || (!isPressed && trigger == Trigger.OnRelease)))
		{
			Send();
		}
	}

	private void OnClick()
	{
		if (base.enabled && trigger == Trigger.OnClick)
		{
			Send();
		}
	}

	private void Send()
	{
		if (!base.gameObject.active || string.IsNullOrEmpty(functionName))
		{
			return;
		}
		if (target == null)
		{
			target = base.gameObject;
		}
		if (includeChildren)
		{
			Transform[] componentsInChildren = target.GetComponentsInChildren<Transform>();
			int i = 0;
			for (int num = componentsInChildren.Length; i < num; i++)
			{
				Transform transform = componentsInChildren[i];
				transform.gameObject.SendMessage(functionName, base.gameObject, SendMessageOptions.DontRequireReceiver);
			}
		}
		else
		{
			target.SendMessage(functionName, base.gameObject, SendMessageOptions.DontRequireReceiver);
		}
	}

	public void SetEnable(bool enable)
	{
		if (Bkg == null)
		{
			return;
		}
		if (enable)
		{
			Bkg.spriteName = "Port_button_s_4";
			if (GetComponent<Collider>() != null)
			{
				GetComponent<Collider>().enabled = false;
			}
		}
		else
		{
			Bkg.spriteName = "button_xs_0";
			if (GetComponent<Collider>() != null)
			{
				GetComponent<Collider>().enabled = true;
			}
		}
	}

	private void TooolTipsXXX(bool isOver)
	{
		if (isOver)
		{
			TipsData tipsData = new TipsData();
			tipsData.Contex = _tipLabel;
			_curTips = GUITools.AddTips(UITipStyle.Normal, tipsData);
		}
		else if (_curTips != null)
		{
			Object.Destroy(_curTips.gameObject);
			_curTips = null;
		}
	}

	private void AddTips()
	{
		if (!(tips != null))
		{
			tips = base.gameObject.AddComponent<ToolTipsListen>();
			tips.Target = base.gameObject;
		}
	}
}
