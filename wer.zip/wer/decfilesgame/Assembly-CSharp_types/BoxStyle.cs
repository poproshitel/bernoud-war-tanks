public enum BoxStyle
{
	None,
	IconDialog,
	TextAndIcon,
	TextOnly,
	Max
}
