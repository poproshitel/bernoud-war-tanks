public struct BattleEndInfoCommon
{
	public long RoomGuid;

	public int MapId;

	public byte VipOrNomal;

	public int Money;

	public int Exp;

	public int VipMoney;

	public int VipExp;

	public byte HasBehave;

	public float ExpMultiple;

	public float MoneyMultiple;

	public byte State;

	public byte Result;

	public byte EndReason;

	public int StartSecond;

	public float[] VipMoneyMultiple;

	public float[] VipExpMultiple;

	public byte RoomType;

	public byte IsGarageIncrease;

	public float SpeActivityIncrease;
}
