using System;
using System.Collections.Generic;
using UnityEngine;

public class BetterList<T>
{
	public T[] buffer;

	public int size;

	public int internalSize => (buffer != null) ? buffer.Length : 0;

	public T this[int i]
	{
		get
		{
			return buffer[i];
		}
		set
		{
			buffer[i] = value;
		}
	}

	public IEnumerator<T> GetEnumerator()
	{
		if (buffer != null)
		{
			for (int i = 0; i < size; i++)
			{
				yield return buffer[i];
			}
		}
	}

	private void AllocateMore()
	{
		T[] array;
		if (buffer != null)
		{
			int a = Mathf.Min(buffer.Length << 1, 65000);
			array = new T[Mathf.Max(a, 32)];
		}
		else
		{
			array = new T[32];
		}
		if (buffer != null && size > 0)
		{
			buffer.CopyTo(array, 0);
		}
		buffer = array;
	}

	private void Trim()
	{
	}

	public void FillDefaultCoordinates(ref Vector3[] array)
	{
		float z = 0f;
		if (size > 0)
		{
			z = array[size - 1].z;
		}
		for (int i = size; i < array.Length; i++)
		{
			array[i].x = 0f;
			array[i].y = 0f;
			array[i].z = z;
		}
	}

	public void Clear()
	{
		size = 0;
	}

	public void Release()
	{
		size = 0;
		buffer = null;
	}

	public void Add(T item)
	{
		if (buffer == null || size == buffer.Length)
		{
			AllocateMore();
		}
		buffer[size++] = item;
	}

	public void Remove(T item)
	{
		if (buffer == null)
		{
			return;
		}
		EqualityComparer<T> @default = EqualityComparer<T>.Default;
		for (int i = 0; i < size; i++)
		{
			if (@default.Equals(buffer[i], item))
			{
				size--;
				Array.Copy(buffer, i, buffer, i + 1, size - i);
				break;
			}
		}
	}

	public void RemoveAt(int index)
	{
		if (buffer != null && index < size)
		{
			size--;
			buffer[index] = default(T);
			for (int i = index; i < size; i++)
			{
				buffer[i] = buffer[i + 1];
			}
		}
	}

	public T[] ToArray()
	{
		Trim();
		return buffer;
	}
}
