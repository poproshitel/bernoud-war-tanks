using UnityEngine;

public class BackgroundButton : MonoBehaviour
{
	public UISprite normalSprite;

	public UISprite hoverSprite;

	private void Start()
	{
		if (hoverSprite != null)
		{
			hoverSprite.enabled = false;
		}
	}

	private void OnHover(bool isOver)
	{
		if (!isOver && base.gameObject.transform != UICamera.lastHit.transform && NGUITools.IsChild(base.gameObject.transform, UICamera.lastHit.transform))
		{
			return;
		}
		try
		{
			if (isOver)
			{
				normalSprite.enabled = true;
				hoverSprite.enabled = true;
			}
			else
			{
				normalSprite.enabled = true;
				hoverSprite.enabled = false;
			}
		}
		catch
		{
			TKLog.Log("BackgroundButton: parameter need check~~~");
		}
	}
}
