public enum BorderState
{
	None,
	ReachLeft,
	ReachRight,
	Ok
}
