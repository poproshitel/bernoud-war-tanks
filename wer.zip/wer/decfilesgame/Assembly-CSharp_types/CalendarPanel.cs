using System;
using System.Collections.Generic;
using UnityEngine;

public class CalendarPanel : MonoBehaviour
{
	public UILabel ActivityMonthLabel;

	public UILabel Week1Label;

	public UILabel Week2Label;

	public UILabel Week3Label;

	public UILabel Week4Label;

	public UILabel Week5Label;

	public UILabel Week6Label;

	public UILabel Week7Label;

	public UILabel SignInNum;

	public CalendarItemPanel CalendarItemPrefab;

	public Transform CalendarItemList;

	private List<CalendarItemPanel> _calendarItemList = new List<CalendarItemPanel>();

	private MonthlyLoginAwardDataManager _data = Singleton<MonthlyLoginAwardDataManager>.Instance;

	private void Awake()
	{
		InitLabel();
		InitPanel();
		UpdatePanel();
	}

	private void Start()
	{
		MonthlyLoginAwardDataManager data = _data;
		data.UpdateCalendar = (Action)Delegate.Combine(data.UpdateCalendar, new Action(InitPanel));
		MonthlyLoginAwardDataManager data2 = _data;
		data2.UpdateSignIn = (Action)Delegate.Combine(data2.UpdateSignIn, new Action(UpdatePanel));
	}

	private void OnDestroy()
	{
		MonthlyLoginAwardDataManager data = _data;
		data.UpdateCalendar = (Action)Delegate.Remove(data.UpdateCalendar, new Action(InitPanel));
		MonthlyLoginAwardDataManager data2 = _data;
		data2.UpdateSignIn = (Action)Delegate.Remove(data2.UpdateSignIn, new Action(UpdatePanel));
	}

	private void InitLabel()
	{
		Week1Label.text = CommonTools.GetDictString("week_07");
		Week2Label.text = CommonTools.GetDictString("week_01");
		Week3Label.text = CommonTools.GetDictString("week_02");
		Week4Label.text = CommonTools.GetDictString("week_03");
		Week5Label.text = CommonTools.GetDictString("week_04");
		Week6Label.text = CommonTools.GetDictString("week_05");
		Week7Label.text = CommonTools.GetDictString("week_06");
	}

	private void InitPanel()
	{
		foreach (CalendarItemPanel calendarItem in _calendarItemList)
		{
			UnityEngine.Object.Destroy(calendarItem.gameObject);
		}
		_calendarItemList.Clear();
		for (int i = 1; i <= _data.Days; i++)
		{
			int num = i + _data.FirstDayWeek % 7 - 1;
			int num2 = num % 7;
			int num3 = num / 7;
			CalendarItemPanel calendarItemPanel = UnityEngine.Object.Instantiate(CalendarItemPrefab);
			calendarItemPanel.CacheTrans.parent = CalendarItemList;
			calendarItemPanel.CacheTrans.localPosition = new Vector3(110 * num2, -44 * num3, -5f);
			calendarItemPanel.CacheTrans.localScale = Vector3.one;
			calendarItemPanel.SetDate(i, num2 == 0 || num2 == 6);
			_calendarItemList.Add(calendarItemPanel);
		}
		string text = ((_data.Month >= 10) ? (_data.Month + string.Empty) : ("0" + _data.Month));
		ActivityMonthLabel.text = CommonTools.GetDictString("month_" + text);
	}

	public void UpdatePanel()
	{
		SignInNum.text = string.Format(CommonTools.GetDictString("activity_month_times"), _data.SignInNum);
		foreach (CalendarItemPanel calendarItem in _calendarItemList)
		{
			calendarItem.IsSignIn = _data.SignInList.Contains((byte)calendarItem.Date);
			calendarItem.IsToday = _data.TodayDate == calendarItem.Date;
		}
	}
}
