using System;
using System.Collections.Generic;
using SceneCameraStruct;
using TK;
using UnityEngine;

public class CameraManager : MonoBehaviour
{
	public GameObject FirstSight;

	public GameObject ThirdSight;

	private long _currentTargetGUID;

	private PVEGodView _godView;

	private CamThirdModel _thirdCamFuc;

	private AlphaHandle _alphaHandle;

	private CamFirstModel _firstCamFuc;

	public CamObserverMode CamObserverMode;

	private DeathCamera deathCamera;

	private CameraState _cameraState = CameraState.Third;

	public static bool LastNeedAim;

	public static CameraManager Instance;

	[SerializeField]
	private int _alaphMask;

	private Vector3 _firstUIPosition;

	private Vector3 _uiPosition;

	public bool IsFirstPerson;

	public bool IsObserve;

	private Camera camera;

	public Camera RealMainCam;

	public Transform AimUIPosition;

	private int _uiScale;

	private float _angleOffset;

	public bool HasInited;

	public bool IsDeath;

	private bool _hasInited;

	private float _pointLight = 2f;

	private float _dirLight = 0.3f;

	private Light _roomLight;

	private GameObject _lightGameObject;

	private bool _needChange;

	private bool _hasFirstShootPoint;

	private Vector3 _firstShootPoint;

	public double DelayTime = 0.1;

	private double _totalDelayTime;

	private Queue<Vector3> _queueShootPoint = new Queue<Vector3>();

	private Queue<float> _queueDeltaTime = new Queue<float>();

	private const float GodViewDisableShootTime = 1f;

	private float _godViewDisableShootClock;

	private CameraState _saveCameraState;

	private Vector3 _savePosition;

	private Quaternion _saveRotation;

	public PVESkillType KatyushaSkillType;

	public PVECostType KatyushaCostType;

	public long CurrentTargetGuid
	{
		get
		{
			return _currentTargetGUID;
		}
		set
		{
			_currentTargetGUID = value;
		}
	}

	public CameraState CameraState => _cameraState;

	public bool NeedAim
	{
		get
		{
			RaycastHit shootRayHit = ShootRayHit;
			if (_cameraState == CameraState.First || shootRayHit.collider == null || Vector3.Distance(SceneRoom.Instance.GetMainPlayer().Trans.position, shootRayHit.point) > 30f || ((uint)(1 << shootRayHit.transform.gameObject.layer) & ((uint)(int)GameManager.EnvManager.HitRemoteTankLayer | 0x400u)) != 0)
			{
				LastNeedAim = true;
				return true;
			}
			LastNeedAim = false;
			return false;
		}
	}

	public float CameraAngle => _thirdCamFuc.transform.localEulerAngles.x;

	public static Camera MainCamera => Instance.RealMainCam;

	public float AgeOff => _angleOffset;

	private Vector3 TurretAngle => SceneRoom.Instance.GetMainPlayer().transform.eulerAngles;

	public Vector3 UIPosition
	{
		get
		{
			if (_cameraState == CameraState.First)
			{
				return _firstUIPosition;
			}
			return _uiPosition;
		}
	}

	public int AlaphMask => _alaphMask;

	public float MaxAmmoDistance
	{
		set
		{
			if (_thirdCamFuc == null)
			{
				_thirdCamFuc = GetComponent<CamThirdModel>();
			}
			_thirdCamFuc.MaxAmmoDistance = value;
			if (_firstCamFuc == null)
			{
				_firstCamFuc = GetComponent<CamFirstModel>();
			}
			_firstCamFuc.MaxAmmoDistance = value;
		}
	}

	public float FirstLimitUp
	{
		set
		{
			if (_firstCamFuc == null)
			{
				_firstCamFuc = GetComponent<CamFirstModel>();
			}
			_firstCamFuc._limitUp = value;
		}
	}

	public Vector3 DelayShootPoint
	{
		get
		{
			if (!_hasFirstShootPoint && _queueShootPoint.Count > 0)
			{
				_hasFirstShootPoint = true;
				_firstShootPoint = _queueShootPoint.Dequeue();
			}
			if (_hasFirstShootPoint)
			{
				if (_queueShootPoint.Count > 0)
				{
					return (_firstShootPoint + _queueShootPoint.Peek()) / 2f;
				}
				return _firstShootPoint;
			}
			_totalDelayTime = 0.0;
			return ShootPoint;
		}
	}

	public Vector3 ShootPoint
	{
		get
		{
			Vector3 result = Vector3.zero;
			switch (_cameraState)
			{
			case CameraState.Third:
				result = _thirdCamFuc.ShootPoint.point;
				break;
			case CameraState.First:
				result = _firstCamFuc.ShootPoint.point;
				break;
			}
			return result;
		}
	}

	public RaycastHit ShootRayHit
	{
		get
		{
			CameraState cameraState = _cameraState;
			if (cameraState == CameraState.Third)
			{
				return _thirdCamFuc.ShootPoint;
			}
			return _firstCamFuc.ShootPoint;
		}
	}

	public CameraState CurrentCameraState => _cameraState;

	public Step CurCamStep
	{
		get
		{
			int result = 0;
			switch (_cameraState)
			{
			case CameraState.First:
				result = _firstCamFuc.CurStep + 1;
				break;
			case CameraState.Third:
				result = _thirdCamFuc.CurThirdStep + 4;
				break;
			case CameraState.Death:
				result = _thirdCamFuc.CurThirdStep + 4;
				break;
			}
			return (Step)result;
		}
	}

	public int CurFirstStep => _firstCamFuc.CurStep;

	public int CurThirdStep => _thirdCamFuc.CurThirdStep;

	public event XXXCallBack OnChangeStep;

	private void Awake()
	{
		Instance = this;
		base.enabled = false;
	}

	private void OnDestroy()
	{
		_firstCamFuc.ChangeStepEvent -= CameraStepChange;
		_thirdCamFuc.ChangeStepEvent -= CameraStepChange;
		Instance = null;
	}

	public void Init()
	{
		_hasInited = true;
		IsDeath = false;
		FirstSight = RoomGUIManager.Instance.Get<SightUI>().FirstUi;
		ThirdSight = RoomGUIManager.Instance.Get<SightUI>().ThirdUi;
		AimUIPosition = ThirdSight.transform;
		_uiScale = 14;
		RealMainCam.enabled = true;
		_alaphMask = 32768;
		camera = Camera.main;
		camera = base.transform.GetComponent<Camera>();
		camera.farClipPlane = GameManager.Player.RendererDistance;
		float v = 45f;
		ReadConfig.TryGetValue("Main Camera", "field_rate", out v);
		camera.fieldOfView = v;
		if (_thirdCamFuc == null)
		{
			_thirdCamFuc = GetComponent<CamThirdModel>();
			_thirdCamFuc.ChangeStepEvent += CameraStepChange;
		}
		if (_alphaHandle == null)
		{
			_alphaHandle = GetComponent<AlphaHandle>();
		}
		if (_firstCamFuc == null)
		{
			_firstCamFuc = GetComponent<CamFirstModel>();
			_firstCamFuc.ChangeStepEvent += CameraStepChange;
		}
		if (deathCamera == null)
		{
			deathCamera = GetComponent<DeathCamera>();
		}
		if (CamObserverMode == null)
		{
			CamObserverMode = GetComponent<CamObserverMode>();
		}
		if (_godView == null)
		{
			_godView = GetComponent<PVEGodView>();
			if (_godView == null)
			{
				throw new Exception("Not find PVEGodView component.");
			}
			_godView.Init();
		}
		_thirdCamFuc.Init();
		_alphaHandle.Init();
		_firstCamFuc.Init();
		deathCamera.Init();
		RoomGUIManager.Instance.Get<SightUI>().CamTankDistance.Init();
		_angleOffset = AngleOffset();
		base.enabled = true;
		HasInited = true;
		base.gameObject.AddComponent<DamageAlert>();
		SetHallLight();
	}

	private void CameraStepChange()
	{
		if (this.OnChangeStep != null)
		{
			this.OnChangeStep();
		}
	}

	private void SetHallLight()
	{
		if (!(_lightGameObject != null))
		{
			_lightGameObject = new GameObject("RoomLight");
			_lightGameObject.transform.parent = deathCamera.transform;
			_roomLight = _lightGameObject.AddComponent<Light>();
			_roomLight.transform.localPosition = Vector3.zero;
			_roomLight.transform.localEulerAngles = Vector3.zero;
			_roomLight.cullingMask = 4096;
			_roomLight.cullingMask |= int.MinValue;
			SetLightToDirectional();
		}
	}

	public void SetLightToDirectional()
	{
		if (!(_roomLight == null))
		{
			_roomLight.type = LightType.Directional;
			_roomLight.intensity = _dirLight;
		}
	}

	public void SetLightToPoint()
	{
		if (!(_roomLight == null))
		{
			_roomLight.range = 30f;
			_roomLight.type = LightType.Point;
			_roomLight.intensity = _pointLight;
		}
	}

	private float AngleOffset()
	{
		UpdateUIParams();
		Ray ray = camera.ScreenPointToRay(new Vector3(Screen.width / 2, Screen.height / 2, 0f));
		Ray ray2 = camera.ScreenPointToRay(_uiPosition);
		return Vector3.Angle(ray.direction, ray2.direction);
	}

	private void Update()
	{
		if (!base.enabled || _alphaHandle == null || _thirdCamFuc == null)
		{
			return;
		}
		if (RoomGUIManager.CurWarState == WarState.Waiting)
		{
			SceneToGUI.UpdateTankUIState(TurretAngle.y, TurretAngle.y, Instance.transform.eulerAngles.y);
			SceneToGUI.UpdateSmallmapTankAngle(Instance.transform.eulerAngles.y);
		}
		UpdateUIParams();
		if (_needChange)
		{
			if (!IsFirstPerson)
			{
				ChangeToFirst();
			}
			else if (IsObserve)
			{
				ChangeToObserve();
			}
			else if (IsDeath && GameManager.Player.IsTerritoryWar)
			{
				if (CurrentTargetGuid != 0)
				{
					deathCamera.ChangeToDeath(CurrentTargetGuid);
				}
				else
				{
					TKLog.LogError("CurrentTargetGuid is null");
				}
			}
			else
			{
				ChangeToThird();
			}
			_needChange = false;
		}
		switch (_cameraState)
		{
		case CameraState.Third:
			_thirdCamFuc.UpdateThird();
			break;
		case CameraState.First:
			_firstCamFuc.UpdateFistModel();
			break;
		case CameraState.Death:
			deathCamera.UpdateDeath();
			break;
		case CameraState.Observe:
			CamObserverMode.UpdateObserverMode();
			break;
		}
		_alphaHandle.AlaphResetHandle(_cameraState);
		UpdateDelayShootPoint();
		if (_cameraState != CameraState.God && SceneRoom.Instance.GetRoom().ERoomState == ERoomState.Fighting && InputManager.ShootSurprisemodeDown && _cameraState != CameraState.Death)
		{
			_needChange = true;
		}
		if (_cameraState == CameraState.Death)
		{
			deathCamera.UpdateChangeSight();
		}
		UpdateGodViewDisableShootClock();
	}

	private void UpdateDelayShootPoint()
	{
		_queueShootPoint.Enqueue(ShootPoint);
		_queueDeltaTime.Enqueue(Time.deltaTime);
		_totalDelayTime += Time.deltaTime;
		while (_totalDelayTime > DelayTime)
		{
			if (_hasFirstShootPoint)
			{
				_hasFirstShootPoint = false;
				_totalDelayTime -= _queueDeltaTime.Dequeue();
			}
			_queueShootPoint.Dequeue();
			_totalDelayTime -= _queueDeltaTime.Dequeue();
		}
		Debug.DrawLine(base.transform.position, ShootPoint, Color.white);
	}

	private void UpdateUIParams()
	{
		float x = (float)Screen.width / 2f;
		float num = (float)Screen.height / 2f;
		if (_cameraState == CameraState.Third || _cameraState == CameraState.Death)
		{
			_uiPosition.x = x;
			_uiPosition.y = (float)(Screen.height / _uiScale) + num;
			_uiPosition.z = 0f;
			Vector3 localPosition = AimUIPosition.localPosition;
			localPosition.y = Screen.height / _uiScale;
			AimUIPosition.localPosition = localPosition;
			SceneToGUI.OnAimUiPostionChange((int)localPosition.y);
		}
		else
		{
			_firstUIPosition.x = x;
			_firstUIPosition.y = num;
			_firstUIPosition.z = 0f;
		}
	}

	public void ChangeToFirst()
	{
		if (!IsDeath)
		{
			_firstCamFuc.ChangeToFirst();
			_cameraState = CameraState.First;
			ChangeFirstSight();
			IsFirstPerson = true;
			if (this.OnChangeStep != null)
			{
				this.OnChangeStep();
			}
			if (RoomGUIManager.Instance != null && RoomGUIManager.Instance.IsExistUI<RoomGuideHelper>())
			{
				RoomGUIManager.Instance.Get<RoomGuideHelper>().SetCameraStateFrame(_cameraState);
			}
		}
	}

	public void ChangeToObserve()
	{
		if (base.gameObject != null && base.gameObject.transform != null)
		{
			CamObserverMode.StartObserve(base.gameObject.transform);
			UpdateChangeToObserveFirst();
		}
	}

	public void UpdateChangeToObserveFirst()
	{
		IsFirstPerson = true;
		IsObserve = true;
		IsDeath = false;
		_needChange = true;
		_cameraState = CameraState.Observe;
	}

	public void UpdateChangeToObserveThird()
	{
		IsFirstPerson = true;
		IsObserve = false;
		IsDeath = true;
		_needChange = true;
		_cameraState = CameraState.Death;
	}

	public void ChangeToThird(bool isScroll = false)
	{
		_thirdCamFuc.ChangeToThird(isScroll);
		_cameraState = CameraState.Third;
		ChangeThirdSight();
		IsFirstPerson = false;
		if (this.OnChangeStep != null)
		{
			this.OnChangeStep();
		}
		if (RoomGUIManager.Instance != null && RoomGUIManager.Instance.IsExistUI<RoomGuideHelper>() && !GameManager.Player.IsWarObserver)
		{
			RoomGUIManager.Instance.Get<RoomGuideHelper>().SetCameraStateFrame(_cameraState);
		}
	}

	public void ChangeToDeath(long emyGuid)
	{
		if (SelecteObject.Instance != null)
		{
			SelecteObject.Instance.enabled = false;
		}
		IsDeath = true;
		_cameraState = CameraState.Third;
		ResetCam(_cameraState);
		_cameraState = CameraState.Death;
		ChangeDeathSight();
		deathCamera.ChangeToDeath(emyGuid);
		if (GameManager.Player.IsWarObserver)
		{
			IsFirstPerson = true;
		}
		else
		{
			IsFirstPerson = false;
		}
		if (this.OnChangeStep != null)
		{
			this.OnChangeStep();
		}
		if (RoomGUIManager.Instance != null && RoomGUIManager.Instance.IsExistUI<RoomGuideHelper>())
		{
			RoomGUIManager.Instance.Get<RoomGuideHelper>().SetCameraStateFrame(_cameraState);
		}
	}

	public void ResetCam(CameraState state = CameraState.Third)
	{
		if (state != CameraState.Death)
		{
			IsDeath = false;
		}
		_cameraState = state;
		if (IsFirstPerson)
		{
			if (state == CameraState.Third)
			{
				ChangeToThird();
			}
			else
			{
				float v = 45f;
				ReadConfig.TryGetValue("Main Camera", "field_rate", out v);
				camera.fieldOfView = v;
			}
		}
		IsFirstPerson = false;
		if (RoomGUIManager.Instance != null && RoomGUIManager.Instance.IsExistUI<RoomGuideHelper>())
		{
			RoomGUIManager.Instance.Get<RoomGuideHelper>().SetCameraStateFrame(_cameraState);
		}
		if (_hasInited)
		{
			Init();
		}
		WhenChangeFileOfView(camera.fieldOfView);
	}

	public void WhenChangeFileOfView(float viewValue)
	{
		SelecteObject.Instance.SetFieldOfView(viewValue);
	}

	public void ChangeThirdSight()
	{
		FirstSight.SetActiveRecursively(state: false);
		ThirdSight.SetActiveRecursively(state: true);
	}

	public void ChangeDeathSight()
	{
		FirstSight.SetActive(value: false);
		ThirdSight.SetActive(value: false);
		RoomGUIManager.Instance.Get<AimAreaUI>().AimingCenterCircle.ShowOrHide(show: false);
		RoomGUIManager.Instance.Get<AimAreaUI>().AimCenter.gameObject.SetActive(value: false);
	}

	public void Revive()
	{
		deathCamera.MainPlayerRevive();
		IsDeath = false;
		RoomGUIManager.Instance.Get<AimAreaUI>().AimingCenterCircle.ShowOrHide(show: true);
		RoomGUIManager.Instance.Get<AimAreaUI>().ReSet(isDead: false);
		SceneToGUI.UpdateSightUIBlood(1f);
		RoomGUIManager.Instance.Get<SightUI>().ShowOrHide(show: true);
		ChangeToThird();
		if (SelecteObject.Instance != null)
		{
			SelecteObject.Instance.enabled = true;
		}
		ResourcesManager.Audio._deadmodeTargetPlayer = null;
	}

	public void ChangeFirstSight()
	{
		FirstSight.SetActiveRecursively(state: true);
		ThirdSight.SetActiveRecursively(state: false);
	}

	public void WarEnd()
	{
		deathCamera.EndWar();
	}

	public void DeadChangeView(long friendGuid)
	{
		deathCamera.ChangeView(friendGuid);
	}

	public PlayerProxy GetPlayerProxyWithCamera()
	{
		PlayerProxy result = null;
		switch (_cameraState)
		{
		case CameraState.First:
			result = SceneRoom.Instance.GetMainPlayer();
			break;
		case CameraState.Third:
			result = SceneRoom.Instance.GetMainPlayer();
			break;
		case CameraState.Death:
			if (deathCamera == null)
			{
				TKLog.Log("GetPlayerProxyWithCamera Error : deathCamera is Null");
			}
			else
			{
				result = ((!deathCamera.IsOnEmy) ? deathCamera.CurrentTarget : deathCamera.Emy);
			}
			break;
		}
		return result;
	}

	public void OpenGodView(PVESkillType skillType, PVECostType costType, float fRate = 1f)
	{
		KatyushaSkillType = skillType;
		KatyushaCostType = costType;
		RoomGUIManager.Instance.Get<SightUI>().ShowOrHide(show: false);
		RoomGUIManager.Instance.Get<AimAreaUI>().ShowOrHide(show: false);
		_saveCameraState = _cameraState;
		_savePosition = Camera.main.transform.position;
		_saveRotation = Camera.main.transform.rotation;
		if (_cameraState == CameraState.First)
		{
			ChangeToThird();
		}
		_cameraState = CameraState.God;
		SceneRoom.Instance.GetRoom().GetMainPlayer().TankStateSync.AutoAim = false;
		_godView.FocusView(fRate);
	}

	public void CloseGodView()
	{
		_godView.UnFocusView();
		if (_saveCameraState == CameraState.First)
		{
			ChangeToThird();
			ChangeToFirst();
		}
		if (_saveCameraState == CameraState.Third)
		{
			ChangeToThird();
		}
		RoomGUIManager.Instance.Get<SightUI>().ShowOrHide(show: true);
		RoomGUIManager.Instance.Get<AimAreaUI>().ShowOrHide(show: true);
		Camera.main.transform.position = _savePosition;
		Camera.main.transform.rotation = _saveRotation;
		SceneRoom.Instance.GetRoom().GetMainPlayer().TankStateSync.AutoAim = true;
		_godViewDisableShootClock = 1f;
	}

	public Vector3 GetGuidePosition()
	{
		return _godView.GetGuidePosition();
	}

	public bool IsCanShoot()
	{
		return _godViewDisableShootClock <= 0f;
	}

	private void UpdateGodViewDisableShootClock()
	{
		if (_godViewDisableShootClock > 0f)
		{
			_godViewDisableShootClock -= Time.deltaTime;
		}
		else
		{
			_godViewDisableShootClock = 0f;
		}
	}
}
