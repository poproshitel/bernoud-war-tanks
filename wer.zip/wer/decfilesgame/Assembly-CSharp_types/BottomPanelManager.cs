using System;
using UnityEngine;

public class BottomPanelManager : MonoBehaviour
{
	public UIChildInterface MidlePanle;

	[SerializeField]
	private ToggleFAceButton[] _buttons;

	public UISprite LeftBackground;

	public UISprite RightBackground;

	private ToggleFAceButton[] _buttonsDict;

	private UIChildInterface _curPanel;

	private Vector3 _middlePos;

	private bool _enabledBattleButton = true;

	private bool _enabledModeButton = true;

	private bool _isEnterPrepareWallPage_Directly;

	private bool _isEnterLaserTankBid_Directly;

	public UIChildInterface CurPanel => _curPanel;

	public bool enableBattleButton
	{
		get
		{
			return _enabledBattleButton;
		}
		set
		{
			if (_enabledBattleButton != value)
			{
				_enabledBattleButton = value;
				ToggleFAceButton toggleBtnByType = GetToggleBtnByType(ToggleFaceType.Battle);
				toggleBtnByType.Enable = value;
			}
		}
	}

	public bool enableModeButton
	{
		get
		{
			return _enabledModeButton;
		}
		set
		{
			if (_enabledModeButton != value)
			{
				_enabledModeButton = value;
				ToggleFAceButton toggleBtnByType = GetToggleBtnByType(ToggleFaceType.BattleMode);
				toggleBtnByType.Enable = value;
			}
		}
	}

	public bool IsEnterPrepareWallPage_Directly => _isEnterPrepareWallPage_Directly;

	public bool IsEnterLaserTankBid_Directly
	{
		get
		{
			return _isEnterLaserTankBid_Directly;
		}
		set
		{
			_isEnterLaserTankBid_Directly = value;
		}
	}

	public event Action OnEnterPrepareHallFinish;

	private void Awake()
	{
		if (_buttonsDict == null)
		{
			_buttonsDict = new ToggleFAceButton[28];
		}
		ToggleFAceButton[] buttons = _buttons;
		foreach (ToggleFAceButton toggleFAceButton in buttons)
		{
			if (toggleFAceButton != null)
			{
				_buttonsDict[(int)toggleFAceButton.FaceType] = toggleFAceButton;
			}
		}
		InitButtons();
	}

	public void Init()
	{
		MidlePanle = HallGuiManager.Instance.Get<MiddlePanleManager>();
		_middlePos = MidlePanle.transform.localPosition;
		HallGuiManager.Instance.Get<TankInfoPanle>().Init();
		HallGuiManager.Instance.Get<TankInfoPanle>().SetPosition();
		GoHome();
	}

	public void InitButtons()
	{
		if (_buttons == null)
		{
			return;
		}
		for (int i = 0; i < _buttons.Length; i++)
		{
			if (_buttons[i] != null)
			{
				_buttons[i].Init();
			}
		}
		UpdateButtonVisable();
		SetButtonPt();
	}

	public void SetButtonPt()
	{
		Vector3 localPosition = GetToggleBtnByType(ToggleFaceType.Setting).transform.localPosition;
		localPosition.x = -Screen.width / 2 + 24;
		localPosition.z = -1f;
		GetToggleBtnByType(ToggleFaceType.Setting).transform.localPosition = localPosition;
		Vector3 localPosition2 = GetToggleBtnByType(ToggleFaceType.SystemMsg).transform.localPosition;
		localPosition2.x = Screen.width / 2 - 24;
		localPosition2.z = -1f;
		GetToggleBtnByType(ToggleFaceType.SystemMsg).transform.localPosition = localPosition2;
		Transform transform = GetToggleBtnByType(ToggleFaceType.OfferPanel).transform;
		Vector3 localPosition3 = transform.localPosition;
		localPosition3.x = Screen.width / 2 - 34;
		localPosition3.y = Screen.height / 2 - 580;
		localPosition3.z = -1f;
		transform.localPosition = localPosition3;
		Transform transform2 = GetToggleBtnByType(ToggleFaceType.TournamentPanel).transform;
		Vector3 localPosition4 = transform2.localPosition;
		localPosition4.y = localPosition3.y;
		localPosition4.z = localPosition3.z;
		if (GetToggleBtnByType(ToggleFaceType.OfferPanel).gameObject.activeSelf)
		{
			localPosition4.x = localPosition3.x - 70f;
		}
		else
		{
			localPosition4.x = localPosition3.x;
		}
		transform2.localPosition = localPosition4;
	}

	public ToggleFAceButton GetToggleBtnByType(ToggleFaceType type)
	{
		return _buttonsDict[(int)type];
	}

	public void SetToggleBtnByType(ToggleFaceType type, ToggleFAceButton faceButton)
	{
		_buttonsDict[(int)type] = faceButton;
	}

	private void OnChangeScreenHandle()
	{
		SetButtonPt();
		HallGuiManager.Instance.Get<TankInfoPanle>().SetPosition();
	}

	public void ChangeFace(ToggleFaceType kind)
	{
		if (_curPanel != null)
		{
			_curPanel.ShowOrHide(flag: false, null);
		}
		_curPanel = GetToggleBtnByType(kind).Panel as UIChildInterface;
		float time = Time.time;
		if (_curPanel.UiType == HallUiKind.Shop || _curPanel.UiType == HallUiKind.Package || _curPanel.UiType == HallUiKind.Members)
		{
			ResourcesManager.Instance.LoadAtlasesWhenClickUI(new CYAtlas[1] { CYAtlas.HallShopAtlas }, delegate
			{
				AfterLoadChangeButton(_curPanel, Time.time - time);
			}, needloadList: true);
		}
		else if (_curPanel.UiType == HallUiKind.Science)
		{
			StatisticalManager.Instance.SendClickLog("44");
			ResourcesManager.Instance.LoadAtlasesWhenClickUI(new CYAtlas[1] { CYAtlas.HallScience }, delegate
			{
				AfterLoadChangeButton(_curPanel, Time.time - time);
			}, needloadList: true);
		}
		else
		{
			AfterLoadChangeButton(_curPanel);
		}
		UIHallBackground.Instance.ShowOrHide(flag: true);
	}

	private void AfterLoadChangeButton(UIChildInterface panel, float time = 0f)
	{
		if (_curPanel != null)
		{
			_curPanel.ShowOrHide(flag: true, GameManager.Player.GetBattleTank());
		}
		GUITools.SetHallMiddleUiVisible(panel.UiType == HallUiKind.Port);
		if (panel.UiType == HallUiKind.Science && !HallGuiManager.Instance.Get<SciencePanelMainUi>().HadOpenResearch)
		{
			StatisticalManager.Instance.SendTimeLog("45", ((int)(time * 1000f)).ToString());
			HallGuiManager.Instance.Get<SciencePanelMainUi>().HadOpenResearch = true;
		}
		HallGuideManager.Instance.ServiceMainMenu(panel.UiType);
	}

	public void GoHome()
	{
		if (_curPanel != null)
		{
			_curPanel.ShowOrHide(flag: false, null);
		}
		_curPanel = MidlePanle;
		AfterLoadChangeButton(MidlePanle);
		SetCarPortVisible(flag: true);
		UIHallBackground.Instance.ShowOrHide(flag: false);
	}

	public void ReturnHall_WhenChooseCorpsTank()
	{
		_curPanel = MidlePanle;
		AfterLoadChangeButton(MidlePanle);
		SetCarPortVisible(flag: true);
		HallGuiManager.Instance.Get<TankPortUIManager>().BottomNaScript.MakeBottomDown();
		UIHallBackground.Instance.ShowOrHide(flag: false);
	}

	public void ReturnDeployPage_WhenChooseCorpsTank()
	{
		_curPanel = UILandWarPanel.Instance;
		GUITools.SetHallMiddleUiVisible(flag: false);
		HallGuideManager.Instance.ServiceMainMenu(_curPanel.UiType);
		HallGuiManager.Instance.Get<TankPortUIManager>().BottomNaScript.MakeBottomUp();
		UIHallBackground.Instance.ShowOrHide(flag: false);
	}

	public void SetCarPortVisible(bool flag)
	{
		if (!flag)
		{
			Vector3 localPosition = MidlePanle.transform.localPosition;
			localPosition.y = 1000f;
			MidlePanle.transform.localPosition = localPosition;
		}
		else
		{
			MidlePanle.transform.localPosition = _middlePos;
		}
	}

	public void UpdateButtonVisable()
	{
		float v = -1f;
		if (ReadConfig.TryGetValue("new_box", "box_isopoen", out v))
		{
			GetToggleBtnByType(ToggleFaceType.TreasureBox).gameObject.SetActive((int)v == 1);
		}
	}

	public void EnterPrepareWallPage_Directly()
	{
		_isEnterPrepareWallPage_Directly = true;
		ToggleFAceButton toggleBtnByType = GetToggleBtnByType(ToggleFaceType.LandWar);
		toggleBtnByType.OnClick();
	}

	public void EndPrepareWallPage_Directly(bool isFinish)
	{
		if (isFinish && this.OnEnterPrepareHallFinish != null)
		{
			this.OnEnterPrepareHallFinish();
		}
		_isEnterPrepareWallPage_Directly = false;
	}
}
