using System.Collections;
using TK;
using UnityEngine;

public class BrowserCommunication : MonoBehaviour
{
	public delegate void DataBackDelegate(string data);

	public static BrowserCommunication Instance;

	private bool _escDown;

	public bool EscDown => _escDown;

	private void Awake()
	{
		Instance = this;
		Object.DontDestroyOnLoad(this);
	}

	public void GetRevision()
	{
		Application.ExternalCall("JS_GetRevision");
	}

	public void SetEscDown()
	{
		_escDown = true;
	}

	public void LateUpdate()
	{
		if (_escDown)
		{
			_escDown = false;
		}
	}

	public void SetRevision(string strRevision)
	{
		GameManager.ServerInfo.SetRevision(strRevision);
	}

	public void GetURLInfo()
	{
		Application.ExternalCall("JS_GetURLInfo");
	}

	public void SetURLInfo(string strParams)
	{
		TKLog.Log("SetURLInfo:" + strParams);
		if (!string.IsNullOrEmpty(strParams) && strParams.Length >= 7)
		{
			GameManager.ServerInfo.SetPlatformInfo(strParams, showAgreementWindow: false);
		}
	}

	public void GetUnityPackageTime()
	{
		Application.ExternalCall("JS_GetUnityPackageTime");
	}

	public void SetUnityPackageTime(string time)
	{
		if (!string.IsNullOrEmpty(time))
		{
			GameManager.Instance.UnityPackageTime = time;
		}
	}

	public void GetBrowserInfo()
	{
		Application.ExternalCall("JS_GetBrowserInfo");
	}

	public void SetBrowserInfo(string info)
	{
		StatisticalManager.Instance.SetBrowserInfo(info);
	}

	public void OpenConsumeWeb()
	{
		BrowserCommunicationFactory.Instance().CallPayment();
	}

	public void CallInviteCallBack(string data)
	{
		TKLog.Log("CallInviteFriendBack: data is " + data);
		BrowserCommunicationFactory.Instance().CallInviteFriendBack(data);
	}

	public void CallFeedCallBack(string data)
	{
		TKLog.Log("CallShareBack: data is " + data);
		BrowserCommunicationFactory.Instance().CallShareBack(data);
	}

	public void CallPictureCallBack(string data)
	{
		TKLog.Log("CallPhotoBack: data is " + data);
		BrowserCommunicationFactory.Instance().CallPhotoBack(data);
	}

	public void CallGetFriendsCallBack(string data)
	{
		BrowserCommunicationFactory.Instance().GetFriendsBack(data);
		TKLog.Log("GetFriendsBack: data is " + data);
	}

	public void OpenDownloadExe(string sURL)
	{
		Application.ExternalCall("Util.openDownloadExe", sURL);
	}

	public void SendHttpRequest(string url, DataBackDelegate callBack = null)
	{
		StartCoroutine(SendReqProcess(url, callBack));
	}

	private IEnumerator SendReqProcess(string url, DataBackDelegate callBack = null)
	{
		TKLog.Log("Send to Auth: url" + url);
		WWW data = new WWW(url);
		yield return data;
		if (data.error != null)
		{
			TKLog.LogError("Auth failed. Error: " + data.error);
		}
		else
		{
			callBack?.Invoke(data.text);
		}
	}
}
