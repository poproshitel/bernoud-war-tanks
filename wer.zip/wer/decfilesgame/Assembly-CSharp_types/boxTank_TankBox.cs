using System;
using UnityEngine;

namespace boxTank;

public class TankBox
{
	public enum CollideTouchProperty
	{
		CTP_EDGE,
		CTP_Pnt
	}

	public enum KeyCtrlType
	{
		KCT_FWD,
		KCT_BKWD,
		KCT_LEFT,
		KCT_RIGHT
	}

	public enum CompoundOperationType
	{
		COT_NONE,
		COT_FWD,
		COT_BKWD,
		COT_LEFT,
		COT_RIGHT,
		COT_FW_LEFT,
		COT_FW_RIGHT,
		COT_BK_LEFT,
		COT_BK_RIGHT
	}

	public Vector3 pos;

	public Vector3 dir;

	public Vector3 sz;

	public Vector3[] fpnts;

	public Vector3 spd;

	public float spdVal;

	public float rotSpd;

	public float fwdAcc = 1f;

	public float cfg_maxFwdSpd = 5f;

	public float cfg_maxBkwdSpd = 2f;

	public float cfg_sleepSpd = 0.2f;

	public float cur_maxFwdSpd = 5f;

	public float cur_maxBkwdSpd = 2f;

	public float crashAngle;

	public float inertia = 200000f;

	public float mass = 1000f;

	public float frictionModulus = 0.35f;

	public Vector3 curFriction;

	public float collideEllapse = 100000f;

	private bool ctrl_fwd;

	private bool ctrl_bkwd;

	private bool ctrl_left;

	private bool ctrl_right;

	private GameObject go;

	private GameObject subGo;

	private int id;

	private bool isMainTank;

	private Quaternion turnRightQ = Quaternion.AngleAxis(90f, Vector3.up);

	private Quaternion tmpQ = Quaternion.identity;

	private Quaternion turnCCWQ = Quaternion.AngleAxis(-90f, Vector3.up);

	private float tankPosY;

	private Vector3 tmpV0 = default(Vector3);

	private Vector3 tmpV1 = default(Vector3);

	private Vector3 tmpV2 = default(Vector3);

	private Vector3 tmpV3 = default(Vector3);

	private Vector3 tmpV4 = default(Vector3);

	private Vector3 tmpV5 = default(Vector3);

	private double moveInfoSendEllapse;

	private Vector3 dyn_linearSpd = Vector3.zero;

	private float dyn_rotSpd;

	public int CrashPntQuadrant;

	private float playCollideEffectLastTm;

	private bool[] ctrlKeys = new bool[4];

	private Vector3 tmpVec3 = new Vector3(5f, 0f, 0f);

	private Vector3 tmpVec23 = new Vector3(7f, 0f, 0f);

	private GameObject goFlg;

	private GameObject goFlg1;

	public int ID
	{
		get
		{
			return id;
		}
		set
		{
			id = value;
		}
	}

	public bool IsMainTank
	{
		get
		{
			return isMainTank;
		}
		set
		{
			isMainTank = value;
		}
	}

	public float CurMaxFwdSpd
	{
		get
		{
			return cur_maxFwdSpd;
		}
		set
		{
			cur_maxFwdSpd = value;
		}
	}

	public float TankPosY
	{
		get
		{
			return tankPosY;
		}
		set
		{
			tankPosY = value;
		}
	}

	public TankBox(Vector3 p, Vector3 s)
	{
		pos = p;
		sz = s;
		dir = new Vector3(1f, 0f);
		spd = new Vector3(0f, 0f);
		curFriction = new Vector3(0f, 0f);
	}

	public void SetForwardDir(float x, float z)
	{
		dir = new Vector3(x, 0f, z);
	}

	public void UpdateVisual()
	{
	}

	public void TurnCW(ref Vector3 inV)
	{
		inV = turnRightQ * inV;
	}

	public void TurnCW(ref Vector3 inV, float angle)
	{
		tmpQ = Quaternion.AngleAxis(angle, Vector3.up);
		inV = tmpQ * inV;
	}

	public void TurnCCW(ref Vector3 inV, float angle)
	{
		tmpQ = Quaternion.AngleAxis(0f - angle, Vector3.up);
		inV = tmpQ * inV;
	}

	public void TurnCCW(ref Vector3 inV)
	{
		inV = turnCCWQ * inV;
	}

	public Vector3[] GetFPoints()
	{
		if (fpnts == null)
		{
			fpnts = new Vector3[4];
		}
		float num = sz.x * 0.5f;
		float num2 = sz.z * 0.5f;
		Vector3 inV = dir;
		TurnCW(ref inV);
		Vector3 vector = dir;
		vector *= num2;
		Vector3 vector2 = inV;
		vector2 *= num;
		ref Vector3 reference = ref fpnts[0];
		reference = pos + vector + vector2;
		ref Vector3 reference2 = ref fpnts[1];
		reference2 = pos + vector - vector2;
		ref Vector3 reference3 = ref fpnts[2];
		reference3 = pos - vector - vector2;
		ref Vector3 reference4 = ref fpnts[3];
		reference4 = pos - vector + vector2;
		if (Math.Abs(fpnts[0].x) > 5000f || Math.Abs(fpnts[0].z) > 5000f)
		{
			Console.WriteLine("Math.Abs(fpnts[0].x) > 5000 || Math.Abs(fpnts[0].z) > 5000");
		}
		return fpnts;
	}

	public void Update(float tf)
	{
		UpdateDynamic(tf);
		if (isMainTank)
		{
			moveInfoSendEllapse += tf;
			if (moveInfoSendEllapse > 0.12200000137090683)
			{
				moveInfoSendEllapse = 0.0;
				SendMoveInfo();
			}
			UpdateMain();
		}
		UpdateVisual();
	}

	public static bool TankOverlap(TankBox tb0, TankBox tb1)
	{
		float num = (float)Math.Sqrt((double)(tb0.sz.x * tb0.sz.x) * 0.25 + (double)(tb0.sz.z * tb0.sz.z) * 0.25);
		float num2 = (float)Math.Sqrt((double)(tb1.sz.x * tb1.sz.x) * 0.25 + (double)(tb1.sz.z * tb1.sz.z) * 0.25);
		float num3 = num + num2;
		float magnitude = (tb0.pos - tb1.pos).magnitude;
		if (num3 < magnitude)
		{
			return false;
		}
		return false;
	}

	public void SetOperation(bool fwd, bool bkwd, bool left, bool right)
	{
		ctrl_fwd = fwd;
		ctrl_bkwd = bkwd;
		ctrl_left = left;
		ctrl_right = right;
	}

	public void SetDynState(Vector3 linearSpd, float rotSpd)
	{
		dyn_linearSpd = linearSpd;
		dyn_rotSpd = rotSpd;
	}

	public CompoundOperationType GetCompoundOperationType()
	{
		CompoundOperationType compoundOperationType = CompoundOperationType.COT_FWD;
		int num = 0;
		if (ctrl_fwd)
		{
			num++;
		}
		if (ctrl_bkwd)
		{
			num++;
		}
		if (ctrl_left)
		{
			num++;
		}
		if (ctrl_right)
		{
			num++;
		}
		switch (num)
		{
		case 0:
			return CompoundOperationType.COT_NONE;
		case 1:
			if (ctrl_fwd)
			{
				return CompoundOperationType.COT_FWD;
			}
			if (ctrl_bkwd)
			{
				return CompoundOperationType.COT_BKWD;
			}
			if (ctrl_left)
			{
				return CompoundOperationType.COT_LEFT;
			}
			if (ctrl_right)
			{
				return CompoundOperationType.COT_RIGHT;
			}
			break;
		}
		if (num == 2)
		{
			if (ctrl_fwd && ctrl_left)
			{
				return CompoundOperationType.COT_FW_LEFT;
			}
			if (ctrl_fwd && ctrl_right)
			{
				return CompoundOperationType.COT_FW_RIGHT;
			}
			if (ctrl_bkwd && ctrl_left)
			{
				return CompoundOperationType.COT_BK_RIGHT;
			}
			if (ctrl_bkwd && ctrl_right)
			{
				return CompoundOperationType.COT_BK_LEFT;
			}
		}
		return CompoundOperationType.COT_NONE;
	}

	public void UpdateDynamic(float tf)
	{
		if (!isMainTank)
		{
			return;
		}
		if (ctrl_fwd && ctrl_bkwd)
		{
			ctrl_fwd = false;
			ctrl_bkwd = false;
		}
		if (ctrl_left && ctrl_right)
		{
			ctrl_left = false;
			ctrl_right = false;
		}
		fwdAcc = 0f;
		if (ctrl_fwd)
		{
			fwdAcc = 1f;
		}
		if (ctrl_bkwd)
		{
			fwdAcc = -0.5f;
		}
		tmpV0 = dir;
		tmpV0 *= fwdAcc;
		spd += tmpV0;
		tmpV1 = dir;
		TurnCW(ref tmpV1);
		float num = Vector3.Dot(tmpV1, spd);
		tmpV1 *= num;
		spd -= tmpV1;
		tmpV0 = spd;
		bool flag = Vector3.Dot(dir, tmpV0) > 0f;
		if (flag && (tmpV0.magnitude > cfg_maxFwdSpd || tmpV0.magnitude > cur_maxFwdSpd))
		{
			tmpV0.Normalize();
			float num2 = cfg_maxFwdSpd;
			if (num2 > cur_maxFwdSpd)
			{
				num2 = cur_maxFwdSpd;
			}
			tmpV0 *= num2;
		}
		if (!flag && (tmpV0.magnitude > cfg_maxBkwdSpd || tmpV0.magnitude > cur_maxBkwdSpd))
		{
			tmpV0.Normalize();
			float num3 = cfg_maxBkwdSpd;
			if (num3 > cur_maxBkwdSpd)
			{
				num3 = cur_maxBkwdSpd;
			}
			tmpV0 *= num3;
		}
		spd = tmpV0;
		tmpV0 *= tf;
		pos += tmpV0;
		collideEllapse += tf;
		if (collideEllapse > 2f)
		{
			cur_maxFwdSpd = cfg_maxFwdSpd;
		}
		else
		{
			cur_maxFwdSpd = 3f * (float)Math.Sin(crashAngle);
		}
		float num4 = 1f;
		if (ctrl_bkwd)
		{
			num4 = -1f;
		}
		if (ctrl_right)
		{
			TurnCW(ref dir, num4 * 10.5f * tf);
		}
		if (ctrl_left)
		{
			TurnCW(ref dir, (0f - num4) * 10.5f * tf);
		}
		if (!ctrl_fwd && !ctrl_bkwd)
		{
			tmpV0 = spd;
			float magnitude = tmpV0.magnitude;
			tmpV0.Normalize();
			tmpV1 = tmpV0;
			tmpV1 *= -1f * magnitude * magnitude * 3000f;
			tmpV1 *= 1f / mass;
			tmpV1 *= tf;
			spd += tmpV1;
			curFriction = tmpV1;
		}
		if (spd.magnitude < cfg_sleepSpd)
		{
			spd = Vector3.zero;
		}
	}

	public void OnCollide(Vector3 absPos, Vector3 nor, float punchDepth, GeoCompute.ElementType selfEt, GeoCompute.ElementType otherEt, TankBox otherTb)
	{
		if (!isMainTank)
		{
			return;
		}
		float magnitude = dyn_linearSpd.magnitude;
		if (magnitude < 0.01f && GetCompoundOperationType() == CompoundOperationType.COT_NONE)
		{
			return;
		}
		collideEllapse = 0f;
		float value = Vector3.Dot(dir, nor);
		float magnitude2 = Vector3.Cross(dir, nor).magnitude;
		crashAngle = (float)Math.Acos(Math.Abs(value));
		CompoundOperationType compoundOperationType = otherTb.GetCompoundOperationType();
		int pntRelQuadrant = otherTb.GetPntRelQuadrant(absPos);
		CompoundOperationType compoundOperationType2 = GetCompoundOperationType();
		int pntRelQuadrant2 = GetPntRelQuadrant(absPos);
		CrashPntQuadrant = pntRelQuadrant2;
		if (Math.Abs(magnitude2) < 0.707f)
		{
			Vector3 zero = Vector3.zero;
			Vector3 rhs = absPos - pos;
			if (Vector3.Dot(dir, rhs) < 0f)
			{
				zero = dir * punchDepth;
			}
			else
			{
				zero = -dir * punchDepth;
			}
			return;
		}
		if (selfEt == GeoCompute.ElementType.ET_POINT && otherEt == GeoCompute.ElementType.ET_EDGE)
		{
			if (Math.Abs(value) > 0.78f)
			{
				tmpV0 = nor;
				tmpV0 *= punchDepth;
				pos -= tmpV0;
				TKLog.Log("PARALLEL...Punch depth is " + punchDepth);
				return;
			}
			if (Math.Abs(magnitude2) < 0.32f)
			{
				tmpV0 = nor;
				tmpV0 *= punchDepth;
				pos -= tmpV0;
				TKLog.Log("VERTICLE...Punch depth is " + punchDepth);
				return;
			}
		}
		if (selfEt == GeoCompute.ElementType.ET_POINT && otherEt == GeoCompute.ElementType.ET_POINT)
		{
			tmpV0 = absPos - pos;
			float magnitude3 = tmpV0.magnitude;
			float num = punchDepth / magnitude3;
			float y = Vector3.Cross(tmpV0, nor).y;
			if (y > 0f)
			{
				num *= -1f;
			}
		}
		else if (selfEt == GeoCompute.ElementType.ET_EDGE && otherEt == GeoCompute.ElementType.ET_POINT)
		{
			tmpV0 = absPos - pos;
			tmpV0.Normalize();
			float num2 = Vector3.Dot(nor, dir);
			if (Math.Abs(num2) > 0.816f)
			{
				spd = Vector3.zero;
				tmpV1 = dir;
				tmpV1 *= Math.Abs(punchDepth);
				if (num2 > 0f)
				{
					pos -= tmpV1;
				}
				else
				{
					pos += tmpV1;
				}
				return;
			}
			tmpV0 = absPos - pos;
			float magnitude4 = tmpV0.magnitude;
			tmpV0.Normalize();
			float num3 = Vector3.Dot(tmpV0, dir);
			if (num3 > -0.5f && num3 < 0.5f)
			{
				tmpV0 = nor;
				tmpV0 *= punchDepth;
				pos -= tmpV0;
				return;
			}
			tmpV1 = nor;
			if (Vector3.Dot(nor, tmpV0) > 0f)
			{
				tmpV1 *= -1f;
			}
			float num4 = Math.Abs(punchDepth / magnitude4);
			float y2 = Vector3.Cross(tmpV0, tmpV1).y;
			if (y2 > 0f)
			{
				num4 *= -1f;
			}
			TurnCCW(ref dir, num4 * 57.3f);
		}
		else if (selfEt == GeoCompute.ElementType.ET_POINT && otherEt == GeoCompute.ElementType.ET_EDGE)
		{
			tmpV0 = absPos;
			tmpV1 = absPos;
			tmpV2 = absPos - pos;
			float magnitude5 = tmpV2.magnitude;
			if (magnitude5 < 1f)
			{
				TKLog.LogError("TankBox.OnCollide() , The collide point is too close to the tank center.");
				return;
			}
			TurnCW(ref tmpV2);
			tmpV2.Normalize();
			float num5 = Vector3.Dot(tmpV2, nor);
			float num6 = punchDepth / Math.Abs(num5);
			float num7 = num6 / magnitude5;
			if (num5 > 0f)
			{
				TurnCCW(ref dir, num7 * 57.3f);
			}
			else
			{
				TurnCW(ref dir, num7 * 57.3f);
			}
		}
		else if (selfEt == GeoCompute.ElementType.ET_EDGE && otherEt == GeoCompute.ElementType.ET_EDGE)
		{
			TKLog.Log("OnCollide() , edge vs edge , impossible ? ");
		}
	}

	private int GetPntRelQuadrant(Vector3 pnt)
	{
		tmpV1 = dir;
		TurnCCW(ref tmpV1);
		tmpV0 = pnt - pos;
		bool flag = Vector3.Dot(tmpV0, dir) > 0f;
		bool flag2 = Vector3.Dot(tmpV0, tmpV1) > 0f;
		if (flag2 && flag)
		{
			return 1;
		}
		if (flag2 && !flag)
		{
			return 4;
		}
		if (!flag2 && flag)
		{
			return 2;
		}
		if (!flag2 && !flag)
		{
			return 3;
		}
		return 0;
	}

	private void SendMoveInfo()
	{
		ctrlKeys[0] = ctrl_fwd;
		ctrlKeys[1] = ctrl_bkwd;
		ctrlKeys[2] = ctrl_left;
		ctrlKeys[3] = ctrl_right;
	}

	private void UpdateMain()
	{
	}
}
