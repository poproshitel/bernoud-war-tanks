using System;
using System.Collections;
using System.Collections.Generic;
using TK;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
	private class FadingAudio
	{
		public VolumeType Type;

		private AudioSource _audioSource;

		private float _startVol;

		private float _tgtVol;

		private Action _onFadeOver;

		private float _spd;

		public void Init(VolumeType type, AudioSource audioSource, float startVol, float tgtVol, Action onFadeOver, float time)
		{
			Type = type;
			_audioSource = audioSource;
			_startVol = startVol;
			_tgtVol = tgtVol;
			_onFadeOver = onFadeOver;
			_spd = (_tgtVol - startVol) / time;
		}

		public bool Update(float deltaTime, float curVol)
		{
			if (Mathf.Abs(_startVol - _tgtVol) < 0.05f)
			{
				_onFadeOver();
				return true;
			}
			if (!_audioSource)
			{
				return true;
			}
			_startVol += deltaTime * _spd;
			_audioSource.volume = _startVol * curVol;
			return false;
		}
	}

	private const string PreStringFlagForDontDestroyAudio = "dontdestroy_";

	public const int None = 0;

	public const int ButtonClick = 56;

	public const int MapClick = 58;

	public const int Mark = 59;

	public const int CountDown = 60;

	public const int Critical = 82;

	private readonly List<AudioSource> _ambianceAudios = new List<AudioSource>();

	private readonly List<AudioSource> _musicAudios = new List<AudioSource>();

	private readonly List<AudioSource> _particleAudios = new List<AudioSource>();

	private readonly List<AudioSource> _tankAudios = new List<AudioSource>();

	private readonly List<AudioSource> _uiAudios = new List<AudioSource>();

	private readonly List<AudioSource> _promptAudios = new List<AudioSource>();

	[SerializeField]
	private Dictionary<int, float> _curVolumes;

	private float _timer;

	private Transform _listener;

	public PlayerProxy _deadmodeTargetPlayer;

	private AudioSource _curCrewVoiceSource;

	private AudioSource _battleResaultMusic;

	private readonly List<FadingAudio> _fadingAudioList = new List<FadingAudio>();

	public bool IsPlayingBattleResultMusic => _battleResaultMusic != null;

	private void Start()
	{
		_curVolumes = new Dictionary<int, float>
		{
			{ 1, 1f },
			{ 2, 1f },
			{ 3, 1f },
			{ 4, 1f },
			{ 5, 1f },
			{ 6, 1f }
		};
		base.gameObject.AddComponent<AudioListener>();
		_listener = base.transform;
	}

	private void Update()
	{
		_timer += Time.deltaTime;
		if (_timer > 10f)
		{
			_timer = 0f;
			ResetList(_ambianceAudios);
			ResetList(_musicAudios);
			ResetList(_particleAudios);
			ResetList(_tankAudios);
			ResetList(_uiAudios);
			ResetList(_promptAudios);
		}
		switch (GameManager.Instance.GameLevel)
		{
		case Level.Room:
			if (SceneRoom.Instance.GetMainPlayer() != null && SceneRoom.Instance.GetMainPlayer().TankModel != null)
			{
				if (_deadmodeTargetPlayer == null)
				{
					TankModel tankModel = SceneRoom.Instance.GetMainPlayer().TankModel;
					if (tankModel.Turret != null)
					{
						_listener.position = tankModel.Turret.position;
						_listener.rotation = tankModel.Turret.rotation;
					}
					else
					{
						_listener.position = tankModel.Hull.position;
						_listener.rotation = tankModel.Hull.rotation;
					}
					break;
				}
				TankModel tankModel2 = _deadmodeTargetPlayer.TankModel;
				if (tankModel2 != null)
				{
					if (tankModel2.Turret != null)
					{
						_listener.position = tankModel2.Turret.position;
						_listener.rotation = tankModel2.Turret.rotation;
					}
					else
					{
						_listener.position = tankModel2.Hull.position;
						_listener.rotation = tankModel2.Hull.rotation;
					}
				}
			}
			else if (Camera.main != null)
			{
				_listener.position = Camera.main.transform.position;
				_listener.rotation = Camera.main.transform.rotation;
			}
			break;
		case Level.Hall:
			_listener.position = Camera.main.transform.position;
			_listener.rotation = Camera.main.transform.rotation;
			break;
		}
		for (int num = _fadingAudioList.Count - 1; num >= 0; num--)
		{
			FadingAudio fadingAudio = _fadingAudioList[num];
			if (fadingAudio.Update(Time.deltaTime, _curVolumes[(int)fadingAudio.Type]))
			{
				_fadingAudioList.RemoveAt(num);
			}
		}
	}

	private void ResetList(IList<AudioSource> audioSources)
	{
		if (audioSources == null || audioSources.Count == 0)
		{
			return;
		}
		for (int num = audioSources.Count - 1; num >= 0; num--)
		{
			AudioSource audioSource = audioSources[num];
			if (audioSource == null)
			{
				audioSources.RemoveAt(num);
			}
		}
	}

	public void SetAudioVolume(float value, VolumeType type)
	{
		_curVolumes[(int)type] = value;
		switch (type)
		{
		case VolumeType.Particle:
			ApplyAudioVolume(_particleAudios);
			break;
		case VolumeType.Tank:
			ApplyAudioVolume(_tankAudios);
			break;
		case VolumeType.Ambiance:
			ApplyAudioVolume(_ambianceAudios);
			break;
		case VolumeType.Music:
			ApplyAudioVolume(_musicAudios);
			break;
		case VolumeType.UI:
			ApplyAudioVolume(_uiAudios);
			break;
		case VolumeType.Prompt:
			ApplyAudioVolume(_promptAudios);
			break;
		}
	}

	private void ApplyAudioVolume(IList<AudioSource> list)
	{
		if (list.Count == 0)
		{
			return;
		}
		for (int num = list.Count - 1; num >= 0; num--)
		{
			AudioSource audioSource = list[num];
			if (audioSource == null)
			{
				list.RemoveAt(num);
			}
			else if ((bool)audioSource.clip)
			{
				string s = audioSource.clip.name.Split('_')[0];
				audioSource.volume = ((!int.TryParse(s, out var result)) ? 0.1f : GetVolume(result));
			}
			else
			{
				audioSource.volume = 0.1f;
			}
		}
	}

	public float GetVolume(int id)
	{
		Table_Audio audio = GameManager.TableMgr.GetAudio(id);
		int audio_type = audio.audio_type;
		float volume = audio.volume;
		float value = 0f;
		if (_curVolumes.TryGetValue(audio_type, out value))
		{
			return value * volume;
		}
		TKLog.LogError("Audio table type error.  type : " + audio_type);
		return 0.1f;
	}

	public float GetVolume(VolumeType type)
	{
		return _curVolumes[(int)type];
	}

	public void PlayAudioLoop(int id, Transform emitter, Action<AudioSource> onPlay = null, bool dontDestroyOnLoad = false)
	{
		Table_Audio tableAudio = GameManager.TableMgr.GetAudio(id);
		ResourcesManager.Instance.Retrieve(id, ResourceType.Audio, () => emitter != null, delegate(UnityEngine.Object asset)
		{
			AudioClip clip = asset as AudioClip;
			AudioSource obj = PlayerAudioClip(clip, tableAudio.id, loop: true, 100, emitter.position, emitter, null, dontDestroyOnLoad);
			if (onPlay != null)
			{
				onPlay(obj);
			}
		});
	}

	public void PlayAudioLoopEmitterStickToEar(int id, Transform emitter, Action<AudioSource> onPlay = null)
	{
		Table_Audio tableAudio = GameManager.TableMgr.GetAudio(id);
		ResourcesManager.Instance.Retrieve(id, ResourceType.Audio, () => emitter != null, delegate(UnityEngine.Object asset)
		{
			AudioClip clip = asset as AudioClip;
			AudioSource obj = PlayerAudioClip(clip, tableAudio.id, loop: true, 100, emitter.position, emitter);
			emitter.parent = _listener;
			emitter.localPosition = Vector3.zero;
			emitter.localRotation = Quaternion.identity;
			if (onPlay != null)
			{
				onPlay(obj);
			}
		});
	}

	public void PlayAudioOnce(int id, Vector3 worldPos, Action<AudioSource> onPlay = null, Func<bool> conditon = null, Action onDelComplete = null, bool dontDestroyOnLoad = false)
	{
		Table_Audio tableAudio = GameManager.TableMgr.GetAudio(id);
		ResourcesManager.Instance.Retrieve(id, ResourceType.Audio, conditon, delegate(UnityEngine.Object asset)
		{
			AudioClip clip = asset as AudioClip;
			AudioSource obj = PlayerAudioClip(clip, tableAudio.id, loop: false, 100, worldPos, _listener, onDelComplete, dontDestroyOnLoad);
			if (onPlay != null)
			{
				onPlay(obj);
			}
		});
	}

	public void PlayGlobalAudioOnce(int id, Action<AudioSource> onPlay = null, Func<bool> conditon = null, Action onDelComplete = null, bool dontDestroyOnLoad = false)
	{
		PlayAudioOnce(id, _listener.position, onPlay, conditon, onDelComplete, dontDestroyOnLoad);
	}

	public void PlayGlobalAudioLoop(int id, Action<AudioSource> onPlay = null, bool dontDestroyOnLoad = false)
	{
		PlayAudioLoop(id, _listener, onPlay, dontDestroyOnLoad);
	}

	private AudioSource PlayerAudioClip(AudioClip clip, int id, bool loop, int distance, Vector3 worldPos, Transform parent = null, Action onDelComplete = null, bool dontDestroyOnLoad = false)
	{
		if (clip == null)
		{
			return null;
		}
		GameObject gameObject = new GameObject("Audio: " + clip.name);
		gameObject.transform.parent = parent;
		gameObject.transform.position = worldPos;
		AudioSource audioSource = gameObject.AddComponent<AudioSource>();
		audioSource.loop = loop;
		audioSource.clip = ((!dontDestroyOnLoad) ? clip : UnityEngine.Object.Instantiate(clip));
		audioSource.pitch = 1f;
		audioSource.rolloffMode = AudioRolloffMode.Linear;
		audioSource.minDistance = 1f;
		audioSource.maxDistance = distance;
		audioSource.spread = 0f;
		audioSource.time = 0f;
		audioSource.spatialBlend = 1f;
		if (!audioSource.isPlaying && audioSource.clip.isReadyToPlay)
		{
			audioSource.Play();
		}
		if (dontDestroyOnLoad)
		{
			gameObject.name = "dontdestroy_" + gameObject.name;
		}
		AddAudioToList(audioSource, id);
		if (!loop)
		{
			UnityEngine.Object.Destroy(gameObject, clip.length);
			if (onDelComplete != null)
			{
				StartCoroutine(LagDo(clip.length, onDelComplete));
			}
		}
		return audioSource;
	}

	private static IEnumerator LagDo(float lagTime, Action doSomething)
	{
		yield return new WaitForSeconds(lagTime);
		yield return new WaitForEndOfFrame();
		doSomething();
	}

	public void AddAudio(int id, AudioSource audioSource)
	{
		AddAudioToList(audioSource, id);
	}

	private void AddAudioToList(AudioSource audioSource, int id)
	{
		Table_Audio audio = GameManager.TableMgr.GetAudio(id);
		if (audio == null)
		{
			TKLog.Log("AddAudio tableAudio is null" + id);
			return;
		}
		audioSource.volume = GetVolume(audio.id);
		switch (audio.audio_type)
		{
		case 1:
			_particleAudios.Add(audioSource);
			break;
		case 2:
			_tankAudios.Add(audioSource);
			break;
		case 3:
			_ambianceAudios.Add(audioSource);
			break;
		case 4:
			_musicAudios.Add(audioSource);
			break;
		case 5:
			_uiAudios.Add(audioSource);
			break;
		case 6:
			_promptAudios.Add(audioSource);
			break;
		}
	}

	public void PlayCrewVoice(int id, Action<AudioSource> onPlay = null, Action onDelComplete = null)
	{
		if (_curCrewVoiceSource != null)
		{
			UnityEngine.Object.Destroy(_curCrewVoiceSource);
			_curCrewVoiceSource = null;
		}
		Action<AudioSource> onPlay2 = delegate(AudioSource source)
		{
			_curCrewVoiceSource = source;
			_curCrewVoiceSource.Play();
			if (onPlay != null)
			{
				onPlay(source);
			}
		};
		PlayGlobalAudioOnce(id, onPlay2, GameManager.IsRoomLevel, onDelComplete);
	}

	public void StopCrewVoice()
	{
		if (_curCrewVoiceSource != null)
		{
			UnityEngine.Object.Destroy(_curCrewVoiceSource);
		}
	}

	public void PlayBattleResultMusic(bool winOrLose, Func<bool> condition = null)
	{
		PlayGlobalAudioOnce((!winOrLose) ? 104 : 103, delegate(AudioSource source)
		{
			source.enabled = true;
			source.Play();
			_battleResaultMusic = source;
		}, null, PlayHallBgMusic, dontDestroyOnLoad: true);
	}

	public void FadeOutBattleResultMusic()
	{
		if (_battleResaultMusic != null && _battleResaultMusic.enabled)
		{
			StartFadeOutAudio(_battleResaultMusic);
		}
	}

	public void PlayHallBgMusic()
	{
	}

	public void WhenChangeMap()
	{
		WhenChangeMap(_musicAudios);
		WhenChangeMap(_ambianceAudios);
		WhenChangeMap(_uiAudios);
		WhenChangeMap(_promptAudios);
		WhenChangeMap(_tankAudios);
		WhenChangeMap(_particleAudios);
		_deadmodeTargetPlayer = null;
	}

	private void WhenChangeMap(IList<AudioSource> list)
	{
		for (int num = list.Count - 1; num >= 0; num--)
		{
			AudioSource audioSource = list[num];
			if (audioSource != null && !audioSource.name.StartsWith("dontdestroy_"))
			{
				list.RemoveAt(num);
				UnityEngine.Object.Destroy(audioSource.gameObject);
			}
		}
	}

	public void StartFadeOutAudio(AudioSource audioSource)
	{
		string s = audioSource.clip.name.Split('_')[0];
		if (!int.TryParse(s, out var result))
		{
			return;
		}
		int audio_type = GameManager.TableMgr.GetAudio(result).audio_type;
		float volume = GameManager.TableMgr.GetAudio(result).volume;
		FadingAudio fadingAudio = new FadingAudio();
		fadingAudio.Init((VolumeType)audio_type, audioSource, volume, 0f, delegate
		{
			if ((bool)audioSource && (bool)audioSource.gameObject)
			{
				UnityEngine.Object.Destroy(audioSource.gameObject);
			}
		}, 2f);
		_fadingAudioList.Add(fadingAudio);
	}

	public void StartFadeInAudio(AudioSource audioSource, float tgtVol)
	{
		string s = audioSource.clip.name.Split('_')[0];
		if (int.TryParse(s, out var result))
		{
			int audio_type = GameManager.TableMgr.GetAudio(result).audio_type;
			float volume = GameManager.TableMgr.GetAudio(result).volume;
			FadingAudio fadingAudio = new FadingAudio();
			fadingAudio.Init((VolumeType)audio_type, audioSource, 0f, volume, delegate
			{
			}, 2f);
			_fadingAudioList.Add(fadingAudio);
		}
	}
}
