using System;
using System.Collections.Generic;
using UnityEngine;

public class BulletMark : MonoBehaviour
{
	public LayerMask AffectedLayers;

	public GameObject AffectedObject;

	[HideInInspector]
	public Bounds Bounds;

	public Material DecalMaterial;

	public Texture[] Images;

	public DecalMode DecalMode;

	public float MaxAngle = 90f;

	public Vector2 Offset = Vector2.zero;

	public float PushDistance;

	public Vector2 Tiling = Vector2.one;

	public float StartAnimationTime;

	private float _angleCosine;

	private Vector4 _backPlane;

	private Vector4 _bottomPlane;

	[SerializeField]
	private List<DecalPolygon> _clippedPolygons;

	private Vector3 _decalBinormal;

	private Vector3 _decalCenter;

	private Vector3 _decalNormal;

	private Vector3 _decalSize;

	private Vector3 _decalTangent;

	private Vector4 _frontPlane;

	private List<CombineInstance> _combineInstances;

	private Vector4 _leftPlane;

	private Vector4 _rightPlane;

	[SerializeField]
	private List<DecalPolygon> _startPolygons;

	private Vector4 _topPlane;

	private float _uCos;

	private float _uvAngle;

	private float _vSin;

	private void Start()
	{
		AffectedLayers = 524544;
	}

	public void GenerateDecal(HitType type, GameObject go, ShootResult res)
	{
		if (type != 0 && type != HitType.UvAnimation)
		{
			return;
		}
		_uvAngle = UnityEngine.Random.Range(0f, 360f);
		AffectedObject = go;
		DecalMode = DecalMode.MeshFilter;
		PushDistance += BulletMarkManager.Add(base.gameObject);
		Material material = new Material(DecalMaterial);
		if (Images.Length < 3)
		{
			TKLog.LogWarning("texture count is not encourage" + Images.Length);
			return;
		}
		switch (res)
		{
		default:
			return;
		case ShootResult.Success:
			material.mainTexture = Images[0];
			break;
		case ShootResult.Fail:
			material.mainTexture = Images[1];
			break;
		case ShootResult.JumpBullet:
			material.mainTexture = Images[2];
			break;
		case ShootResult.Error:
		case ShootResult.Chassis:
			return;
		}
		DecalMaterial = material;
		CalculateDecal();
		base.transform.position = go.transform.position;
		base.transform.rotation = go.transform.rotation;
		base.transform.localScale = go.transform.localScale;
	}

	private void OnDrawGizmosSelected()
	{
		CalculateBounds();
		Gizmos.DrawRay(_decalCenter, _decalNormal);
		Gizmos.matrix = base.transform.localToWorldMatrix;
		Gizmos.DrawWireCube(Vector3.zero, Vector3.one);
	}

	public void CalculateBounds()
	{
		Bounds = new Bounds(base.transform.position, base.transform.lossyScale * 1.414214f);
	}

	public void CalculateDecal()
	{
		ClearDecals();
		MaxAngle = Mathf.Clamp(MaxAngle, 0f, 180f);
		_angleCosine = Mathf.Cos(MaxAngle * ((float)Math.PI / 180f));
		_uvAngle = Mathf.Clamp(_uvAngle, 0f, 360f);
		_uCos = Mathf.Cos(_uvAngle * ((float)Math.PI / 180f));
		_vSin = Mathf.Sin(_uvAngle * ((float)Math.PI / 180f));
		if (AffectedObject == null)
		{
			TKLog.LogWarning("No object will be affected. Decal will not be calculated.");
			return;
		}
		Matrix4x4 worldToLocalMatrix = base.transform.worldToLocalMatrix;
		_combineInstances = new List<CombineInstance>();
		CalculateObjectDecal(AffectedObject, worldToLocalMatrix);
		if (_combineInstances.Count > 0)
		{
			CombineInstance[] combine = _combineInstances.ToArray();
			MeshRenderer meshRenderer = base.gameObject.GetComponent<MeshRenderer>();
			if (meshRenderer == null)
			{
				meshRenderer = base.gameObject.AddComponent<MeshRenderer>();
			}
			meshRenderer.material = DecalMaterial;
			MeshFilter meshFilter = base.gameObject.GetComponent<MeshFilter>();
			if (meshFilter == null)
			{
				meshFilter = base.gameObject.AddComponent<MeshFilter>();
			}
			else
			{
				UnityEngine.Object.DestroyImmediate(meshFilter.sharedMesh);
			}
			Mesh mesh = new Mesh();
			mesh.CombineMeshes(combine, mergeSubMeshes: true);
			if (PushDistance > 0f)
			{
				List<List<int>> list = new List<List<int>>();
				Vector3[] vertices = mesh.vertices;
				Vector3[] normals = mesh.normals;
				bool[] array = new bool[vertices.Length];
				for (int i = 0; i < array.Length; i++)
				{
					array[i] = false;
				}
				for (int j = 0; j < vertices.Length; j++)
				{
					if (array[j])
					{
						continue;
					}
					List<int> list2 = new List<int>();
					list2.Add(j);
					array[j] = true;
					for (int k = j + 1; k < vertices.Length; k++)
					{
						if (!array[k] && Vector3.Distance(vertices[j], vertices[k]) < 0.001f)
						{
							list2.Add(k);
							array[k] = true;
						}
					}
					list.Add(list2);
				}
				foreach (List<int> item in list)
				{
					Vector3 zero = Vector3.zero;
					foreach (int item2 in item)
					{
						zero += normals[item2];
					}
					zero = (zero / item.Count).normalized;
					foreach (int item3 in item)
					{
						vertices[item3] += zero * PushDistance;
					}
				}
				mesh.vertices = vertices;
			}
			mesh.name = "DecalMesh";
			meshFilter.mesh = mesh;
			for (int l = 0; l < _combineInstances.Count; l++)
			{
				UnityEngine.Object.DestroyImmediate(_combineInstances[l].mesh);
			}
		}
		_combineInstances.Clear();
		_combineInstances = null;
	}

	public void ClearDecals()
	{
		MeshFilter component = base.gameObject.GetComponent<MeshFilter>();
		if (component != null)
		{
			UnityEngine.Object.DestroyImmediate(component.sharedMesh);
			UnityEngine.Object.DestroyImmediate(component);
		}
		MeshRenderer component2 = base.gameObject.GetComponent<MeshRenderer>();
		if (component2 != null)
		{
			UnityEngine.Object.DestroyImmediate(component2);
		}
	}

	public void CalculateObjectDecal(GameObject obj, Matrix4x4 cTransform)
	{
		Mesh mesh = null;
		if (DecalMode == DecalMode.MeshCollider && obj.GetComponent<MeshCollider>() != null)
		{
			mesh = obj.GetComponent<MeshCollider>().sharedMesh;
		}
		if (mesh == null || DecalMode == DecalMode.MeshFilter)
		{
			if (obj.GetComponent<MeshFilter>() == null)
			{
				return;
			}
			mesh = obj.GetComponent<MeshFilter>().sharedMesh;
		}
		if (mesh == null || mesh.name.ToLower().Contains("combined"))
		{
			return;
		}
		_decalNormal = obj.transform.InverseTransformDirection(base.transform.forward);
		_decalCenter = obj.transform.InverseTransformPoint(base.transform.position);
		_decalTangent = obj.transform.InverseTransformDirection(base.transform.right);
		_decalBinormal = obj.transform.InverseTransformDirection(base.transform.up);
		_decalSize = new Vector3(base.transform.lossyScale.x / obj.transform.lossyScale.x, base.transform.lossyScale.y / obj.transform.lossyScale.y, base.transform.lossyScale.z / obj.transform.lossyScale.z);
		_bottomPlane = new Vector4(0f - _decalBinormal.x, 0f - _decalBinormal.y, 0f - _decalBinormal.z, _decalSize.y * 0.5f + Vector3.Dot(_decalCenter, _decalBinormal));
		_topPlane = new Vector4(_decalBinormal.x, _decalBinormal.y, _decalBinormal.z, _decalSize.y * 0.5f - Vector3.Dot(_decalCenter, _decalBinormal));
		_rightPlane = new Vector4(0f - _decalTangent.x, 0f - _decalTangent.y, 0f - _decalTangent.z, _decalSize.x * 0.5f + Vector3.Dot(_decalCenter, _decalTangent));
		_leftPlane = new Vector4(_decalTangent.x, _decalTangent.y, _decalTangent.z, _decalSize.x * 0.5f - Vector3.Dot(_decalCenter, _decalTangent));
		_frontPlane = new Vector4(_decalNormal.x, _decalNormal.y, _decalNormal.z, _decalSize.z * 0.5f - Vector3.Dot(_decalCenter, _decalNormal));
		_backPlane = new Vector4(0f - _decalNormal.x, 0f - _decalNormal.y, 0f - _decalNormal.z, _decalSize.z * 0.5f + Vector3.Dot(_decalCenter, _decalNormal));
		int[] triangles = mesh.triangles;
		Vector3[] vertices = mesh.vertices;
		Vector3[] normals = mesh.normals;
		Vector4[] tangents = mesh.tangents;
		_startPolygons = new List<DecalPolygon>();
		for (int i = 0; i < triangles.Length; i += 3)
		{
			int num = triangles[i];
			int num2 = triangles[i + 1];
			int num3 = triangles[i + 2];
			Vector3 vector = vertices[num];
			Vector3 vector2 = vertices[num2];
			Vector3 vector3 = vertices[num3];
			Vector3 vector4 = normals[num];
			float num4 = Vector3.Dot(vector4, -_decalNormal);
			if (!(num4 <= _angleCosine))
			{
				Vector3 vector5 = tangents[num];
				Vector3 vector6 = tangents[num2];
				Vector3 vector7 = tangents[num3];
				DecalPolygon decalPolygon = new DecalPolygon();
				decalPolygon.VerticeCount = 3;
				decalPolygon.Vertice[0] = vector;
				decalPolygon.Vertice[1] = vector2;
				decalPolygon.Vertice[2] = vector3;
				decalPolygon.Normal[0] = vector4;
				decalPolygon.Normal[1] = vector4;
				decalPolygon.Normal[2] = vector4;
				ref Vector4 reference = ref decalPolygon.Tangent[0];
				reference = vector5;
				ref Vector4 reference2 = ref decalPolygon.Tangent[1];
				reference2 = vector6;
				ref Vector4 reference3 = ref decalPolygon.Tangent[2];
				reference3 = vector7;
				_startPolygons.Add(decalPolygon);
			}
		}
		Mesh mesh2 = CreateMesh(ClipMesh());
		if (mesh2 != null)
		{
			CombineInstance item = default(CombineInstance);
			item.mesh = mesh2;
			item.subMeshIndex = 0;
			item.transform = Matrix4x4.identity;
			_combineInstances.Add(item);
		}
		mesh2 = null;
		_startPolygons.Clear();
		_startPolygons = null;
		_clippedPolygons.Clear();
		_clippedPolygons = null;
		triangles = null;
		normals = null;
		vertices = null;
		tangents = null;
		GC.Collect();
	}

	private Mesh CreateMesh(int totalVertices)
	{
		if (_clippedPolygons == null)
		{
			return null;
		}
		if (_clippedPolygons.Count <= 0)
		{
			return null;
		}
		if (totalVertices < 3)
		{
			return null;
		}
		int[] array = new int[(totalVertices - 2) * 3];
		Vector3[] array2 = new Vector3[totalVertices];
		Vector3[] array3 = new Vector3[totalVertices];
		Vector2[] array4 = new Vector2[totalVertices];
		Vector4[] array5 = new Vector4[totalVertices];
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		float num4 = 1f / _decalSize.x;
		float num5 = 1f / _decalSize.y;
		foreach (DecalPolygon clippedPolygon in _clippedPolygons)
		{
			for (int i = 0; i < clippedPolygon.VerticeCount; i++)
			{
				ref Vector3 reference = ref array2[num];
				reference = clippedPolygon.Vertice[i];
				ref Vector3 reference2 = ref array3[num];
				reference2 = clippedPolygon.Normal[i];
				ref Vector4 reference3 = ref array5[num];
				reference3 = clippedPolygon.Tangent[i];
				if (i < clippedPolygon.VerticeCount - 2)
				{
					array[num2] = num3;
					array[num2 + 1] = num + 1;
					array[num2 + 2] = num + 2;
					num2 += 3;
				}
				num++;
			}
			num3 = num;
		}
		for (int j = 0; j < array2.Length; j++)
		{
			Vector3 lhs = array2[j] - _decalCenter;
			float num6 = Vector3.Dot(lhs, _decalTangent) * num4;
			float num7 = Vector3.Dot(lhs, _decalBinormal) * num5;
			float num8 = num6 * _uCos - num7 * _vSin + 0.5f;
			float num9 = num6 * _vSin + num7 * _uCos + 0.5f;
			num8 *= Tiling.x;
			num9 *= Tiling.y;
			num8 += Offset.x;
			num9 += Offset.y;
			ref Vector2 reference4 = ref array4[j];
			reference4 = new Vector2(num8, num9);
		}
		Mesh mesh = new Mesh();
		mesh.vertices = array2;
		mesh.normals = array3;
		mesh.triangles = array;
		mesh.uv = array4;
		mesh.uv2 = array4;
		mesh.uv2 = array4;
		mesh.tangents = array5;
		return mesh;
	}

	private int ClipMesh()
	{
		int num = 0;
		if (_clippedPolygons == null)
		{
			_clippedPolygons = new List<DecalPolygon>();
		}
		else
		{
			_clippedPolygons.Clear();
		}
		for (int i = 0; i < _startPolygons.Count; i++)
		{
			DecalPolygon polygon = _startPolygons[i];
			DecalPolygon decalPolygon = DecalPolygon.ClipPolygonAgainstPlane(polygon, _frontPlane);
			if (decalPolygon == null)
			{
				continue;
			}
			decalPolygon = DecalPolygon.ClipPolygonAgainstPlane(decalPolygon, _backPlane);
			if (decalPolygon == null)
			{
				continue;
			}
			decalPolygon = DecalPolygon.ClipPolygonAgainstPlane(decalPolygon, _rightPlane);
			if (decalPolygon == null)
			{
				continue;
			}
			decalPolygon = DecalPolygon.ClipPolygonAgainstPlane(decalPolygon, _leftPlane);
			if (decalPolygon == null)
			{
				continue;
			}
			decalPolygon = DecalPolygon.ClipPolygonAgainstPlane(decalPolygon, _bottomPlane);
			if (decalPolygon != null)
			{
				decalPolygon = DecalPolygon.ClipPolygonAgainstPlane(decalPolygon, _topPlane);
				if (decalPolygon != null)
				{
					num += decalPolygon.VerticeCount;
					_clippedPolygons.Add(decalPolygon);
				}
			}
		}
		return num;
	}
}
