using System;
using System.Collections;
using System.Collections.Generic;
using ClientSocket;
using SceneCameraStruct;
using UnityEngine;

public class BattleMedalPanel : UIBase
{
	public int FixParticleId_Self = 291;

	public Vector3 MedialIconEffectScale = new Vector3(0.65f, 0.65f, 0f);

	public Vector3 MedalEffectPosition = new Vector3(0f, 120f, -20f);

	public float WaitMedalEffectTime = 2.5f;

	public int IntuitionId = 354;

	public int ProficiencyId = 355;

	public Vector3 SkillIconEffectScale = new Vector3(0.65f, 0.65f, 0f);

	public Vector3 SkillEffectPosition = new Vector3(0f, 140f, -20f);

	public GameObject CurrentPlayingMedal;

	public int CurrentLoadMedalIconID;

	public List<int> WaitMedalList;

	public bool IsPlayingEffect;

	public bool OpenTest;

	public bool IsStopPlayEffect;

	public int TestCount = 10;

	public UITexture CurrentLoadMedalIcon;

	public bool BeginLoadingMedalIcon;

	public Vector3 MedialIconStartPosition = new Vector3(300f, 300f, 0f);

	public float MedialIconSpace = -40f;

	public List<UITexture> IconList;

	public UITexture LastTexture;

	public UILabel MedalNameLabel;

	private GameObject intuitionEffect;

	public GameObject IntuitionEffectPrefab;

	public override void Init()
	{
		WaitMedalList = new List<int>();
		IconList = new List<UITexture>();
		MedalDataManager instance = MedalDataManager.GetInstance();
		instance.GetMedalOnBattle = (MedalDataManager.GetMedalOnBattleDelegate)Delegate.Combine(instance.GetMedalOnBattle, new MedalDataManager.GetMedalOnBattleDelegate(GetMedalOnBattle));
		MedalDataManager instance2 = MedalDataManager.GetInstance();
		instance2.StopPlayEffect = (Action)Delegate.Combine(instance2.StopPlayEffect, new Action(StopPlayEffect));
		MedalDataManager.GetInstance().PlaySkillOnBattle += PlaySkillEffectOnBattle;
		MedalDataManager.GetInstance().TankDarkedEvent += OnTankDarked;
		CameraManager.Instance.OnChangeStep += OnCameraChangeStep;
	}

	private void OnDestroy()
	{
		MedalDataManager instance = MedalDataManager.GetInstance();
		instance.GetMedalOnBattle = (MedalDataManager.GetMedalOnBattleDelegate)Delegate.Remove(instance.GetMedalOnBattle, new MedalDataManager.GetMedalOnBattleDelegate(GetMedalOnBattle));
		MedalDataManager instance2 = MedalDataManager.GetInstance();
		instance2.StopPlayEffect = (Action)Delegate.Remove(instance2.StopPlayEffect, new Action(StopPlayEffect));
		MedalDataManager.GetInstance().PlaySkillOnBattle -= PlaySkillEffectOnBattle;
		MedalDataManager.GetInstance().TankDarkedEvent -= OnTankDarked;
		if (CameraManager.Instance != null)
		{
			CameraManager.Instance.OnChangeStep -= OnCameraChangeStep;
		}
	}

	private void OnTankDarked()
	{
		UnityEngine.Object.Destroy(intuitionEffect);
		intuitionEffect = null;
	}

	private void OnCameraChangeStep()
	{
		if (!(intuitionEffect == null))
		{
			OnChangeScreenHandle();
		}
	}

	public void StartIntuition()
	{
		if (!(intuitionEffect != null))
		{
			intuitionEffect = UnityEngine.Object.Instantiate(IntuitionEffectPrefab);
			intuitionEffect.GetComponentInChildren<UILabel>().text = GameManager.TableMgr.GetDirString("intuition_label").value;
			intuitionEffect.transform.SetParent(base.transform.parent.transform);
			OnCameraChangeStep();
		}
	}

	private void OnChangeScreenHandle()
	{
		switch (CameraManager.Instance.CameraState)
		{
		case CameraState.Third:
			intuitionEffect.transform.localPosition = new Vector3(280f, Screen.height / 14 + 12, 1f);
			break;
		case CameraState.First:
			intuitionEffect.transform.localPosition = new Vector3(350f, 121f, 1f);
			break;
		case CameraState.Death:
			OnTankDarked();
			break;
		}
	}

	public void PlayMedalEffect(int medalID)
	{
		if (!BeginLoadingMedalIcon)
		{
			CurrentLoadMedalIconID = medalID;
			BeginLoadingMedalIcon = true;
			if (medalID > 10000)
			{
				LoadAndPlaySkillEffect(medalID - 10000);
			}
			else
			{
				LoadEffectMedalIcon();
			}
		}
		else
		{
			WaitMedalList.Add(medalID);
		}
	}

	public void PlaySkillEffectOnBattle(PK_RC_SkillEffect response)
	{
		if (response.nEffectType == 1)
		{
			StartIntuition();
		}
		else if (response.nEffectType == 2)
		{
			int proficiencyId = ProficiencyId;
			PlayMedalEffect(proficiencyId + 10000);
		}
		else
		{
			TKLog.LogError("Find Error When Attempt to Play the Skill Effect");
		}
	}

	public void GetMedalOnBattle(PK_RC_GetHonor response)
	{
		if (response.GUID == GameManager.Player.PlayerGUID)
		{
			PlayMedalEffect(response.MedalID);
		}
	}

	private void LoadAndPlayEffect(UITexture uiTexture)
	{
		uiTexture.cachedTransform.localPosition = new Vector3(2000f, 2000f, 0f);
		GUITools.PlayParticleOnUi(FixParticleId_Self, base.transform.parent.transform, new Vector3(0f, 80f, 0f), MedialIconEffectScale, Quaternion.identity, destroySelf: true, delegate(UnityEngine.Object r)
		{
			BeginPlayingEffect((GameObject)r);
		});
	}

	private void LoadEffectMedalIcon()
	{
		CurrentLoadMedalIcon = NGUITools.AddWidget<UITexture>(base.gameObject);
		ResourcesManager.Instance.RetrieveUIMaterial(CommonTools.GetIdFormString(GameManager.TableMgr.GetMedal(CurrentLoadMedalIconID).icon_in_battle.ToString()), CurrentLoadMedalIcon, delegate
		{
			LoadAndPlayEffect(CurrentLoadMedalIcon);
		});
	}

	private GameObject LoadAndPlaySkillEffect(int skill_id)
	{
		return GUITools.PlayParticleOnUi(skill_id, base.transform.parent.transform, new Vector3(0f, 80f, 0f), SkillIconEffectScale, Quaternion.identity, destroySelf: true, delegate(UnityEngine.Object r)
		{
			BeginPlayingSkillEffect((GameObject)r);
		});
	}

	private void BeginPlayingSkillEffect(GameObject effect)
	{
		IsPlayingEffect = true;
		UnityEngine.Object.Destroy(CurrentPlayingMedal);
		CurrentPlayingMedal = effect;
		CurrentPlayingMedal.transform.localPosition = SkillEffectPosition;
		UnityEngine.Object.Destroy(CurrentLoadMedalIcon);
	}

	private void BeginPlayingEffect(GameObject effect)
	{
		MedalNameLabel.text = CommonTools.GetDictString(GameManager.TableMgr.GetMedal(CurrentLoadMedalIconID).name_in_battle);
		IsPlayingEffect = true;
		UnityEngine.Object.Destroy(CurrentPlayingMedal);
		CurrentPlayingMedal = effect;
		effect.gameObject.SetActiveRecursively(state: true);
		MedalEffectHelp componentInChildren = effect.GetComponentInChildren<MedalEffectHelp>();
		componentInChildren.UpdateMedalMaterTexture(CurrentLoadMedalIcon.mainTexture);
		CurrentPlayingMedal.transform.localPosition = MedalEffectPosition;
		if (TestHited.Instance != null)
		{
			TestHited.Instance.ShakeCamera(showImageEffect: true, vibration: false);
		}
		UnityEngine.Object.Destroy(CurrentLoadMedalIcon);
	}

	private IEnumerator SetMedalIconAfterEffect(UITexture icon)
	{
		yield return new WaitForSeconds(WaitMedalEffectTime);
		if (LastTexture != null)
		{
			icon.cachedTransform.localPosition = new Vector3(LastTexture.cachedTransform.localPosition.x - icon.cachedTransform.localScale.x - MedialIconSpace, MedialIconStartPosition.y, MedialIconStartPosition.z);
		}
		else
		{
			icon.cachedTransform.localPosition = MedialIconStartPosition;
		}
		LastTexture = icon;
	}

	public void Update()
	{
		if (OpenTest)
		{
			ShowTest();
			OpenTest = false;
		}
		if (IsStopPlayEffect)
		{
			StopPlayEffect();
		}
		if (IsPlayingEffect && !CheckEffectIsPlaying())
		{
			MedalNameLabel.text = string.Empty;
			IsPlayingEffect = false;
			BeginLoadingMedalIcon = false;
			UnityEngine.Object.Destroy(CurrentPlayingMedal);
			PlayNextMedalEffect();
		}
	}

	private void PlayNextMedalEffect()
	{
		if (WaitMedalList != null && WaitMedalList.Count > 0)
		{
			BeginLoadingMedalIcon = false;
			PlayMedalEffect(WaitMedalList[0]);
			WaitMedalList.RemoveAt(0);
		}
	}

	private bool CheckEffectIsPlaying()
	{
		if (CurrentPlayingMedal != null && CurrentPlayingMedal.GetComponentInChildren<Animation>() != null)
		{
			return true;
		}
		return false;
	}

	private void StopPlayEffect()
	{
		if (CurrentPlayingMedal != null)
		{
			NGUITools.SetActive(CurrentPlayingMedal, !IsPlayingEffect);
		}
		NGUITools.SetActive(base.gameObject, !IsPlayingEffect);
		IsPlayingEffect = !IsPlayingEffect;
	}

	private void ShowTest()
	{
		for (int i = 2; i < TestCount; i++)
		{
			PlayMedalEffect(i);
		}
	}
}
