public class BuyCarPort
{
	private string _title;

	private float _goldCoin;

	private string _contex;

	private string _contexForward;

	private string _noMoney;

	private bool flag = true;

	private float carPortMaxNum;

	private string[] btnContex;

	private string okBtn;

	private string cancleBtn;

	public BuyCarPort()
	{
		_title = GameManager.TableMgr.GetDirString("garage_list_buySpace").value;
		_contexForward = GameManager.TableMgr.GetDirString("garage_park_buy_money").value;
		_noMoney = GameManager.TableMgr.GetDirString("10002").value;
		okBtn = GameManager.TableMgr.GetDirString("button_confirmbuy_01").value;
		cancleBtn = GameManager.TableMgr.GetDirString("msg_bt_close").value;
	}

	public void Init(float goldCoin)
	{
		DialogData dialogData = new DialogData();
		dialogData.Add2ButtonList(ButtonStyle.Normal, okBtn, OnSureCallBack);
		dialogData.Add2ButtonList(ButtonStyle.Normal, cancleBtn, OnCancleCallBack);
		dialogData.Contex = _contexForward;
		dialogData.Title = _title;
		dialogData.AddIconValueToTextOnly(CommonIconType.Gold, string.Format(GameManager.TableMgr.GetDirString("tvstyle_gse").value, goldCoin));
		GUITools.IconDialog(BoxStyle.TextOnly, dialogData);
	}

	public void OnSureCallBack()
	{
		int num = 1;
		GameManager.Hall.SendBuyCarPOrt(num);
	}

	public void OnCancleCallBack()
	{
	}

	public void OnNoMoney()
	{
		PayGuidTools.ShowPayGuid(PayGuidType.Gold);
	}

	public void OnCarPortMax()
	{
		GUITools.ShowMessageByConfig("10053");
	}
}
