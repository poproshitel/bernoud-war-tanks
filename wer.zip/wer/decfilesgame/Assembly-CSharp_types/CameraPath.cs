using System.Collections.Generic;
using UnityEngine;

public class CameraPath : MonoBehaviour
{
	public struct PathPnt
	{
		public Vector3 pos;

		public Vector3 dir;

		public Quaternion rot;

		public float spd;
	}

	private int testI;

	private float testF;

	private string myString = "Hello World";

	private bool groupEnabled;

	private bool myBool = true;

	private float myFloat = 1.23f;

	private List<PathPnt> lstPnts;

	private bool bPlaying;

	private float fPlayEllapse;

	private int nPlayCalInd;

	private float fBezierCalPercent;

	private Vector3 vPlayCamPos = Vector3.zero;

	private Quaternion qPlayCamQut = Quaternion.identity;

	private Vector3[] vBezierPntQuadGroup = new Vector3[4];

	private Quaternion[] qBezierPntDirQuadGroup = new Quaternion[4];

	private float addPntEllapse;

	private float delPntEllapse;

	private float playCtrlEllapse;

	private bool _showUI = true;

	private Rect drawPathPntRct = new Rect(450f, 0f, 300f, 22f);

	private void OnGUI()
	{
		if (lstPnts == null)
		{
			lstPnts = new List<PathPnt>();
		}
		if (!bPlaying)
		{
			int count = lstPnts.Count;
			for (int i = 0; i < count; i++)
			{
				drawPathPntRct.y = i * 23 + 10;
				PathPnt pathPnt = lstPnts[i];
				GUI.Box(drawPathPntRct, "pos:" + pathPnt.pos.ToString("f2") + ",dir:" + pathPnt.dir.ToString("f2"));
			}
		}
	}

	private void Start()
	{
	}

	private void Update()
	{
		if (Input.GetKey(KeyCode.H) && Input.GetKeyDown(KeyCode.U))
		{
			UICamera uiCamera = GUITools.GetUiCamera();
			if (uiCamera != null)
			{
				uiCamera.cachedCamera.cullingMask = 0;
			}
			_showUI = false;
		}
		else if (Input.GetKey(KeyCode.S) && Input.GetKeyDown(KeyCode.U))
		{
			UICamera uiCamera2 = GUITools.GetUiCamera();
			if (uiCamera2 != null)
			{
				uiCamera2.cachedCamera.cullingMask = 2048;
			}
			_showUI = true;
		}
		if (bPlaying)
		{
			UpdatePlaying();
			if (Input.GetKey(KeyCode.Space))
			{
				bPlaying = false;
				OnPlayOver();
			}
			return;
		}
		if (CheckAddModDelOper())
		{
		}
		addPntEllapse += 0.03f;
		delPntEllapse += 0.03f;
		CheckPlayControl();
		DebugDraw();
	}

	private void OnEnable()
	{
	}

	public void SceneObj2UI()
	{
		GameObject gameObject = CreateCameraPath();
		if (lstPnts == null)
		{
			lstPnts = new List<PathPnt>();
		}
		List<float> list = new List<float>();
		for (int i = 0; i < lstPnts.Count; i++)
		{
			list.Add(lstPnts[i].spd);
		}
		lstPnts.Clear();
		int childCount = gameObject.transform.GetChildCount();
		for (int j = 0; j < childCount; j++)
		{
			Transform child = gameObject.transform.GetChild(j);
			PathPnt item = default(PathPnt);
			item.pos = child.position;
			item.dir = child.forward;
			item.spd = 0f;
			if (j < list.Count)
			{
				item.spd = list[j];
			}
			lstPnts.Add(item);
		}
	}

	public void UI2SceneObj()
	{
		GameObject gameObject = CreateCameraPath();
		if (lstPnts == null)
		{
			lstPnts = new List<PathPnt>();
		}
		gameObject.transform.DetachChildren();
		int count = lstPnts.Count;
		for (int i = 0; i < count; i++)
		{
			GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
			if (gameObject2.GetComponent<Renderer>() != null)
			{
				gameObject2.GetComponent<Renderer>().enabled = false;
			}
			if (gameObject2.GetComponent<Collider>() != null)
			{
				gameObject2.GetComponent<Collider>().enabled = false;
			}
			gameObject2.transform.parent = gameObject.transform;
			gameObject2.transform.position = lstPnts[i].pos;
		}
	}

	private GameObject CreateCameraPath()
	{
		GameObject gameObject = GameObject.Find("CameraPath");
		if (gameObject != null)
		{
			return gameObject;
		}
		gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
		if (gameObject.GetComponent<Renderer>() != null)
		{
			gameObject.GetComponent<Renderer>().enabled = false;
		}
		if (gameObject.GetComponent<Collider>() != null)
		{
			gameObject.GetComponent<Collider>().enabled = false;
		}
		return gameObject;
	}

	private bool CheckAddModDelOper()
	{
		bool mouseButtonDown = Input.GetMouseButtonDown(2);
		bool keyDown = Input.GetKeyDown(KeyCode.Alpha2);
		bool keyDown2 = Input.GetKeyDown(KeyCode.Alpha3);
		if (!mouseButtonDown && !keyDown && !keyDown2)
		{
			return false;
		}
		if (Input.GetKey(KeyCode.LeftControl) && mouseButtonDown)
		{
			if (lstPnts != null)
			{
				lstPnts.Clear();
			}
			return true;
		}
		Camera main = Camera.main;
		Vector3 position = main.transform.position;
		Vector3 forward = main.transform.forward;
		Quaternion rotation = main.transform.rotation;
		if (mouseButtonDown && addPntEllapse > 0.6f)
		{
			addPntEllapse = 0f;
			OnAddPnt(position, rotation, forward);
			return true;
		}
		if (keyDown)
		{
		}
		if (keyDown2 && delPntEllapse > 0.6f)
		{
			delPntEllapse = 0f;
			return OnDelPnt(position);
		}
		return true;
	}

	private void OnAddPnt(Vector3 p, Quaternion q, Vector3 dir)
	{
		if (lstPnts == null)
		{
			lstPnts = new List<PathPnt>();
		}
		PathPnt item = default(PathPnt);
		item.pos = p;
		item.dir = dir;
		item.rot = q;
		if (lstPnts.Count < 2)
		{
			item.spd = 1f;
		}
		else
		{
			item.spd = lstPnts[lstPnts.Count - 1].spd;
		}
		lstPnts.Add(item);
		Debug.Log("gggggggg");
	}

	private bool OnDelPnt(Vector3 p)
	{
		float num = 0f;
		int num2 = -1;
		int count = lstPnts.Count;
		for (int i = 0; i < count; i++)
		{
			if (i == 0)
			{
				num = (p - lstPnts[i].pos).sqrMagnitude;
				num2 = 0;
				continue;
			}
			float sqrMagnitude = (p - lstPnts[i].pos).sqrMagnitude;
			if (sqrMagnitude < num)
			{
				num = sqrMagnitude;
				num2 = i;
			}
		}
		if (num2 < 0)
		{
			return false;
		}
		return true;
	}

	private void CheckPlayControl()
	{
		playCtrlEllapse += 0.02f;
		if (Input.GetKeyDown(KeyCode.Alpha9))
		{
			Debug.Log("bvvvvv");
			playCtrlEllapse = 0f;
			if (!bPlaying)
			{
				OnPlayBegin();
			}
			bPlaying = !bPlaying;
			fPlayEllapse = 0f;
			nPlayCalInd = 0;
			fBezierCalPercent = 0f;
			CalBezierPntRotGroup(0);
		}
	}

	private void DebugDraw()
	{
		if (lstPnts != null)
		{
			int count = lstPnts.Count;
			for (int i = 0; i < count - 1; i++)
			{
				PathPnt pathPnt = lstPnts[i];
				PathPnt pathPnt2 = lstPnts[i + 1];
				Debug.DrawLine(pathPnt.pos, pathPnt2.pos);
			}
		}
	}

	private void UpdatePlaying()
	{
		int count = lstPnts.Count;
		if (nPlayCalInd < 0 || 2 * nPlayCalInd + 3 >= count - 1)
		{
			bPlaying = false;
			OnPlayOver();
			return;
		}
		fBezierCalPercent += 0.005f;
		if (fBezierCalPercent > 1f)
		{
			nPlayCalInd++;
			fBezierCalPercent = 0f;
			CalBezierPntRotGroup(nPlayCalInd);
			return;
		}
		Vector3 vector = vBezierPntQuadGroup[0] + (vBezierPntQuadGroup[1] - vBezierPntQuadGroup[0]) * fBezierCalPercent;
		Vector3 vector2 = vBezierPntQuadGroup[1] + (vBezierPntQuadGroup[2] - vBezierPntQuadGroup[1]) * fBezierCalPercent;
		Vector3 vector3 = vBezierPntQuadGroup[2] + (vBezierPntQuadGroup[3] - vBezierPntQuadGroup[2]) * fBezierCalPercent;
		Vector3 vector4 = vector + (vector2 - vector) * fBezierCalPercent;
		Vector3 vector5 = vector2 + (vector3 - vector2) * fBezierCalPercent;
		Vector3 position = vector4 + (vector5 - vector4) * fBezierCalPercent;
		float num = 0f;
		Quaternion identity = Quaternion.identity;
		Quaternion identity2 = Quaternion.identity;
		Quaternion identity3 = Quaternion.identity;
		if (fBezierCalPercent < 0.3333f)
		{
			identity = qBezierPntDirQuadGroup[0];
			identity2 = qBezierPntDirQuadGroup[1];
			num = fBezierCalPercent * 3f;
		}
		else if (fBezierCalPercent < 0.6667f)
		{
			identity = qBezierPntDirQuadGroup[1];
			identity2 = qBezierPntDirQuadGroup[2];
			num = (fBezierCalPercent - 0.3333f) * 3f;
		}
		else
		{
			identity = qBezierPntDirQuadGroup[2];
			identity2 = qBezierPntDirQuadGroup[3];
			num = (fBezierCalPercent - 0.6667f) * 3f;
		}
		if (num < 0f)
		{
			num = 0f;
		}
		if (num > 1f)
		{
			num = 1f;
		}
		Camera.main.transform.position = position;
		Camera.main.transform.rotation = Quaternion.Slerp(identity, identity2, num);
	}

	private void CalBezierPntRotGroup(int ind)
	{
		if (ind * 2 + 3 >= lstPnts.Count)
		{
			bPlaying = false;
			OnPlayOver();
		}
		else if (ind == 0)
		{
			ref Vector3 reference = ref vBezierPntQuadGroup[0];
			reference = lstPnts[0].pos;
			ref Quaternion reference2 = ref qBezierPntDirQuadGroup[0];
			reference2 = lstPnts[0].rot;
			ref Vector3 reference3 = ref vBezierPntQuadGroup[1];
			reference3 = lstPnts[1].pos;
			ref Quaternion reference4 = ref qBezierPntDirQuadGroup[1];
			reference4 = lstPnts[1].rot;
			ref Vector3 reference5 = ref vBezierPntQuadGroup[2];
			reference5 = lstPnts[2].pos;
			ref Quaternion reference6 = ref qBezierPntDirQuadGroup[2];
			reference6 = lstPnts[2].rot;
			ref Vector3 reference7 = ref vBezierPntQuadGroup[3];
			reference7 = (lstPnts[2].pos + lstPnts[3].pos) * 0.5f;
			ref Quaternion reference8 = ref qBezierPntDirQuadGroup[3];
			reference8 = Quaternion.Slerp(lstPnts[2].rot, lstPnts[3].rot, 0.5f);
		}
		else
		{
			ref Vector3 reference9 = ref vBezierPntQuadGroup[0];
			reference9 = (lstPnts[ind * 2].pos + lstPnts[ind * 2 + 1].pos) * 0.5f;
			ref Quaternion reference10 = ref qBezierPntDirQuadGroup[0];
			reference10 = Quaternion.Slerp(lstPnts[ind * 2].rot, lstPnts[ind * 2 + 1].rot, 0.5f);
			ref Vector3 reference11 = ref vBezierPntQuadGroup[1];
			reference11 = lstPnts[ind * 2 + 1].pos;
			ref Quaternion reference12 = ref qBezierPntDirQuadGroup[1];
			reference12 = lstPnts[ind * 2 + 1].rot;
			ref Vector3 reference13 = ref vBezierPntQuadGroup[2];
			reference13 = lstPnts[ind * 2 + 2].pos;
			ref Quaternion reference14 = ref qBezierPntDirQuadGroup[2];
			reference14 = lstPnts[ind * 2 + 2].rot;
			ref Vector3 reference15 = ref vBezierPntQuadGroup[3];
			reference15 = (lstPnts[ind * 2 + 2].pos + lstPnts[ind * 2 + 3].pos) * 0.5f;
			ref Quaternion reference16 = ref qBezierPntDirQuadGroup[3];
			reference16 = Quaternion.Slerp(lstPnts[ind * 2 + 2].rot, lstPnts[ind * 2 + 3].rot, 0.5f);
		}
	}

	private void OnPlayBegin()
	{
		CameraManager component = Camera.main.GetComponent<CameraManager>();
		if (component != null)
		{
			component.enabled = false;
		}
	}

	private void OnPlayOver()
	{
		CameraManager component = Camera.main.GetComponent<CameraManager>();
		if (component != null)
		{
			component.enabled = true;
		}
	}
}
