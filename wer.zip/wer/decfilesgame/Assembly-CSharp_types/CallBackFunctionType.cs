public enum CallBackFunctionType
{
	NoParameter,
	OneObject
}
