using System;
using UnityEngine;

public class AttackArrow : MonoBehaviour
{
	public enum AttackOwn
	{
		My,
		Others
	}

	public GameObject ArrowBtn;

	protected Action<int, int> DoBtnCallback;

	protected int TerritoryId;

	protected int AttackTerritoryId;

	protected bool CanArrowBtnDo = true;

	protected const float PositionZ = -10f;

	public const float DistanceOffset = 20f;

	private const string ArrowSpriteWhiteRealLine = "T_Map_White_Arrow";

	private const string ArrowSpriteWhiteBrokeLine = "T_Map_White_Arrow_Broke";

	public UIDragPanelContents UiDragPanelContents;

	private void Awake()
	{
		base.gameObject.tag = "MapArrow";
		UiDragPanelContents = ArrowBtn.AddComponent<UIDragPanelContents>();
	}

	protected void SetAttackArrowImage(string imageName)
	{
		ArrowBtn.transform.GetComponentInChildren<UISprite>().spriteName = imageName;
	}

	protected void SetAttackArrowType(Color arrowColor, ContendMap.ArrowType arrowType)
	{
		UISlicedSprite component = ArrowBtn.GetComponent<UISlicedSprite>();
		component.spriteName = ((arrowType != 0) ? "T_Map_White_Arrow_Broke" : "T_Map_White_Arrow");
		component.color = arrowColor;
		SetArrowBtnBoxColidder(arrowType != ContendMap.ArrowType.RealLine);
	}

	protected void SetHeadEnd(Vector2 head, Vector2 end)
	{
		Vector2 vector = end - head;
		float z = Mathf.Atan2(vector.y, vector.x) * 57.29578f + 90f;
		Vector2 a = (head - end).normalized * 20f;
		a += end;
		Vector2 b = (end - head).normalized * 20f;
		b += head;
		float z2 = ArrowBtn.transform.localEulerAngles.z;
		ArrowBtn.transform.localEulerAngles = new Vector3(0f, 0f, z);
		ArrowBtn.transform.localScale = new Vector3(ArrowBtn.transform.localScale.x, Vector2.Distance(a, b), 1f);
		int num = ((!(a.x + 0.5f > (float)((int)a.x + 1))) ? ((int)a.x) : ((int)a.x + 1));
		int num2 = ((!(a.y + 0.5f > (float)((int)a.y + 1))) ? ((int)a.y) : ((int)a.y + 1));
		ArrowBtn.transform.localPosition = new Vector3(num, num2, 0f);
	}

	private void SetArrowBtnBoxColidder(bool canActive)
	{
		GetComponentInChildren<BoxCollider>().enabled = canActive;
	}
}
