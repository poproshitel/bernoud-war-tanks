using System;
using System.Collections.Generic;
using UnityEngine;

public class BaseNode : MonoBehaviour
{
	public static Action<int> OnShowExpDeduct;

	public static Action OnStopShowExpDeduct;

	public static int PartNameWidth = 80;

	public NodePart TypeOfNode;

	public int TableId;

	public ResearchStage _isResearched = ResearchStage.Invalid;

	public bool _hasBuy;

	public int Price;

	public int Id;

	public UISprite BackGround;

	public UILabel Exp;

	public UILabel Name;

	public UITexture RootSprite;

	public UITexture TankLevel;

	public UISprite Frame;

	public UISprite ExpIcon;

	public UITexture TankRank;

	public UILabel TankName;

	public UISprite IsEquiped;

	public bool BIsEquiped;

	private BoxCollider _myCollider;

	private int _researchExp;

	private int _level;

	private int _tankType;

	private int _tankNation;

	private byte _relegationTank;

	public GameObject Target;

	public string Function;

	public Transform CachedTransform;

	public BaseData Data;

	public Table_Module_research TableData;

	private static int _sTankExp;

	private bool _hasChanged;

	private bool _boughtTankStage;

	public static string TankNameStyle;

	public static string TankValueStyle;

	public static string ModuleNameStyle;

	public static string ModuleValueStyle;

	public static string GoldTankNameStyle;

	private bool _partsInfoOnly;

	private static Vector3 _tankLevelScale = new Vector3(24f, 17f, 0f);

	private static Vector3 _moduleIconScale = new Vector3(43f, 43f, 0f);

	private static Vector3 _moduleButtonPostion = new Vector3(-36f, -5f, -4f);

	private static Vector3 _tankIconScale = new Vector3(108f, 41f, 0f);

	private static Vector3 _tankRankPostion = new Vector3(-54f, 18f, -5f);

	private static Vector3 _tankLevelPostion = new Vector3(-56f, -4f, -5f);

	private static Vector3 _tankNamePostion = new Vector3(51f, 18f, -5f);

	private static Vector3 _tankExpPostion = new Vector3(41f, -13f, -4f);

	private static Vector3 _tankExpIconPostion = new Vector3(55f, -13f, -3f);

	private static Vector3 _rootPanelOffset = new Vector3(12f, 16f, 0f);

	private static Vector3 _tankButtonPostion = new Vector3(-35f, -5f, -7f);

	private EsayImageButto _curButton;

	private Vector3 _scale1 = new Vector3(136f, 82f, 1f);

	private Vector3 _scale2 = new Vector3(43f, 43f, 1f);

	private Vector3 _scale3 = new Vector3(108f, 41f, 1f);

	private Vector3 _addition = new Vector3(14f, 14f, 0f);

	private Vector3 _redFlagAddition = new Vector3(6f, 6f, 0f);

	private Color _researchedColor = new Color(1f, 0f, 0f);

	private Color _invalidColor = new Color(0f, 1f, 0f);

	private Color _availableColor = new Color(0f, 0f, 1f);

	public TankNodeShowStage CurStage;

	public int ShowValue;

	public CommonIconType CurShowIcon;

	public ResearchStruct CurShowNode;

	private Tips _curTips;

	public ResearchStage IsResearched
	{
		get
		{
			return _isResearched;
		}
		set
		{
			_isResearched = value;
		}
	}

	public bool HasBuy
	{
		get
		{
			return _hasBuy;
		}
		set
		{
			_hasBuy = value;
		}
	}

	public int ResearchExp => _researchExp;

	public byte TankId => _relegationTank;

	public TankNodeShowStage CurShowStage
	{
		get
		{
			return CurStage;
		}
		set
		{
			if (CurStage != value)
			{
				_hasChanged = true;
			}
			CurStage = value;
		}
	}

	public bool PartsInfoOnly => _partsInfoOnly;

	public bool IsPartNode => TableData.icontype == ModuleResearchIconType.PartIcon;

	private void Awake()
	{
		CachedTransform = base.transform;
	}

	private void Start()
	{
	}

	public void EasyInit(Table_Module_research node, BaseData data, GameObject parent, int startIndex, bool partsInfoOnly)
	{
		if (node == null || data == null)
		{
			TKLog.LogWarning(string.Concat("node :", node, " data : ", data));
			return;
		}
		_partsInfoOnly = partsInfoOnly;
		Target = parent;
		Function = "OnNodeClickNew";
		TableData = node;
		_relegationTank = (byte)node.vehicle;
		TypeOfNode = data.Typeid;
		_researchExp = node.exp;
		TableId = data.TableId;
		Id = node.id;
		Data = data;
		base.gameObject.name = data.Typeid.ToString() + "_" + data.TableId;
		CheckResearchStage(TableData, data);
		if (data.Typeid == NodePart.Vehicle)
		{
			CheckBoughtHistory(TableId);
		}
		ShowView();
		InitCollider();
		ToolTipsListen toolTipsListen = base.gameObject.AddComponent<ToolTipsListen>();
		toolTipsListen.IncludeClild = true;
		if (!_boughtTankStage || _curButton != null)
		{
		}
		if (_curButton != null)
		{
			_curButton.IncludeChild = true;
		}
	}

	public void CheckBoughtHistory(int id)
	{
		if (CurShowStage == TankNodeShowStage.HaveNotBuyEnoughMoney || CurShowStage == TankNodeShowStage.HaveNotBuyNoMoney)
		{
			_boughtTankStage = Singleton<AccountProfilesManager>.Instance.PersonalVehicleHasBattleHistory(id);
		}
	}

	private void ShowView()
	{
		TankLevel.cachedTransform.localScale = _tankLevelScale;
		int level;
		if (TableData.icontype == ModuleResearchIconType.TankBigIcon || TableData.icontype == ModuleResearchIconType.TankSmallIcon)
		{
			if (CurStage == TankNodeShowStage.HaveInDepot)
			{
				ExpIcon.spriteName = UiConst.TankExpIconSmall;
			}
			else
			{
				ExpIcon.spriteName = UiConst.GlobleExpIconSmall;
			}
			TankBaseData tankBaseData = (TankBaseData)Data;
			IsEquiped.spriteName = UiConst.ResearchTankEquiped;
			IsEquiped.MakePixelPerfect();
			NGUITools.SetActive(Name.gameObject, state: false);
			NGUITools.SetActive(TankName.gameObject, state: true);
			NGUITools.SetActive(TankRank.gameObject, state: true);
			if (tankBaseData.Currency == 2)
			{
				Frame.spriteName = UiConst.GoldResearchFrame;
				TankName.text = string.Format(GoldTankNameStyle, GameManager.TableMgr.GetDirString(Data.PartName).value);
			}
			else
			{
				Frame.spriteName = UiConst.ResearchFrameGreen3;
				TankName.text = string.Format(TankNameStyle, GameManager.TableMgr.GetDirString(Data.PartName).value);
			}
			Frame.MakePixelPerfect();
			TankName.cachedTransform.localPosition = _tankNamePostion;
			Exp.text = string.Format(TankValueStyle, ShowValue);
			Exp.cachedTransform.localPosition = _tankExpPostion;
			ExpIcon.cachedTransform.localPosition = _tankExpIconPostion;
			int num = 0;
			num = ((tankBaseData.TankType > 5 || tankBaseData.TankType < 1) ? 1 : tankBaseData.TankType);
			TankRank.cachedTransform.localPosition = _tankRankPostion;
			Table_Vehicle vehicle = GameManager.TableMgr.GetVehicle(tankBaseData.TableId);
			if (vehicle == null)
			{
				TKLog.LogError("Can't find Table_Vehicle where id = " + tankBaseData.TableId);
			}
			bool flag = vehicle.currency == 2;
			ResourcesManager.Instance.RetrieveUIMaterial(TextureAsset.GetTankTypeTextureId(num, flag, CrewManager.IsEliteTank(vehicle.id) || flag), TankRank);
			level = Mathf.Clamp(tankBaseData.TankLevel, 1, GameManager.TableMgr.MaxVehicleLevel);
			TankLevel.cachedTransform.localPosition = _tankLevelPostion;
			TankLevel.cachedTransform.localScale = _tankLevelScale;
			ResourcesManager.Instance.RetrieveUIMaterial(TextureAsset.GetLevelTextureId(level), TankLevel);
			RootSprite.cachedTransform.localScale = _tankIconScale;
			if (TableData.icontype == ModuleResearchIconType.TankBigIcon)
			{
				CachedTransform.localPosition += _rootPanelOffset;
			}
			if (CurShowStage == TankNodeShowStage.Invalid)
			{
				BackGround.spriteName = UiConst.ResearchTankBackGroundGrey;
				BackGround.MakePixelPerfect();
				NGUITools.SetActive(Exp.gameObject, state: true);
				NGUITools.SetActive(ExpIcon.gameObject, state: true);
				ResourcesManager.Instance.RetrieveUIMaterial(CommonTools.GetIdFormString(TableData.icon), RootSprite, delegate
				{
					IconComplete();
				});
				ChangeAlpha(UiConst.ResearchNodeGreyAlpha);
				return;
			}
			if (tankBaseData.Currency == 2)
			{
				BackGround.spriteName = UiConst.GoldResearchBg2;
				TankRank.color = UiConst.GoldTankRankLevelColor;
				TankLevel.color = UiConst.GoldTankRankLevelColor;
			}
			else
			{
				BackGround.spriteName = UiConst.ResearchTankBackGroundNormal;
			}
			BackGround.MakePixelPerfect();
			ChangeAlpha(UiConst.ResearchNodeNormalAlpha);
			if (TableData.icontype == ModuleResearchIconType.TankBigIcon || TableData.icontype == ModuleResearchIconType.TankSmallIcon)
			{
				if (GameManager.Player.TryGetHallTank(Data.TableId, out var tank))
				{
					if (tank.TankData.ModificationId != 0)
					{
						Table_Tank_transform tankTransform = GameManager.TableMgr.GetTankTransform(tank.TankData.ModificationId);
						ResourcesManager.Instance.RetrieveUIMaterial(CommonTools.GetIdFormString(tankTransform.small_icon), RootSprite);
					}
					else
					{
						ResourcesManager.Instance.RetrieveUIMaterial(CommonTools.GetIdFormString(TableData.icon), RootSprite);
					}
				}
				else
				{
					ResourcesManager.Instance.RetrieveUIMaterial(CommonTools.GetIdFormString(TableData.icon), RootSprite);
				}
			}
			if (CurShowStage == TankNodeShowStage.HaveInDepot)
			{
				NGUITools.SetActive(Exp.gameObject, state: true);
				NGUITools.SetActive(ExpIcon.gameObject, state: true);
			}
			else if (CurShowStage == TankNodeShowStage.Available)
			{
				_curButton = GUITools.CreateEasyButton(base.gameObject, base.gameObject, string.Format(TankValueStyle, ShowValue), ButtonStyle.ModuleResearchExp, _tankButtonPostion, "ModuleOperator", CurShowStage, 5);
			}
			else if (CurShowStage == TankNodeShowStage.NotEnoughExp)
			{
				_curButton = GUITools.CreateEasyButton(base.gameObject, base.gameObject, string.Format(TankValueStyle, ShowValue), ButtonStyle.BaseNodeNotEnoughExp, _tankButtonPostion, "ModuleOperator", CurShowStage, 5);
			}
			else if (CurShowStage == TankNodeShowStage.HaveNotBuyEnoughMoney)
			{
				if (tankBaseData.Currency == 2)
				{
					_curButton = GUITools.CreateEasyButton(base.gameObject, base.gameObject, string.Format(TankValueStyle, ShowValue), ButtonStyle.ModuleResearchGold, _tankButtonPostion, "ModuleOperator", CurShowStage, 5);
				}
				else
				{
					_curButton = GUITools.CreateEasyButton(base.gameObject, base.gameObject, string.Format(TankValueStyle, ShowValue), ButtonStyle.ModuleResearchSilver, _tankButtonPostion, "ModuleOperator", CurShowStage, 5);
				}
			}
			else if (CurShowStage == TankNodeShowStage.HaveNotBuyNoMoney)
			{
				if (tankBaseData.Currency == 2)
				{
					_curButton = GUITools.CreateEasyButton(base.gameObject, base.gameObject, string.Format(TankValueStyle, ShowValue), ButtonStyle.BaseNodeNotEnoughGold, _tankButtonPostion, "ModuleOperator", CurShowStage, 5);
				}
				else
				{
					_curButton = GUITools.CreateEasyButton(base.gameObject, base.gameObject, string.Format(TankValueStyle, ShowValue), ButtonStyle.BaseNodeNotEnoughMoney, _tankButtonPostion, "ModuleOperator", CurShowStage, 5);
				}
			}
			return;
		}
		RootSprite.cachedTransform.localScale = _moduleIconScale;
		NGUITools.SetActive(TankName.gameObject, state: false);
		NGUITools.SetActive(TankRank.gameObject, state: false);
		PartBaseData partBaseData = (PartBaseData)Data;
		Name.text = string.Format(ModuleNameStyle, GameManager.TableMgr.GetDirString(Data.PartName).value);
		GUITools.FitUilabelWithLineWidth(Name, PartNameWidth);
		level = CommonTools.GetIntByName(partBaseData.Table, "level");
		level = Mathf.Clamp(level, 1, GameManager.TableMgr.MaxVehicleLevel);
		ResourcesManager.Instance.RetrieveUIMaterial(TextureAsset.GetLevelTextureId(level), TankLevel);
		Frame.spriteName = UiConst.ResearchFrameGrey2;
		Frame.MakePixelPerfect();
		if (CurShowStage == TankNodeShowStage.Invalid)
		{
			BackGround.spriteName = UiConst.ResearchModuleBackGroundGrey;
			NGUITools.SetActive(Exp.gameObject, state: true);
			Exp.text = string.Format(ModuleValueStyle, CurShowNode.Exp);
			NGUITools.SetActive(ExpIcon.gameObject, state: true);
			ResourcesManager.Instance.RetrieveUIMaterial(CommonTools.GetIdFormString(TableData.icon), RootSprite, delegate
			{
				IconComplete();
			});
			ChangeAlpha(UiConst.ResearchNodeGreyAlpha);
			return;
		}
		if (CurShowStage == TankNodeShowStage.UnreDeOnUnreTank)
		{
			BackGround.spriteName = UiConst.ResearchModuleBackGroundGrey;
			NGUITools.SetActive(Exp.gameObject, state: false);
			NGUITools.SetActive(ExpIcon.gameObject, state: false);
			ResourcesManager.Instance.RetrieveUIMaterial(CommonTools.GetIdFormString(TableData.icon), RootSprite, delegate
			{
				IconComplete();
			});
			ChangeAlpha(UiConst.ResearchNodeGreyAlpha);
			return;
		}
		if (CurShowStage == TankNodeShowStage.UnreUndeOnUnreTank)
		{
			BackGround.spriteName = UiConst.ResearchModuleBackGroundGrey;
			NGUITools.SetActive(Exp.gameObject, state: true);
			Exp.text = string.Format(ModuleValueStyle, CurShowNode.Exp);
			NGUITools.SetActive(ExpIcon.gameObject, state: true);
			ResourcesManager.Instance.RetrieveUIMaterial(CommonTools.GetIdFormString(TableData.icon), RootSprite, delegate
			{
				IconComplete();
			});
			ChangeAlpha(UiConst.ResearchNodeGreyAlpha);
			return;
		}
		if (CurShowStage == TankNodeShowStage.ReOnReOnReTank || CurShowStage == TankNodeShowStage.ReUndeOnUnreTank)
		{
			BackGround.spriteName = UiConst.ResearchModuleSpecialNormal;
			NGUITools.SetActive(Exp.gameObject, state: true);
			NGUITools.SetActive(Exp.gameObject, state: false);
			NGUITools.SetActive(ExpIcon.gameObject, state: false);
			ResourcesManager.Instance.RetrieveUIMaterial(CommonTools.GetIdFormString(TableData.icon), RootSprite);
			return;
		}
		NGUITools.SetActive(Exp.gameObject, state: false);
		NGUITools.SetActive(ExpIcon.gameObject, state: false);
		ResourcesManager.Instance.RetrieveUIMaterial(CommonTools.GetIdFormString(TableData.icon), RootSprite);
		if (CurShowStage != TankNodeShowStage.HaveInDeportNotQqu)
		{
			if (CurShowStage == TankNodeShowStage.Equiped)
			{
				BIsEquiped = true;
				Frame.spriteName = UiConst.ResearchFrameEquiped;
				Frame.MakePixelPerfect();
			}
			else if (CurShowStage == TankNodeShowStage.Available && !_partsInfoOnly)
			{
				_curButton = GUITools.CreateEasyButton(base.gameObject, base.gameObject, string.Format(ModuleValueStyle, CurShowNode.Exp), ButtonStyle.ModuleResearchExp, _moduleButtonPostion, "ModuleOperator", CurShowStage, 5);
			}
			else if (CurShowStage == TankNodeShowStage.NotEnoughExp && !_partsInfoOnly)
			{
				_curButton = GUITools.CreateEasyButton(base.gameObject, base.gameObject, string.Format(ModuleValueStyle, CurShowNode.Exp), ButtonStyle.BaseNodeNotEnoughExp, _moduleButtonPostion, "ModuleOperator", CurShowStage, 5);
			}
			else if (CurShowStage == TankNodeShowStage.HaveNotBuyEnoughMoney && !_partsInfoOnly)
			{
				_curButton = GUITools.CreateEasyButton(base.gameObject, base.gameObject, string.Format(ModuleValueStyle, ShowValue), ButtonStyle.ModuleResearchSilver, _moduleButtonPostion, "ModuleOperator", CurShowStage, 5);
			}
			else if (CurShowStage == TankNodeShowStage.HaveNotBuyNoMoney && !_partsInfoOnly)
			{
				_curButton = GUITools.CreateEasyButton(base.gameObject, base.gameObject, string.Format(ModuleValueStyle, ShowValue), ButtonStyle.BaseNodeNotEnoughMoney, _moduleButtonPostion, "ModuleOperator", CurShowStage, 5);
			}
			else if (CurShowStage != TankNodeShowStage.ReDeOnUnreTank && CurShowStage != TankNodeShowStage.ReUndeOnUnreTank)
			{
			}
		}
	}

	private void ModuleOperator(EsayImageButto button)
	{
		switch ((TankNodeShowStage)button.Flag)
		{
		case TankNodeShowStage.Available:
		case TankNodeShowStage.HaveNotBuyEnoughMoney:
			HallGuiManager.Instance.Get<SciencePanelMainUi>().ModuleOperator(this);
			break;
		case TankNodeShowStage.HaveNotBuyNoMoney:
			if (Data.Currency == 2)
			{
				PayGuidTools.ShowPayGuid(PayGuidType.Gold);
			}
			else
			{
				PayGuidTools.ShowPayGuid(PayGuidType.Silver);
			}
			break;
		case TankNodeShowStage.NotEnoughExp:
			PayGuidTools.ShowPayGuid(PayGuidType.Exp);
			break;
		}
	}

	private void IconComplete()
	{
		ResearchStatic.MakeUITextureGery(RootSprite, stage: true);
	}

	private void InitCollider()
	{
		_myCollider = GetComponent<BoxCollider>();
		if (_myCollider == null)
		{
			_myCollider = base.gameObject.AddComponent<BoxCollider>();
		}
		if (RootSprite != null)
		{
			_myCollider.size = RootSprite.transform.localScale;
			_myCollider.center = RootSprite.transform.localPosition;
		}
	}

	public void OnClick()
	{
		if (base.enabled && Input.GetMouseButtonUp(0) && !string.IsNullOrEmpty(Function) && Target != null)
		{
			Target.SendMessage(Function, this, SendMessageOptions.DontRequireReceiver);
		}
	}

	private void CheckResearchStage(Table_Module_research tableData, BaseData data)
	{
		TankBaseData tankBaseData = (TankBaseData)GameManager.UiDataCache.TankResearchData.GetData(NodePart.Vehicle, tableData.vehicle);
		if (tableData.icontype == ModuleResearchIconType.TankBigIcon)
		{
			int techIdByTankId = ResearchStatic.GetTechIdByTankId(data.TableId);
			if (techIdByTankId >= 0)
			{
				Table_Techtree_ussr techTree = GameManager.TableMgr.GetTechTree(techIdByTankId);
				CheckNodeStage(techTree, (TankBaseData)data);
			}
		}
		else if (tableData.icontype == ModuleResearchIconType.PartIcon)
		{
			ResearchStruct reStu2;
			if (tankBaseData.Count > 0)
			{
				ResearchStruct reStu;
				if (ResearchStatic.CheckModuleQquiped(tankBaseData.TableId, data.Typeid, data.TableId))
				{
					CurShowStage = TankNodeShowStage.Equiped;
				}
				else if (data.Count > 0)
				{
					CurShowStage = TankNodeShowStage.HaveInDeportNotQqu;
				}
				else if (data.IsResearched)
				{
					if (data.Currency == 1)
					{
						ShowValue = data.Price;
						CurShowIcon = CommonIconType.Silver;
						if (GameManager.Player.GameMoney >= data.Price)
						{
							CurShowStage = TankNodeShowStage.HaveNotBuyEnoughMoney;
						}
						else
						{
							CurShowStage = TankNodeShowStage.HaveNotBuyNoMoney;
						}
					}
					else
					{
						ShowValue = data.Price;
						CurShowIcon = CommonIconType.Gold;
						if (GameManager.Player.GoldMoney >= data.Price)
						{
							CurShowStage = TankNodeShowStage.HaveNotBuyEnoughMoney;
						}
						else
						{
							CurShowStage = TankNodeShowStage.HaveNotBuyNoMoney;
						}
					}
				}
				else if (ResearchStatic.GetModuleStage(tankBaseData.TableId, data.Typeid, data.TableId, out reStu))
				{
					CurShowNode = reStu;
					CurShowStage = reStu.Stage;
					CurShowIcon = CommonIconType.Exp;
					ShowValue = reStu.Exp;
				}
				else
				{
					CurShowStage = TankNodeShowStage.Error;
				}
			}
			else if (ResearchStatic.GetModuleStage(tankBaseData.TableId, data.Typeid, data.TableId, out reStu2))
			{
				if ((reStu2.Stage == TankNodeShowStage.Available || reStu2.Stage == TankNodeShowStage.NotEnoughExp) && data.IsResearched)
				{
					reStu2.Stage = TankNodeShowStage.ReOnReOnReTank;
				}
				CurShowNode = reStu2;
				CurShowStage = reStu2.Stage;
				CurShowIcon = CommonIconType.Exp;
				ShowValue = reStu2.Exp;
			}
			else
			{
				CurShowStage = TankNodeShowStage.Error;
			}
		}
		else
		{
			if (tableData.icontype != ModuleResearchIconType.TankSmallIcon)
			{
				return;
			}
			TankBaseData tankBaseData2 = (TankBaseData)data;
			ResearchStruct reStu3;
			if (data.Count > 0)
			{
				CurShowStage = TankNodeShowStage.HaveInDepot;
				CurShowIcon = CommonIconType.Exp;
				ShowValue = tankBaseData2.TankExp;
			}
			else if (data.IsResearched)
			{
				if (data.Currency == 1)
				{
					ShowValue = ShopTools.GetItemPrice(data);
					CurShowIcon = CommonIconType.Silver;
					if (GameManager.Player.GameMoney >= ShowValue)
					{
						CurShowStage = TankNodeShowStage.HaveNotBuyEnoughMoney;
					}
					else
					{
						CurShowStage = TankNodeShowStage.HaveNotBuyNoMoney;
					}
				}
				else
				{
					ShowValue = ShopTools.GetItemPrice(tankBaseData2);
					CurShowIcon = CommonIconType.Gold;
					if (GameManager.Player.GoldMoney >= ShowValue)
					{
						CurShowStage = TankNodeShowStage.HaveNotBuyEnoughMoney;
					}
					else
					{
						CurShowStage = TankNodeShowStage.HaveNotBuyNoMoney;
					}
				}
			}
			else if (ResearchStatic.GetModuleStage(tankBaseData.TableId, data.Typeid, data.TableId, out reStu3))
			{
				CurShowNode = reStu3;
				CurShowStage = reStu3.Stage;
				CurShowIcon = CommonIconType.Exp;
				ShowValue = reStu3.Exp;
			}
			else
			{
				CurShowStage = TankNodeShowStage.Error;
			}
		}
	}

	public void CheckNodeStage(Table_Techtree_ussr node, TankBaseData data)
	{
		if (data.TableId == 40)
		{
			int num = 10;
		}
		if (data.Count > 0)
		{
			CurShowStage = TankNodeShowStage.HaveInDepot;
			ShowValue = data.TankExp;
			CurShowIcon = CommonIconType.Exp;
			return;
		}
		if (data.IsResearched)
		{
			if (data.Currency == 1)
			{
				int itemPrice = ShopTools.GetItemPrice(data);
				CurShowStage = ((GameManager.Player.GameMoney < itemPrice) ? TankNodeShowStage.HaveNotBuyNoMoney : TankNodeShowStage.HaveNotBuyEnoughMoney);
				CurShowIcon = CommonIconType.Silver;
				ShowValue = itemPrice;
			}
			else if (data.Currency == 2)
			{
				int itemPrice2 = ShopTools.GetItemPrice(data);
				CurShowStage = ((GameManager.Player.GoldMoney < itemPrice2) ? TankNodeShowStage.HaveNotBuyNoMoney : TankNodeShowStage.HaveNotBuyEnoughMoney);
				CurShowIcon = CommonIconType.Gold;
				ShowValue = itemPrice2;
			}
			else
			{
				CurShowStage = TankNodeShowStage.Error;
			}
			return;
		}
		List<ResearchStruct> list = new List<ResearchStruct>();
		if (data.TableId == 40)
		{
			int num2 = 100;
		}
		bool flag = false;
		int num3 = 1;
		int intByName = CommonTools.GetIntByName(node, UiConst.TankResearchTableParent + num3);
		if (intByName <= 0)
		{
			flag = true;
		}
		while (intByName > 0 && num3 < 6)
		{
			Table_Techtree_ussr techTree = GameManager.TableMgr.GetTechTree(intByName);
			string text = (byte)100 + "_" + techTree.vehicleID;
			BaseData data2 = TankTechData.Instance.GetData(text);
			if (data2 == null)
			{
				TKLog.LogWarning("can't find " + text);
				num3++;
				intByName = CommonTools.GetIntByName(node, UiConst.TankResearchTableParent + num3);
				continue;
			}
			if (ResearchStatic.GetModuleStage(techTree.vehicleID, NodePart.Vehicle, data.TableId, out var reStu))
			{
				list.Add(reStu);
				num3++;
				intByName = CommonTools.GetIntByName(node, UiConst.TankResearchTableParent + num3);
				continue;
			}
			CurShowStage = TankNodeShowStage.Error;
			return;
		}
		if (list.Count == 0)
		{
			CurStage = TankNodeShowStage.Available;
			CurShowIcon = CommonIconType.Exp;
			ShowValue = TableData.exp;
			CurShowNode.Exp = TableData.exp;
			CurShowNode.Stage = TankNodeShowStage.Available;
			CurShowNode.TankId = Data.TableId;
			return;
		}
		int num4 = 0;
		int num5 = 0;
		int num6 = 0;
		int num7 = int.MinValue;
		int num8 = int.MinValue;
		int index = -1;
		int index2 = -1;
		int num9 = 0;
		int num10 = 0;
		int index3 = -1;
		int index4 = -1;
		int num11 = int.MaxValue;
		int num12 = int.MinValue;
		for (int i = 0; i < list.Count; i++)
		{
			ResearchStruct researchStruct = list[i];
			if (researchStruct.Stage == TankNodeShowStage.Invalid)
			{
				num4++;
				if (num7 < researchStruct.Exp)
				{
					index = i;
					num7 = researchStruct.Exp;
				}
			}
			else if (researchStruct.Stage == TankNodeShowStage.NotEnoughExp)
			{
				num6++;
				if (num8 < researchStruct.DelateExp)
				{
					index2 = i;
					num8 = researchStruct.DelateExp;
				}
			}
			else
			{
				if (researchStruct.Stage != TankNodeShowStage.Available)
				{
					continue;
				}
				num5++;
				if (researchStruct.TankExp >= researchStruct.Exp)
				{
					num9++;
					if (num11 > researchStruct.Exp)
					{
						index3 = i;
						num11 = researchStruct.Exp;
					}
				}
				else
				{
					num10++;
					if (num12 < researchStruct.DelateExp)
					{
						index4 = i;
						num12 = researchStruct.DelateExp;
					}
				}
			}
		}
		if (num5 != 0)
		{
			if (num9 > 0)
			{
				CurShowNode = list[index3];
			}
			else
			{
				CurShowNode = list[index4];
			}
			CurShowStage = TankNodeShowStage.Available;
			ShowValue = CurShowNode.Exp;
			CurShowIcon = CommonIconType.Exp;
		}
		else if (num6 > 0)
		{
			CurShowNode = list[index2];
			CurShowStage = TankNodeShowStage.NotEnoughExp;
			CurShowIcon = CommonIconType.Exp;
			ShowValue = CurShowNode.Exp;
		}
		else
		{
			CurShowNode = list[index];
			CurShowStage = TankNodeShowStage.Invalid;
			CurShowIcon = CommonIconType.Exp;
			ShowValue = CurShowNode.Exp;
		}
	}

	private void TooolTipsXXX(bool value)
	{
		if (value)
		{
			if (Tips.Instance != null)
			{
				UnityEngine.Object.Destroy(Tips.Instance.gameObject);
			}
			TipsData content = ((TableData.node_id != 1) ? ResearchStatic.GetTipdata(TankId, Data, TableData.exp, showCostExp: true, CurStage) : ResearchStatic.GetTipdata(TankId, Data, TableData.exp, showCostExp: false, CurStage));
			if ((CurShowStage == TankNodeShowStage.NotEnoughExp || CurShowStage == TankNodeShowStage.Available) && OnShowExpDeduct != null)
			{
				OnShowExpDeduct(ShowValue);
			}
			_curTips = GUITools.AddTips(UITipStyle.NewAttribute, content);
			if (_boughtTankStage && !(_curButton != null))
			{
			}
		}
		else
		{
			if (OnStopShowExpDeduct != null)
			{
				OnStopShowExpDeduct();
			}
			if (_curTips != null)
			{
				UnityEngine.Object.Destroy(_curTips.gameObject);
				_curTips = null;
			}
			if (_boughtTankStage && !(_curButton != null))
			{
			}
		}
	}

	private void OnApplicationFocus(bool value)
	{
		if (_boughtTankStage && !(_curButton != null))
		{
		}
	}

	private void ChangeAlpha(float value)
	{
		TankName.alpha = value;
		Name.alpha = value;
		ExpIcon.alpha = value;
		if (TankRank != null)
		{
			TankRank.alpha = value;
		}
		if (TankLevel != null)
		{
			TankLevel.alpha = value;
		}
		Exp.alpha = value;
	}
}
