public struct AttributeStruct
{
	public byte AttrKind;

	public float AttrValue;
}
