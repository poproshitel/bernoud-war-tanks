using System;

[Serializable]
public class BattleEndData : BaseMessage
{
	public bool Prepare2Show;

	public int Money;

	public int Exp;

	public byte State;

	public byte Result;

	public TankBattleEndInfo MyBattleEndInfo;

	public byte Destroycount;

	public PlayerBattleEndInfo[] MyDestroySomeBodyArr;

	public BattleEndData(bool prepare2Show, int money, int exp, byte state, byte result, ref TankBattleEndInfo myBattleEndInfo, byte destroycount, ref PlayerBattleEndInfo[] hitTankList)
	{
		Type = MessageType.BattleEndMessage;
		Prepare2Show = prepare2Show;
		Money = money;
		Exp = exp;
		State = state;
		Result = result;
		MyBattleEndInfo = myBattleEndInfo;
		Destroycount = destroycount;
		if (Destroycount > 0 && hitTankList.Length == destroycount)
		{
			MyDestroySomeBodyArr = new PlayerBattleEndInfo[destroycount];
			hitTankList = new PlayerBattleEndInfo[destroycount];
			for (int i = 0; i < Destroycount; i++)
			{
				MyDestroySomeBodyArr[i].playerName = hitTankList[i].playerName;
				MyDestroySomeBodyArr[i].tankId = hitTankList[i].tankId;
				MyDestroySomeBodyArr[i].damageCount = hitTankList[i].damageCount;
				MyDestroySomeBodyArr[i].destroyModuleCount = hitTankList[i].destroyModuleCount;
				MyDestroySomeBodyArr[i].killOrDamage = hitTankList[i].killOrDamage;
			}
		}
	}
}
