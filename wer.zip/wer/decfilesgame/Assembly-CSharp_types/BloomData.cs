using System;
using UnityEngine;

[Serializable]
public class BloomData
{
	public bool Enabled;

	public TweakMode34 TweakMode;

	public BloomScreenBlendMode ScreenBlendMode;

	public HDRBloomMode Hdr;

	public float SepBlurSpread;

	public float UseSrcAlphaAsMask;

	public float BloomIntensity;

	public float BloomThreshhold;

	public int BloomBlurIterations;

	public bool Lensflares;

	public int HollywoodFlareBlurIterations;

	public LensflareStyle34 LensflareMode;

	public float HollyStretchWidth;

	public float LensflareIntensity;

	public float LensflareThreshhold;

	public Color FlareColorA;

	public Color FlareColorB;

	public Color FlareColorC;

	public Color FlareColorD;

	public float BlurWidth;

	public Texture2D LensFlareVignetteMask;

	public BloomData()
	{
		Enabled = false;
	}

	public BloomData(BloomAndLensFlares bloom)
	{
		Enabled = bloom.enabled;
		TweakMode = bloom.tweakMode;
		ScreenBlendMode = bloom.screenBlendMode;
		Hdr = bloom.hdr;
		SepBlurSpread = bloom.sepBlurSpread;
		UseSrcAlphaAsMask = bloom.useSrcAlphaAsMask;
		BloomIntensity = bloom.bloomIntensity;
		BloomThreshhold = bloom.bloomThreshhold;
		BloomBlurIterations = bloom.bloomBlurIterations;
		Lensflares = bloom.lensflares;
		HollywoodFlareBlurIterations = bloom.hollywoodFlareBlurIterations;
		LensflareMode = bloom.lensflareMode;
		HollyStretchWidth = bloom.hollyStretchWidth;
		LensflareIntensity = bloom.lensflareIntensity;
		LensflareThreshhold = bloom.lensflareThreshhold;
		FlareColorA = bloom.flareColorA;
		FlareColorB = bloom.flareColorB;
		FlareColorC = bloom.flareColorC;
		FlareColorD = bloom.flareColorD;
		BlurWidth = bloom.blurWidth;
		LensFlareVignetteMask = bloom.lensFlareVignetteMask;
	}

	public void CopyTo(BloomAndLensFlares bloom)
	{
		bloom.tweakMode = TweakMode;
		bloom.screenBlendMode = ScreenBlendMode;
		bloom.hdr = Hdr;
		bloom.sepBlurSpread = SepBlurSpread;
		bloom.useSrcAlphaAsMask = UseSrcAlphaAsMask;
		bloom.bloomIntensity = BloomIntensity;
		bloom.bloomThreshhold = BloomThreshhold;
		bloom.bloomBlurIterations = BloomBlurIterations;
		bloom.lensflares = Lensflares;
		bloom.hollywoodFlareBlurIterations = HollywoodFlareBlurIterations;
		bloom.lensflareMode = LensflareMode;
		bloom.hollyStretchWidth = HollyStretchWidth;
		bloom.lensflareIntensity = LensflareIntensity;
		bloom.lensflareThreshhold = LensflareThreshhold;
		bloom.flareColorA = FlareColorA;
		bloom.flareColorB = FlareColorB;
		bloom.flareColorC = FlareColorC;
		bloom.flareColorD = FlareColorD;
		bloom.blurWidth = BlurWidth;
		bloom.lensFlareVignetteMask = LensFlareVignetteMask;
		bloom.enabled = Enabled;
	}
}
