using System;
using TK;
using UnityEngine;

public class CamFirstModel : MonoBehaviour
{
	private Vector3 _uiPosition;

	private Transform _transform;

	private float _maxAmmoDistance;

	public float _limitUp;

	private float _limitDown;

	private float[] _firstSteps;

	private int _curStep = 2;

	private float _limitLeft;

	private float _limitRight;

	private float _curYaw;

	private float _curPitch;

	private Camera camera;

	public RaycastHit ShootPoint;

	[SerializeField]
	private float RotateSpeedScale = 1f;

	private int _needIgnoreAxis;

	public float LimitDown => SceneRoom.Instance.GetMainPlayer().TankStateSync.GunSync.GunSyncData.LimitDown;

	public Transform CurTurret => SceneRoom.Instance.GetMainPlayer().TankStateSync.TurretSync.Trans;

	public Transform CurGun => SceneRoom.Instance.GetMainPlayer().TankStateSync.GunSync.Trans;

	public float MaxAmmoDistance
	{
		set
		{
			_maxAmmoDistance = value;
		}
	}

	public CameraManager CameraManager => CameraManager.Instance;

	public int CurStep => _curStep;

	public event Action ChangeStepEvent;

	public void Init()
	{
		camera = Camera.main;
		_limitLeft = Mathf.Abs(SceneRoom.Instance.GetMainPlayer().TankData.TableTurret.angle_left);
		_limitRight = Mathf.Abs(SceneRoom.Instance.GetMainPlayer().TankData.TableTurret.angle_right);
		_transform = base.transform;
		InitFirstSteps();
		RotateSpeedScale = 1f;
	}

	public void UpdateFistModel()
	{
		if (base.enabled)
		{
			SightMove();
			_uiPosition = CameraManager.UIPosition;
			CamMove();
			ShootPoint = FirstGetShotPoint();
		}
	}

	private RaycastHit FirstGetShotPoint()
	{
		Ray ray = camera.ScreenPointToRay(_uiPosition);
		return TankTools.CalCameraOrGunHit(ray.origin, ray.direction, _maxAmmoDistance, RaycastType.Camera);
	}

	private void SightMove()
	{
		float mouseStandardSpecial = InputManager.MouseStandardSpecial;
		float mouseVerticalSpecial = InputManager.MouseVerticalSpecial;
		float num = mouseStandardSpecial * RotateSpeedScale;
		float num2 = mouseVerticalSpecial * RotateSpeedScale;
		_curYaw += num;
		Util.CorrectAngle(ref _curYaw);
		_curYaw = Mathf.Clamp(_curYaw, 0f - _limitLeft, _limitRight);
		_curPitch -= num2;
		Util.CorrectAngle(ref _curPitch);
		_curPitch = Mathf.Clamp(_curPitch, 0f - _limitUp, LimitDown);
		UpdateCameraTransform();
	}

	public void ChangeToFirst()
	{
		TankStateSync tankStateSync = SceneRoom.Instance.GetMainPlayer().TankStateSync;
		_curYaw = tankStateSync.TurretSync.TargetAngle;
		_curYaw = Mathf.Clamp(_curYaw, 0f - _limitLeft, _limitRight);
		_curPitch = tankStateSync.GunSync.TargetAngle;
		_curPitch = Mathf.Clamp(_curPitch, 0f - _limitUp, LimitDown);
		UpdateCameraTransform();
		_curStep = 2;
		camera.fieldOfView = _firstSteps[_curStep];
		CameraManager.Instance.WhenChangeFileOfView(_firstSteps[_curStep]);
		PlayerProxy mainPlayer = SceneRoom.Instance.GetMainPlayer();
		mainPlayer.TankModel.SetVisibleModel(mainPlayer, visible: false);
	}

	private void UpdateCameraTransform()
	{
		TankStateSync tankStateSync = SceneRoom.Instance.GetMainPlayer().TankStateSync;
		Quaternion quaternion = tankStateSync.Trans.rotation * Quaternion.AngleAxis(_curYaw, Vector3.up);
		Vector3 vector = tankStateSync.TurretSync.StableWorldPos + quaternion * tankStateSync.GunSync.Trans.localPosition;
		Quaternion quaternion2 = Quaternion.AngleAxis(_curPitch, Vector3.right);
		Quaternion quaternion3 = quaternion * quaternion2;
		Vector3 vector2 = vector + quaternion3 * tankStateSync.GunSync.FireStartPointTrans.localPosition;
		Vector3 v = tankStateSync.TurretSync.StableWorldPos - vector2;
		Vector3 v2 = Util.ProjectOntoPlane(v, quaternion3 * Vector3.right);
		v2 = Util.ProjectOntoPlane(v2, quaternion3 * Vector3.up);
		_transform.position = vector2 + v2;
		_transform.rotation = quaternion3;
	}

	private void ChangeAlphaFOVTestState(bool state)
	{
		AlphaHandle component = GetComponent<AlphaHandle>();
		if ((bool)component)
		{
			component.AlphaFOVTest = state;
		}
	}

	private void CamMove()
	{
		float mouseScroll = InputManager.MouseScroll;
		if (mouseScroll.CompareTo(0f) == 0)
		{
			return;
		}
		_needIgnoreAxis = 2;
		if (mouseScroll > 0f)
		{
			_curStep = ((_curStep < 1) ? _curStep : ReduceStep());
		}
		if (mouseScroll < 0f)
		{
			if (_curStep == 2)
			{
				ChangeAlphaFOVTestState(state: false);
				CameraManager.ChangeToThird(isScroll: true);
				return;
			}
			_curStep = ((_curStep > 1) ? _curStep : AddStep());
		}
		camera.fieldOfView = _firstSteps[_curStep];
		if (_curStep < 2)
		{
			ChangeAlphaFOVTestState(state: false);
		}
		else
		{
			ChangeAlphaFOVTestState(state: true);
		}
	}

	private int ReduceStep()
	{
		_curStep--;
		CameraManager.Instance.WhenChangeFileOfView(_firstSteps[_curStep]);
		OnChangeStep();
		return _curStep;
	}

	private int AddStep()
	{
		_curStep++;
		CameraManager.Instance.WhenChangeFileOfView(_firstSteps[_curStep]);
		OnChangeStep();
		return _curStep;
	}

	private void OnChangeStep()
	{
		if (this.ChangeStepEvent != null)
		{
			this.ChangeStepEvent();
		}
	}

	private void InitFirstSteps()
	{
		if (_firstSteps == null)
		{
			_firstSteps = new float[3];
			_firstSteps[0] = 8f;
			_firstSteps[1] = 15f;
			_firstSteps[2] = 30f;
		}
	}
}
