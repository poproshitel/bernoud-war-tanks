using UnityEngine;

public class BattleEndInfoPanel : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
