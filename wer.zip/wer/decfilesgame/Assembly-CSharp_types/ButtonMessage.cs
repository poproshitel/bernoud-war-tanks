using UnityEngine;

public class ButtonMessage : MonoBehaviour
{
	public UISprite ButtonSprite;

	public UILabel KeyValue;

	public UILabel FunctionName;

	public ButtonType TypeOfButton;

	public GameObject target;

	public string MouseOverFunction;

	public string MouseOutFunction;

	public string MousePressFunction;

	public string MouseReleaseFunction;

	public string MouseClickFunction;

	public string MouseRightClickFunction;

	public ForbiddenType ForType;

	private bool _forbiddenFlag = true;

	private UIImageButton _imageControl;

	private bool mStarted;

	public bool ForbiddenFlag
	{
		set
		{
			if (_imageControl != null)
			{
				_imageControl.Flag = value;
			}
			else
			{
				_imageControl = GetComponent<UIImageButton>();
				if (_imageControl != null)
				{
					_imageControl.Flag = value;
				}
			}
			_forbiddenFlag = value;
		}
	}

	private void Start()
	{
		mStarted = true;
		if (ForType == ForbiddenType.EnableColloider)
		{
			_imageControl = GetComponent<UIImageButton>();
		}
	}

	private void OnEnable()
	{
		if (mStarted)
		{
			OnHover(UICamera.IsHighlighted(base.gameObject));
		}
	}

	private void OnPress(bool isPressed)
	{
		if ((ForType == ForbiddenType.EnableColloider && !_forbiddenFlag) || !base.enabled)
		{
			return;
		}
		if (isPressed)
		{
			if (Input.GetMouseButtonDown(0))
			{
				Send(TriggerStage.OnPress);
			}
		}
		else if (Input.GetMouseButtonUp(0))
		{
			Send(TriggerStage.OnRelease);
		}
	}

	private void OnClick()
	{
		if ((ForType != ForbiddenType.EnableColloider || _forbiddenFlag) && base.enabled)
		{
			float realtimeSinceStartup = Time.realtimeSinceStartup;
			if (Input.GetMouseButtonUp(0))
			{
				Send(TriggerStage.OnClick);
			}
			else if (Input.GetMouseButtonUp(1))
			{
				Send(TriggerStage.OnRightClick);
			}
		}
	}

	private void OnHover(bool isOver)
	{
		if ((ForType != ForbiddenType.EnableColloider || _forbiddenFlag) && base.enabled)
		{
			if (isOver)
			{
				Send(TriggerStage.OnMouseOver);
			}
			else
			{
				Send(TriggerStage.OnMouseOut);
			}
		}
	}

	private void Send(TriggerStage stage)
	{
		if (target == null)
		{
			return;
		}
		switch (stage)
		{
		case TriggerStage.OnMouseOver:
			if (!string.IsNullOrEmpty(MouseOverFunction))
			{
				target.SendMessage(MouseOverFunction, base.gameObject, SendMessageOptions.DontRequireReceiver);
			}
			break;
		case TriggerStage.OnMouseOut:
			if (!string.IsNullOrEmpty(MouseOutFunction))
			{
				target.SendMessage(MouseOutFunction, base.gameObject, SendMessageOptions.DontRequireReceiver);
			}
			break;
		case TriggerStage.OnPress:
			if (!string.IsNullOrEmpty(MousePressFunction))
			{
				target.SendMessage(MousePressFunction, base.gameObject, SendMessageOptions.DontRequireReceiver);
			}
			break;
		case TriggerStage.OnRelease:
			if (!string.IsNullOrEmpty(MouseReleaseFunction))
			{
				target.SendMessage(MouseReleaseFunction, base.gameObject, SendMessageOptions.DontRequireReceiver);
			}
			break;
		case TriggerStage.OnClick:
			if (!string.IsNullOrEmpty(MouseClickFunction))
			{
				target.SendMessage(MouseClickFunction, base.gameObject, SendMessageOptions.DontRequireReceiver);
			}
			break;
		case TriggerStage.OnRightClick:
			if (!string.IsNullOrEmpty(MouseRightClickFunction))
			{
				target.SendMessage(MouseRightClickFunction, base.gameObject, SendMessageOptions.DontRequireReceiver);
			}
			break;
		case TriggerStage.OnDoubleClick:
			break;
		}
	}
}
