public class AccountUserDataModel
{
	public string PlayerName;

	public uint CreationTime;

	public int MaxKillVehicleId;

	public int MaxExpVehicleId;

	public int MaxRoundVehicleId;

	public int MaxScoreVehicleId;

	public string DebugLogString => "PlayerName" + PlayerName.Replace('\0', ' ') + " \n CreationTime" + CreationTime + " \n MaxKillVehicleId" + MaxKillVehicleId + " \n MaxExpVehicleId" + MaxExpVehicleId + " \n MaxRoundVehicleId" + MaxRoundVehicleId + " \n MaxScoreVehicleId" + MaxScoreVehicleId;
}
