using UnityEngine;

public class AdjustButtonPosHelper : MonoBehaviour
{
	public Vector3 LastPos;

	public Vector3 AdjustPos;

	public Transform NewPosTransform;

	public Transform TargetTransform;

	public Transform LeftTransform;

	public Transform RightTransform;

	public float XFlag;

	public float YFlag;

	public virtual void OnChangeScreenHandle()
	{
		if (XFlag > 0f)
		{
			if (LeftTransform.localPosition.x - RightTransform.localPosition.x >= XFlag && XFlagExpand())
			{
				TargetTransform.localPosition = NewPosTransform.localPosition + AdjustPos;
			}
			else
			{
				TargetTransform.localPosition = LastPos;
			}
		}
		else if (!(YFlag > 0f))
		{
		}
	}

	public virtual bool XFlagExpand()
	{
		return true;
	}
}
