using System;
using System.Collections.Generic;

public abstract class AHashableTable
{
	private Dictionary<Type, ColumnMappingAttribute[]> type2ColumnMappingAttributeses = new Dictionary<Type, ColumnMappingAttribute[]>();

	public virtual string GetAsString()
	{
		ColumnMappingAttribute[] attributeHandles = GetAttributeHandles();
		string text = string.Empty;
		ColumnMappingAttribute[] array = attributeHandles;
		foreach (ColumnMappingAttribute columnMappingAttribute in array)
		{
			text += columnMappingAttribute.TargetField.GetValue(this).ToString();
		}
		return text;
	}

	public virtual ColumnMappingAttribute[] GetAttributeHandles()
	{
		if (!type2ColumnMappingAttributeses.ContainsKey(GetType()))
		{
			type2ColumnMappingAttributeses[GetType()] = CsvImporter.GetFieldHandles(GetType());
		}
		return type2ColumnMappingAttributeses[GetType()];
	}
}
