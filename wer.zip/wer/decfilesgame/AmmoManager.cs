using UnityEngine;

public class AmmoManager : MonoBehaviour
{
	public static AmmoManager Instance;

	public float Caliber;

	public GameObject Ammo;

	public GameObject SmokeTrail;

	public TankShellVirtue AmmoData = new TankShellVirtue();

	public bool AmmoShow = true;

	private void Awake()
	{
		Instance = this;
		AmmoShow = GameManager.SettingManager.ImageSet.Projectile;
	}

	public void SettingAmmo(bool isShow)
	{
		AmmoShow = isShow;
	}
}
