public enum ActivityRequirement
{
	None,
	WinTimes,
	BattleTimes,
	KillerNum,
	Max
}
