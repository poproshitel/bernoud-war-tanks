public class ArearBaseColor : UIButtonColor
{
	protected override void OnPress(bool isPressed)
	{
	}

	protected override void OnHover(bool isOver)
	{
	}

	public void SetOnPress(bool isPressed)
	{
		base.OnPress(isPressed);
	}

	public void SetOnHover(bool isOver)
	{
		base.OnHover(isOver);
	}
}
