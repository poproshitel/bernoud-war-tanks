using System.Collections.Generic;

namespace AOI;

public class InterestArea
{
	private IntVec2 _viewDistanceEnter;

	private IntVec2 _viewDistanceExit;

	private readonly GridWorld _world;

	private readonly Bound _worldArea;

	private Dictionary<IntVec2, Region> _allLoadedRegions;

	private Bound _currentRegionInnerFocus;

	private Bound _currentRegionOuterFocus;

	private IntVec2 _position;

	private Dictionary<IntVec2, Region> _subscribedWorldRegions;

	private static readonly IntVec2[] _outers = new IntVec2[2];

	public GridWorld GridWorld => _world;

	public IntVec2 Position
	{
		get
		{
			return _position;
		}
		set
		{
			_position = value;
		}
	}

	public InterestArea(GridWorld world, IntVec2 viewDistanceEnter, IntVec2 viewDistanceExit, IntVec2 position)
	{
		_world = world;
		_viewDistanceEnter = viewDistanceEnter;
		_viewDistanceExit = viewDistanceExit;
		_position = position;
		_worldArea = world.Area;
		_currentRegionOuterFocus = (_currentRegionInnerFocus = new Bound(_worldArea.Max, _worldArea.Min));
		_subscribedWorldRegions = new Dictionary<IntVec2, Region>();
		_allLoadedRegions = new Dictionary<IntVec2, Region>();
	}

	public int GetRegionsCount()
	{
		Bound bound = default(Bound);
		bound.Min = _position - _viewDistanceEnter;
		bound.Max = _position + _viewDistanceEnter;
		Bound area = bound.IntersectWith(_worldArea);
		area = _world.GetRegionAlignedBound(area);
		if (area.IsValid())
		{
			HashSet<Region> hashSet = ((!_currentRegionInnerFocus.IsValid()) ? _world.GetRegions(area) : _world.GetRegionsExcept(area, _currentRegionInnerFocus));
			return hashSet.Count;
		}
		TKLog.Log("Regions Count is 0");
		return 0;
	}

	public void ResetView(IntVec2 viewDistanceEnter, IntVec2 viewDistanceExit)
	{
		_viewDistanceEnter = viewDistanceEnter;
		_viewDistanceExit = viewDistanceExit;
	}

	public void UpdateInterestManagement()
	{
		ref IntVec2 reference = ref _outers[0];
		reference = _position - _viewDistanceExit;
		ref IntVec2 reference2 = ref _outers[1];
		reference2 = _position + _viewDistanceExit;
		Bound area = Bound.CreateFromPoints(_outers).IntersectWith(_worldArea);
		Bound bound = default(Bound);
		bound.Min = _position - _viewDistanceEnter;
		bound.Max = _position + _viewDistanceEnter;
		Bound area2 = bound.IntersectWith(_worldArea);
		area2 = _world.GetRegionAlignedBound(area2);
		if (area2 != _currentRegionInnerFocus)
		{
			if (area2.IsValid())
			{
				HashSet<Region> regions = ((!_currentRegionInnerFocus.IsValid()) ? _world.GetRegions(area2) : _world.GetRegionsExcept(area2, _currentRegionInnerFocus));
				SubscribeRegions(regions);
			}
			_currentRegionInnerFocus = area2;
		}
		area = _world.GetRegionAlignedBound(area);
		if (!(area != _currentRegionOuterFocus))
		{
			return;
		}
		if (area.IsValid())
		{
			foreach (KeyValuePair<IntVec2, Region> subscribedWorldRegion in _subscribedWorldRegions)
			{
				Region value = subscribedWorldRegion.Value;
				if (!area.Contains(value.Coordinate))
				{
					value.OnRegionUnsubscribe(_world);
					_subscribedWorldRegions.Remove(value.Coordinate);
				}
			}
			return;
		}
		_currentRegionOuterFocus = area;
	}

	private void SubscribeRegions(IEnumerable<Region> regions)
	{
		if (regions == null)
		{
			return;
		}
		foreach (Region region in regions)
		{
			if (!_subscribedWorldRegions.ContainsKey(region.Coordinate))
			{
				region.OnRegionSubscribe(_world);
				_subscribedWorldRegions.Add(region.Coordinate, region);
			}
			if (!_allLoadedRegions.ContainsKey(region.Coordinate))
			{
				_allLoadedRegions.Add(region.Coordinate, region);
			}
		}
	}

	public void OnDestroy()
	{
		foreach (KeyValuePair<IntVec2, Region> allLoadedRegion in _allLoadedRegions)
		{
			allLoadedRegion.Value.OnRegionUnLoad();
		}
		_allLoadedRegions.Clear();
		_subscribedWorldRegions.Clear();
		_allLoadedRegions = null;
		_subscribedWorldRegions = null;
	}
}
