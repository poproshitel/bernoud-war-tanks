using System;
using System.Collections.Generic;

namespace AOI;

[Serializable]
public class GridWorld
{
	private readonly Bound _rectangleArea;

	private readonly IntVec2 _tileDimensions;

	private readonly IntVec2 _tileSize;

	private readonly Region[][] _worldRegions;

	public int LeastViewCount;

	public int RegionNodesCount
	{
		get
		{
			IntVec2 tileDimensions = _tileDimensions;
			int x = tileDimensions.X;
			IntVec2 tileDimensions2 = _tileDimensions;
			return x * tileDimensions2.Y;
		}
	}

	public Bound Area => _rectangleArea;

	public GridWorld(Bound bound, IntVec2 tileDimensions)
	{
		LeastViewCount = int.MaxValue;
		_rectangleArea = bound;
		IntVec2 intVec = new IntVec2(bound.Max.X - bound.Min.X + 1, bound.Max.Y - bound.Min.Y + 1);
		_tileDimensions = tileDimensions;
		_tileSize = new IntVec2(tileDimensions.X - 1, tileDimensions.Y - 1);
		int num = (int)Math.Ceiling((double)intVec.X / (double)tileDimensions.X);
		int num2 = (int)Math.Ceiling((double)intVec.Y / (double)tileDimensions.Y);
		_worldRegions = new Region[num][];
		IntVec2 min = bound.Min;
		for (int i = 0; i < num; i++)
		{
			_worldRegions[i] = new Region[num2];
			for (int j = 0; j < num2; j++)
			{
				_worldRegions[i][j] = new Region(min);
				min.Y += tileDimensions.Y;
			}
			min.X += tileDimensions.X;
			min.Y = bound.Min.Y;
		}
	}

	public Region GetRegion(IntVec2 pos)
	{
		if (_rectangleArea.Contains(pos))
		{
			return GetRegionAt(pos);
		}
		return null;
	}

	public Bound GetRegionAlignedBound(Bound area)
	{
		area = _rectangleArea.IntersectWith(area);
		if (area.IsValid())
		{
			Bound result = default(Bound);
			result.Min = GetRegionAt(area.Min).Coordinate;
			result.Max = GetRegionAt(area.Max).Coordinate + _tileSize;
			return result;
		}
		return area;
	}

	private Region GetRegionAt(IntVec2 coordinate)
	{
		Bound rectangleArea = _rectangleArea;
		IntVec2 intVec = coordinate - rectangleArea.Min;
		int x = intVec.X;
		IntVec2 tileDimensions = _tileDimensions;
		int num = x / tileDimensions.X;
		int y = intVec.Y;
		IntVec2 tileDimensions2 = _tileDimensions;
		int num2 = y / tileDimensions2.Y;
		return _worldRegions[num][num2];
	}

	public HashSet<Region> GetRegions(Bound area)
	{
		return new HashSet<Region>(GetRegionEnumerable(area));
	}

	public HashSet<Region> GetRegionsExcept(Bound area, Bound except)
	{
		HashSet<Region> hashSet = new HashSet<Region>();
		if (area.Min.X < except.Min.X)
		{
			Bound bound = default(Bound);
			bound.Min = area.Min;
			bound.Max = new IntVec2(Math.Min(area.Max.X, except.Min.X - 1), area.Max.Y);
			Bound area2 = bound;
			hashSet.UnionWith(GetRegionEnumerable(area2));
		}
		if (area.Min.Y < except.Min.Y)
		{
			Bound area3 = new Bound(area.Min, new IntVec2(area.Max.X, Math.Min(area.Max.Y, except.Min.Y - 1)));
			hashSet.UnionWith(GetRegionEnumerable(area3));
		}
		if (area.Max.X > except.Max.X)
		{
			Bound area4 = new Bound(new IntVec2(Math.Min(area.Min.X, except.Max.X + 1), area.Min.Y), area.Max);
			hashSet.UnionWith(GetRegionEnumerable(area4));
		}
		if (area.Max.Y > except.Max.Y)
		{
			Bound area5 = new Bound(new IntVec2(area.Min.X, Math.Max(area.Min.Y, except.Max.Y + 1)), area.Max);
			hashSet.UnionWith(GetRegionEnumerable(area5));
		}
		return hashSet;
	}

	private IEnumerable<Region> GetRegionEnumerable(Bound area)
	{
		Bound overlap = area.IntersectWith(_rectangleArea);
		IntVec2 min = overlap.Min;
		while (min.Y <= overlap.Max.Y)
		{
			IEnumerator<Region> enumerator = GetRegionsForY(overlap, min).GetEnumerator();
			while (enumerator.MoveNext())
			{
				yield return enumerator.Current;
			}
			int y = min.Y;
			IntVec2 tileDimensions = _tileDimensions;
			min.Y = y + tileDimensions.Y;
		}
		if (min.Y <= overlap.Max.Y)
		{
			yield break;
		}
		min.Y = overlap.Max.Y;
		foreach (Region item in GetRegionsForY(overlap, min))
		{
			yield return item;
		}
	}

	private IEnumerable<Region> GetRegionsForY(Bound overlap, IntVec2 current)
	{
		current.X = overlap.Min.X;
		while (current.X <= overlap.Max.X)
		{
			yield return GetRegionAt(current);
			int x = current.X;
			IntVec2 tileDimensions = _tileDimensions;
			current.X = x + tileDimensions.X;
		}
		if (current.X > overlap.Max.X)
		{
			current.X = overlap.Max.X;
			yield return GetRegionAt(current);
		}
	}
}
