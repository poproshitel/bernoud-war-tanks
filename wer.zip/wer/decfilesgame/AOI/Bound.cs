using System;

namespace AOI;

public struct Bound
{
	public IntVec2 Max;

	public IntVec2 Min;

	public Bound(IntVec2 min, IntVec2 max)
	{
		Min = min;
		Max = max;
	}

	public void Inflate(int amount)
	{
		Min.SetTo(Min.X + amount, Min.Y + amount);
		Max.SetTo(Max.X + amount, Max.Y + amount);
	}

	public void Inflate(IntVec2 amount)
	{
		Min.SetTo(Min.X + amount.X, Min.Y + amount.Y);
		Max.SetTo(Max.X + amount.X, Max.Y + amount.Y);
	}

	public override string ToString()
	{
		return $"Min: {Min}, Max: {Max}";
	}

	public string ToString(string format)
	{
		return $"Min: {Min}, Max: {Max}";
	}

	public static bool operator ==(Bound lhs, Bound rhs)
	{
		return lhs.Min == rhs.Min && lhs.Max == rhs.Max;
	}

	public static bool operator !=(Bound lhs, Bound rhs)
	{
		return !(lhs == rhs);
	}

	public bool IsValid()
	{
		return Max.X > Min.X && Max.Y > Min.Y;
	}

	public bool Contains(IntVec2 point)
	{
		return point.X >= Min.X && point.X <= Max.X && point.Y >= Min.Y && point.Y <= Max.Y;
	}

	public bool Contains(Bound other)
	{
		return Contains(other.Min) && Contains(other.Max);
	}

	public bool ContainsEntirelY(IntVec2 point)
	{
		return point.X > Min.X && point.X < Max.X && point.Y > Min.Y && point.Y < Max.Y;
	}

	public bool ContainsEntirelY(Bound other)
	{
		return ContainsEntirelY(other.Min) && ContainsEntirelY(other.Max);
	}

	public Bound UnionWith(Bound other)
	{
		Bound result = default(Bound);
		result.Min = IntVec2.Min(Min, other.Min);
		result.Max = IntVec2.Max(Max, other.Max);
		return result;
	}

	public bool Intersects(Bound other)
	{
		return Min.X < other.Max.X && Max.X > other.Min.X && Min.Y < other.Max.Y && Max.Y > other.Min.Y;
	}

	public Bound IntersectWith(Bound other)
	{
		Bound result = default(Bound);
		result.Min = IntVec2.Max(Min, other.Min);
		result.Max = IntVec2.Min(Max, other.Max);
		return result;
	}

	public static Bound CreateFromPoints(params IntVec2[] points)
	{
		if (points == null)
		{
			throw new ArgumentNullException("points");
		}
		if (points.Length == 0)
		{
			throw new ArgumentException("points");
		}
		IntVec2 min = points[0];
		IntVec2 max = points[0];
		for (int i = 1; i < points.Length; i++)
		{
			IntVec2 intVec = points[i];
			if (intVec.X < min.X)
			{
				min.X = intVec.X;
			}
			if (intVec.Y < min.Y)
			{
				min.Y = intVec.Y;
			}
			if (intVec.X > max.X)
			{
				max.X = intVec.X;
			}
			if (intVec.Y > max.Y)
			{
				max.Y = intVec.Y;
			}
		}
		Bound result = default(Bound);
		result.Min = min;
		result.Max = max;
		return result;
	}
}
