using System;
using UnityEngine;

namespace AOI;

public struct IntVec2 : IEquatable<IntVec2>
{
	public int X;

	public int Y;

	public static IntVec2 Zero => new IntVec2(0, 0);

	public static IntVec2 One => new IntVec2(1, 1);

	public IntVec2(int x, int y)
	{
		X = x;
		Y = y;
	}

	public IntVec2(float x, float y)
	{
		X = Mathf.RoundToInt(x);
		Y = Mathf.RoundToInt(y);
	}

	public void SetTo(int x, int y)
	{
		X = x;
		Y = y;
	}

	public void SetTo(float x, float y)
	{
		X = Mathf.RoundToInt(x);
		Y = Mathf.RoundToInt(y);
	}

	public static IntVec2 operator +(IntVec2 a, IntVec2 b)
	{
		IntVec2 result = default(IntVec2);
		result.X = a.X + b.X;
		result.Y = a.Y + b.Y;
		return result;
	}

	public static IntVec2 operator /(IntVec2 a, int b)
	{
		IntVec2 result = default(IntVec2);
		result.X = a.X / b;
		result.Y = a.Y / b;
		return result;
	}

	public static bool operator ==(IntVec2 coordinate1, IntVec2 coordinate2)
	{
		return coordinate1.Equals(coordinate2);
	}

	public static bool operator !=(IntVec2 coordinate1, IntVec2 coordinate2)
	{
		return !coordinate1.Equals(coordinate2);
	}

	public static IntVec2 operator *(IntVec2 a, int b)
	{
		IntVec2 result = default(IntVec2);
		result.X = a.X * b;
		result.Y = a.Y * b;
		return result;
	}

	public static IntVec2 operator -(IntVec2 a, IntVec2 b)
	{
		IntVec2 result = default(IntVec2);
		result.X = a.X - b.X;
		result.Y = a.Y - b.Y;
		return result;
	}

	public static IntVec2 operator -(IntVec2 a)
	{
		IntVec2 result = default(IntVec2);
		result.X = -a.X;
		result.Y = -a.Y;
		return result;
	}

	public static IntVec2 Max(IntVec2 value1, IntVec2 value2)
	{
		IntVec2 result = default(IntVec2);
		result.X = Math.Max(value1.X, value2.X);
		result.Y = Math.Max(value1.Y, value2.Y);
		return result;
	}

	public static IntVec2 Min(IntVec2 value1, IntVec2 value2)
	{
		IntVec2 result = default(IntVec2);
		result.X = Math.Min(value1.X, value2.X);
		result.Y = Math.Min(value1.Y, value2.Y);
		return result;
	}

	public override bool Equals(object obj)
	{
		if (obj is IntVec2 other)
		{
			return Equals(other);
		}
		return false;
	}

	public double GetDistance(IntVec2 intVec2)
	{
		return Math.Sqrt(Math.Pow(intVec2.X - X, 2.0) + Math.Pow(intVec2.Y - Y, 2.0));
	}

	public override int GetHashCode()
	{
		return X.GetHashCode() ^ Y.GetHashCode();
	}

	public double GetMagnitude()
	{
		return Math.Sqrt(X * X + Y * Y);
	}

	public override string ToString()
	{
		return string.Format("{0}({1},{2})", new object[3]
		{
			base.ToString(),
			X,
			Y
		});
	}

	public bool Equals(IntVec2 other)
	{
		return X.Equals(other.X) && Y.Equals(other.Y);
	}
}
