using TK;
using UnityEngine;

namespace AOI;

public class Region
{
	private readonly IntVec2 _coordinate;

	private GameObject _parent;

	public GameObject RegionObject
	{
		get
		{
			if (_parent == null)
			{
				_parent = new GameObject(_coordinate.ToString());
				_parent.transform.parent = SceneRoom.Instance.GetSceneObject().transform;
			}
			return _parent;
		}
	}

	public IntVec2 Coordinate => _coordinate;

	public Region(IntVec2 coordinate)
	{
		_coordinate = coordinate;
	}

	public virtual void OnRegionSubscribe(GridWorld world)
	{
		SceneRoom.Instance.GetMapEntity().GenerateRegion(_coordinate, _parent);
	}

	public virtual void OnRegionUnsubscribe(GridWorld world)
	{
		if (_parent == null)
		{
			return;
		}
		MeshFilter[] componentsInChildren = _parent.GetComponentsInChildren<MeshFilter>();
		MeshFilter[] array = componentsInChildren;
		foreach (MeshFilter meshFilter in array)
		{
			if (meshFilter.sharedMesh != null && meshFilter.name.StartsWith("Combine"))
			{
				Object.Destroy(meshFilter.sharedMesh);
			}
		}
		int childCount = _parent.transform.GetChildCount();
		for (int j = 0; j < childCount; j++)
		{
			Transform child = _parent.transform.GetChild(j);
			if (!child.name.StartsWith("Rubbish"))
			{
				Object.Destroy(child.gameObject);
			}
		}
	}

	public virtual void OnRegionUnLoad()
	{
		if (_parent == null)
		{
			TKLog.Log("OnRegionUnLoad Parent is null");
			return;
		}
		MeshFilter[] componentsInChildren = _parent.GetComponentsInChildren<MeshFilter>();
		MeshFilter[] array = componentsInChildren;
		foreach (MeshFilter meshFilter in array)
		{
			if (meshFilter.sharedMesh != null && meshFilter.name.StartsWith("Combine"))
			{
				Object.Destroy(meshFilter.sharedMesh);
			}
		}
		Object.Destroy(_parent);
	}
}
