namespace AOI;

public class AOIManager : Singleton<AOIManager>
{
	public static readonly IntVec2 TileDimensions = new IntVec2(80, 80);

	public const int ExtendTile = 1;

	private InterestArea _interestArea;

	public InterestArea InterestArea => _interestArea;

	public bool GenerateWholeMap(int mapLength, int mapWidth)
	{
		IntVec2 intVec = new IntVec2(mapWidth, mapLength);
		if (_interestArea == null)
		{
			TKLog.Log("GenerateWholeMap _interestArea is null");
			return false;
		}
		_interestArea.ResetView(intVec, intVec + TileDimensions * 1);
		_interestArea.Position = IntVec2.One;
		_interestArea.UpdateInterestManagement();
		return true;
	}

	public void Init(int mapLength, int mapWidth, int view, IntVec2 pos)
	{
		Bound bound = new Bound(new IntVec2(0, 0), new IntVec2(mapWidth - 1, mapLength - 1));
		GridWorld world = new GridWorld(bound, TileDimensions);
		view = mapLength;
		IntVec2 intVec = new IntVec2(view, view);
		_interestArea = new InterestArea(world, intVec, intVec + TileDimensions * 1, pos);
	}

	public void Update(float x, float y)
	{
		if (_interestArea != null)
		{
			_interestArea.Position.SetTo(x, y);
			_interestArea.UpdateInterestManagement();
		}
	}
}
