public enum AntialiasingType
{
	None,
	X2,
	X4,
	X8
}
