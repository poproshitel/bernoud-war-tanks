using System.Collections.Generic;

public class AccountProfilesData
{
	public string PlayerName;

	public string AccountCreationTime;

	public int MaxKillVehicleId;

	public int MaxExpVehicleId;

	public List<AccountProfilesDataItem> DataItemList;
}
