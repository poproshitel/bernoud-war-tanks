using UnityEngine;

public class AdjustFontTool : MonoBehaviour
{
	public int Font;

	public int OriginFont;

	private UILabel m_label;

	private void Start()
	{
		m_label = GetComponent<UILabel>();
		if (m_label == null)
		{
			TKLog.LogWarning("Can't find the UILabel Frome the Object");
		}
		else
		{
			OriginFont = m_label.FontID;
		}
	}

	public void ApplyFont()
	{
		m_label = GetComponent<UILabel>();
		if (m_label == null)
		{
			TKLog.LogWarning("Can't find the UILabel Frome the Object");
			return;
		}
		Table_DictionaryStyle dirStyle = GameManager.TableMgr.GetDirStyle(Font);
		if (dirStyle == null)
		{
			TKLog.LogWarning("Can't find the font in DirStyleTable " + Font);
		}
		else
		{
			m_label.AdjustFontByOtherScript(dirStyle);
		}
	}
}
