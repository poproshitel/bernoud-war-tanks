public class ActivitySelect
{
	public int PageId;

	public int Level1Id;

	public int Level2Id;

	public override string ToString()
	{
		return $"{PageId}_{Level1Id}_{Level2Id}";
	}
}
