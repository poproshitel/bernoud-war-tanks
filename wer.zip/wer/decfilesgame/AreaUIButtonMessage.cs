public class AreaUIButtonMessage : UIButtonMessage
{
	public override void OnClick()
	{
	}

	public void SetOnClick()
	{
		base.OnClick();
	}
}
