using UnityEngine;

public class ActivityMainPanelUi : UIChildInterface
{
	public Transform PanelTransform;

	private readonly Vector3 _openPosition = new Vector3(0f, -20f, -10f);

	private readonly Vector3 _closePosition = new Vector3(10000f, 0f, 0f);

	private bool _isMainUiOpen;

	public GameObject LeftPanelPrefabRootObj;

	public GameObject RightPanelPrefabRootObj;

	public UIButtonMessage CloseBtn;

	public UILabel TitleLabel;

	public bool isFirstOpen = true;

	private ActivityMainPanelMediator _activityMainPanelMediator;

	public GameObject LaserTankSaleGo;

	public GameObject VersionBillboard;

	public GameObject Mission;

	public GameObject ActivityCenter;

	public GameObject SignLoginAward;

	public GameObject TreasureBox;

	public GameObject NewRecruit;

	public GameObject SevenDayLoginGo;

	public GameObject DiscountPromote;

	public GameObject Tournament;

	public GameObject CodeKey;

	public GameObject FullServerLimitDiscount;

	public GameObject PersonLimitDiscount;

	public GameObject SingleRechargeActivity;

	public GameObject AccumulateRechargeActivity;

	public GameObject BulletPriceAdjust;

	public GameObject CrewlevelInfluenceAdjust;

	public GameObject GunPrecisionAdjust;

	public GameObject GunPriceAdjust;

	public GameObject TankProceedsAdjust;

	public GameObject TankAttributeAdjust;

	public GameObject ChristmasLogin;

	private ActivityWindowType pendingActivityWindowType;

	public bool IsMainUiOpen => _isMainUiOpen;

	public event ActivityMainPanelUiDoClose ActivityMainPanelUiDoCloseEvent;

	protected virtual void OnActivityMainPanelUiDoCloseEvent(bool isShow)
	{
		this.ActivityMainPanelUiDoCloseEvent?.Invoke(isShow);
	}

	private void Awake()
	{
		_activityMainPanelMediator = GetComponent<ActivityMainPanelMediator>();
		PanelTransform = base.transform;
		TitleLabel.text = CommonTools.GetDictString("Hot_TT_01");
	}

	public void OpenDefaultPanel()
	{
		_activityMainPanelMediator.OpenDefaultPanel();
	}

	public void OpenPanel(ActivityWindowType activityWindowType)
	{
		if (!base.Switch)
		{
			pendingActivityWindowType = activityWindowType;
			Toggle();
		}
		_activityMainPanelMediator.OpenPanel(activityWindowType);
	}

	protected override void Toggle(bool state)
	{
		if (state)
		{
			HallGuiManager.Instance.Get<TankPortUIManager>().BottomNaScript.BottomPanelManager.ChangeFace(GetButtonType());
		}
		else
		{
			HallGuiManager.Instance.Get<TankPortUIManager>().BottomNaScript.BottomPanelManager.GoHome();
		}
	}

	public override ToggleFaceType GetButtonType()
	{
		return ToggleFaceType.NewActivity;
	}

	public override void ShowOrHide(bool flag, object parameter)
	{
		base.ShowOrHide(flag, parameter);
		if (flag)
		{
			HallGuideManager.Instance.PopupInterface(EnumHallInterface.NewActivity);
			GUITools.SetParentlayerAndForbiddenScreen(UiStage.Tips, base.gameObject, isTransorm: true);
			PanelTransform.localPosition = _openPosition;
		}
		else
		{
			GUITools.SetParentlayerAndForbiddenScreen(UiStage.Tips, base.gameObject, isTransorm: true);
			HallGuideManager.Instance.ClosePopupInterface(EnumHallInterface.NewActivity);
			PanelTransform.localPosition = _closePosition;
		}
		OnActivityMainPanelUiDoCloseEvent(flag);
		_isMainUiOpen = flag;
		if (flag && Singleton<ActivityMainPanelUiData>.Instance.IsNeedRefresh)
		{
			_activityMainPanelMediator.RefreshActivity(pendingActivityWindowType);
			pendingActivityWindowType = ActivityWindowType.None;
			Singleton<ActivityMainPanelUiData>.Instance.IsNeedRefresh = false;
		}
	}

	private void DoCloseBtn()
	{
		Toggle();
	}
}
