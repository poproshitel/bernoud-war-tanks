public class AmmoStateHitMain : AmmoStateBase
{
	private AmmoStateType _tempNextStateType;

	public override void EnterState(CAmmoStateParam param)
	{
		_tempNextStateType = AmmoStateType.Invaid;
		param.CurState = AmmoStateType.HitMain;
	}

	public override bool UpdateState(CAmmoStateParam param)
	{
		if (param.Ammo.HasTouchDown || param.IsInTraining)
		{
			if (param.Ammo.HeSendDataCache != null || param.Ammo.SendDataCache != null)
			{
				AmmoTools.MainPlayerLastHitAmmo = param.Ammo;
			}
			param.Trans.position = param.Ammo.GetRealHitWorldPosition();
			switch (param.Ammo.ShootRes)
			{
			case ShootResult.JumpBullet:
				_tempNextStateType = AmmoStateType.Jump;
				break;
			case ShootResult.Fail:
				_tempNextStateType = AmmoStateType.Jump;
				break;
			default:
				_tempNextStateType = AmmoStateType.Bomb;
				break;
			}
			return true;
		}
		return false;
	}

	public override void LeaveState(CAmmoStateParam param, ref AmmoStateType nextstate)
	{
		Singleton<AmmoEvnet>.Instance.OnEvent(AmmoStateType.HitMain, param);
		nextstate = _tempNextStateType;
	}
}
