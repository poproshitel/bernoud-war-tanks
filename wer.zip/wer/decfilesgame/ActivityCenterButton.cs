using UnityEngine;

public class ActivityCenterButton : MonoBehaviour
{
	public UILabel CountLabel;

	private string normalSprite = "activity_number_bg1";

	private string hoverSprite = "activity_number_bg2";

	public Transform Root;

	private UISprite sprite;

	private ActivityCenterManager manager;

	private int index;

	private bool _isSelected;

	private ActivityCenterModel _activityModel;

	private Transform _cachedTransform;

	public bool IsSelected
	{
		get
		{
			return _isSelected;
		}
		set
		{
			_isSelected = value;
			if (value)
			{
				HoverHandler();
				if (!(Root != null))
				{
					return;
				}
				ActivityCenterButton[] componentsInChildren = Root.GetComponentsInChildren<ActivityCenterButton>(includeInactive: true);
				int i = 0;
				for (int num = componentsInChildren.Length; i < num; i++)
				{
					ActivityCenterButton activityCenterButton = componentsInChildren[i];
					if (activityCenterButton != this && activityCenterButton.Root == Root)
					{
						activityCenterButton.IsSelected = false;
					}
				}
			}
			else
			{
				NormalHandler();
			}
		}
	}

	public ActivityCenterModel ActivityModel
	{
		get
		{
			return _activityModel;
		}
		set
		{
			_activityModel = value;
		}
	}

	public Transform CachedTransform
	{
		get
		{
			if (_cachedTransform == null)
			{
				_cachedTransform = base.transform;
			}
			return _cachedTransform;
		}
	}

	private void OnClick()
	{
	}

	private void OnHover(bool flag)
	{
		if (!_isSelected)
		{
			if (flag)
			{
				HoverHandler();
			}
			else
			{
				NormalHandler();
			}
		}
	}

	public void OnPress(bool flag)
	{
		if (flag)
		{
			IsSelected = true;
			manager.ChangeActivity(ActivityModel);
		}
	}

	private void NormalHandler()
	{
		sprite.spriteName = normalSprite;
		CountLabel.text = string.Format(CommonTools.GetDictString("activity_number_1"), index);
	}

	private void HoverHandler()
	{
		sprite.spriteName = hoverSprite;
		CountLabel.text = string.Format(CommonTools.GetDictString("activity_number_2"), index);
	}

	public void Init(ActivityCenterModel model, ActivityCenterManager centerManager, int num)
	{
		sprite = GetComponentInChildren<UISprite>();
		ActivityModel = model;
		manager = centerManager;
		index = num;
		NormalHandler();
	}
}
