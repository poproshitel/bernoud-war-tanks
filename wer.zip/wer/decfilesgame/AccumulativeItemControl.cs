using UnityEngine;

public class AccumulativeItemControl : MonoBehaviour
{
	public UILabel BtnLabel;

	public UISlicedSprite Background;

	public UIImageButton BtnImage;

	public UILabel Label1;

	public UILabel Label2;

	public UITexture Pic;

	public UITexture GotIcon;

	public GameObject Bg1;

	public GameObject Bg2;

	private byte _id;

	public UILabel VIPLabel;

	public int ImageWidth = 208;

	public int ImageHeight = 208;

	private LoginAwardBtnType _buttonType;

	private bool _canClick = true;

	private Table_Reward _reward;

	public byte ID
	{
		get
		{
			return _id;
		}
		set
		{
			_id = value;
		}
	}

	public int PicID
	{
		set
		{
			if (Pic != null)
			{
				ResourcesManager.Instance.RetrieveUIMaterial(value, Pic);
				Pic.transform.localScale = new Vector3(ImageWidth, ImageHeight, 1f);
				Pic.MakePixelPerfect();
			}
		}
	}

	public LoginAwardBtnType ButtonType
	{
		get
		{
			return _buttonType;
		}
		set
		{
			if (_buttonType != value)
			{
				switch (value)
				{
				case LoginAwardBtnType.DOING:
					BtnLabel.text = CommonTools.GetDictString("activity_reward_get");
					Bg1.SetActive(value: true);
					Bg2.SetActive(value: true);
					CanClick = true;
					break;
				case LoginAwardBtnType.DONE:
					BtnLabel.text = CommonTools.GetDictString("activity_reward_geted");
					Bg1.SetActive(value: false);
					Bg2.SetActive(value: false);
					ResearchStatic.MakeUITextureGery(Pic, stage: true);
					CanClick = false;
					break;
				case LoginAwardBtnType.NONE:
					BtnLabel.text = CommonTools.GetDictString("activity_reward_notget");
					Bg1.SetActive(value: false);
					Bg2.SetActive(value: false);
					CanClick = false;
					break;
				}
				_buttonType = value;
			}
		}
	}

	public bool CanClick
	{
		get
		{
			return _canClick;
		}
		set
		{
			if (_canClick != value)
			{
				_canClick = value;
				BtnImage.Flag = _canClick;
				if (_canClick)
				{
					Background.spriteName = "MissionBtn_Normal";
					BtnImage.normalSprite = "MissionBtn_Normal";
				}
				else
				{
					Background.spriteName = "MissionBtn_Unable";
					BtnImage.normalSprite = "MissionBtn_Unable";
				}
			}
		}
	}

	public Table_Reward Reward
	{
		get
		{
			return _reward;
		}
		set
		{
			_reward = value;
		}
	}

	private void Awake()
	{
		ButtonType = LoginAwardBtnType.NONE;
	}

	private void OnClick()
	{
		if (CanClick)
		{
			AccumulativeLoginAwardPanel.Instance.OnGetAwardBtnClickHandler(this);
		}
	}
}
