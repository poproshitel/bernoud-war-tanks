public abstract class AmmoStateBase
{
	public abstract void EnterState(CAmmoStateParam param);

	public abstract bool UpdateState(CAmmoStateParam param);

	public abstract void LeaveState(CAmmoStateParam param, ref AmmoStateType nextstate);
}
