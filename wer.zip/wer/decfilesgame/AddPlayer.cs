public delegate void AddPlayer(PlayerNode data);
