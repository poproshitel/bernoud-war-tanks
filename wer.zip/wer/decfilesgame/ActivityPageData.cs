public class ActivityPageData
{
	public int Id;

	public BetterList<ActivityItemData> ActivityItemList = new BetterList<ActivityItemData>();
}
