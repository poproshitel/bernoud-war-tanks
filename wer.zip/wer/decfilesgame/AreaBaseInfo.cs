using System.Collections.Generic;
using UnityEngine;

public class AreaBaseInfo
{
	public int Id { get; set; }

	public string Name { get; set; }

	public List<int> CanAttackTerritoryIdList { get; set; }

	public Vector2 LocalPostion { get; set; }

	public Vector2 TagetPostion { get; set; }
}
