using System;
using System.Collections.Generic;
using TK;
using UnityEngine;

public class AccountMedalMedialtor : MonoBehaviour
{
	public UIAccountProfiles AccountProfiles;

	public static string AccountItemOnClickHandlerName = "AccountItemOnClickHandler";

	private static AccountMedalMedialtor _instance;

	public TroopsPageGroupButton BattleStatisticsBtn;

	public static AccountMedalMedialtor GetInstance()
	{
		return _instance;
	}

	private void Awake()
	{
		if (_instance == null)
		{
			_instance = this;
		}
		MedalDataManager instance = MedalDataManager.GetInstance();
		instance.LoadTankMedalInfo = (MedalDataManager.LoadTankMedalInfoDelegate)Delegate.Combine(instance.LoadTankMedalInfo, new MedalDataManager.LoadTankMedalInfoDelegate(LoadTankMedalInfo));
	}

	private void OnDestroy()
	{
		MedalDataManager instance = MedalDataManager.GetInstance();
		instance.LoadTankMedalInfo = (MedalDataManager.LoadTankMedalInfoDelegate)Delegate.Remove(instance.LoadTankMedalInfo, new MedalDataManager.LoadTankMedalInfoDelegate(LoadTankMedalInfo));
	}

	public void AccountItemOnClickHandler(UIAccountProfilesItem item)
	{
		GameManager.Hall.SendRequestTankMedal(item.VehicleId, item.CurrentBattleType);
	}

	public void LoadTankMedalInfo(List<MedalInfoModel> medalInfoList)
	{
		AccountProfiles.UpdateMedalItemPanel(medalInfoList);
	}

	public void ShowBattleStaticsPanel(EBattleMode mode)
	{
		AccountProfiles.SetBattleTypeListStatus(showOrHide: true);
		AccountProfiles.SetBasePanelUpDown(upOrDown: true);
		AccountProfiles.PlayerRankList.gameObject.SetActive(value: false);
		AccountProfiles.AccountInfoBoard.gameObject.SetActive(value: false);
		AccountProfiles.BaseInfoPanel.gameObject.SetActive(value: true);
		AccountProfiles.BattleStaticBoard.gameObject.SetActive(value: true);
		AccountProfiles.PlayerStatisticsPanel.gameObject.SetActive(value: false);
		AccountProfiles.CurrentBattleType = (byte)mode;
		switch (mode)
		{
		case EBattleMode.Standard:
			AccountProfiles.SetAccountData(Singleton<AccountProfilesManager>.Instance.ApDataNml);
			break;
		case EBattleMode.Relive:
			AccountProfiles.SetAccountData(Singleton<AccountProfilesManager>.Instance.ApDataRvv);
			break;
		case EBattleMode.PVE:
			AccountProfiles.SetAccountData(Singleton<AccountProfilesManager>.Instance.ApDataPVE);
			break;
		case EBattleMode.Commander:
			AccountProfiles.SetAccountData(Singleton<AccountProfilesManager>.Instance.ApDataCommander);
			break;
		}
		BattleStatisticsBtn.OnPress(pressed: true);
	}
}
