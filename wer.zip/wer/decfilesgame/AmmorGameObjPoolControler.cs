using System.Collections.Generic;
using UnityEngine;

public class AmmorGameObjPoolControler : GameObjPoolControler
{
	public GameObject AmmoParent;

	private Queue<ObjectPoolAmmoAsset> _shellContiner;

	private int _curWholeCount;

	public AmmorGameObjPoolControler()
	{
		_shellContiner = new Queue<ObjectPoolAmmoAsset>();
	}

	public GameObject GetObj(Object asset)
	{
		if (asset == null)
		{
			TKLog.LogError("AmmorGameObjPoolControler.AddToQueue called! asset is null!");
			return null;
		}
		if (_shellContiner.Count > 0)
		{
			ObjectPoolAmmoAsset objectPoolAmmoAsset = _shellContiner.Dequeue();
			objectPoolAmmoAsset.transform.parent = null;
			if (objectPoolAmmoAsset != null)
			{
				objectPoolAmmoAsset.Show();
				return objectPoolAmmoAsset.gameObject;
			}
			return null;
		}
		if (_shellContiner.Count == 0 && _curWholeCount >= 10)
		{
			GameObject gameObject = CommonTools.InstantiateObject(asset);
			Object.Destroy(gameObject.GetComponent<Collider>());
			return gameObject;
		}
		GameObject gameObject2 = CommonTools.InstantiateObject(asset);
		Object.Destroy(gameObject2.GetComponent<Collider>());
		ObjectPoolAmmoAsset objectPoolAmmoAsset2 = gameObject2.AddComponent<ObjectPoolAmmoAsset>();
		_curWholeCount++;
		objectPoolAmmoAsset2.Show();
		return gameObject2;
	}

	public void AddToPool(ObjectPoolAmmoAsset assetControler)
	{
		if (assetControler == null)
		{
			return;
		}
		AmmoControl component = assetControler.GetComponent<AmmoControl>();
		if (component == null)
		{
			TKLog.LogError("Error ammo !  don't have AmmControl!");
			return;
		}
		Object.Destroy(component);
		_shellContiner.Enqueue(assetControler);
		if (AmmoParent == null)
		{
			AmmoParent = new GameObject("AmmoPoolParent");
			CommonTools.InitNewGameObject(AmmoParent);
		}
		BigAmmoTrailMeshRenderer bigAmmoRender = assetControler.BigAmmoRender;
		SmallAmmoTrailMeshRenderer smallAmmoRender = assetControler.SmallAmmoRender;
		if (bigAmmoRender != null)
		{
			bigAmmoRender.ResetAmmo();
		}
		if (smallAmmoRender != null)
		{
			smallAmmoRender.ResetAmmo();
		}
		assetControler.transform.parent = AmmoParent.transform;
		assetControler.ReturnPool();
	}

	public override void Clear()
	{
		_shellContiner.Clear();
		AmmoParent = null;
		_curWholeCount = 0;
	}
}
