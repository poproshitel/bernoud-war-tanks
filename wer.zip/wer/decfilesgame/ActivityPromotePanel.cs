using UnityEngine;

public class ActivityPromotePanel : MonoBehaviour
{
	public UITexture PromotePic;

	private void Awake()
	{
		ResourcesManager.Instance.RetrieveUIMaterial(1091, PromotePic);
	}

	private void OnDestroy()
	{
	}
}
