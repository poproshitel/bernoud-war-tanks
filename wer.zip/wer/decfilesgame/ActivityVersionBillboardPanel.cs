using System;
using System.Collections.Generic;
using UnityEngine;

public class ActivityVersionBillboardPanel : ActivityRightSubBasePanel
{
	public Vector3 ShowPosition;

	private List<ActivityVersionBillboardTabButton> _allShowTabButton = new List<ActivityVersionBillboardTabButton>();

	private ActivityVersionBillboardTabButton _currentSelectedButton;

	private List<UIPageDataModel> _allPageData;

	public override void Load()
	{
		if (LoadOverCallback != null)
		{
			LoadOverCallback();
		}
	}

	public override void Open()
	{
		base.gameObject.transform.localPosition = ShowPosition;
		OnTabButtonClick(VersionBillboardTabPage.PageOne);
	}

	public override void Close()
	{
		base.gameObject.transform.localPosition = new Vector3(2000f, 2000f, 0f);
	}

	private void Awake()
	{
		InitPageData();
		VersionBillboardDataManager instance = Singleton<VersionBillboardDataManager>.Instance;
		instance.ShowPanelByTabButtonIndex = (Action<VersionBillboardTabPage>)Delegate.Combine(instance.ShowPanelByTabButtonIndex, new Action<VersionBillboardTabPage>(OnTabButtonClick));
	}

	private void OnDestroy()
	{
		_allShowTabButton.Clear();
		VersionBillboardDataManager instance = Singleton<VersionBillboardDataManager>.Instance;
		instance.ShowPanelByTabButtonIndex = (Action<VersionBillboardTabPage>)Delegate.Remove(instance.ShowPanelByTabButtonIndex, new Action<VersionBillboardTabPage>(OnTabButtonClick));
	}

	private void InitPageData()
	{
		if (_allPageData == null)
		{
			_allPageData = Singleton<VersionBillboardDataManager>.Instance.GetUIConfigInfo();
		}
		_allShowTabButton.Clear();
		for (int i = 0; i < _allPageData.Count; i++)
		{
			ActivityVersionBillboardTabButton activityVersionBillboardTabButton = new ActivityVersionBillboardTabButton();
			activityVersionBillboardTabButton.ButtonIndex = (VersionBillboardTabPage)i;
			activityVersionBillboardTabButton.FatherPanel = base.gameObject;
			_allShowTabButton.Add(activityVersionBillboardTabButton);
		}
	}

	private void OnTabButtonClick(VersionBillboardTabPage tabButtonIndex)
	{
		if ((int)tabButtonIndex >= _allPageData.Count)
		{
			TKLog.LogError("tab button count != data count, check it");
			return;
		}
		if (_currentSelectedButton != null && _currentSelectedButton.Panel != null)
		{
			_currentSelectedButton.Panel.SetActive(value: false);
		}
		ActivityVersionBillboardTabButton tabButtonByIndex = GetTabButtonByIndex((int)tabButtonIndex);
		if (tabButtonByIndex == null)
		{
			TKLog.LogError("version bill board click item is null, check it");
			return;
		}
		_currentSelectedButton = tabButtonByIndex;
		if (tabButtonByIndex.Panel != null)
		{
			tabButtonByIndex.Panel.SetActive(value: true);
		}
		else
		{
			tabButtonByIndex.RefreshPanelByTempIndex(_allPageData[(int)_currentSelectedButton.ButtonIndex].templateEnum);
		}
		tabButtonByIndex.RefreshPanel(_allPageData[(int)_currentSelectedButton.ButtonIndex]);
	}

	private ActivityVersionBillboardTabButton GetTabButtonByIndex(int index)
	{
		ActivityVersionBillboardTabButton result = null;
		foreach (ActivityVersionBillboardTabButton item in _allShowTabButton)
		{
			if (item.ButtonIndex == (VersionBillboardTabPage)index)
			{
				result = item;
				break;
			}
		}
		return result;
	}
}
