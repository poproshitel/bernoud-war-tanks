using System;
using ClientSocket;
using TK;
using UnityEngine;

[Serializable]
public class AmmoInfo
{
	public PlayerProxy ShootBy;

	public Table_Shell TableShell;

	public int ShellIndex;

	public Vector3 ShootPosition;

	public Vector3 ShootDirection;

	public Vector3 IdealPosition;

	public bool HasTouchDown;

	public long HitPlayerGuid;

	public Vector3 RealWorldPosition;

	public Vector3 RealLocalPosition;

	public Vector3 RealNormal;

	public Vector3 HitLastPosition;

	public Vector3 HitLastDirection;

	public byte HitLayerId;

	public byte HitModelId;

	public Vector3 GunFirePoint;

	public int SpecialObjectId;

	public ShootResult ShootRes = ShootResult.Error;

	private PK_RC_ShellDecal _shellDecalInfo;

	public ApSendData SendDataCache;

	public HeSendData HeSendDataCache;

	public uint TimeStamp;

	public float ShotDispersionRadiusMultiple;

	public Vector3 FireGunPos;

	private RaycastHit _hitInfo;

	private PlayerProxy _hitedPlayer;

	private DamageHE damageHE;

	public AmmoInfo(PlayerProxy pp)
	{
		ShootBy = pp;
	}

	public AmmoInfo()
	{
	}

	public void DisposeMe()
	{
		ShootBy.TankStateSync.GunSync.DisposeAmmo(GetKey());
	}

	public int GetKey()
	{
		return GetKey(TableShell.id, ShellIndex);
	}

	public static int GetKey(int shellId, int shellIndex)
	{
		return (shellId << 16) | shellIndex;
	}

	public void UpdateIdealPosition()
	{
		IdealPosition = TankTools.CalCameraOrGunHit(ShootPosition, ShootDirection, TableShell.ammo_distance, RaycastType.Gun).point;
	}

	public void ProcessAmmoHit(RaycastHit hitInfo)
	{
		_hitInfo = hitInfo;
		UpdateHitLayerModel();
		UpdateHitSpecialObjectId();
		CalculateDamage();
		if (ServerInfo.UseLegacyShooting)
		{
			DestorySceneObjs();
			SendDamageTankInfo();
			SendDamage();
		}
		if (HitPlayerGuid != 0 && ServerInfo.UseLegacyShooting)
		{
			GenerateAndSynShellDecal(send: true);
		}
		if (ServerInfo.UseLegacyShooting)
		{
			SendAmmoHitInfo();
		}
		if (SpecialObjectId >= 0 && ServerInfo.UseLegacyShooting)
		{
			SendSceneInfo();
			AmmoTools.SyncSpecialObjectSceneInfo((ushort)SpecialObjectId, RealWorldPosition);
		}
	}

	public bool OverMaxDistance(Vector3 curPosition)
	{
		return (curPosition - ShootPosition).sqrMagnitude > (float)(TableShell.ammo_distance * TableShell.ammo_distance);
	}

	public bool OverRealHitPosition(Vector3 curPostion)
	{
		return (curPostion - ShootPosition).sqrMagnitude > (GetRealHitWorldPosition() - ShootPosition).sqrMagnitude;
	}

	public Vector3 GetRealHitWorldPosition()
	{
		if (HitPlayerGuid == 0)
		{
			return RealWorldPosition;
		}
		UpdateHitRealWorldPosition();
		return RealWorldPosition;
	}

	public void UpdateHitRealWorldPosition()
	{
		if (HitPlayerGuid == 0)
		{
			return;
		}
		if (_hitedPlayer == null)
		{
			_hitedPlayer = SceneRoom.Instance.GetRoom().GetPlayerByID(HitPlayerGuid);
			if (_hitedPlayer == null)
			{
				TKLog.LogError("hit player not exsits, " + HitPlayerGuid);
				return;
			}
			if (!_hitedPlayer.IsShow || !_hitedPlayer.IsVisible)
			{
				TKLog.LogWarning("hit player not visible, " + HitPlayerGuid);
				GUITools.Log("hit player not visible, " + _hitedPlayer.name);
			}
		}
		if (_hitedPlayer.IsShow && _hitedPlayer.IsVisible)
		{
			RealWorldPosition = _hitedPlayer.Trans.TransformPoint(RealLocalPosition);
		}
	}

	public static Vector3 GetRealHitWorldPosition(long playerGuid, Vector3 position)
	{
		if (playerGuid == 0)
		{
			return position;
		}
		PlayerProxy playerByID = SceneRoom.Instance.GetRoom().GetPlayerByID(playerGuid);
		if (playerByID == null)
		{
			TKLog.LogWarning("hit player not exsits, " + playerGuid);
			return position;
		}
		return playerByID.Trans.TransformPoint(position);
	}

	public Vector3 GetRealNormalWorldDirection()
	{
		if (HitPlayerGuid == 0)
		{
			return RealNormal;
		}
		if (_hitedPlayer != null && _hitedPlayer.IsShow)
		{
			return _hitedPlayer.Trans.TransformDirection(RealNormal);
		}
		return (ShootPosition - IdealPosition).normalized;
	}

	public static Vector3 GetRealNormalWorldDirection(long playerGuid, Vector3 normal)
	{
		if (playerGuid == 0)
		{
			return normal;
		}
		PlayerProxy playerByID = SceneRoom.Instance.GetRoom().GetPlayerByID(playerGuid);
		if (playerByID == null)
		{
			TKLog.LogWarning("hit player not exsits, " + playerGuid);
			return normal;
		}
		return playerByID.Trans.TransformDirection(normal);
	}

	private void GenerateAndSynShellDecal(bool send)
	{
		EComponent eComponent = EComponent.Max;
		PlayerProxy player = TankTools.GetPlayer(_hitInfo.transform);
		if (player == null || (ShootRes != 0 && ShootRes != ShootResult.Fail && ShootRes != ShootResult.JumpBullet))
		{
			return;
		}
		Transform parent = _hitInfo.collider.transform.parent;
		TankModel tankModel = player.TankModel;
		Vector3 realPos = Vector3.zero;
		Vector3 vector = Vector3.zero;
		if (tankModel == null)
		{
			return;
		}
		if (_hitInfo.collider.transform.name == tankModel.Hull.name)
		{
			realPos = tankModel.Hull.InverseTransformPoint(RealWorldPosition);
			vector = tankModel.Hull.InverseTransformDirection(_hitInfo.normal);
			eComponent = EComponent.Hull;
		}
		else if (tankModel.Turret != null && _hitInfo.collider.transform.name == tankModel.Turret.name)
		{
			realPos = tankModel.Turret.InverseTransformPoint(RealWorldPosition);
			vector = tankModel.Turret.InverseTransformDirection(_hitInfo.normal);
			eComponent = EComponent.Turret;
		}
		else if (_hitInfo.collider.transform.name == tankModel.Gun.name)
		{
			realPos = tankModel.Gun.InverseTransformPoint(RealWorldPosition);
			vector = tankModel.Gun.InverseTransformDirection(_hitInfo.normal);
			eComponent = EComponent.Gun;
		}
		if (GameManager.Instance.GameType == GameType.Train)
		{
			send = false;
			ShootRes = ShootResult.Success;
		}
		if (eComponent != EComponent.Max)
		{
			if (send)
			{
				GameManager.RoomNetwork.SendShellDecal((short)TableShell.id, (short)ShellIndex, player.PlayerGUID, eComponent, realPos, vector);
				return;
			}
			PK_RC_ShellDecal pK_RC_ShellDecal = new PK_RC_ShellDecal();
			pK_RC_ShellDecal.PartId = (byte)eComponent;
			pK_RC_ShellDecal.RealPos = realPos;
			pK_RC_ShellDecal.HitNormal = vector;
			pK_RC_ShellDecal.ShellCaliber = TableShell.caliber;
			pK_RC_ShellDecal.TypeDecal = (byte)ShootRes;
			player.OnSynShellDecal(pK_RC_ShellDecal);
		}
	}

	public void SyncAITankShellHit(PK_RC_ShellHit msg)
	{
		ShootRes = (ShootResult)msg.ShellResult;
		if (TableShell == null)
		{
			TableShell = GameManager.TableMgr.GetShell(msg.ShellID);
			ShellIndex = msg.ShellIndex;
		}
		if (ShootBy == null)
		{
			ShootBy = SceneRoom.Instance.GetRoom().GetPlayerByID(msg.AttackPlayerGuid);
		}
		if (msg.HitPlayerGuid != 0 && _hitedPlayer == null)
		{
			_hitedPlayer = SceneRoom.Instance.GetRoom().GetPlayerByID(msg.HitPlayerGuid);
			HitPlayerGuid = HitPlayerGuid;
		}
		Vector3 tankLastShootPostion = ShootBy.TankLastShootPostion;
		Vector3 vector = msg.RealWorldPosition;
		Vector3 vector2 = Vector3.zero;
		if (_hitedPlayer != null && _hitedPlayer.IsShow && _hitedPlayer.IsVisible && _hitedPlayer.TankModel != null && _hitedPlayer.TankModel.Turret != null)
		{
			vector = _hitedPlayer.TankModel.BpTurret.position + (Vector3.down + UnityEngine.Random.onUnitSphere) * 0.2f;
			tankLastShootPostion += UnityEngine.Random.onUnitSphere * 2f;
		}
		if (msg.HitPlayerGuid == 0)
		{
			System.Random random = new System.Random();
			vector2 = new Vector3(0f, ((float)random.Next(0, 2) - 0.5f) * 2f * (0.5f + (float)random.NextDouble()), 0f);
		}
		Ray ray = new Ray(tankLastShootPostion, vector + vector2 - tankLastShootPostion);
		if (_hitedPlayer == null)
		{
			RaycastHit[] rhs = Physics.RaycastAll(ray, 800f, GameManager.EnvManager.AmmoHitWithoutTankLayerMask);
			TankTools.OrderRaycastHitResult(ref rhs);
			if (rhs.Length == 0)
			{
				RealWorldPosition = ray.GetPoint(800f);
			}
			else
			{
				_hitInfo = rhs[0];
				UpdateHitLayerModel();
			}
		}
		else if (_hitedPlayer.IsShow && _hitedPlayer.IsVisible)
		{
			TankTools.SetTankArmorActive(value: true, RaycastType.Shoot, _hitedPlayer);
			RaycastHit[] rhs2 = Physics.RaycastAll(ray, 800f, (int)GameManager.EnvManager.HitMainTankLayer | (int)GameManager.EnvManager.HitRemoteTankLayer);
			TankTools.OrderRaycastHitResult(ref rhs2);
			bool flag = false;
			for (int i = 0; i < rhs2.Length; i++)
			{
				PlayerProxy player = TankTools.GetPlayer(rhs2[i].transform);
				if (player == _hitedPlayer)
				{
					flag = true;
					_hitInfo = rhs2[i];
					break;
				}
			}
			if (flag)
			{
				UpdateHitLayerModel();
				GenerateAndSynShellDecal(send: false);
			}
			else
			{
				TKLog.LogWarning("SyncAITankShellHit hitedPlayer not hit");
				HitPlayerGuid = 0L;
				RealWorldPosition = msg.RealWorldPosition;
				RealNormal = Vector3.up;
			}
			TankTools.SetTankArmorActive(value: false, RaycastType.Shoot, _hitedPlayer);
		}
		msg.HitLayer = HitLayerId;
		msg.HitModel = HitModelId;
		msg.HitPlayerGuid = HitPlayerGuid;
		msg.RealWorldPosition = RealWorldPosition;
		msg.RealLocalPosition = RealLocalPosition;
		msg.HitNormal = RealNormal;
	}

	private void UpdateHitLayerModel()
	{
		if (_hitInfo.collider == null)
		{
			HitLayerId = 100;
			HitModelId = 14;
			HitPlayerGuid = 0L;
			RealWorldPosition = IdealPosition;
			RealLocalPosition = IdealPosition;
			RealNormal = Vector3.up;
			return;
		}
		HitPlayerGuid = 0L;
		RealWorldPosition = _hitInfo.point;
		RealLocalPosition = RealWorldPosition;
		RealNormal = _hitInfo.normal;
		Transform transform = _hitInfo.collider.transform;
		HitLastDirection = ShootDirection;
		HitLastPosition = RealWorldPosition - HitLastDirection.normalized * 5f;
		if (GameManager.EnvManager.IsTank(transform.gameObject.layer))
		{
			HitLayerId = 8;
			HitModelId = 0;
			_hitedPlayer = TankTools.GetPlayer(_hitInfo.transform);
			if (_hitedPlayer != null)
			{
				HitPlayerGuid = _hitedPlayer.PlayerGUID;
				RealLocalPosition = _hitedPlayer.Trans.InverseTransformPoint(RealWorldPosition);
				RealNormal = _hitedPlayer.Trans.InverseTransformDirection(_hitInfo.normal);
			}
		}
		else if (transform.gameObject.layer == 10)
		{
			HitLayerId = 10;
			HitModelId = 0;
		}
		else
		{
			HitLayerId = 100;
			if (CommonTools.GetModelType(_hitInfo.transform.name, out var id))
			{
				HitModelId = (byte)id;
			}
			else
			{
				HitModelId = 14;
			}
		}
	}

	private void CalculateDamage()
	{
		int kind = TableShell.kind;
		switch ((ShellType)kind)
		{
		case ShellType.He:
			ShootRes = ShootResult.He;
			damageHE = new DamageHE();
			damageHE.CalHEDamage(RealWorldPosition + GetRealNormalWorldDirection() * 0.1f, this);
			break;
		case ShellType.Ap:
		case ShellType.ApCr:
		case ShellType.Heat:
			ShootRes = DamageAP.CalApDamage(this);
			if (SendDataCache != null)
			{
				SendDataCache.Dis[0] = Vector3.Distance(RealWorldPosition, ShootPosition);
				if (HitPlayerGuid == 0)
				{
					TKLog.LogError("HitPlayerGuid=0 ApDamage");
				}
			}
			break;
		case ShellType.Laser:
			ShootRes = DamageAP.CalApDamage(this);
			if (SendDataCache != null)
			{
				SendDataCache.Dis[0] = Vector3.Distance(RealWorldPosition, ShootPosition);
				if (HitPlayerGuid == 0)
				{
					TKLog.LogError("HitPlayerGuid=0 ApDamage");
				}
			}
			break;
		default:
			TKLog.LogError("DamageType Error, TableShell.kind = " + kind);
			break;
		}
	}

	private void DestorySceneObjs()
	{
		int kind = TableShell.kind;
		if ((decimal)kind == 2m)
		{
			Vector3 worldPos = RealWorldPosition + GetRealNormalWorldDirection() * 0.1f;
			GameObject gameObject = new GameObject("Destroy Scene Obj Collider");
			gameObject.AddComponent<HeDestroySceneObj>().Init(worldPos, TableShell.explode_radius);
		}
	}

	private void SendDamage()
	{
		if (HeSendDataCache != null)
		{
			damageHE.SendHEDamage((short)TableShell.id, (short)ShellIndex);
		}
		else if (SendDataCache != null)
		{
			if (TableShell.kind == 6)
			{
				GameManager.RoomNetwork.SendLaserDamage((short)TableShell.id, (short)ShellIndex, SendDataCache.PlayerGuid, SendDataCache.Type, SendDataCache.Ind, SendDataCache.HitPoint, SendDataCache.Dis, SendDataCache.Angle);
			}
			else
			{
				GameManager.RoomNetwork.SendAPDamage((short)TableShell.id, (short)ShellIndex, SendDataCache.PlayerGuid, SendDataCache.Type, SendDataCache.Ind, SendDataCache.HitPoint, SendDataCache.Dis, SendDataCache.Angle);
			}
		}
	}

	private void SendDamageTankInfo()
	{
		if (SendDataCache != null)
		{
			PK_HitTankInfo hitTankInfo = AmmoTools.GetHitTankInfo(SendDataCache.PlayerGuid);
			if (hitTankInfo != null)
			{
				PK_HitTankInfo[] infos = new PK_HitTankInfo[1] { hitTankInfo };
				GameManager.RoomNetwork.SendDamageTankInfos((short)TableShell.id, (short)ShellIndex, HitLastPosition, HitLastDirection, infos);
			}
		}
		else if (HeSendDataCache == null)
		{
		}
	}

	private void UpdateHitSpecialObjectId()
	{
		Transform transform = _hitInfo.transform;
		if (transform != null && GameManager.EnvManager.IsSpecialObjectByAmmo(transform.gameObject.layer))
		{
			if (CommonTools.GetModelNum(transform.name, out var num))
			{
				SpecialObjectId = num;
			}
			else
			{
				SpecialObjectId = -1;
			}
		}
	}

	public void SendAmmoHitInfo()
	{
		GameManager.RoomNetwork.SendShellHit(this);
	}

	public void SendSceneInfo()
	{
		GameManager.RoomNetwork.SendSceneInfo((ushort)SpecialObjectId, RealWorldPosition, 0);
	}

	private void LocalVerifyDamageAP()
	{
		PlayerProxy playerByID = SceneRoom.Instance.GetRoom().GetPlayerByID(HitPlayerGuid);
		PK_RC_VerifyDamageAP pK_RC_VerifyDamageAP = new PK_RC_VerifyDamageAP();
		pK_RC_VerifyDamageAP.DamagedCount = (byte)SendDataCache.Type.Length;
		pK_RC_VerifyDamageAP.LastPosition = HitLastPosition;
		pK_RC_VerifyDamageAP.LastDirection = HitLastDirection;
		pK_RC_VerifyDamageAP.Distance = SendDataCache.Dis;
		pK_RC_VerifyDamageAP.AssemblyIndex = SendDataCache.Ind;
		pK_RC_VerifyDamageAP.AssemblyType = SendDataCache.Type;
		pK_RC_VerifyDamageAP.GunId = (short)playerByID.TankData.MainGunID;
		pK_RC_VerifyDamageAP.TurretId = (short)playerByID.TankData.TurretID;
		pK_RC_VerifyDamageAP.VehicleId = (short)playerByID.TankData.VehicleId;
		pK_RC_VerifyDamageAP.HullId = (short)playerByID.TankData.HullID;
		pK_RC_VerifyDamageAP.VerifyId = GetKey();
		pK_RC_VerifyDamageAP.GunAngle = playerByID.TankStateSync.GunSync.CurAngle;
		pK_RC_VerifyDamageAP.MendAngle = SendDataCache.Angle;
		pK_RC_VerifyDamageAP.ShellId = (short)TableShell.id;
		pK_RC_VerifyDamageAP.Pos = playerByID.Trans.position;
		pK_RC_VerifyDamageAP.Rotation = playerByID.Trans.eulerAngles;
		pK_RC_VerifyDamageAP.TurretAngle = playerByID.TankStateSync.TurretSync.CurAngle;
		pK_RC_VerifyDamageAP.HullAngle = playerByID.TankModel.Hull.localEulerAngles;
		Singleton<VerifyManager>.Instance.VerifyDamageAP(pK_RC_VerifyDamageAP);
	}

	private void LocalVerifyDamageHE()
	{
	}
}
