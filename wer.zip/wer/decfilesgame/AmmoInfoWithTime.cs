public class AmmoInfoWithTime
{
	public AmmoInfo Ammo;

	public float RealFireTime;
}
