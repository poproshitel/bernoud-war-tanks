using System.Collections.Generic;

public class AmmoEvnet : Singleton<AmmoEvnet>
{
	private Dictionary<AmmoStateType, List<AmmoEventHandler>> _eventTable;

	public AmmoEvnet()
	{
		_eventTable = new Dictionary<AmmoStateType, List<AmmoEventHandler>>();
		_eventTable.Clear();
	}

	public void AddListener(AmmoStateType name, AmmoEventHandler obj)
	{
		if (_eventTable.ContainsKey(name))
		{
			_eventTable[name].Add(obj);
			return;
		}
		List<AmmoEventHandler> list = new List<AmmoEventHandler>();
		list.Add(obj);
		List<AmmoEventHandler> list2 = list;
		list2.Clear();
		list2.Add(obj);
		_eventTable.Add(name, list2);
	}

	public void RemoveListener(AmmoStateType name)
	{
		if (_eventTable.ContainsKey(name))
		{
			_eventTable.Remove(name);
		}
	}

	public void RemoveListener(AmmoStateType name, AmmoEventHandler func)
	{
		if (_eventTable.ContainsKey(name))
		{
			_eventTable[name].Remove(func);
		}
	}

	public void OnEvent(AmmoStateType name, CAmmoStateParam info)
	{
		if (!_eventTable.ContainsKey(name))
		{
			return;
		}
		List<AmmoEventHandler> list = _eventTable[name];
		foreach (AmmoEventHandler item in list)
		{
			item.OnEvent(info);
		}
	}
}
