using System.Collections.Generic;

public class AccProData<T> where T : AccProItem
{
	public string PlayerName;

	public string AccountCreationTime;

	public int MaxKillVehicleId;

	public int MaxExpVehicleId;

	public int MaxRoundVehicleId;

	public int MaxScoreVehicleId;

	public List<T> DataItemList;
}
