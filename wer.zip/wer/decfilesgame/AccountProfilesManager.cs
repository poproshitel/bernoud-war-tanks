using System;
using System.Collections.Generic;
using ClientSocket;

public class AccountProfilesManager : Singleton<AccountProfilesManager>
{
	public bool PersonalProfilesHasChanged;

	public Action OnPersonalProfilesChange;

	private AccProData<AccProItem> _apDataNml;

	private AccProData<AccProItem> _apDataRvv;

	private AccProData<AccProItem> _apDataPVE;

	private AccProData<AccProItem> _apDataCommander;

	public AccProData<AccProItem> ApDataNml => _apDataNml;

	public AccProData<AccProItem> ApDataRvv => _apDataRvv;

	public AccProData<AccProItem> ApDataCommander => _apDataCommander;

	public AccProData<AccProItem> ApDataPVE => _apDataPVE;

	public int GetTotalBattleCount()
	{
		int num = 0;
		if (_apDataNml != null && _apDataNml.DataItemList != null && _apDataNml.DataItemList.Count > 0)
		{
			num += _apDataNml.DataItemList[0].BattleCount;
		}
		if (_apDataRvv != null && _apDataRvv.DataItemList != null && _apDataRvv.DataItemList.Count > 0)
		{
			num += _apDataRvv.DataItemList[0].BattleCount;
		}
		if (_apDataCommander != null && _apDataCommander.DataItemList != null && _apDataCommander.DataItemList.Count > 0)
		{
			num += _apDataCommander.DataItemList[0].BattleCount;
		}
		if (_apDataPVE != null && _apDataPVE.DataItemList != null && _apDataPVE.DataItemList.Count > 0)
		{
			num += _apDataPVE.DataItemList[0].BattleCount;
		}
		return num;
	}

	public int GetBattleCountInStandardMode(int tankID)
	{
		if (_apDataNml == null || _apDataNml.DataItemList == null)
		{
			return 0;
		}
		for (int i = 0; i < _apDataNml.DataItemList.Count; i++)
		{
			if (_apDataNml.DataItemList[i].VehicleId == tankID)
			{
				return _apDataNml.DataItemList[i].BattleCount;
			}
		}
		return 0;
	}

	public int GetPlayerAllBattleCountInStandardMode()
	{
		int num = 0;
		if (_apDataNml != null && _apDataNml.DataItemList != null && _apDataNml.DataItemList.Count > 0)
		{
			num += _apDataNml.DataItemList[0].BattleCount;
		}
		return num;
	}

	private int GetBattleCount(AccProData<AccProItem> pd)
	{
		if (pd != null && pd.DataItemList != null && pd.DataItemList.Count > 0)
		{
			return pd.DataItemList[0].BattleCount;
		}
		return 0;
	}

	public void HandleAccountStatistics(PK_HC_AccountStatistic msg)
	{
		_apDataNml = HandleAccountStatisticsProxy(msg.AccountUserData, msg.ItemList, msg.ItemCount, _apDataNml);
		_apDataNml.DataItemList.Sort(AccProItem.SortByBattleCount);
	}

	public void HandleAccountStatisticsRelive(PK_HC_AccountStatisticRevive msg)
	{
		_apDataRvv = HandleAccountStatisticsProxy(msg.AccountUserData, msg.ItemList, msg.ItemCount, _apDataRvv);
		_apDataRvv.DataItemList.Sort(AccProItem.SortByBattleCount);
	}

	public void HandleAccountStatisticsCommander(PK_HC_AccountStatisticCommander msg)
	{
		_apDataCommander = HandleAccountStatisticsProxy(msg.AccountUserData, msg.ItemList, msg.ItemCount, _apDataCommander);
		_apDataCommander.DataItemList.Sort(AccProItem.SortByBattleCount);
	}

	public void HandleAccountStatisticsPVE(PK_HC_AccountStatisticPVE msg)
	{
		_apDataPVE = HandleAccountStatisticsProxy(msg.AccountUserData, msg.ItemList, msg.ItemCount, _apDataPVE);
		_apDataPVE.DataItemList.Sort(AccProItem.SortByBattleCount);
	}

	private AccProData<AccProItem> HandleAccountStatisticsProxy<T>(AccountUserDataModel accountUserData, IList<T> itemList, int itemCount, AccProData<AccProItem> personalProfiles) where T : AccProItem
	{
		PersonalProfilesHasChanged = true;
		if (personalProfiles == null)
		{
			AccProData<AccProItem> accProData = new AccProData<AccProItem>();
			accProData.PlayerName = accountUserData.PlayerName;
			accProData.AccountCreationTime = CommonTools.GetDataStringFormSeconds((int)accountUserData.CreationTime);
			accProData.DataItemList = new List<AccProItem>(itemCount);
			personalProfiles = accProData;
			foreach (T item in itemList)
			{
				T current = item;
				current.Calculate();
				personalProfiles.DataItemList.Add(current);
			}
			FillPersonalProfiles<T>(personalProfiles);
		}
		else
		{
			if (itemCount != 2)
			{
				TKLog.Log("更新的玩家统计信息不是两条");
				return null;
			}
			List<AccProItem> dataItemList = personalProfiles.DataItemList;
			T val = itemList[0];
			dataItemList[0] = val.Calculate();
			int updateId = itemList[1].VehicleId;
			int num = personalProfiles.DataItemList.FindIndex((AccProItem obj) => obj.VehicleId == updateId);
			if (num > 0)
			{
				List<AccProItem> dataItemList2 = personalProfiles.DataItemList;
				T val2 = itemList[1];
				dataItemList2[num] = val2.Calculate();
			}
			else if (num == 0)
			{
				TKLog.Log("更新的账号信息有误");
			}
			else
			{
				List<AccProItem> dataItemList3 = personalProfiles.DataItemList;
				T val3 = itemList[1];
				dataItemList3.Add(val3.Calculate());
			}
		}
		personalProfiles.MaxExpVehicleId = accountUserData.MaxExpVehicleId;
		personalProfiles.MaxKillVehicleId = accountUserData.MaxKillVehicleId;
		personalProfiles.MaxRoundVehicleId = accountUserData.MaxRoundVehicleId;
		personalProfiles.MaxScoreVehicleId = accountUserData.MaxScoreVehicleId;
		if (OnPersonalProfilesChange != null)
		{
			OnPersonalProfilesChange();
		}
		return personalProfiles;
	}

	private void FillPersonalProfiles<T>(AccProData<AccProItem> personalProfiles) where T : AccProItem
	{
		Dictionary<int, bool> dictionary = new Dictionary<int, bool>();
		foreach (AccProItem dataItem in personalProfiles.DataItemList)
		{
			dictionary.Add(dataItem.VehicleId, value: true);
		}
		foreach (Tank hallTank in GameManager.Player.HallTanks)
		{
			if (!dictionary.ContainsKey(hallTank.TankData.VehicleId))
			{
				AccProItem accProItem = new T
				{
					VehicleId = hallTank.TankData.VehicleId
				};
				personalProfiles.DataItemList.Add(accProItem.Calculate());
			}
		}
	}

	public void FillPersonalProfilesWhenUpdateTankInfo()
	{
		FillPersonalProfiles<AccProItemForNmlRvv>(_apDataNml);
		FillPersonalProfiles<AccProItemForNmlRvv>(_apDataRvv);
		FillPersonalProfiles<AccProItemForPVE>(_apDataPVE);
		FillPersonalProfiles<AccProItemForNmlRvv>(_apDataCommander);
	}

	public byte GetNmlTankMedalLevel(int vehicleId)
	{
		if (_apDataNml != null && _apDataNml.DataItemList.Find((AccProItem obj) => obj.VehicleId == vehicleId) is AccProItemForNmlRvv accProItemForNmlRvv)
		{
			return accProItemForNmlRvv.MedalLevel;
		}
		return 0;
	}

	public bool PersonalVehicleHasBattleHistory(int vehicleId)
	{
		if (_apDataNml != null && _apDataNml.DataItemList.Find((AccProItem obj) => obj != null && obj.VehicleId == vehicleId) is AccProItemForNmlRvv { BattleCount: >0 })
		{
			return true;
		}
		if (_apDataRvv != null && _apDataRvv.DataItemList.Find((AccProItem obj) => obj != null && obj.VehicleId == vehicleId) is AccProItemForNmlRvv { BattleCount: >0 })
		{
			return true;
		}
		if (_apDataCommander != null && _apDataCommander.DataItemList.Find((AccProItem obj) => obj != null && obj.VehicleId == vehicleId) is AccProItemForNmlRvv { BattleCount: >0 })
		{
			return true;
		}
		if (_apDataPVE != null && _apDataPVE.DataItemList.Find((AccProItem obj) => obj != null && obj.VehicleId == vehicleId) is AccProItemForPVE { BattleCount: >0 })
		{
			return true;
		}
		return false;
	}
}
