public class AreaButtonTipListener : ToolTipsListen
{
	protected override void OnHover(bool isOver)
	{
	}

	public void SetOnHover(bool isOver)
	{
		base.OnHover(isOver);
	}
}
