using System;
using UnityEngine;

public class ActivityRightSubBasePanel : MonoBehaviour
{
	protected Vector3 ShowPageLocalPositon = new Vector3(0f, 0f, 0f);

	protected Vector3 HidePageLocalPositon = new Vector3(2000f, 0f, 0f);

	public Action LoadOverCallback;

	public Action<bool> RefreshActivity;

	public virtual void Load()
	{
	}

	public virtual void Close()
	{
	}

	public virtual void Open()
	{
	}
}
