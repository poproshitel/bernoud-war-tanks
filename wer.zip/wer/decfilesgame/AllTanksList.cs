using UnityEngine;

public class AllTanksList : MonoBehaviour
{
	public UIPanel AllTankListPanle;

	public GameObject Button;

	private int _buttonNum;

	public GameObject Target;

	private void Start()
	{
		_buttonNum = 0;
	}

	public void Init(GameObject target)
	{
		Target = target;
		UIPanel component = AllTankListPanle.GetComponent<UIPanel>();
		component.clipRange = new Vector4(333.7f, -130.7f, 679.6f, 328f);
		component.transform.localPosition = new Vector3(0f, -28.68988f, 0f);
	}

	public GameObject AddButton(Tank tank, int index)
	{
		float num = -(_buttonNum / 5 * 85);
		GameObject gameObject = NGUITools.AddChild(AllTankListPanle.gameObject, Button);
		Vector3 localPosition = gameObject.transform.localPosition;
		float x = (float)(_buttonNum % 5 * 135) + 67.5f;
		localPosition.x = x;
		localPosition.y += num;
		localPosition.z = -0.1f;
		gameObject.transform.localPosition = localPosition;
		SetButtonMessage(gameObject, tank, index);
		_buttonNum++;
		return gameObject;
	}

	public void SetButtonMessage(GameObject go, Tank tank, int index)
	{
		TankProjectListButton component = go.GetComponent<TankProjectListButton>();
		component.enabled = false;
		TankProjectAllButton component2 = go.GetComponent<TankProjectAllButton>();
		component2.enabled = true;
		if (component2 == null)
		{
			TKLog.Log("button dosn't hanve componete TankListButtonMessage");
			return;
		}
		component2.Index = index;
		component2.target = Target;
		component2.Tank = tank;
		component.Index = index;
		component.target = Target;
		component.Tank = tank;
		Table_Vehicle vehicle = GameManager.TableMgr.GetVehicle(tank.TankData.VehicleId);
		if (vehicle == null)
		{
			TKLog.Log("dosn't have Vehice table by tanID " + tank.TankData.VehicleId);
			return;
		}
		string tankName = vehicle.name;
		int level = vehicle.level;
		string bigicon = vehicle.bigicon;
		int type = vehicle.type;
		int nation = vehicle.nation;
		component2.Init(tank, nation, bigicon, type, tankName, level);
	}

	public void AllTankDestroy()
	{
		_buttonNum = 0;
	}
}
