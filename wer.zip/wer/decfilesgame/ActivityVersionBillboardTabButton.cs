using UnityEngine;

public class ActivityVersionBillboardTabButton
{
	public VersionBillboardTabPage ButtonIndex;

	public GameObject FatherPanel;

	public GameObject Panel;

	private bool _hasInit;

	public void RefreshPanelByTempIndex(UIBillboardTabPageTempEnum tempEnum)
	{
		if (Panel != null)
		{
			Object.Destroy(Panel);
		}
		GameObject pageTemp = PageTempManager.Instance.GetPageTemp(tempEnum);
		if (pageTemp != null)
		{
			Panel = Object.Instantiate(pageTemp);
			Panel.transform.parent = FatherPanel.transform;
			Panel.transform.localScale = new Vector3(1f, 1f, 1f);
			Panel.transform.localPosition = default(Vector3);
		}
	}

	public void RefreshPanel(UIPageDataModel pageData)
	{
		if (!(Panel != null))
		{
			return;
		}
		UIBillboardTabPage component = Panel.GetComponent<UIBillboardTabPage>();
		if (!(component == null))
		{
			if (!_hasInit)
			{
				component.Refresh(pageData);
				_hasInit = true;
			}
			else
			{
				component.ResetScrollBar();
			}
		}
	}
}
