using UnityEngine;

public class AmmoStateHitError : AmmoStateBase
{
	private float _dirX;

	private float _dirY;

	private float _timecount;

	public AmmoStateHitError()
	{
		_timecount = 0f;
	}

	public override void EnterState(CAmmoStateParam param)
	{
		_dirX = Random.Range(300, 340);
		_dirY = param.Trans.eulerAngles.y + (float)Random.Range(-90, 90);
		param.Trans.eulerAngles = new Vector3(_dirX, _dirY, param.Trans.transform.eulerAngles.z);
		ResourcesManager.Particle.Emit(439, param.Ammo.GetRealHitWorldPosition(), param.Ammo.GetRealNormalWorldDirection());
	}

	public override bool UpdateState(CAmmoStateParam param)
	{
		_timecount += Time.fixedDeltaTime * 20f;
		param.Trans.position += param.Trans.transform.forward * 5f;
		if (_timecount > 10f)
		{
			return true;
		}
		return false;
	}

	public override void LeaveState(CAmmoStateParam param, ref AmmoStateType nextstate)
	{
		nextstate = AmmoStateType.Bomb;
	}
}
