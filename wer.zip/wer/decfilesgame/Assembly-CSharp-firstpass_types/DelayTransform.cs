using System;
using UnityEngine;

[Serializable]
public class DelayTransform
{
	public EffectTimeDelayMode ModeSet;

	public float TimeDelay;

	public Transform Trans;
}
