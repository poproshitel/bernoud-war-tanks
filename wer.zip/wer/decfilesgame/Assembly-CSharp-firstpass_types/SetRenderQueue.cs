using UnityEngine;

[ExecuteInEditMode]
public class SetRenderQueue : MonoBehaviour
{
	public RenderQueue[] RenderQueues;

	private void Start()
	{
		if (RenderQueues == null)
		{
			return;
		}
		for (int i = 0; i < RenderQueues.Length; i++)
		{
			RenderQueue renderQueue = RenderQueues[i];
			if (renderQueue == null || !(renderQueue.Renderer != null))
			{
				continue;
			}
			Material[] sharedMaterials = renderQueue.Renderer.sharedMaterials;
			if (sharedMaterials == null || sharedMaterials.Length <= 0)
			{
				continue;
			}
			foreach (Material material in sharedMaterials)
			{
				if (material != null && material.shader != null)
				{
					material.renderQueue = material.shader.renderQueue + renderQueue.RendererDepth;
				}
			}
		}
	}
}
