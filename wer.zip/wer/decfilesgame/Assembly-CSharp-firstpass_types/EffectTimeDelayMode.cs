public enum EffectTimeDelayMode
{
	None,
	GameObjectOn,
	GameObjectOff,
	EmitterOn,
	EmitterOff,
	AnimationStart,
	AnimationStop
}
