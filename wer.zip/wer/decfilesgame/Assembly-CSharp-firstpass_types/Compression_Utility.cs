using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using ICSharpCode.SharpZipLib.GZip;

namespace Compression;

public class Utility
{
	public static byte[] Compress(byte[] buffer)
	{
		MemoryStream memoryStream = new MemoryStream();
		GZipOutputStream gZipOutputStream = new GZipOutputStream(memoryStream);
		gZipOutputStream.Write(buffer, 0, buffer.Length);
		gZipOutputStream.IsStreamOwner = false;
		gZipOutputStream.Close();
		memoryStream.Seek(0L, SeekOrigin.Begin);
		byte[] array = new byte[memoryStream.Length];
		memoryStream.Read(array, 0, array.Length);
		return array;
	}

	public static string Compress2(string text)
	{
		byte[] bytes = Encoding.UTF8.GetBytes(text);
		MemoryStream memoryStream = new MemoryStream();
		GZipOutputStream gZipOutputStream = new GZipOutputStream(memoryStream);
		gZipOutputStream.Write(bytes, 0, bytes.Length);
		gZipOutputStream.IsStreamOwner = false;
		gZipOutputStream.Close();
		memoryStream.Seek(0L, SeekOrigin.Begin);
		byte[] array = new byte[memoryStream.Length];
		memoryStream.Read(array, 0, array.Length);
		return Convert.ToBase64String(array);
	}

	public static List<byte> DecompressToBytes(byte[] bytes)
	{
		byte[] array = new byte[65536];
		List<byte> list = new List<byte>();
		using MemoryStream baseInputStream = new MemoryStream(bytes, writable: false);
		using GZipInputStream gZipInputStream = new GZipInputStream(baseInputStream);
		while (true)
		{
			int num = 0;
			try
			{
				num = gZipInputStream.Read(array, 0, array.Length);
			}
			catch (GZipException)
			{
			}
			if (num == 0)
			{
				break;
			}
			for (int i = 0; i < num; i++)
			{
				list.Add(array[i]);
			}
		}
		return list;
	}

	public static string Decompress(byte[] bytes)
	{
		MemoryStream baseInputStream = new MemoryStream(bytes, writable: false);
		GZipInputStream gZipInputStream = new GZipInputStream(baseInputStream);
		byte[] array = new byte[65536];
		char[] array2 = new char[65536];
		Decoder decoder = Encoding.UTF8.GetDecoder();
		StringBuilder stringBuilder = new StringBuilder();
		long num = 0L;
		try
		{
			while (true)
			{
				int num2 = gZipInputStream.Read(array, 0, array.Length);
				if (num2 == 0)
				{
					break;
				}
				num += num2;
				int chars = decoder.GetChars(array, 0, num2, array2, 0);
				stringBuilder.Append(array2, 0, chars);
			}
		}
		catch (GZipException)
		{
		}
		gZipInputStream.Close();
		return stringBuilder.ToString();
	}
}
