using System;
using UnityEngine;

public class FlashLight : MonoBehaviour
{
	private const float FlashIntervalCfg = 10f;

	private const float FlashIntervalRand = 0.2f;

	public AudioSource AudioSrc;

	private float _flashEllapse;

	private float _flashInterfalThisTm = 10f;

	private void Start()
	{
		_flashInterfalThisTm = 10f * (1f + UnityEngine.Random.Range(-0.2f, 0.2f));
	}

	private void Update()
	{
		_flashEllapse += Time.deltaTime;
		if (_flashEllapse > _flashInterfalThisTm)
		{
			_flashEllapse = 0f;
			_flashInterfalThisTm = 10f * (1f + UnityEngine.Random.Range(-0.2f, 0.2f));
			Flash();
			int min = 154350;
			int max = 198450;
			AudioSrc.Play(Convert.ToUInt64(UnityEngine.Random.Range(min, max)));
		}
	}

	private void Flash()
	{
		GetComponent<Animation>().Play("dengshan");
	}
}
