using UnityEngine;

[ExecuteInEditMode]
[AddComponentMenu("Image Effects/Grayscale")]
public class GrayscaleEffect : ImageEffectBase
{
	public float RampOffset;

	public Texture TextureRamp;

	public void OnRenderImageFun(RenderTexture source, RenderTexture destination)
	{
		base.material.SetTexture("_RampTex", TextureRamp);
		base.material.SetFloat("_RampOffset", RampOffset);
		Graphics.Blit(source, destination, base.material);
	}
}
