using System.Collections;
using UnityEngine;

public class EffectTimeDelay : MonoBehaviour
{
	public DelayTransform[] DelayTransforms;

	private void Start()
	{
		if (DelayTransforms == null || DelayTransforms.Length == 0)
		{
			return;
		}
		DelayTransform[] delayTransforms = DelayTransforms;
		foreach (DelayTransform delayTransform in delayTransforms)
		{
			if (!(delayTransform.Trans == null) && delayTransform.ModeSet != 0)
			{
				StartCoroutine("OnEffectEventFire", delayTransform);
			}
		}
	}

	private IEnumerator OnEffectEventFire(DelayTransform delayTransform)
	{
		yield return new WaitForSeconds(delayTransform.TimeDelay);
		EffectTimeDelayMode modeSet = delayTransform.ModeSet;
		Transform trans = delayTransform.Trans;
		switch (modeSet)
		{
		case EffectTimeDelayMode.GameObjectOn:
			trans.gameObject.SetActive(value: true);
			break;
		case EffectTimeDelayMode.GameObjectOff:
			trans.gameObject.SetActive(value: false);
			break;
		case EffectTimeDelayMode.EmitterOn:
		{
			ParticleEmitter[] componentsInChildren = trans.GetComponentsInChildren<ParticleEmitter>();
			ParticleEmitter[] array = componentsInChildren;
			foreach (ParticleEmitter particleEmitter in array)
			{
				particleEmitter.emit = true;
			}
			break;
		}
		case EffectTimeDelayMode.EmitterOff:
		{
			ParticleEmitter[] componentsInChildren2 = trans.GetComponentsInChildren<ParticleEmitter>();
			ParticleEmitter[] array2 = componentsInChildren2;
			foreach (ParticleEmitter particleEmitter2 in array2)
			{
				particleEmitter2.emit = false;
			}
			break;
		}
		case EffectTimeDelayMode.AnimationStart:
			if (trans.GetComponent<Animation>() != null)
			{
				trans.GetComponent<Animation>().Play();
			}
			break;
		case EffectTimeDelayMode.AnimationStop:
			if (trans.GetComponent<Animation>() != null)
			{
				trans.GetComponent<Animation>().Stop();
			}
			break;
		}
	}
}
