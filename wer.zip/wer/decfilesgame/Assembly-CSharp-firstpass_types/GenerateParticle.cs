using UnityEngine;

public class GenerateParticle : MonoBehaviour
{
	public GameObject P;

	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.E))
		{
			Object.Instantiate(P);
		}
	}
}
