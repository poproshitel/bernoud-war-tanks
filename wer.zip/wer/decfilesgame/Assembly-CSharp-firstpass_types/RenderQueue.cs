using System;
using UnityEngine;

[Serializable]
public class RenderQueue
{
	public Renderer Renderer;

	public int RendererDepth;
}
