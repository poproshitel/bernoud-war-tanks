using UnityEngine;

public class MedalEffectHelp : MonoBehaviour
{
	public GameObject[] xunzhang;

	public GameObject liuguang;

	public Texture TestMedalTexture;

	public Texture TestMaskTexture;

	public bool TestModel;

	private void Awake()
	{
		if (TestModel)
		{
			UpdateMedalMaterTexture(TestMedalTexture);
			UpdateMaterialMask(TestMaskTexture);
		}
	}

	public void UpdateMedalMaterTexture(Texture MedalTexture)
	{
		GameObject[] array = xunzhang;
		foreach (GameObject go in array)
		{
			ChangeMaterialTexture(go, MedalTexture);
		}
	}

	public void ChangeMaterialTexture(GameObject go, Texture MedalTexture)
	{
		if (!(MedalTexture == null) && (go.GetComponent<Renderer>() != null || go.GetComponent<Renderer>().material != null))
		{
			go.GetComponent<Renderer>().material.mainTexture = MedalTexture;
		}
	}

	public void UpdateMaterialMask(Texture MaskTexture)
	{
		if (!(MaskTexture == null))
		{
			liuguang.GetComponent<Renderer>().material.SetTexture("_Mask", MaskTexture);
		}
	}
}
