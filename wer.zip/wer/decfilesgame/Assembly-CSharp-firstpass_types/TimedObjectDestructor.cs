using UnityEngine;

public class TimedObjectDestructor : MonoBehaviour
{
	public float Time;

	public bool DetchChildren;

	private void Start()
	{
		Invoke("DestroyNow", Time);
	}

	private void DestroyNow()
	{
		if (DetchChildren)
		{
			base.transform.DetachChildren();
		}
		Object.DestroyObject(base.gameObject);
	}
}
