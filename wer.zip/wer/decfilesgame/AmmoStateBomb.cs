public class AmmoStateBomb : AmmoStateBase
{
	public override void EnterState(CAmmoStateParam param)
	{
		if (param.Ammo.ShootRes == ShootResult.Success || param.Ammo.ShootRes == ShootResult.Error || param.Ammo.ShootRes == ShootResult.Chassis || param.Ammo.ShootRes == ShootResult.He)
		{
			AmmoTools.DoAmmoAudioAndEffect(param.Ammo.TableShell, param.Ammo.HitLayerId, param.Ammo.HitModelId, param.Ammo.GetRealHitWorldPosition(), param.Ammo.GetRealNormalWorldDirection(), param.Ammo.ShootRes);
		}
		if (param.AmmoEntity != null && param.SmokeEnt != null)
		{
			param.AmmoEntity.gameObject.SetActive(value: false);
		}
		param.Ammo.DisposeMe();
		param.LiveTime = 0f;
	}

	public override bool UpdateState(CAmmoStateParam param)
	{
		return true;
	}

	public override void LeaveState(CAmmoStateParam param, ref AmmoStateType nextstate)
	{
		nextstate = AmmoStateType.Destroy;
	}
}
