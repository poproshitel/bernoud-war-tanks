namespace AnimationOrTween;

public enum Trigger
{
	OnClick,
	OnHover,
	OnPress,
	OnHoverTrue,
	OnHoverFalse,
	OnPressTrue,
	OnPressFalse
}
