public enum ActivityTypeForRewardListItem
{
	SingleRechargeBonus,
	AccumulateRechargeBonus
}
