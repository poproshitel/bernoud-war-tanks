using UnityEngine;

public class AdujustTroopsButton : MonoBehaviour
{
	public Transform TargetButtonTransformLeft;

	public Transform TargetButtonTransformRight;

	private Transform _myTransl;

	private void Awake()
	{
		_myTransl = base.transform;
		OnChangeScreenHandle();
	}

	private void OnChangeScreenHandle()
	{
		_myTransl.localPosition = new Vector3(TargetButtonTransformLeft.localPosition.x + (TargetButtonTransformRight.localPosition.x - TargetButtonTransformLeft.localPosition.x) / 2f, -285f, -1f);
	}
}
