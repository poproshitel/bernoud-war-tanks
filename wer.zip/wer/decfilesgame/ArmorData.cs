using UnityEngine;

public class ArmorData : MonoBehaviour
{
	public int[] ArmorIds;
}
