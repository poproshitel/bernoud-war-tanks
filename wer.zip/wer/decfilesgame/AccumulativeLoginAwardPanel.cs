using System.Collections.Generic;
using UnityEngine;

public class AccumulativeLoginAwardPanel : UIBase
{
	public ProcessStateControl ProcessStatePrefab;

	public Transform ItemsListTrans;

	public Transform StateItemsListTrans;

	public List<GameObject> ProcessList;

	public List<AccumulativeItemControl> ItemList = new List<AccumulativeItemControl>();

	public UITexture GotTexture;

	public UILabel Day1Label;

	public UILabel Day2Label;

	public UILabel Day3Label;

	public UILabel NoteLabel;

	private List<AccumulativeItemControl> _itemList = new List<AccumulativeItemControl>();

	private List<ProcessStateControl> _stateItemList = new List<ProcessStateControl>();

	private List<Table_Reward> _rewardList = new List<Table_Reward>();

	private AccumulativeLoginDataManager data = Singleton<AccumulativeLoginDataManager>.Instance;

	private int[] picIDs = new int[3] { 584, 585, 586 };

	private int[] effectPicIDs = new int[3] { 608, 599, 652 };

	private int gotEffectPicIDs = 651;

	public int TestID;

	private static AccumulativeLoginAwardPanel _instance;

	private GameObject _gotEffect;

	private GameObject _getRewardEffect;

	public static AccumulativeLoginAwardPanel Instance => _instance;

	private void Awake()
	{
		_instance = this;
		InitData();
		InitPanel();
		InitLabel();
	}

	private void Start()
	{
		UpdatePanel();
	}

	public void InitLabel()
	{
		Day1Label.text = CommonTools.GetDictString("activity_reward_day_1");
		Day2Label.text = CommonTools.GetDictString("activity_reward_day_2");
		Day3Label.text = CommonTools.GetDictString("activity_reward_day_3");
		NoteLabel.text = CommonTools.GetDictString("activity_reward_notice");
		ItemList[0].Label1.text = string.Format(CommonTools.GetDictString("activity_reward_style"), _rewardList[0].reward1_count);
		ItemList[1].Label1.text = string.Format(CommonTools.GetDictString("activity_reward_style"), _rewardList[1].reward1_count);
		ItemList[2].Label1.text = CommonTools.GetDictString("activity_reward_slot");
		ItemList[2].Label2.text = string.Format(CommonTools.GetDictString("activity_reward_style"), CommonTools.GetDictString(GameManager.TableMgr.GetVehicle(_rewardList[2].reward2_ID).name));
		UILabel vIPLabel = ItemList[0].VIPLabel;
		string dictString = CommonTools.GetDictString("activity_reward_vip_1");
		ItemList[2].VIPLabel.text = dictString;
		dictString = dictString;
		ItemList[1].VIPLabel.text = dictString;
		vIPLabel.text = dictString;
	}

	public void InitData()
	{
		_rewardList.Add(GameManager.TableMgr.GetReward(125));
		_rewardList.Add(GameManager.TableMgr.GetReward(126));
		_rewardList.Add(GameManager.TableMgr.GetReward(127));
	}

	public void InitPanel()
	{
		Vector3 localPosition = ProcessStatePrefab.transform.localPosition;
		for (int i = 0; i < 3; i++)
		{
			AccumulativeItemControl accumulativeItemControl = ItemList[i];
			accumulativeItemControl.CanClick = false;
			accumulativeItemControl.Reward = _rewardList[i];
			accumulativeItemControl.PicID = picIDs[i];
			accumulativeItemControl.ID = (byte)(i + 1);
			_itemList.Add(accumulativeItemControl);
			ProcessStateControl processStateControl = Object.Instantiate(ProcessStatePrefab);
			processStateControl.transform.parent = StateItemsListTrans;
			processStateControl.transform.localPosition = new Vector3(localPosition.x + (float)(i * 288), localPosition.y, localPosition.z);
			processStateControl.transform.localScale = Vector3.one;
			_stateItemList.Add(processStateControl);
		}
	}

	public void OnGetAwardBtnClickHandler(AccumulativeItemControl item)
	{
		GameManager.Hall.SendNewGuideGetReward(item.ID);
	}

	public void UpdatePanel()
	{
		if (data.data == null)
		{
			return;
		}
		if (data.LastestGetedItem(out var itemID))
		{
			LoadRewardIcon(itemID);
			LoadGotEffect(itemID);
		}
		if (ProcessList.Count == 2)
		{
			ProcessList[0].SetActive(data.data.LoginDays > 1 || data.data.Rewards[0] == 1);
			ProcessList[1].SetActive(data.data.LoginDays > 2 || data.data.Rewards[1] == 1);
		}
		for (int i = 0; i < _stateItemList.Count; i++)
		{
			if (i < data.data.LoginDays - 1)
			{
				_stateItemList[i].State = EnumLoginAwardPS.DONE;
			}
			else if (i == data.data.LoginDays - 1)
			{
				_stateItemList[i].State = EnumLoginAwardPS.REACH;
			}
			else
			{
				_stateItemList[i].State = EnumLoginAwardPS.UNREACH;
			}
		}
		for (int j = 0; j < _itemList.Count; j++)
		{
			if (j > data.data.LoginDays - 1)
			{
				_itemList[j].ButtonType = LoginAwardBtnType.NONE;
			}
			else if (data.data.Rewards[j] == 0)
			{
				_itemList[j].ButtonType = LoginAwardBtnType.DOING;
			}
			else if (data.data.Rewards[j] == 1)
			{
				_itemList[j].ButtonType = LoginAwardBtnType.DONE;
				LoadGotIcon(j);
			}
		}
	}

	public void LoadRewardIcon(int rewardId)
	{
		ResourcesManager.Instance.Retrieve(effectPicIDs[rewardId], ResourceType.Texture, GameManager.IsHallLevel, delegate(Object r)
		{
			if (_getRewardEffect != null)
			{
				Object.Destroy(_getRewardEffect);
			}
			_getRewardEffect = GUITools.PlayParticleOnUi(327, base.transform, new Vector3(0f, 0f, 0f), new Vector3(1f, 1f, 1f), Quaternion.identity, destroySelf: true, delegate(Object o)
			{
				PlayGetRewardEffect((GameObject)o, r as Texture);
			});
		});
	}

	private void LoadGotIcon(int rewardId)
	{
		UITexture texture = _itemList[rewardId].GotIcon;
		if (texture.material == null)
		{
			ResourcesManager.Instance.RetrieveUIMaterial(gotEffectPicIDs, texture, delegate
			{
				texture.transform.Rotate(Vector3.forward * 23f);
			});
		}
	}

	private void LoadGotEffect(int rewardId)
	{
		if (_gotEffect != null)
		{
			Object.Destroy(_gotEffect);
		}
		_gotEffect = GUITools.PlayParticleOnUi(330, base.transform, new Vector3(0f, 0f, 0f), new Vector3(1f, 1f, 1f), Quaternion.identity, destroySelf: true, delegate(Object o)
		{
			if (o != null)
			{
				PlayGotEffect((GameObject)o, rewardId);
			}
		});
	}

	private void PlayGetRewardEffect(GameObject go, Texture icon)
	{
		if (!(go == null))
		{
			MedalEffectHelp componentInChildren = go.GetComponentInChildren<MedalEffectHelp>();
			if (componentInChildren != null)
			{
				componentInChildren.UpdateMedalMaterTexture(icon);
				go.transform.localPosition = new Vector3(0f, 128f, 0f);
			}
			else
			{
				TKLog.LogWarning("MedalEffectHelp is null in PlayGetRewardEffect");
			}
		}
	}

	private void PlayGotEffect(GameObject go, int id)
	{
		if (_gotEffect != null)
		{
			_gotEffect.AddComponent<TimedObjectDestructor>().Time = 3f;
			GUITools.SetParent(_itemList[id].transform, go.transform.parent, isTransform: true);
			go.transform.parent.localPosition += new Vector3(0f, 0f, -10f);
			go.transform.parent.localScale = new Vector3(1.8f, 1.8f, 1.8f);
		}
	}

	public void BeforeClosed()
	{
		if (_gotEffect != null)
		{
			Object.Destroy(_gotEffect);
		}
		if (_getRewardEffect != null)
		{
			Object.Destroy(_getRewardEffect);
		}
	}
}
