using UnityEngine;

public class ArrowHeadEnd
{
	public Vector2 Head;

	public Vector2 End;
}
