using ClientSocket;

public class AccProItemForPVE : AccProItem
{
	public int TotalKill;

	public int MaxKillOneBattle;

	public int TotalScore;

	public int MaxScoreOneBattle;

	public int TotalExp;

	public int MaxExpOneBattle;

	public string AverageKill => ((BattleCount != 0) ? ((float)TotalKill / (float)BattleCount) : 0f).ToString("0.00");

	public string AverageScore => ((BattleCount != 0) ? ((float)TotalScore / (float)BattleCount) : 0f).ToString("0.00");

	public string AverageExp => ((BattleCount != 0) ? ((float)TotalExp / (float)BattleCount) : 0f).ToString("0.00");

	public void ReadByte(ByteArray ba)
	{
		VehicleId = ba.ReadInt();
		BattleCount = ba.ReadInt();
		WinCount = ba.ReadInt();
		TotalKill = ba.ReadInt();
		MaxKillOneBattle = ba.ReadInt();
		TotalScore = ba.ReadInt();
		MaxScoreOneBattle = ba.ReadInt();
		TotalExp = ba.ReadInt();
		MaxExpOneBattle = ba.ReadInt();
	}
}
