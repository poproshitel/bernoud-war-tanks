public enum AimSightBaseSize
{
	Third,
	First0,
	First1,
	First2
}
