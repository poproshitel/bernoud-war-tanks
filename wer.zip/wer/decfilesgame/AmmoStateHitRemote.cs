using SceneCameraStruct;

public class AmmoStateHitRemote : AmmoStateBase
{
	private AmmoStateType _tempNextStateType;

	public AmmoStateHitRemote()
	{
		_tempNextStateType = AmmoStateType.Invaid;
	}

	public override void EnterState(CAmmoStateParam param)
	{
		param.CurState = AmmoStateType.HitRemote;
		if (CameraManager.Instance.CameraState == CameraState.First)
		{
			_tempNextStateType = AmmoStateType.Bomb;
			return;
		}
		switch (param.Ammo.ShootRes)
		{
		case ShootResult.JumpBullet:
			_tempNextStateType = AmmoStateType.Jump;
			break;
		case ShootResult.Fail:
			_tempNextStateType = AmmoStateType.Jump;
			break;
		default:
			_tempNextStateType = AmmoStateType.Bomb;
			break;
		}
	}

	public override bool UpdateState(CAmmoStateParam param)
	{
		return true;
	}

	public override void LeaveState(CAmmoStateParam param, ref AmmoStateType nextstate)
	{
		Singleton<AmmoEvnet>.Instance.OnEvent(AmmoStateType.HitRemote, param);
		nextstate = _tempNextStateType;
	}
}
