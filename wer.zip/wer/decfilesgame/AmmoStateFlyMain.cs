using UnityEngine;

public class AmmoStateFlyMain : AmmoStateBase
{
	private AmmoStateType _tempNextStateType;

	public override void EnterState(CAmmoStateParam param)
	{
		_tempNextStateType = AmmoStateType.Invaid;
		param.CurState = AmmoStateType.FlyMain;
	}

	public override bool UpdateState(CAmmoStateParam param)
	{
		if (param.HitPath == null || param.AmmoPath == null)
		{
			return false;
		}
		param.LiveTime += Time.fixedDeltaTime;
		param.NextHitCheckPositon = param.HitPath.GetPositionByTime(param.LiveTime);
		if (param.LiveTime <= param.AmmoPath.HitNeedTime)
		{
			param.NextPostion = param.AmmoPath.GetPositionByTime(param.LiveTime);
		}
		else
		{
			param.NextPostion = param.NextHitCheckPositon;
		}
		if (AmmoTools.CheckHit(param.CurHitCheckPosition, param.NextHitCheckPositon, out param.HitInfo))
		{
			param.Ammo.ProcessAmmoHit(param.HitInfo);
			param.Trans.position = param.HitInfo.point;
			_tempNextStateType = AmmoStateType.HitMain;
			return true;
		}
		if (param.Ammo.OverMaxDistance(param.NextHitCheckPositon))
		{
			_tempNextStateType = AmmoStateType.Bomb;
			return true;
		}
		param.AccmulateDisplacement += (param.NextPostion - param.Trans.position).magnitude;
		if (param.AccmulateDisplacement > 10f && !param.AmmoEntity.gameObject.activeSelf)
		{
			param.AmmoEntity.gameObject.SetActive(value: true);
		}
		param.Trans.position = param.NextPostion;
		param.CurHitCheckPosition = param.NextHitCheckPositon;
		return false;
	}

	public override void LeaveState(CAmmoStateParam param, ref AmmoStateType nextstate)
	{
		nextstate = _tempNextStateType;
	}
}
