using UnityEngine;

public class AmmoStateFlyRemoteReach : AmmoStateBase
{
	private AmmoStateType _tempNextStateType;

	public AmmoStateFlyRemoteReach()
	{
		_tempNextStateType = AmmoStateType.Invaid;
	}

	public override void EnterState(CAmmoStateParam param)
	{
		param.CurState = AmmoStateType.FlyRemoteHitpacketReachedFly;
	}

	public override bool UpdateState(CAmmoStateParam param)
	{
		if (param.Ammo.HasTouchDown)
		{
			if (param.Ammo.OverRealHitPosition(param.Trans.position))
			{
				param.HasReadyDestory = true;
				_tempNextStateType = AmmoStateType.HitRemote;
				return true;
			}
			Vector3 realHitWorldPosition = param.Ammo.GetRealHitWorldPosition();
			param.Trans.position = Util.ConstantLerp(param.Trans.position, realHitWorldPosition, (float)param.Ammo.TableShell.ammo_speed * Time.fixedDeltaTime);
			if (param.Trans.position == realHitWorldPosition)
			{
				_tempNextStateType = AmmoStateType.HitRemote;
				return true;
			}
		}
		return false;
	}

	public override void LeaveState(CAmmoStateParam param, ref AmmoStateType nextstate)
	{
		nextstate = _tempNextStateType;
	}
}
