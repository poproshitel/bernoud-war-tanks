public enum AddMode
{
	Add2Target,
	Add2Other
}
