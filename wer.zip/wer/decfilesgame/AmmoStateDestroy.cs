public class AmmoStateDestroy : AmmoStateBase
{
	public override void EnterState(CAmmoStateParam param)
	{
		param.HasReadyDestory = true;
	}

	public override bool UpdateState(CAmmoStateParam param)
	{
		return true;
	}

	public override void LeaveState(CAmmoStateParam param, ref AmmoStateType nextstate)
	{
		nextstate = AmmoStateType.Invaid;
	}
}
