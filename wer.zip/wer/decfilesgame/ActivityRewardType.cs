public enum ActivityRewardType
{
	None,
	TankExp,
	TankSilver,
	PlayerExp,
	Max
}
