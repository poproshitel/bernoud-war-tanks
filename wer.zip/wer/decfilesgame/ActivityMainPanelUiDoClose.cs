public delegate void ActivityMainPanelUiDoClose(bool isShow);
