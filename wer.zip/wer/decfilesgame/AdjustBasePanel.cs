using System.Collections.Generic;
using UnityEngine;

public class AdjustBasePanel : ActivityRightSubBasePanel
{
	public AdjustBaseItem AdjustBaseItemObj;

	public PanelAndScollBarVertical PanelAndScollBarVertical;

	public UITexture BgTexture;

	protected float[] LocalPositionX;

	protected List<AdjustBaseItem.Data> TitleDataList = new List<AdjustBaseItem.Data>();

	protected List<List<AdjustBaseItem.Data>> ItemDataList = new List<List<AdjustBaseItem.Data>>();

	protected const int PosYOffset = 18;

	protected const int LocalPositionY = 0;

	protected const int LocalPositionZ = -8;

	protected const float TiletLocalPosX = -479f;

	protected const float TitleLocalPosY = 127f;

	protected virtual void Awake()
	{
		ShowPageLocalPositon = new Vector3(-294f, -240f, -1f);
		BgTexture.pivot = UIWidget.Pivot.TopLeft;
		ResourcesManager.Instance.RetrieveUIMaterial(2427, BgTexture);
	}

	public override void Open()
	{
		base.Open();
		base.transform.localPosition = ShowPageLocalPositon;
	}

	public override void Close()
	{
		base.Close();
		base.transform.localPosition = HidePageLocalPositon;
	}

	public override void Load()
	{
		base.Load();
		LoadOverCallback();
	}

	protected void DestroyChildren()
	{
		AdjustBaseItem[] componentsInChildren = PanelAndScollBarVertical.transform.GetComponentsInChildren<AdjustBaseItem>();
		for (int num = componentsInChildren.Length - 1; num >= 0; num--)
		{
			Object.DestroyObject(componentsInChildren[num].gameObject);
		}
	}

	protected virtual void Start()
	{
		SetTableT();
		PanelAndScollBarVertical.CurUsedScrollBar.scrollValue = 0f;
	}

	protected AdjustBaseItem.Data CreateAdjustBaseItemData(string text, int index)
	{
		AdjustBaseItem.Data data = new AdjustBaseItem.Data();
		data.Text = text;
		data.Position = GetVec3(index);
		return data;
	}

	protected Vector3 GetVec3(int index)
	{
		return new Vector3(LocalPositionX[index], 0f, -8f);
	}

	protected void SetUiScrollBarForeAlpha()
	{
		UIScrollBar curUsedScrollBar = PanelAndScollBarVertical.CurUsedScrollBar;
		curUsedScrollBar.ForeAlpha = ((!curUsedScrollBar.barSize.Equals(1f)) ? 1f : 0f);
	}

	protected void CreateScrollList()
	{
		int num = 0;
		foreach (List<AdjustBaseItem.Data> itemData in ItemDataList)
		{
			AdjustBaseItem adjustBaseItem = CreatAdjustBaseItem(PanelAndScollBarVertical.transform);
			adjustBaseItem.SetData(itemData, num, AdjustBaseItem.TextStyle.Content);
			num -= 18;
		}
	}

	private void SetTableT()
	{
		AdjustBaseItem adjustBaseItem = CreatTitle(base.transform);
		adjustBaseItem.SetData(TitleDataList, -479f, 127f, AdjustBaseItem.TextStyle.Title);
	}

	protected AdjustBaseItem CreatTitle(Transform parent)
	{
		return CreatAdjustBaseItem(parent);
	}

	protected string GetPercentageString(string str)
	{
		if (double.TryParse(str, out var result))
		{
			return $"{(double)(int)(result * 10000.0) / 100.0:F2}%";
		}
		return str;
	}

	protected AdjustBaseItem CreatAdjustBaseItem(Transform parent)
	{
		GameObject gameObject = Object.Instantiate(AdjustBaseItemObj.gameObject);
		gameObject.transform.parent = parent;
		gameObject.transform.localScale = Vector3.one;
		return gameObject.GetComponent<AdjustBaseItem>();
	}
}
