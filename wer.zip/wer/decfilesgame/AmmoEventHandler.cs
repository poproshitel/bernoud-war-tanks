public interface AmmoEventHandler
{
	void OnEvent(CAmmoStateParam info);
}
