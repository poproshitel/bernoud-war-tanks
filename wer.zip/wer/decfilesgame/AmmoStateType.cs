public enum AmmoStateType
{
	Invaid,
	FlyMain,
	FlyRemoteHitpacketUnreachedFly,
	FlyRemoteHitpacketReachedFly,
	HitMain,
	HitRemote,
	Jump,
	HitError,
	Bomb,
	Destroy
}
