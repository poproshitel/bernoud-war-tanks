using UnityEngine;

public class AllSlotsManager : MonoBehaviour
{
	public UILabel ShellInfoLabel;

	public UILabel StorageLabel;

	public UILabel PriceLabel;

	public UILabel NumLabel;

	public GameObject BuyButton;

	public SlotScrollPanle SlotScrollPanleScript;

	private Transform _transform;

	public int CurSelectID;

	private GameTableMgr _tableMgr => GameManager.TableMgr;

	private void Start()
	{
		ShellInfoLabel.text = _tableMgr.GetDirString("ammunition_head_shellinfo").value;
		StorageLabel.text = _tableMgr.GetDirString("ammunition_head_shellcount").value;
		PriceLabel.text = _tableMgr.GetDirString("ammunition_head_shellprice").value;
		NumLabel.text = _tableMgr.GetDirString("ammunition_head_shellbuycount").value;
	}

	public void Init(int[] shellIDs)
	{
		_transform = base.transform;
		if (BuyButton != null)
		{
			BuyButton.GetComponentInChildren<UILabel>().text = GameManager.TableMgr.GetDirString("UI_common_button_buy").value;
		}
		SlotScrollPanleScript.Init(shellIDs);
	}

	public void BuyShells()
	{
		SlotScrollPanleScript.BuyShells();
	}

	public void OnClick(GameObject go)
	{
		SlotInfos component = go.transform.parent.GetComponent<SlotInfos>();
		if (component == null)
		{
			TKLog.LogError("error,dosn't have slotinfo");
		}
		SlotInfoBar slotInfoBar = CurSlotInfoBar();
		if (slotInfoBar != null)
		{
			slotInfoBar.slotInfosScript.SetHighted(flag: false);
		}
		CurSelectID = component.ShellID;
		component.SetHighted(flag: true);
	}

	public SlotInfoBar CurSlotInfoBar()
	{
		if (CurSelectID <= 0)
		{
			return null;
		}
		return SlotScrollPanleScript.GetInfoBar(CurSelectID);
	}
}
