using UnityEngine;

public class AdjustButtonPosHelperForTroopsWar : AdjustButtonPosHelper
{
	public Vector3 Condition2Pos;

	public override bool XFlagExpand()
	{
		if (LeftTransform.localPosition.y == RightTransform.localPosition.y)
		{
			return true;
		}
		return false;
	}

	public override void OnChangeScreenHandle()
	{
		if (XFlag > 0f)
		{
			if (LeftTransform.localPosition.x - RightTransform.localPosition.x >= XFlag && XFlagExpand())
			{
				TargetTransform.localPosition = NewPosTransform.localPosition + AdjustPos;
			}
			else if (LeftTransform.localPosition.x - RightTransform.localPosition.x >= XFlag && !XFlagExpand())
			{
				TargetTransform.localPosition = LastPos;
			}
			else
			{
				TargetTransform.localPosition = Condition2Pos;
			}
		}
		else if (!(YFlag > 0f))
		{
		}
	}
}
