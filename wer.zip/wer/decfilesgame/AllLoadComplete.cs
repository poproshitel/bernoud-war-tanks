using System;

[Serializable]
public delegate void AllLoadComplete(int path, object go);
