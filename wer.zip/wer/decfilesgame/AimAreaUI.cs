using System;
using System.Collections.Generic;
using TK;
using UnityEngine;

public class AimAreaUI : UIBase
{
	private float _aimUIDisplayMultiple;

	public UISprite AimCenter;

	private int _baseSize = 8;

	private bool _visible;

	private bool _visibleChanged = true;

	public AimingCenterCircle AimingCenterCircle;

	private bool _cameraChanged;

	private float _maxCdTime;

	private float _cdTime;

	private Sight _sight;

	private Transform _cachedTransform;

	private Queue<Vector3> _queueTargetPos = new Queue<Vector3>();

	private Queue<float> _queueDistance = new Queue<float>();

	private static Vector3 HLP_VECTOR3 = default(Vector3);

	private Action OnClipRechargingComplete;

	private float _reloadTimeStart;

	public float CdTime
	{
		get
		{
			return _cdTime;
		}
		set
		{
			_cdTime = value;
			RoomGUIManager.Instance.Get<SightUI>().TotalReloadTime = value;
		}
	}

	public Sight Sight => _sight;

	public float GetAimValue => AimingCenterCircle.ScaleModule;

	private void Awake()
	{
		_cachedTransform = base.transform;
	}

	public override void Init()
	{
		AimingCenterCircle.ShowOrHide(show: false);
		AimCenter.gameObject.SetActive(value: false);
		if (!ReadConfig.TryGetValue("physics_system", "diffuse_multiple", out _aimUIDisplayMultiple))
		{
			_aimUIDisplayMultiple = 1f;
		}
	}

	public void ChangeBullet(bool fastChangeShell)
	{
		ERoomState eRoomState = SceneRoom.Instance.GetRoom().ERoomState;
		if (eRoomState >= ERoomState.Fighting && (!fastChangeShell || (_reloadTimeStart == -1f && !GunSync.FireSuccess)))
		{
			UpdateReloadAmmoUI();
		}
	}

	public void ReSet(bool isDead)
	{
		if (isDead)
		{
			ShowOrHide(show: false);
			AimingCenterCircle.ShowOrHide(show: false);
			AimCenter.gameObject.SetActive(value: false);
			RoomGUIManager.Instance.Get<ControlShellProvisionPosition>().TankCannonballOperation.SetNoUse();
			RoomGUIManager.Instance.Get<ControlShellProvisionPosition>().TankCannonballOperation.MainPlayerDead = true;
		}
		else
		{
			ShowOrHide(show: true);
			AimingCenterCircle.ShowOrHide(show: true);
			AimCenter.gameObject.SetActive(value: true);
			_sight.CurDispersionFactor = 1f;
			RoomGUIManager.Instance.Get<ControlShellProvisionPosition>().TankCannonballOperation.MainPlayerDead = false;
			UpdateReloadAmmoUI();
		}
	}

	public void StartFight()
	{
		_sight.CurDispersionFactor = 1f;
		ShowOrHide(show: true);
	}

	private void OnGunReloadComplete()
	{
		GunSync.FireSuccess = true;
		_reloadTimeStart = -1f;
		RoomGUIManager.Instance.Get<ControlShellProvisionPosition>().TankCannonballOperation.SetLoadComplete();
		AimingCenterCircle.FillAcount = 1f;
		SceneToGUI.UpdateSightUIAmmo(1f);
		if (OnClipRechargingComplete != null)
		{
			OnClipRechargingComplete();
			OnClipRechargingComplete = null;
		}
	}

	public void InitSight(Tank tank)
	{
		if (_sight == null)
		{
			_sight = new Sight();
		}
		_sight.InitSight(tank);
		TankProperty attributeContainer = tank.AttributeContainer;
		_cdTime = (_maxCdTime = attributeContainer.GetValue(EqAttributeType.EReloadTime));
		if (Math.Abs(_maxCdTime) < float.Epsilon)
		{
			_cdTime = 5f;
			TKLog.LogError("cd  is  0~~~~");
		}
		RoomGUIManager.Instance.Get<SightUI>().TotalReloadTime = _cdTime;
		RoomGUIManager.Instance.Get<SightUI>().InitSight(_sight);
	}

	public void UpdateSight(Vector3 targetPos, float distance)
	{
		if (_visibleChanged)
		{
			_visibleChanged = false;
			if (!_visible)
			{
				HLP_VECTOR3.Set(0f, 0f, 10000f);
				_cachedTransform.localPosition = HLP_VECTOR3;
				return;
			}
		}
		_queueTargetPos.Enqueue(targetPos);
		_queueDistance.Enqueue(distance);
		int num = _queueTargetPos.Count;
		if (num > 5)
		{
			_queueTargetPos.Dequeue();
			_queueDistance.Dequeue();
			num--;
		}
		HLP_VECTOR3.Set(0f, 0f, 0f);
		foreach (Vector3 queueTargetPo in _queueTargetPos)
		{
			HLP_VECTOR3.Set(HLP_VECTOR3.x + queueTargetPo.x, HLP_VECTOR3.y + queueTargetPo.y, HLP_VECTOR3.z + queueTargetPo.z);
		}
		HLP_VECTOR3.Set(HLP_VECTOR3.x / (float)num, HLP_VECTOR3.y / (float)num, HLP_VECTOR3.z / (float)num);
		distance = 0f;
		foreach (float item in _queueDistance)
		{
			float num2 = item;
			distance += num2;
		}
		distance /= (float)num;
		Vector3 vector = Camera.main.WorldToScreenPoint(HLP_VECTOR3);
		_sight.UpdateSight();
		if (vector.z >= 0f)
		{
			float num3 = _sight.CurIdealRadiusRad * distance;
			Vector3 vector2 = Camera.main.transform.up * num3;
			HLP_VECTOR3.Set(HLP_VECTOR3.x + vector2.x, HLP_VECTOR3.y + vector2.y, HLP_VECTOR3.z + vector2.z);
			Vector3 vector3 = Camera.main.WorldToScreenPoint(HLP_VECTOR3);
			AimingCenterCircle.ScaleModule = (vector3.y - vector.y + (float)_baseSize) * _aimUIDisplayMultiple;
			if (!AimCenter.gameObject.activeSelf)
			{
				AimCenter.gameObject.SetActive(value: true);
				AimingCenterCircle.ShowOrHide(show: true);
			}
			HLP_VECTOR3.Set(vector.x - (float)Screen.width * 0.5f, vector.y - (float)Screen.height * 0.5f, 0f);
			_cachedTransform.localPosition = HLP_VECTOR3;
		}
		else
		{
			AimCenter.gameObject.SetActive(value: false);
			AimingCenterCircle.ShowOrHide(show: false);
		}
	}

	internal void OnFireUI(bool autoFill = true, bool fullClipReload = false, float newCd = -1f, Action callback = null)
	{
		if (callback != null)
		{
			OnClipRechargingComplete = callback;
		}
		if (newCd > -1f)
		{
			CdTime = newCd;
		}
		TankCannonballOperation tankCannonballOperation = RoomGUIManager.Instance.Get<ControlShellProvisionPosition>().TankCannonballOperation;
		if (fullClipReload && tankCannonballOperation.ShellSelectedButNotInUse())
		{
			_reloadTimeStart = -1f;
			GunSync.FireSuccess = false;
			tankCannonballOperation.ForceSelectChoosenShells();
		}
		else
		{
			UpdateReloadAmmoUI(autoFill);
		}
	}

	internal float OnFire()
	{
		return _sight.OnFire();
	}

	public void UpdateReloadAmmoUI(bool autoFill = true)
	{
		TankCannonballOperation tankCannonballOperation = RoomGUIManager.Instance.Get<ControlShellProvisionPosition>().TankCannonballOperation;
		StopReloadAmmo();
		AimingCenterCircle.FillAcount = 0f;
		SceneToGUI.UpdateSightUIAmmo(0f);
		tankCannonballOperation.SetNoUse();
		GunSync.FireSuccess = false;
		if (autoFill)
		{
			if (IsHaveShell())
			{
				_reloadTimeStart = Time.time;
				tankCannonballOperation.CanControl = true;
			}
			else
			{
				tankCannonballOperation.CanControl = false;
			}
		}
	}

	public void ReloadAmmoImmediately()
	{
		OnGunReloadComplete();
		GUIToScene.SyncReliveClipCountFull();
	}

	private void Update()
	{
		if (_reloadTimeStart > -1f)
		{
			float num = Time.time - _reloadTimeStart;
			float num2 = Mathf.Min(num / _cdTime, 1f);
			AimingCenterCircle.FillAcount = num2;
			SceneToGUI.UpdateSightUIAmmo(num2);
			if (num2 == 1f)
			{
				OnGunReloadComplete();
			}
		}
	}

	public void StopReloadAmmo()
	{
	}

	private bool IsHaveShell()
	{
		return SceneRoom.Instance.GetRoom().GetMainPlayer().GetMainPlayerCurrentShell()
			.Count > 0;
	}

	public void ShowOrHide(bool show)
	{
		if (_visible != show)
		{
			_visibleChanged = true;
			_visible = show;
		}
	}
}
