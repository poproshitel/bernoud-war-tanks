using System.Collections.Generic;
using UnityEngine;

public class ActivityCenterManager : ActivityRightSubBasePanel
{
	public Transform ButtonsParentNode;

	public ActivityCenterButton ButtonPrefab;

	public UITexture DisplayPic;

	public BaseActivityTemplate[] Templates;

	public int ImageWidth;

	public int ImageHeight;

	public Vector3 ShowPosition;

	public Vector3 ButtonStartPosition;

	private int _curActivityID = -1;

	private Dictionary<EnumActivityCenterTemplate, BaseActivityTemplate> _templateDic = new Dictionary<EnumActivityCenterTemplate, BaseActivityTemplate>();

	private ActivityCenterModel _curActivity;

	private List<ActivityCenterButton> _activityButtons = new List<ActivityCenterButton>();

	private ActivityCenterDataManager data = Singleton<ActivityCenterDataManager>.Instance;

	private void Awake()
	{
		InitTemplates();
		InitButton();
	}

	private void InitTemplates()
	{
		BaseActivityTemplate[] templates = Templates;
		foreach (BaseActivityTemplate baseActivityTemplate in templates)
		{
			if (_templateDic.ContainsKey(baseActivityTemplate.Type))
			{
				Debug.Log("Activity Template is duplicated");
			}
			else
			{
				_templateDic.Add(baseActivityTemplate.Type, baseActivityTemplate);
			}
		}
	}

	public void InitButton()
	{
		foreach (ActivityCenterButton activityButton in _activityButtons)
		{
			if (activityButton != null)
			{
				Object.Destroy(activityButton.gameObject);
			}
		}
		_activityButtons = new List<ActivityCenterButton>();
		for (int num = Mathf.Min(data.ActivityIngList.Count, data.MaxActivityNum); num > 0; num--)
		{
			ActivityCenterButton activityCenterButton = Object.Instantiate(ButtonPrefab);
			activityCenterButton.Init(data.ActivityIngList[num - 1], this, num);
			activityCenterButton.CachedTransform.parent = ButtonsParentNode;
			activityCenterButton.Root = ButtonsParentNode;
			activityCenterButton.CachedTransform.localPosition = ButtonStartPosition;
			activityCenterButton.CachedTransform.localScale = Vector3.one;
			Vector3 localPosition = activityCenterButton.CachedTransform.localPosition;
			activityCenterButton.CachedTransform.localPosition = new Vector3(localPosition.x - (float)((data.ActivityIngList.Count - num) * 50), localPosition.y, localPosition.z);
			if (num == 1)
			{
				activityCenterButton.OnPress(flag: true);
			}
			_activityButtons.Add(activityCenterButton);
		}
	}

	public override void Load()
	{
		if (LoadOverCallback != null)
		{
			LoadOverCallback();
		}
	}

	public override void Open()
	{
		BeforeOpen();
		base.gameObject.transform.localPosition = ShowPosition;
	}

	public override void Close()
	{
		base.gameObject.transform.localPosition += Vector3.down * 2000f;
	}

	public void ChangeActivity(ActivityCenterModel activityModel)
	{
		if (!_templateDic.TryGetValue(activityModel.TemplateType, out var value))
		{
			return;
		}
		if (_curActivity != null)
		{
			if (_curActivity == activityModel)
			{
				return;
			}
			if (_curActivity.TemplateType != activityModel.TemplateType && _templateDic.TryGetValue(_curActivity.TemplateType, out var value2))
			{
				value2.ShowOrHide(flag: false);
			}
		}
		ResourcesManager.Instance.RetrieveUIMaterial(activityModel.PicID, DisplayPic);
		DisplayPic.transform.localScale = new Vector3(ImageWidth, ImageHeight, 1f);
		HotActivityState value3;
		if (activityModel.TemplateType == EnumActivityCenterTemplate.Common)
		{
			value.UpdatePanel(activityModel.CommonActivityData);
		}
		else if (data.ActivityStateDic.TryGetValue(activityModel.Type, out value3) && value3.MakeAsChanged)
		{
			value.UpdatePanel(null);
			value3.MakeAsChanged = false;
		}
		value.ShowOrHide(flag: true);
		_curActivity = activityModel;
	}

	public void BeforeOpen()
	{
		if (data.StateChanged)
		{
			InitButton();
			data.StateChanged = false;
		}
	}

	public void OnClickPicHandler()
	{
	}
}
