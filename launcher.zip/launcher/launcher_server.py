#!/usr/bin/env python3
"""
Ground War Tanks - Launcher (each player runs their OWN copy).

No PowerShell involved anywhere — pure Python does the file writing and the
game launch. On first run you set the server address and your game folder
once; after that it's just login/register -> Играть.

Talks to the server's AuthServer (port 18080) for:
  login_check.action / register.action   - auth
  news_list.action / news_add.action / news_delete.action - news (add/delete = admin only)
  admin_players.action / admin_ban.action / admin_credit.action - admin panel
"""
import json
import subprocess
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONFIG_FILE = HERE / "launcher_config.json"
PORT = 8765

CLIENT_CONFIG_TEMPLATE = """;;-----------------------------------------------------
;;Client configuration
;;Platform:gamebox/mailru
;;-----------------------------------------------------
[Platform]
Platform=mailru

[GameServer]
GameIP={ip}
Port=9801

[AssetServer]
AssetIP={ip}:18081

[StatisticalServer]
;;StatisticalIP=http://prod.tanks.mail.ru/pub/client_log.php

[AuthorizeServer]
AuthorizeIP=http://{ip}:18080

[RechargeServer]
RechargeIP=http://tanks.mail.ru/user/bank
"""



def load_config():
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_config(cfg):
    CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def auth_base(cfg):
    ip = (cfg.get("server_ip") or "").strip()
    return f"http://{ip}:18080" if ip else None


def call_server(url):
    """GET url, return parsed JSON, or {'ok': False, 'error': '...'} on failure."""
    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        return {"ok": False, "error": f"server_unreachable: {e}"}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _json(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path, content_type):
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _body_json(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b""
        try:
            return json.loads(raw or b"{}")
        except Exception:
            return {}

    # ---------------- GET ----------------
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        cfg = load_config()

        if path in ("/", "/index.html"):
            self._file(HERE / "index.html", "text/html; charset=utf-8")

        elif path == "/api/state":
            self._json({
                "configured": bool(cfg.get("server_ip") and cfg.get("game_path")),
                "server_ip": cfg.get("server_ip", ""),
                "game_path": cfg.get("game_path", ""),
                "session": cfg.get("session"),
            })

        elif path == "/api/news":
            base = auth_base(cfg)
            if not base:
                self._json({"ok": False, "error": "not_configured"}); return
            self._json(call_server(f"{base}/TK/news_list.action"))

        elif path == "/api/admin/players":
            base = auth_base(cfg)
            sess = cfg.get("session")
            if not base or not sess or not sess.get("password"):
                self._json({"ok": False, "error": "not_logged_in"}); return
            url = (f"{base}/TK/admin_players.action?"
                   f"adminNickname={urllib.parse.quote(sess['nickname'])}"
                   f"&adminPassword={urllib.parse.quote(sess['password'])}")
            self._json(call_server(url))

        else:
            self.send_error(404)

    # ---------------- POST ----------------
    def do_POST(self):
        data = self._body_json()
        cfg = load_config()

        if self.path == "/api/setup":
            ip = (data.get("server_ip") or "").strip()
            game_path = (data.get("game_path") or "").strip()
            if not ip:
                self._json({"ok": False, "error": "empty_ip"}); return
            gp = Path(game_path)
            if not gp.exists():
                self._json({"ok": False, "error": "path_not_found"}); return
            if not (gp / "Tank.exe").exists():
                self._json({"ok": False, "error": "tank_exe_not_found"}); return
            cfg["server_ip"] = ip
            cfg["game_path"] = str(gp)
            save_config(cfg)
            self._json({"ok": True})

        elif self.path == "/api/register":
            base = auth_base(cfg)
            if not base:
                self._json({"ok": False, "error": "not_configured"}); return
            nickname = (data.get("nickname") or "").strip()
            password = data.get("password") or ""
            url = (f"{base}/TK/register.action?"
                   f"nickname={urllib.parse.quote(nickname)}&password={urllib.parse.quote(password)}")
            result = call_server(url)
            if result.get("ok"):
                self._finish_login(cfg, result, password)
            self._json(result)

        elif self.path == "/api/login":
            base = auth_base(cfg)
            if not base:
                self._json({"ok": False, "error": "not_configured"}); return
            nickname = (data.get("nickname") or "").strip()
            password = data.get("password") or ""
            url = (f"{base}/TK/login_check.action?"
                   f"nickname={urllib.parse.quote(nickname)}&password={urllib.parse.quote(password)}")
            result = call_server(url)
            if result.get("ok"):
                self._finish_login(cfg, result, password)
            self._json(result)

        elif self.path == "/api/logout":
            cfg["session"] = None
            save_config(cfg)
            self._json({"ok": True})

        elif self.path == "/api/play":
            game_path = Path(cfg.get("game_path", ""))
            sess = cfg.get("session")
            if not str(game_path) or not game_path.exists():
                self._json({"ok": False, "error": "game_path_not_set"}); return
            if not sess:
                self._json({"ok": False, "error": "not_logged_in"}); return

            tank_exe = game_path / "Tank.exe"
            if not tank_exe.exists():
                self._json({"ok": False, "error": "tank_exe_not_found"}); return

            # v89: раньше писали start.bat и просили пользователя его же и запускать —
            # но у него игра всегда запускалась через свой ярлык, а не через наш .bat,
            # так что данные аккаунта туда просто не попадали. Теперь лаунчер запускает
            # Tank.exe САМ, с данными аккаунта прямо в командной строке — никакого
            # промежуточного файла не нужно.
            # ClientConfig.tk всё ещё нужен — из него клиент узнаёт адрес сервера
            # (IP/порты), а не из командной строки.
            try:
                (game_path / "ClientConfig.tk").write_text(
                    CLIENT_CONFIG_TEMPLATE.format(ip=cfg.get("server_ip", "")), encoding="utf-8")
            except Exception as e:
                self._json({"ok": False, "error": f"cant_write_client_config: {e}"}); return

            launch_args = (f"--sz_pers_id={sess['persId']} --sz_token=abc123 "
                            f"mpop=cookie123 soc_auth=token456 partner_id=1")
            try:
                subprocess.Popen([str(tank_exe), launch_args], cwd=str(game_path))
                self._json({"ok": True})
            except Exception as e:
                self._json({"ok": False, "error": str(e)})

        elif self.path == "/api/news/add":
            r = self._admin_call(cfg, "news_add.action", {
                "title": data.get("title", ""), "body": data.get("body", "")
            })
            self._json(r)

        elif self.path == "/api/admin/ban":
            r = self._admin_call(cfg, "admin_ban.action", {
                "targetPersId": str(data.get("targetPersId", "")),
                "banned": "1" if data.get("banned") else "0",
            })
            self._json(r)

        elif self.path == "/api/admin/credit":
            r = self._admin_call(cfg, "admin_credit.action", {
                "targetNickname": data.get("targetNickname", ""),
                "silver": str(data.get("silver", 0)),
                "gold": str(data.get("gold", 0)),
            })
            self._json(r)

        else:
            self.send_error(404)

    def do_DELETE(self):
        cfg = load_config()
        if self.path.startswith("/api/news/"):
            news_id = self.path.rsplit("/", 1)[-1]
            r = self._admin_call(cfg, "news_delete.action", {"id": news_id})
            self._json(r)
        else:
            self.send_error(404)

    # ---------------- helpers ----------------
    def _finish_login(self, cfg, result, password):
        cfg["session"] = {
            "nickname": result["nickname"],
            "persId": result["persId"],
            "isAdmin": result.get("isAdmin", False),
            "password": password,
        }
        save_config(cfg)

        game_path = Path(cfg.get("game_path", ""))
        ip = cfg.get("server_ip", "")
        if game_path and ip:
            try:
                (game_path / "ClientConfig.tk").write_text(
                    CLIENT_CONFIG_TEMPLATE.format(ip=ip), encoding="utf-8")
            except Exception as e:
                print(f"[launcher] could not write ClientConfig.tk: {e}")

    def _admin_call(self, cfg, action, params):
        base = auth_base(cfg)
        sess = cfg.get("session")
        if not base or not sess or not sess.get("password"):
            return {"ok": False, "error": "not_logged_in"}
        params["adminNickname"] = sess["nickname"]
        params["adminPassword"] = sess["password"]
        qs = "&".join(f"{k}={urllib.parse.quote(str(v))}" for k, v in params.items())
        return call_server(f"{base}/TK/{action}?{qs}")


def main():
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    url = f"http://127.0.0.1:{PORT}/"
    print(f"Launcher running at {url}")
    print("Close this window to stop the launcher.")
    webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
